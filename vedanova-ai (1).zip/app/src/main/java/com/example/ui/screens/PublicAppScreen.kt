package com.example.ui.screens

import android.Manifest
import android.content.pm.PackageManager
import android.widget.Toast
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ReportEntity
import com.example.domain.voice.LiveVoiceState
import com.example.ui.components.StatusPill
import com.example.ui.theme.*
import com.example.ui.viewmodel.ScreenDestination
import com.example.ui.viewmodel.VedaNovaViewModel
import kotlinx.coroutines.launch

@Composable
fun PublicAppScreen(viewModel: VedaNovaViewModel) {
    val messages by viewModel.publicChatMessages.collectAsStateWithLifecycle()
    val query by viewModel.publicChatQuery.collectAsStateWithLifecycle()
    val isLoading by viewModel.publicIsLoading.collectAsStateWithLifecycle()
    val publishedKnowledge by viewModel.publishedKnowledge.collectAsStateWithLifecycle()
    val clarificationOptions by viewModel.publicClarificationOptions.collectAsStateWithLifecycle()
    val lastResponse by viewModel.lastPublicResponse.collectAsStateWithLifecycle()
    val currentlySpeakingText by viewModel.currentlySpeakingText.collectAsStateWithLifecycle()
    val liveVoiceState by viewModel.liveVoiceState.collectAsStateWithLifecycle()
    val liveVoiceError by viewModel.liveVoiceError.collectAsStateWithLifecycle()

    var selectedTab by remember { mutableStateOf("CHAT") } // "CHAT", "EXPLORE"
    var showReportDialog by remember { mutableStateOf(false) }
    var showFeedbackDialog by remember { mutableStateOf(false) }
    var selectedMessageForFeedback by remember { mutableStateOf("") }
    val likedMessages = remember { mutableStateMapOf<Int, Boolean>() }

    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val listState = rememberLazyListState()
    val coroutineScope = rememberCoroutineScope()

    val micPermissionLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestPermission()
    ) { isGranted ->
        if (isGranted) {
            viewModel.triggerSingleVoiceInput()
            Toast.makeText(context, "কথা বলুন... শুনছি (Listening...)", Toast.LENGTH_SHORT).show()
        } else {
            Toast.makeText(
                context,
                "ভয়েস ইনপুটের জন্য মাইক্রোফোন পারমিশন প্রয়োজন (Microphone permission required)",
                Toast.LENGTH_LONG
            ).show()
        }
    }

    LaunchedEffect(liveVoiceError) {
        liveVoiceError?.let { err ->
            Toast.makeText(context, err, Toast.LENGTH_SHORT).show()
        }
    }

    LaunchedEffect(messages.size, clarificationOptions.size) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size - 1)
        }
    }

    val suggestionChips = listOf(
        "গায়ত্রী মন্ত্র ও বিধি" to "গায়ত্রী মন্ত্রটা লিখে অর্থ আর কীভাবে জপ করতে হয় বলো",
        "মহামৃত্যুঞ্জয় মন্ত্র" to "শিবের মহামৃত্যুঞ্জয় মন্ত্র কী?",
        "গীতা ২.৪৭ শ্লোক" to "কর্মণ্যেবাধিকারস্তে মা ফলেষু কদাচন শ্লোকের অর্থ কী?",
        "অদ্বৈত বনাম দ্বৈত" to "অদ্বৈত ও দ্বৈত বেদান্তের মতে জীব ও ব্রহ্মের সম্পর্ক কী?",
        "দুর্গা পূজার প্রণাম" to "দুর্গা দেবীর প্রণাম মন্ত্র ও অর্থ বলুন"
    )

    Column(modifier = Modifier.fillMaxSize()) {
        // App Header Banner
        Surface(
            color = CosmicNavySurface,
            border = androidx.compose.foundation.BorderStroke(1.dp, CosmicCardBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "🕉️", fontSize = 24.sp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "VedaNova Dharma AI",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = VedicGold
                            )
                            Text(
                                text = "Human-Like Sanatan Spiritual Intelligence",
                                style = MaterialTheme.typography.labelSmall,
                                color = TextSecondaryDark
                            )
                        }
                    }
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        Button(
                            onClick = { viewModel.startLiveVoiceCall() },
                            colors = ButtonDefaults.buttonColors(containerColor = VedicGold),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.Call, contentDescription = null, tint = Color.Black, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Live Voice", color = Color.Black, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        }
                        IconButton(
                            onClick = { viewModel.resetPublicChat() },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = "New Chat (Reset Memory)", tint = TextSecondaryDark)
                        }
                        Button(
                            onClick = { viewModel.navigateTo(ScreenDestination.DASHBOARD) },
                            colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Icon(Icons.Default.AdminPanelSettings, contentDescription = null, tint = Color.Black, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Admin Center", color = Color.Black, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    FilterChip(
                        selected = selectedTab == "CHAT",
                        onClick = { selectedTab = "CHAT" },
                        label = { Text("Dharma AI Chat") },
                        leadingIcon = { Icon(Icons.Default.Chat, contentDescription = null, modifier = Modifier.size(14.dp)) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SaffronPrimary,
                            selectedLabelColor = Color.Black
                        )
                    )
                    FilterChip(
                        selected = selectedTab == "EXPLORE",
                        onClick = { selectedTab = "EXPLORE" },
                        label = { Text("Explore Scripture Nodes (${publishedKnowledge.size})") },
                        leadingIcon = { Icon(Icons.Default.AutoStories, contentDescription = null, modifier = Modifier.size(14.dp)) },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = VedicGold,
                            selectedLabelColor = Color.Black
                        )
                    )
                }
            }
        }

        if (selectedTab == "CHAT") {
            // Chat Message List
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp, vertical = 6.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.padding(vertical = 4.dp)
                    ) {
                        items(suggestionChips) { (chipLabel, chipQuery) ->
                            SuggestionChip(
                                onClick = {
                                    viewModel.setPublicChatQuery(chipQuery)
                                    viewModel.sendPublicChatMessage()
                                },
                                label = { Text(chipLabel, fontSize = 12.sp) },
                                colors = SuggestionChipDefaults.suggestionChipColors(
                                    containerColor = CosmicNavyElevated,
                                    labelColor = VedicGold
                                )
                            )
                        }
                    }
                }

                items(messages.indices.toList()) { index ->
                    val (sender, text) = messages[index]
                    val isUser = sender == "USER"
                    val isSpeakingThis = currentlySpeakingText == text

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                    ) {
                        if (!isUser) {
                            Box(
                                modifier = Modifier
                                    .padding(top = 4.dp)
                                    .size(28.dp)
                                    .clip(CircleShape)
                                    .background(SaffronPrimary.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Text("🕉️", fontSize = 13.sp)
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                        }

                        Card(
                            colors = CardDefaults.cardColors(
                                containerColor = if (isUser) SaffronContainer else CosmicNavySurface
                            ),
                            shape = RoundedCornerShape(
                                topStart = 14.dp,
                                topEnd = 14.dp,
                                bottomStart = if (isUser) 14.dp else 4.dp,
                                bottomEnd = if (isUser) 4.dp else 14.dp
                            ),
                            border = androidx.compose.foundation.BorderStroke(
                                1.dp,
                                if (isUser) SaffronPrimary.copy(alpha = 0.35f) else CosmicCardBorder
                            ),
                            modifier = Modifier.widthIn(max = if (isUser) 300.dp else 340.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text(
                                    text = text,
                                    style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 21.sp),
                                    color = if (isUser) OnSaffronContainer else TextPrimaryDark
                                )

                                // Action Toolbar for AI Responses
                                if (!isUser && text != messages.firstOrNull()?.second) {
                                    Spacer(modifier = Modifier.height(8.dp))
                                    Divider(color = CosmicCardBorder, thickness = 0.8.dp)
                                    Spacer(modifier = Modifier.height(6.dp))

                                    Row(
                                        modifier = Modifier.fillMaxWidth(),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        // Left Action Group: Copy & Voice
                                        Row(horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
                                            // Copy Button
                                            IconButton(
                                                onClick = {
                                                    clipboardManager.setText(AnnotatedString(text))
                                                    Toast.makeText(context, "লেখা ক্লিপবোর্ডে কপি করা হয়েছে", Toast.LENGTH_SHORT).show()
                                                },
                                                modifier = Modifier.size(28.dp)
                                            ) {
                                                Icon(Icons.Default.ContentCopy, contentDescription = "Copy text", tint = VedicGold, modifier = Modifier.size(15.dp))
                                            }

                                            // Voice / TTS Playback Button
                                            IconButton(
                                                onClick = { viewModel.toggleSpeakMessage(text) },
                                                modifier = Modifier.size(28.dp)
                                            ) {
                                                if (isSpeakingThis) {
                                                    Icon(Icons.Default.StopCircle, contentDescription = "Stop Voice", tint = StatusRed, modifier = Modifier.size(17.dp))
                                                } else {
                                                    Icon(Icons.Default.VolumeUp, contentDescription = "Listen to answer", tint = SaffronPrimary, modifier = Modifier.size(16.dp))
                                                }
                                            }

                                            if (isSpeakingThis) {
                                                Text(
                                                    text = "শোনাচ্ছেন...",
                                                    style = MaterialTheme.typography.labelSmall,
                                                    color = SaffronLight,
                                                    fontSize = 10.sp
                                                )
                                            }
                                        }

                                        // Right Action Group: Like, Dislike, Report
                                        Row(horizontalArrangement = Arrangement.spacedBy(2.dp), verticalAlignment = Alignment.CenterVertically) {
                                            val feedbackState = likedMessages[index]

                                            // Like Button
                                            IconButton(
                                                onClick = {
                                                    likedMessages[index] = true
                                                    val kbId = lastResponse?.matchedKnowledgeEntity?.id ?: 1L
                                                    viewModel.recordUsageFeedback(kbId, query, true)
                                                    Toast.makeText(context, "মতামত জমা হয়েছে: সহায়ক 👍", Toast.LENGTH_SHORT).show()
                                                },
                                                modifier = Modifier.size(28.dp)
                                            ) {
                                                Icon(
                                                    Icons.Default.ThumbUp,
                                                    contentDescription = "Helpful",
                                                    tint = if (feedbackState == true) StatusGreen else TextSecondaryDark,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            }

                                            // Dislike Button
                                            IconButton(
                                                onClick = {
                                                    likedMessages[index] = false
                                                    val kbId = lastResponse?.matchedKnowledgeEntity?.id ?: 1L
                                                    viewModel.recordUsageFeedback(kbId, query, false)
                                                    Toast.makeText(context, "মতামত জমা হয়েছে: অসঙ্গত 👎", Toast.LENGTH_SHORT).show()
                                                },
                                                modifier = Modifier.size(28.dp)
                                            ) {
                                                Icon(
                                                    Icons.Default.ThumbDown,
                                                    contentDescription = "Not Helpful",
                                                    tint = if (feedbackState == false) StatusRed else TextSecondaryDark,
                                                    modifier = Modifier.size(14.dp)
                                                )
                                            }

                                            // Report / Correction
                                            IconButton(
                                                onClick = {
                                                    selectedMessageForFeedback = text
                                                    showFeedbackDialog = true
                                                },
                                                modifier = Modifier.size(28.dp)
                                            ) {
                                                Icon(Icons.Default.Flag, contentDescription = "Report or correct", tint = TextSecondaryDark, modifier = Modifier.size(14.dp))
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Interactive Clarification Chips (Requirement #9)
                if (clarificationOptions.isNotEmpty()) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = CosmicNavyElevated),
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, SaffronPrimary.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.HelpOutline, contentDescription = null, tint = SaffronPrimary, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        "যেকোনো একটি সুনির্দিষ্ট বিষয় বেছে নিন:",
                                        style = MaterialTheme.typography.labelMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = SaffronPrimary
                                    )
                                }
                                Spacer(modifier = Modifier.height(8.dp))
                                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                    clarificationOptions.forEach { opt ->
                                        OutlinedButton(
                                            onClick = { viewModel.selectClarificationOption(opt) },
                                            modifier = Modifier.fillMaxWidth(),
                                            shape = RoundedCornerShape(8.dp),
                                            colors = ButtonDefaults.outlinedButtonColors(contentColor = VedicGold)
                                        ) {
                                            Row(
                                                modifier = Modifier.fillMaxWidth(),
                                                horizontalArrangement = Arrangement.SpaceBetween,
                                                verticalAlignment = Alignment.CenterVertically
                                            ) {
                                                Text(opt, style = MaterialTheme.typography.bodySmall, color = TextPrimaryDark)
                                                Icon(Icons.Default.ArrowForward, contentDescription = null, modifier = Modifier.size(14.dp), tint = SaffronPrimary)
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                // Dharma Semantic Graph Recommendations
                lastResponse?.diagnosticInfo?.relatedNodes?.let { relatedNodes ->
                    if (relatedNodes.isNotEmpty()) {
                        item {
                            Surface(
                                color = Color(0xFF140D26),
                                shape = RoundedCornerShape(10.dp),
                                border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF381F60)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Hub, contentDescription = null, tint = VedicGold, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text("সম্পর্কিত শাস্ত্রীয় বিষয় (Dharma Graph):", fontSize = 12.sp, fontWeight = FontWeight.Bold, color = VedicGold)
                                    }
                                    Spacer(modifier = Modifier.height(6.dp))
                                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                        items(relatedNodes) { node ->
                                            AssistChip(
                                                onClick = {
                                                    viewModel.setPublicChatQuery(node.bengaliName)
                                                    viewModel.sendPublicChatMessage()
                                                },
                                                label = { Text(node.bengaliName, fontSize = 11.sp) }
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }

                if (isLoading) {
                    item {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = SaffronPrimary, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("VedaNova AI প্রামাণিক শাস্ত্র ও ঐতিহ্য বিশ্লেষণ করছে...", style = MaterialTheme.typography.labelSmall, color = VedicGold)
                        }
                    }
                }
            }

            // Input Bar
            Surface(
                color = CosmicNavySurface,
                border = androidx.compose.foundation.BorderStroke(1.dp, CosmicCardBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(10.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    IconButton(onClick = { showReportDialog = true }) {
                        Icon(Icons.Default.Feedback, contentDescription = "General Report", tint = VedicGold)
                    }

                    OutlinedTextField(
                        value = query,
                        onValueChange = { viewModel.setPublicChatQuery(it) },
                        placeholder = { 
                            Text(
                                "প্রশ্ন করুন (বাংলা / Sanskrit / English)...",
                                color = TextSecondaryDark,
                                style = MaterialTheme.typography.bodyMedium
                            ) 
                        },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(20.dp),
                        singleLine = true,
                        textStyle = MaterialTheme.typography.bodyMedium.copy(
                            color = TextPrimaryDark,
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Medium
                        ),
                        colors = OutlinedTextFieldDefaults.colors(
                            focusedTextColor = TextPrimaryDark,
                            unfocusedTextColor = TextPrimaryDark,
                            focusedContainerColor = CosmicNavyElevated,
                            unfocusedContainerColor = CosmicNavyElevated,
                            cursorColor = SaffronPrimary,
                            focusedBorderColor = SaffronPrimary,
                            unfocusedBorderColor = CosmicCardBorder,
                            focusedPlaceholderColor = TextSecondaryDark,
                            unfocusedPlaceholderColor = TextSecondaryDark
                        )
                    )

                    Spacer(modifier = Modifier.width(6.dp))

                    val isListening = liveVoiceState == LiveVoiceState.LISTENING

                    IconButton(
                        onClick = {
                            val permissionState = ContextCompat.checkSelfPermission(
                                context,
                                Manifest.permission.RECORD_AUDIO
                            )
                            if (permissionState == PackageManager.PERMISSION_GRANTED) {
                                if (isListening) {
                                    viewModel.liveVoiceManager.stopListening()
                                } else {
                                    viewModel.triggerSingleVoiceInput()
                                    Toast.makeText(context, "কথা বলুন... শুনছি (Listening...)", Toast.LENGTH_SHORT).show()
                                }
                            } else {
                                micPermissionLauncher.launch(Manifest.permission.RECORD_AUDIO)
                            }
                        },
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(if (isListening) StatusRed.copy(alpha = 0.25f) else VedicGold.copy(alpha = 0.2f))
                    ) {
                        Icon(
                            imageVector = if (isListening) Icons.Default.MicOff else Icons.Default.Mic,
                            contentDescription = if (isListening) "Stop Listening" else "Microphone Voice Input",
                            tint = if (isListening) StatusRed else VedicGold
                        )
                    }

                    Spacer(modifier = Modifier.width(6.dp))

                    IconButton(
                        onClick = { viewModel.sendPublicChatMessage() },
                        enabled = query.isNotBlank() && !isLoading,
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(if (query.isNotBlank()) SaffronPrimary else MaterialTheme.colorScheme.surfaceVariant)
                    ) {
                        Icon(
                            Icons.Default.Send,
                            contentDescription = "Send",
                            tint = if (query.isNotBlank()) Color.Black else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            // Explore Scriptures List
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                items(publishedKnowledge) { item ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = CosmicNavySurface),
                        shape = RoundedCornerShape(14.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, CosmicCardBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = item.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = VedicGold
                                )
                                StatusPill(text = item.category, color = SaffronPrimary)
                            }
                            if (item.sanskritText.isNotBlank()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = item.sanskritText,
                                    style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold),
                                    color = TextPrimaryDark
                                )
                            }
                            if (item.banglaMeaning.isNotBlank()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = item.banglaMeaning,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondaryDark
                                )
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "🏛️ ${item.scripture} (${item.reference})",
                                style = MaterialTheme.typography.labelSmall,
                                color = SaffronLight
                            )
                        }
                    }
                }
            }
        }
    }

    // Human Feedback Loop Dialog (Requirement #18)
    if (showFeedbackDialog) {
        var feedbackText by remember { mutableStateOf("") }
        AlertDialog(
            onDismissRequest = { showFeedbackDialog = false },
            title = { Text("সংশোধনের অনুরোধ (Human Feedback Loop)") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        "AI-এর জবাবে কোনো ভুল বা অসম্পূর্ণ তথ্য থাকলে লিখুন। অ্যাডমিন ও গবেষক দল তা যাচাই করে সিস্টেম আপডেট করবেন।",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    OutlinedTextField(
                        value = feedbackText,
                        onValueChange = { feedbackText = it },
                        label = { Text("ভুল বা সংশোধনের বিবরণ") },
                        placeholder = { Text("যেমন: শ্লোকের রেফারেন্স বা অর্থের সামপ্রদায়িক ব্যাখ্যার ঘাটতি...") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (feedbackText.isNotBlank()) {
                            viewModel.submitPublicFeedback(
                                feedbackText = feedbackText,
                                messageSnippet = selectedMessageForFeedback.take(150),
                                onComplete = { showFeedbackDialog = false }
                            )
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
                ) {
                    Text("জমা দিন (Submit)", color = Color.Black)
                }
            },
            dismissButton = {
                TextButton(onClick = { showFeedbackDialog = false }) { Text("বাতিল") }
            }
        )
    }

    // Devotee User Report Dialog
    if (showReportDialog) {
        var repTitle by remember { mutableStateOf("") }
        var repType by remember { mutableStateOf("Missing Knowledge") }
        var repDesc by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showReportDialog = false },
            title = { Text("Submit Dharma Knowledge Feedback") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = repTitle,
                        onValueChange = { repTitle = it },
                        label = { Text("Topic / Title") },
                        placeholder = { Text("e.g. Add detailed procedure for Chandi Path") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = repDesc,
                        onValueChange = { repDesc = it },
                        label = { Text("Explanation or Suggestion") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (repTitle.isNotBlank()) {
                            val newReport = ReportEntity(
                                reportCode = "REP-${(100..999).random()}",
                                reportType = repType,
                                title = repTitle,
                                description = repDesc,
                                userQuery = query,
                                submittedBy = "Devotee User #Mobile"
                            )
                            coroutineScope.launch {
                                viewModel.repository.insertReport(newReport)
                            }
                            showReportDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
                ) {
                    Text("Submit Feedback", color = Color.Black)
                }
            },
            dismissButton = {
                TextButton(onClick = { showReportDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Live Voice Call-Like Mode Overlay (Phase 8)
    val isVoiceCallActive by viewModel.isVoiceCallActive.collectAsStateWithLifecycle()
    if (isVoiceCallActive) {
        com.example.ui.components.LiveVoiceCallOverlay(
            viewModel = viewModel,
            onDismiss = { viewModel.endLiveVoiceCall() }
        )
    }
}
