package com.example

import android.app.Application
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.VedaNovaDatabase
import com.example.data.model.*
import com.example.data.repository.VedaNovaRepository
import com.example.domain.command.AdminCommandEngine
import com.example.domain.health.FeatureHealthAuditor
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var app: Application
    private lateinit var database: VedaNovaDatabase
    private lateinit var repository: VedaNovaRepository
    private lateinit var engine: AdminCommandEngine
    private lateinit var healthAuditor: FeatureHealthAuditor

    @Before
    fun setup() {
        app = ApplicationProvider.getApplicationContext()
        database = Room.inMemoryDatabaseBuilder(app, VedaNovaDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = VedaNovaRepository(database)
        engine = AdminCommandEngine(app, database)
        healthAuditor = FeatureHealthAuditor(app, database, repository)
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun `read string from context`() {
        val appName = app.getString(R.string.app_name)
        assertEquals("VedaNova AI", appName)
    }

    @Test
    fun `test Step 4 Command Analysis and Approval Gating`() = runBlocking {
        // Modifying commands require approval
        val voicePlan = engine.analyzeCommand("Voice ঠিক করো")
        assertTrue(voicePlan.requiresApproval)
        assertFalse(voicePlan.isDestructive)
        assertEquals("VOICE_REPAIR", voicePlan.category)

        val issuePlan = engine.analyzeCommand("এই সমস্যাটা খুঁজে ঠিক করো")
        assertTrue(issuePlan.requiresApproval)
        assertEquals("ISSUE_AUTO_FIX", issuePlan.category)

        val destructivePlan = engine.analyzeCommand("Delete all logs and reset")
        assertTrue(destructivePlan.requiresApproval)
        assertTrue(destructivePlan.isDestructive)
        assertEquals("DESTRUCTIVE_OPERATION", destructivePlan.category)

        // Read-only commands do not block
        val testPlan = engine.analyzeCommand("আবার test করো")
        assertFalse(testPlan.requiresApproval)
        assertEquals("TEST_EXECUTION", testPlan.category)
    }

    @Test
    fun `test Step 4 Approval and Real Execution of Voice Repair`() = runBlocking {
        val task = DevelopmentTaskEntity(
            taskCode = "TASK-TEST-001",
            title = "Repair Voice Engine",
            instruction = "Voice ঠিক করো",
            category = "VOICE_REPAIR",
            targetLocation = "LiveVoiceAiManager",
            requiredComponents = "SpeechRecognizer, SystemSettingDao",
            proposedChanges = "Update voice_engine_verified",
            status = "WAITING_FOR_APPROVAL",
            currentStep = "Waiting for Admin Approval"
        )
        database.developmentTaskDao().insertTask(task)

        // Execute approved task
        val result = engine.executeTask(
            task = task,
            featureHealthAuditor = healthAuditor,
            adminUsername = "superadmin",
            adminRole = "Super Admin"
        )

        assertTrue(result.isSuccess)
        assertEquals("COMPLETED", result.updatedTask.status)
        assertEquals("Completed", result.updatedTask.currentStep)

        // Verify Real DB Persistence (Rule 12 & Rule 5)
        val voiceSetting = database.systemSettingDao().getSetting("voice_engine_verified")
        assertNotNull(voiceSetting)
        assertEquals("true", voiceSetting?.value)

        // Verify Immutable Audit Log (Rule 8)
        val auditLogs = database.auditLogDao().getRecentAuditLogsSync(100)
        assertTrue(auditLogs.any { it.action == "COMMAND_EXECUTED" && it.targetId == "TASK-TEST-001" })
    }

    @Test
    fun `test Step 4 Rejection of Task Applies Zero Changes`() = runBlocking {
        val task = DevelopmentTaskEntity(
            taskCode = "TASK-TEST-002",
            title = "Unsolicited DB Change",
            instruction = "Change internal schema",
            category = "SYSTEM_OPTIMIZATION",
            targetLocation = "Schema",
            requiredComponents = "None",
            proposedChanges = "No change",
            status = "WAITING_FOR_APPROVAL",
            currentStep = "Waiting for Admin Approval"
        )
        val taskId = database.developmentTaskDao().insertTask(task)

        // Admin rejects
        val rejectedTask = task.copy(
            id = taskId,
            status = "REJECTED",
            currentStep = "Rejected by Admin"
        )
        database.developmentTaskDao().updateTask(rejectedTask)

        // Record rejection audit
        database.auditLogDao().insertAuditLog(
            AuditLogEntity(
                adminUsername = "superadmin",
                adminRole = "Super Admin",
                action = "TASK_REJECTED",
                targetType = task.category,
                targetId = task.taskCode,
                details = "Command: '${task.instruction}' | Decision: REJECTED | Result: NO_CHANGE_APPLIED"
            )
        )

        // Assert zero changes to system settings
        val setting = database.systemSettingDao().getSetting("last_op_002")
        assertNull(setting)

        val dbTask = database.developmentTaskDao().getTaskById(taskId)
        assertEquals("REJECTED", dbTask?.status)

        val audits = database.auditLogDao().getRecentAuditLogsSync(100)
        assertTrue(audits.any { it.action == "TASK_REJECTED" && it.details.contains("NO_CHANGE_APPLIED") })
    }

    @Test
    fun `test Step 4 Issue Auto Fix and Verification`() = runBlocking {
        // Create an open issue
        database.issueDao().insertIssue(
            IssueEntity(
                issueCode = "ISSUE-099",
                title = "UI Contrast Glitch",
                description = "Input text unreadable",
                category = "UI",
                severity = "Medium",
                status = "Open"
            )
        )

        val task = DevelopmentTaskEntity(
            taskCode = "TASK-TEST-003",
            title = "Fix Active Issues",
            instruction = "এই সমস্যাটা খুঁজে ঠিক করো",
            category = "ISSUE_AUTO_FIX",
            targetLocation = "IssueDao",
            requiredComponents = "IssueDao",
            proposedChanges = "Resolve open issues",
            status = "WAITING_FOR_APPROVAL",
            currentStep = "Waiting for Admin Approval"
        )
        database.developmentTaskDao().insertTask(task)

        val result = engine.executeTask(task, healthAuditor)
        assertTrue(result.isSuccess)
        assertEquals("COMPLETED", result.updatedTask.status)

        // Check issue was actually updated to Fixed in Room DB
        val issues = database.issueDao().getAllIssuesDirect()
        val fixedIssue = issues.find { it.issueCode == "ISSUE-099" }
        assertEquals("Fixed", fixedIssue?.status)
    }
}
