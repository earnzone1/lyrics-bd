package com.example

import android.app.Application
import android.util.Log
import com.example.data.local.VedaNovaDatabase
import com.example.domain.diagnostic.CrashReportingManager

class VedaNovaApplication : Application() {
    override fun onCreate() {
        super.onCreate()
        try {
            val db = VedaNovaDatabase.getInstance(this)
            CrashReportingManager.initialize(this, db)
            Log.i("VedaNovaApplication", "VedaNovaApplication successfully initialized with CrashReportingManager")
        } catch (e: Exception) {
            Log.e("VedaNovaApplication", "CrashReportingManager init error", e)
        }
    }
}
