package com.example.domain.ai

import java.util.Locale

data class GeneralKnowledgeTopic(
    val id: String,
    val keywords: List<String>,
    val titleBn: String,
    val titleEn: String,
    val category: String, // SCIENCE, GEOGRAPHY, HISTORY, TECH, MATH, LANGUAGE, DAILY_LIFE
    val shortSummaryBn: String,
    val shortSummaryEn: String,
    val fullExplanationBn: String,
    val fullExplanationEn: String,
    val keyFacts: List<String>,
    val references: List<String> = listOf("Universal General Knowledge & Empirical Science Foundation")
) {
    fun generateAnswer(language: String): String {
        val isEnglish = language.contains("English", ignoreCase = true)
        return if (isEnglish) {
            buildString {
                append("🌐 **$titleEn**\n\n")
                append("$shortSummaryEn\n\n")
                append("📘 **Detailed Explanation:**\n$fullExplanationEn\n\n")
                if (keyFacts.isNotEmpty()) {
                    append("🔑 **Key Facts:**\n")
                    keyFacts.forEach { append("• $it\n") }
                }
            }.trim()
        } else {
            buildString {
                append("🌐 **$titleBn**\n\n")
                append("$shortSummaryBn\n\n")
                append("📘 **বিস্তারিত বিবরণ:**\n$fullExplanationBn\n\n")
                if (keyFacts.isNotEmpty()) {
                    append("🔑 **মূল তথ্যসমূহ:**\n")
                    keyFacts.forEach { append("• $it\n") }
                }
            }.trim()
        }
    }
}

object GeneralKnowledgeEngine {

    private val topics = listOf(
        GeneralKnowledgeTopic(
            id = "photosynthesis",
            keywords = listOf("photosynthesis", "সালোকসংশ্লেষণ", "গাছ কীভাবে খাবার বানায়", "chlorophyll", "ক্লোরোফিল"),
            titleBn = "সালোকসংশ্লেষণ (Photosynthesis)",
            titleEn = "Photosynthesis",
            category = "SCIENCE",
            shortSummaryBn = "সালোকসংশ্লেষণ হলো সবুজ উদ্ভিদের সূর্যালোক, কার্বন ডাই-অক্সাইড ও পানির উপস্থিতিতে গ্লুকোজ ও অক্সিজেন তৈরির জৈব-রাসায়নিক প্রক্রিয়া।",
            shortSummaryEn = "Photosynthesis is the biochemical process by which green plants synthesize glucose and oxygen using sunlight, carbon dioxide, and water.",
            fullExplanationBn = "সবুজ উদ্ভিদের পাতায় উপস্থিত ক্লোরোফিল সূর্যালোকের আলোকশক্তি শোষণ করে। মূল দ্বারা শোষিত পানি (H₂O) এবং বায়ুমণ্ডলের কার্বন ডাই-অক্সাইড (CO₂) বিক্রিয়া করে শর্করা/গ্লুকোজ (C₆H₁₂O₆) ও উপজাত হিসেবে অক্সিজেন (O₂) তৈরি করে।\n\nরাসায়নিক সমীকরণ:\n6CO₂ + 6H₂O + আলোকশক্তি ➔ C₆H₁₂O₆ + 6O₂\n\nএটি পৃথিবীর বায়ুমণ্ডলে অক্সিজেন বজায় রাখা এবং সমস্ত প্রাণীর খাদ্যশৃঙ্খলের মূল ভিত্তি।",
            fullExplanationEn = "Chlorophyll in plant leaves captures radiant energy from sunlight. This energy splits water molecules into hydrogen and oxygen, combining with atmospheric CO₂ to form glucose.\n\nChemical Equation:\n6CO₂ + 6H₂O + Light Energy ➔ C₆H₁₂O₆ + 6O₂\n\nIt is the primary basis of oxygen and energy for almost all life on Earth.",
            keyFacts = listOf("Occurs in Chloroplasts", "Produces Glucose & Oxygen", "Requires Chlorophyll, Sunlight, Water, CO₂")
        ),

        GeneralKnowledgeTopic(
            id = "gravity",
            keywords = listOf("gravity", "মহাকর্ষ", "অভিকর্ষ", "newton gravity", "নিউটনের মহাকর্ষ"),
            titleBn = "মহাকর্ষ বল ও মহাকর্ষীয় সূত্র (Gravity & Gravitation)",
            titleEn = "Universal Gravitation and Gravity",
            category = "SCIENCE",
            shortSummaryBn = "মহাকর্ষ হলো মহাবিশ্বের যেকোনো দুটি ভরযুক্ত বস্তুর মধ্যকার পারস্পরিক আকর্ষণ বল।",
            shortSummaryEn = "Gravity is the fundamental attractive force between any two masses in the universe.",
            fullExplanationBn = "স্যার আইজ্যাক নিউটনের সার্বজনীন মহাকর্ষ সূত্র অনুযায়ী, দুটি বস্তুর মধ্যকার আকর্ষণ বল তাদের ভরের গুণফলের সমানুপাতিক এবং তাদের মধ্যকার দূরত্বের বর্গের ব্যস্তানুপাতিক।\n\nসূত্র: F = G * (m₁ * m₂) / r²\n\nপরবর্তীতে আলবার্ট আইনস্টাইন সাধারণ আপেক্ষিকতা তত্ত্বে মহাকর্ষকে স্থান-কালের (Spacetime) বক্রতা হিসেবে ব্যাখ্যা করেন। পৃথিবীর অভিকর্ষ বলের কারণেই বায়ুমণ্ডল, সমুদ্র এবং সকল বস্তু ভূপৃষ্ঠে সংলগ্ন থাকে।",
            fullExplanationEn = "Sir Isaac Newton formulated that the gravitational attraction between two objects is proportional to the product of their masses and inversely proportional to the square of the distance between them (F = G*m₁m₂/r²). Albert Einstein later characterized gravity as the curvature of spacetime.",
            keyFacts = listOf("Inverse Square Law", "Universal Constant G = 6.674×10⁻¹¹ N·m²/kg²", "Einsteinian Spacetime Curvature")
        ),

        GeneralKnowledgeTopic(
            id = "solar_system",
            keywords = listOf("solar system", "সৌরজগৎ", "গ্রহ", "সূর্যজগৎ", "planets in solar system"),
            titleBn = "সৌরজগৎ ও এর গ্রহমণ্ডলী (The Solar System)",
            titleEn = "The Solar System",
            category = "SCIENCE",
            shortSummaryBn = "সৌরজগৎ হলো সূর্য এবং এর চারদিকে মহাকর্ষীয় টানে আবর্তনশীল আটটি গ্রহ, উপগ্রহ, বামন গ্রহ ও অন্যান্য মহাজাগতিক বস্তুর পরিবার।",
            shortSummaryEn = "The Solar System consists of the Sun and the gravitationally bound planetary system comprising 8 major planets, dwarf planets, moons, and asteroids.",
            fullExplanationBn = "সূর্য হলো সৌরজগতের কেন্দ্রবিন্দু, যা সমগ্র সৌরজগতের মোট ভরের প্রায় ৯৯.৮৬% ধারণ করে। সূর্য থেকে ক্রমানুসারে আটটি গ্রহ হলো:\n১. বুধ (Mercury) - ক্ষুদ্রতম ও সূর্যের নিকটতম\n২. শুক্র (Venus) - সবচেয়ে উষ্ণ ও উজ্জ্বলতম\n৩. পৃথিবী (Earth) - একমাত্র নিশ্চিত প্রাণের আবাস\n৪. মঙ্গল (Mars) - লাল গ্রহ\n৫. বৃহস্পতি (Jupiter) - বৃহত্তম গ্যাসীয় গ্রহ\n৬. শনি (Saturn) - সুন্দর বলয়যুক্ত গ্রহ\n৭. ইউরেনাস (Uranus) - বরফ দৈত্য গ্রহ\n৮. নেপচুন (Neptune) - সূর্য থেকে সবচেয়ে দূরবর্তী গ্রহ।",
            fullExplanationEn = "The Sun is at the center, comprising 99.86% of the system's mass. The 8 planets in order of distance from the Sun are: Mercury, Venus, Earth, Mars, Jupiter, Saturn, Uranus, and Neptune.",
            keyFacts = listOf("8 Official Planets", "Sun holds 99.86% mass", "Inner Terrestrial + Outer Gas/Ice Giants")
        ),

        GeneralKnowledgeTopic(
            id = "ai_computing",
            keywords = listOf("artificial intelligence", "কৃত্রিম বুদ্ধিমত্তা", "ai কি", "what is ai", "machine learning", "neural network"),
            titleBn = "কৃত্রিম বুদ্ধিমত্তা (Artificial Intelligence)",
            titleEn = "Artificial Intelligence (AI)",
            category = "TECH",
            shortSummaryBn = "কৃত্রিম বুদ্ধিমত্তা (AI) হলো কম্পিউটার বিজ্ঞানের এমন এক শাখা যা মানুষের মতো যৌক্তিক চিন্তা, ভাষা বোঝা, সিদ্ধান্ত গ্রহণ ও সমস্যা সমাধানের ক্ষমতা সম্পন্ন সিস্টেম তৈরি করে।",
            shortSummaryEn = "Artificial Intelligence is the branch of computer science dedicated to developing systems capable of performing tasks requiring human intelligence, such as reasoning, NLP, and problem solving.",
            fullExplanationBn = "এআই মূলত মেশিন লার্নিং (Machine Learning) এবং ডিপ লার্নিং (Deep Learning) অ্যালগরিদমের মাধ্যমে বিশাল ডেটা থেকে প্যাটার্ন শিখে কাজ করে। আধুনিক লার্জ ল্যাঙ্গুয়েজ মডেল (LLM) এবং নিউরাল নেটওয়ার্ক মানুষের ভাষা বিশ্লেষণ ও নির্ভুল উত্তর তৈরিতে অত্যন্ত পারদর্শী। স্বাস্থ্যসেবা, মহাকাশ গবেষণা, শিক্ষা, আবহাওয়া পূর্বাভাস ও অটোমেশনে এআই বৈপ্লবিক পরিবর্তন আনছে।",
            fullExplanationEn = "AI operates through mathematical models, neural networks, and statistical learning on large datasets. Applications include Natural Language Processing, computer vision, automated scientific discovery, and decision-support systems.",
            keyFacts = listOf("Subfields: ML, Deep Learning, NLP", "Trained on Data Patterns", "Powers Modern Intelligent Systems")
        ),

        GeneralKnowledgeTopic(
            id = "world_war_two",
            keywords = listOf("world war 2", "world war ii", "দ্বিতীয় বিশ্বযুদ্ধ", "দ্বিতীয় বিশ্ব যুদ্ধ", "second world war"),
            titleBn = "দ্বিতীয় বিশ্বযুদ্ধ (World War II)",
            titleEn = "World War II (1939–1945)",
            category = "HISTORY",
            shortSummaryBn = "দ্বিতীয় বিশ্বযুদ্ধ (১৯৩৯–১৯৪৫) ছিল মানব ইতিহাসের সর্ববৃহৎ বৈশ্বিক সংঘাত, যা অক্ষশক্তি (জার্মানি, ইতালি, জাপান) এবং মিত্রশক্তির (ব্রিটেন, সোভিয়েত ইউনিয়ন, যুক্তরাষ্ট্র, ফ্রান্স) মধ্যে সংঘটিত হয়েছিল।",
            shortSummaryEn = "World War II (1939–1945) was the deadliest global conflict in history, fought between the Axis powers and the Allied powers.",
            fullExplanationBn = "১৯৩৯ সালের ১ সেপ্টেম্বর পোল্যান্ডে জার্মানির আক্রমণের মাধ্যমে যুদ্ধের সূত্রপাত ঘটে। ১৯৪৫ সালে জার্মানির নিঃশর্ত আত্মসমর্পণ এবং হিরোশিমা ও নাগাসাকিতে পারমাণবিক বোমা বিস্ফোরণের পর জাপানের আত্মসমর্পণের মধ্য দিয়ে যুদ্ধের অবসান ঘটে। এই যুদ্ধের ফলেই ১৯৪৫ সালে সম্মিলিত জাতিপুঞ্জ (United Nations) গঠিত হয়।",
            fullExplanationEn = "Triggered by Nazi Germany's invasion of Poland in 1939, it concluded in 1945 with the defeat of Nazi Germany and Imperial Japan. It led directly to the establishment of the United Nations.",
            keyFacts = listOf("1939 to 1945", "Allied vs Axis Powers", "Led to the United Nations creation")
        ),

        GeneralKnowledgeTopic(
            id = "dna_genetics",
            keywords = listOf("dna", "ডিএনএ", "gene", "জিন", "genetic code", "ক্রোমোজোম"),
            titleBn = "ডিএনএ ও বংশগতি (DNA & Genetics)",
            titleEn = "Deoxyribonucleic Acid (DNA)",
            category = "SCIENCE",
            shortSummaryBn = "ডিএনএ (Deoxyribonucleic Acid) হলো সকল জীবদেহের বৃদ্ধি, বিকাশ ও বংশগত বৈশিষ্ট্য স্থানান্তরের মূল আণবিক নকশা বা জেনেটিক ব্লুপ্রিন্ট।",
            shortSummaryEn = "DNA is the double-helix molecule carrying genetic instructions for the development, functioning, growth, and reproduction of all living organisms.",
            fullExplanationBn = "১৯৫৩ সালে জেমস ওয়াটসন ও ফ্রান্সিস ক্রিক ডিএনএ-র দ্বি-সূত্রক (Double Helix) গঠন আবিষ্কার করেন। ডিএনএ চারটি নাইট্রোজেনাস বেস দ্বারা গঠিত: অ্যাডেনিন (A), গুয়ানিন (G), সাইটোসিন (C), এবং থাইমিন (T)। A সর্বদা T-এর সাথে এবং G সর্বদা C-এর সাথে যুক্ত থাকে।",
            fullExplanationEn = "Discovered as a double helix by Watson and Crick in 1953, DNA comprises four nucleotide bases: Adenine (A), Thymine (T), Guanine (G), and Cytosine (C) paired precisely across the helical backbone.",
            keyFacts = listOf("Double Helix Structure", "Four Bases: A, T, G, C", "Carrier of Hereditary Information")
        ),

        GeneralKnowledgeTopic(
            id = "mount_everest",
            keywords = listOf("mount everest", "মাউন্ট এভারেস্ট", "এভারেস্ট", "highest mountain", "সর্বোচ্চ পর্বতশৃঙ্গ"),
            titleBn = "মাউন্ট এভারেস্ট (Mount Everest)",
            titleEn = "Mount Everest",
            category = "GEOGRAPHY",
            shortSummaryBn = "মাউন্ট এভারেস্ট হলো সমুদ্রপৃষ্ঠ থেকে পৃথিবীর সর্বোচ্চ পর্বতশৃঙ্গ, যার উচ্চতা ৮,৮৪৮.৮৬ মিটার (২৯,০৩১.৭ ফুট)।",
            shortSummaryEn = "Mount Everest is Earth's highest mountain above sea level, located in the Mahalangur Himal sub-range of the Himalayas, with an elevation of 8,848.86 m (29,031.7 ft).",
            fullExplanationBn = "মাউন্ট এভারেস্ট নেপাল ও চীনের (তিব্বত) সীমান্তে হিমালয় পর্বতমালায় অবস্থিত। নেপালে এটি 'সগরমাথা' এবং তিব্বতে 'চোমোলাংমা' নামে পরিচিত। ১৯৫৩ সালের ২৯ মে নিউজিল্যান্ডের এডমন্ড হিলারি এবং শেরপা তেনজিং নোরগে প্রথমবারের মতো সফলভাবে এভারেস্টের চূড়ায় আরোহণ করেন।",
            fullExplanationEn = "Situated on the China-Nepal border, Mount Everest was first officially summited by Sir Edmund Hillary and Tenzing Norgay on May 29, 1953. In Nepali it is known as Sagarmatha and in Tibetan Chomolungma.",
            keyFacts = listOf("Height: 8,848.86 meters", "Located on Nepal-Tibet border", "First summit: May 29, 1953")
        ),

        GeneralKnowledgeTopic(
            id = "python_programming",
            keywords = listOf("python", "পাইথন", "python programming", "write code", "programming language", "ফাংশন কোড"),
            titleBn = "পাইথন প্রোগ্রামিং ভাষা (Python Programming)",
            titleEn = "Python Programming Language",
            category = "TECH",
            shortSummaryBn = "পাইথন হলো একটি বহুল ব্যবহৃত, উচ্চ-স্তরের, ইন্টারপ্রেটেড প্রোগ্রামিং ভাষা যা এর সহজ পাঠযোগ্য সিনট্যাক্স এবং বহুমুখী লাইব্রেরির জন্য বিশ্ববিখ্যাত।",
            shortSummaryEn = "Python is a high-level, interpreted, general-purpose programming language renowned for its readable syntax, dynamic typing, and vast ecosystem.",
            fullExplanationBn = "১৯৯১ সালে গুইডো ভ্যান রসাম পাইথন তৈরি করেন। এটি ডেটা সায়েন্স, কৃত্রিম বুদ্ধিমত্তা (AI), মেশিন লার্নিং, ওয়েব ডেভেলপমেন্ট (Django, Flask), অটোমেশন ও সফটওয়্যার টেস্টিংয়ে প্রধান ভাষা হিসেবে ব্যবহৃত হয়। পাইথনের কোড সংক্ষিপ্ত ও প্রাঞ্জল হওয়ায় নতুন শিক্ষার্থীদের জন্য এটি অত্যন্ত সুবিধাজনক।",
            fullExplanationEn = "Created by Guido van Rossum and released in 1991, Python emphasizes code readability with its notable use of significant indentation. It is extensively applied in Data Science, Machine Learning, Web Backend, and Automation.",
            keyFacts = listOf("Created by Guido van Rossum", "Multi-paradigm: OOP, Functional, Procedural", "Dominant in Data Science and AI")
        ),

        GeneralKnowledgeTopic(
            id = "pythagoras_theorem",
            keywords = listOf("pythagoras", "পাইথাগোরাস", "পীথাগোরাস", "pythagorean theorem", "সমকোণী ত্রিভুজ", "অতিভুজ", "a2 + b2 = c2"),
            titleBn = "পীথাগোরাসের উপপাদ্য (Pythagorean Theorem)",
            titleEn = "Pythagorean Theorem",
            category = "MATH",
            shortSummaryBn = "সমকোণী ত্রিভুজের অতিভুজের ওপর অঙ্কিত বর্গক্ষেত্রের ক্ষেত্রফল অপর দুই বাহুর ওপর অঙ্কিত বর্গক্ষেত্রের ক্ষেত্রফলের সমষ্টির সমান।",
            shortSummaryEn = "In any right-angled triangle, the square of the hypotenuse is equal to the sum of the squares of the other two sides (a² + b² = c²).",
            fullExplanationBn = "পীথাগোরাসের সূত্রটি জ্যামিতির অন্যতম প্রধান ভিত্তি। যদি একটি সমকোণী ত্রিভুজের সমকোণ সংলগ্ন বাহু দুটি 'a' ও 'b' হয় এবং অতিভুজ 'c' হয়, তবে:\n\na² + b² = c²\n\nউদাহরণস্বরূপ, বাহু দুটির দৈর্ঘ্য ৩ একক ও ৪ একক হলে, অতিভুজ হবে √(৩² + ৪²) = √(৯ + ১৬) = √২৫ = ৫ একক। এই উপপাদ্য ত্রিভুজমিতি, পদার্থবিজ্ঞান, স্থাপত্য ও নৌচালনায় ব্যাপকভাবে ব্যবহৃত হয়।",
            fullExplanationEn = "Discovered by the ancient Greek mathematician Pythagoras, this fundamental geometric theorem states that for a right triangle with legs 'a' and 'b' and hypotenuse 'c': a² + b² = c². For example, a triangle with legs 3 and 4 has hypotenuse √(9+16) = 5.",
            keyFacts = listOf("Formula: a² + b² = c²", "Applies to right-angled triangles", "Fundamental in Trigonometry & Physics")
        ),

        GeneralKnowledgeTopic(
            id = "capital_france_paris",
            keywords = listOf("capital of france", "ফ্রান্সের রাজধানী", "paris", "প্যারিস", "capital france"),
            titleBn = "প্যারিস — ফ্রান্সের রাজধানী (Paris, Capital of France)",
            titleEn = "Paris — Capital of France",
            category = "GEOGRAPHY",
            shortSummaryBn = "প্যারিস হলো পশ্চিম ইউরোপের রাষ্ট্র ফ্রান্সের রাজধানী ও বৃহত্তম শহর।",
            shortSummaryEn = "Paris is the capital and most populous city of France, situated along the Seine River in northern-central France.",
            fullExplanationBn = "প্যারিস সিন (Seine) নদীর তীরে অবস্থিত। এটি বৈশ্বিক শিল্প, ফ্যাশন, সাহিত্য, অর্থনীতি এবং সংস্কৃতির অন্যতম প্রধান কেন্দ্র। বিখ্যাত আইফেল টাওয়ার (Eiffel Tower), ল্যুভর মিউজিয়াম (Louvre Museum) এবং নোত্র দাম ক্যাথেড্রাল প্যারিসে অবস্থিত।",
            fullExplanationEn = "Located on the Seine River, Paris is a leading global center for art, fashion, commerce, and culture. Major landmarks include the Eiffel Tower, the Louvre Museum, and Notre-Dame Cathedral.",
            keyFacts = listOf("Capital of France", "Located on Seine River", "Home to Eiffel Tower and Louvre")
        ),

        GeneralKnowledgeTopic(
            id = "capital_bangladesh_dhaka",
            keywords = listOf("capital of bangladesh", "বাংলাদেশের রাজধানী", "dhaka", "ঢাকা"),
            titleBn = "ঢাকা — বাংলাদেশের রাজধানী (Dhaka, Capital of Bangladesh)",
            titleEn = "Dhaka — Capital of Bangladesh",
            category = "GEOGRAPHY",
            shortSummaryBn = "ঢাকা হলো দক্ষিণ এশিয়ার গণপ্রজাতন্ত্রী বাংলাদেশের রাজধানী ও প্রধান বাণিজ্যিক কেন্দ্র।",
            shortSummaryEn = "Dhaka is the capital and largest city of Bangladesh, serving as the cultural and economic heart of the nation.",
            fullExplanationBn = "বুড়িগঙ্গা নদীর তীরে অবস্থিত ঢাকা একটি ঐতিহাসিক নগরী। মোঘল আমলে এটি সুবাহ বাংলার রাজধানী জাহাঙ্গীরনগর হিসেবে প্রসিদ্ধ ছিল। বর্তমানে এটি বিশ্বের অন্যতম জনবহুল এবং দ্রুত বর্ধনশীল মেগাসিটি।",
            fullExplanationEn = "Situated beside the Buriganga River, Dhaka has historical roots as Mughal Bengal's capital Jahangirnagar. Today it is the political, economic, and cultural center of Bangladesh.",
            keyFacts = listOf("Capital of Bangladesh", "Located on Buriganga River", "Historically known as Jahangirnagar")
        ),

        GeneralKnowledgeTopic(
            id = "speed_of_light",
            keywords = listOf("speed of light", "আলোর গতি", "আলোর বেগ", "light speed", "299792458"),
            titleBn = "শূন্য মাধ্যমে আলোর গতি (Speed of Light in Vacuum)",
            titleEn = "Speed of Light in Vacuum",
            category = "SCIENCE",
            shortSummaryBn = "শূন্য মাধ্যমে আলোর গতি প্রতি সেকেন্ডে প্রায় ২,৯৯,৭৯২ কিলোমিটার (২,৯৯,৭৯২,৪৫৮ মিটার/সেকেন্ড)।",
            shortSummaryEn = "The speed of light in vacuum is an exact physical constant: 299,792,458 meters per second (approximately 300,000 km/s).",
            fullExplanationBn = "পদার্থবিজ্ঞানে আলোর দ্রুতিকে 'c' প্রতীক দ্বারা প্রকাশ করা হয়। এটি মহাবিশ্বের সর্বোচ্চ গতিসীমা। আইনস্টাইনের বিশেষ আপেক্ষিকতা তত্ত্ব অনুযায়ী কোনো ভরযুক্ত বস্তু আলোর চেয়ে দ্রুত গতিতে চলতে পারে না। বিখ্যাত সূত্র E = mc² তে এই আলোর দ্রুতি ব্যবহৃত হয়েছে।",
            fullExplanationEn = "Denoted by 'c', the speed of light in vacuum is the universal physical speed limit. According to Einstein's Special Relativity, no particle with rest mass can accelerate to or exceed this speed.",
            keyFacts = listOf("Exact speed: 299,792,458 m/s", "Universal constant denoted by 'c'", "Cornerstone of Special Relativity (E=mc²)")
        ),

        GeneralKnowledgeTopic(
            id = "water_cycle",
            keywords = listOf("water cycle", "পানি চক্র", "বৃষ্টি কীভাবে হয়", "how rain forms", "hydrological cycle", "বাষ্পীভবন"),
            titleBn = "পানি চক্র ও বৃষ্টি তৈরির প্রক্রিয়া (The Water Cycle)",
            titleEn = "The Water Cycle (Hydrological Cycle)",
            category = "SCIENCE",
            shortSummaryBn = "পানি চক্র হলো পৃথিবীর পৃষ্ঠ ও বায়ুমণ্ডলের মধ্যে পানির বাষ্পীভবন, ঘনীভবন ও বৃষ্টিপাত আকারে চক্রাকার আবর্তন।",
            shortSummaryEn = "The water cycle describes the continuous movement of water on, above, and below the surface of the Earth via evaporation, condensation, and precipitation.",
            fullExplanationBn = "১. বাষ্পীভবন (Evaporation): সূর্যের তাপে নদী, সমুদ্র ও জলাশয়ের পানি বাষ্পীভূত হয়ে বায়ুমণ্ডলে ওঠে।\n২. ঘনীভবন (Condensation): ওপরে উঠে ঠান্ডা হয়ে জলীয় বাষ্প মেঘে পরিণত হয়।\n৩. বৃষ্টিপাত (Precipitation): মেঘের জলকণা ভারি হয়ে বৃষ্টি বা তুষার আকারে ভূপৃষ্ঠে পতিত হয়।\n৪. সংগ্রহ (Collection): পতিত পানি আবার নদী ও ভূগর্ভস্থ জলাধারে ফিরে এসে পুনরায় চক্র শুরু করে।",
            fullExplanationEn = "Driven by solar energy, water evaporates from oceans and rivers, condenses into clouds in cooler atmospheric layers, and falls back to Earth as precipitation (rain or snow), sustaining terrestrial ecosystems.",
            keyFacts = listOf("Phases: Evaporation, Condensation, Precipitation", "Driven by solar thermal energy", "Maintains Earth's freshwater balance")
        ),

        GeneralKnowledgeTopic(
            id = "internet_computing",
            keywords = listOf("internet", "ইন্টারনেট", "world wide web", "www", "টিম বার্নার্স লি", "how internet works"),
            titleBn = "ইন্টারনেট ও ওয়ার্ল্ড ওয়াইড ওয়েব (The Internet & World Wide Web)",
            titleEn = "The Internet & World Wide Web",
            category = "TECH",
            shortSummaryBn = "ইন্টারনেট হলো বিশ্বজুড়ে লক্ষ লক্ষ কম্পিউটারের একটি আন্তঃসংযুক্ত বৈশ্বিক নেটওয়ার্ক যা TCP/IP প্রোটোকলের মাধ্যমে তথ্য বিনিময় করে।",
            shortSummaryEn = "The Internet is a globally connected network of computers that communicates using the standardized Internet Protocol Suite (TCP/IP).",
            fullExplanationBn = "১৯৬০-এর দশকে মার্কিন সামরিক গবেষণার ARPANET প্রকল্পের মাধ্যমে ইন্টারনেটের সূচনা হয়। ১৯৮৯ সালে ব্রিটিশ বিজ্ঞানী স্যার টিম বার্নার্স-লি (Tim Berners-Lee) সার্ন-এ (CERN) ওয়ার্ল্ড ওয়াইড ওয়েব (WWW) উদ্ভাবন করেন। এটি ডেটা প্যাকেট আদান-প্রদান এবং অপটিক্যাল ফাইবার, রাউটার ও স্যাটেলাইটের মাধ্যমে কাজ করে।",
            fullExplanationEn = "Originating from the ARPANET project, the Internet grew into a global communication network. In 1989, Sir Tim Berners-Lee invented the World Wide Web, creating the hyperlinked infrastructure enabling modern digital society.",
            keyFacts = listOf("Uses TCP/IP protocol", "WWW invented by Tim Berners-Lee in 1989", "Interconnects global digital systems")
        )
    )

    fun findGeneralKnowledge(query: String): GeneralKnowledgeTopic? {
        val lower = query.lowercase(Locale.ROOT).trim()

        for (topic in topics) {
            if (topic.id == lower ||
                topic.keywords.any { lower.contains(it.lowercase(Locale.ROOT)) } ||
                lower.contains(topic.titleBn.lowercase(Locale.ROOT)) ||
                lower.contains(topic.titleEn.lowercase(Locale.ROOT))) {
                return topic
            }
        }

        // Token match
        val tokens = lower.split("\\s+".toRegex()).filter { it.length > 2 }
        for (token in tokens) {
            for (topic in topics) {
                if (topic.keywords.any { it.contains(token, ignoreCase = true) }) {
                    return topic
                }
            }
        }

        return null
    }

    fun getAllTopics(): List<GeneralKnowledgeTopic> = topics

    /**
     * Evaluates direct arithmetic expressions (e.g., 25 * 4, 15 + 35, 100 / 4)
     * returns Pair(BengaliAnswer, EnglishAnswer) or null if not an arithmetic expression.
     */
    fun tryEvaluateMath(query: String): Pair<String, String>? {
        val q = query.trim().lowercase(Locale.ROOT)
            .replace("?", "")
            .replace("কত", "")
            .replace("calculate", "")
            .replace("what is", "")
            .replace("হিসাব করো", "")
            .replace("মান কত", "")
            .replace("সমাধান করো", "")
            .trim()

        val mathRegex = "^([0-9]+(?:\\.[0-9]+)?)\\s*([+\\-*×/÷])\\s*([0-9]+(?:\\.[0-9]+)?)$".toRegex()
        val match = mathRegex.find(q) ?: return null

        val num1 = match.groupValues[1].toDoubleOrNull() ?: return null
        val op = match.groupValues[2]
        val num2 = match.groupValues[3].toDoubleOrNull() ?: return null

        val result = when (op) {
            "+", "যোগ" -> num1 + num2
            "-", "বিয়োগ" -> num1 - num2
            "*", "×", "গুণ" -> num1 * num2
            "/", "÷", "ভাগ" -> if (num2 != 0.0) num1 / num2 else Double.NaN
            else -> return null
        }

        val formattedResult = if (result % 1.0 == 0.0 && !result.isNaN()) result.toLong().toString() else result.toString()
        val expr = "${match.groupValues[1]} $op ${match.groupValues[3]}"

        val bnAnswer = "গাণিতিক হিসাবের ফলাফল:\n$expr = $formattedResult"
        val enAnswer = "Mathematical calculation result:\n$expr = $formattedResult"
        return bnAnswer to enAnswer
    }
}
