package com.example.domain.ai

import java.util.Locale

/**
 * Categorizes the structural complexity of a user inquiry to enforce
 * appropriate answer length and depth.
 */
enum class QuestionComplexity {
    SIMPLE_FACTUAL,       // Direct fact, single entity, arithmetic, definition
    CONVERSATIONAL,       // Greeting, identity, brief status check
    MODERATE,             // Daily practice, story summary, practical application
    COMPLEX_REASONING,    // Philosophical comparison, deep exegesis, multi-part query
    CREATIVE_COMPOSITION  // Essay, poetry, study notes
}

enum class QualityIssueType {
    IRRELEVANT_CONTENT,
    CONTEXT_MISMATCH,
    PRONOUN_UNRESOLVED,
    TOPIC_BLEEDING,
    REPETITIVE_CONTENT,
    EXCESSIVE_VERBOSITY,
    INSUFFICIENT_COMPLETENESS,
    ROBOTIC_PHRASING,
    REPEATING_USER_QUESTION,
    REPEATED_SELF_INTRODUCTION,
    UNSUPPORTED_OR_FABRICATED_CLAIM,
    SCRIPTURE_MANTRA_FABRICATION,
    CONTRADICTION_DETECTED,
    UNVERIFIED_UNCERTAIN_DETAIL,
    FORCED_RELIGIOUS_IN_SECULAR
}

enum class IssueSeverity {
    LOW,
    MEDIUM,
    HIGH,
    CRITICAL
}

data class QualityIssue(
    val type: QualityIssueType,
    val description: String,
    val suggestedFix: String? = null,
    val severity: IssueSeverity = IssueSeverity.MEDIUM
)

data class AnswerQualityEvaluationResult(
    val isPassed: Boolean,
    val overallScore: Int,                 // 0-100
    val relevanceScore: Int,               // 0-100
    val contextScore: Int,                 // 0-100
    val factualAccuracyScore: Int,         // 0-100
    val logicalConsistencyScore: Int,      // 0-100
    val clarityScore: Int,                 // 0-100
    val naturalnessScore: Int,             // 0-100
    val lengthAppropriatenessScore: Int,   // 0-100
    val hallucinationRiskScore: Int,       // 0-100 (0 = safe, 100 = high risk)
    val questionComplexity: QuestionComplexity,
    val detectedIssues: List<QualityIssue>,
    val needsCorrection: Boolean,
    val isUncertain: Boolean = false,
    val uncertaintyReason: String? = null
)

object AnswerQualityEvaluator {

    /**
     * Determines question complexity to guide appropriate answer length and format.
     */
    fun determineComplexity(
        query: String,
        intent: IntentAnalysisResult,
        contextState: ConversationContextState
    ): QuestionComplexity {
        val lower = query.lowercase(Locale.ROOT).trim()

        // 1. Creative composition requests
        if (intent.creativeWritingType != CreativeWritingType.NONE) {
            return QuestionComplexity.CREATIVE_COMPOSITION
        }

        // 2. Conversational greetings, creator, identity
        if (intent.primaryIntent in listOf(
                QuestionIntentType.GREETING,
                QuestionIntentType.CREATOR_IDENTITY,
                QuestionIntentType.AI_IDENTITY,
                QuestionIntentType.SYSTEM_HEALTH_CHECK
            )
        ) {
            return QuestionComplexity.CONVERSATIONAL
        }

        // 3. Simple Factual & Arithmetic
        val isMath = lower.matches(".*\\b(\\d+\\s*[+\\-*/^%]\\s*\\d+)\\b.*".toRegex()) ||
                lower.contains("calculate") || lower.contains("গণনা")
        val isShortDirect = (lower.split("\\s+".toRegex()).size <= 12) &&
                (lower.startsWith("what is") || lower.startsWith("who is") || lower.startsWith("কী") ||
                        lower.startsWith("কে") || lower.startsWith("কখন") || lower.startsWith("কোথায়") ||
                        lower.startsWith("capital of") || lower.contains("capital") || lower.contains("রাজধানী") ||
                        lower.contains("সূত্র") || lower.contains("formula"))

        if (isMath || (isShortDirect && intent.primaryIntent == QuestionIntentType.GENERAL_KNOWLEDGE)) {
            return QuestionComplexity.SIMPLE_FACTUAL
        }

        // 4. Complex Reasoning: Philosophy comparisons, contradictions, exegesis
        val isPhilosophicalComparison = lower.contains("vs") || lower.contains("versus") || lower.contains("difference") ||
                lower.contains("পার্থক্য") || lower.contains("বনাম") || lower.contains("advaita") && lower.contains("dvaita") ||
                lower.contains("তুলনা") || lower.contains("কেন") && lower.contains("দার্শনিক")
        val isMultiPart = lower.contains(" and ") || lower.contains("এবং") || lower.contains("ও") || lower.contains("?") && lower.indexOf('?') != lower.lastIndexOf('?')
        val isExegesis = intent.primaryIntent == QuestionIntentType.PHILOSOPHY_AND_DARSHANA ||
                intent.styleRequest == ResponseStyleRequest.SCHOLARLY ||
                intent.styleRequest == ResponseStyleRequest.DETAILED

        if (isPhilosophicalComparison || (isMultiPart && isExegesis) || intent.primaryIntent == QuestionIntentType.PHILOSOPHY_AND_DARSHANA) {
            return QuestionComplexity.COMPLEX_REASONING
        }

        // 5. Moderate: standard questions
        return QuestionComplexity.MODERATE
    }

    /**
     * Comprehensively evaluates draft answer against all criteria in Step 5.
     */
    fun evaluateDraft(
        query: String,
        draftAnswer: String,
        contextState: ConversationContextState,
        intent: IntentAnalysisResult,
        hasCanonicalSource: Boolean,
        canonicalReference: String? = null,
        history: List<Pair<String, String>> = emptyList()
    ): AnswerQualityEvaluationResult {
        val issues = mutableListOf<QualityIssue>()
        val lowerQuery = query.lowercase(Locale.ROOT).trim()
        val lowerAnswer = draftAnswer.lowercase(Locale.ROOT).trim()
        val complexity = determineComplexity(query, intent, contextState)

        var relevanceScore = 100
        var contextScore = 100
        var factualAccuracyScore = 100
        var logicalConsistencyScore = 100
        var clarityScore = 100
        var naturalnessScore = 100
        var lengthScore = 100
        var hallucinationRiskScore = 0
        var isUncertain = false
        var uncertaintyReason: String? = null

        // -------------------------------------------------------------
        // 1. RELEVANCE CHECK
        // -------------------------------------------------------------
        if (draftAnswer.isBlank() || draftAnswer.length < 5) {
            issues.add(
                QualityIssue(
                    type = QualityIssueType.INSUFFICIENT_COMPLETENESS,
                    description = "Answer is empty or practically blank.",
                    severity = IssueSeverity.CRITICAL
                )
            )
            relevanceScore -= 80
            clarityScore -= 80
        }

        // Check if secular query has forced religious terms
        val isSecularQuery = intent.primaryIntent == QuestionIntentType.GENERAL_KNOWLEDGE ||
                contextState.activeDomain == "SCIENCE" || contextState.activeDomain == "TECH" ||
                lowerQuery.matches(".*\\b(gravity|photosynthesis|python|kotlin|capital of|math|25\\s*\\*|arithmetic)\\b.*".toRegex())

        if (isSecularQuery) {
            val religiousTriggers = listOf("মন্ত্র", "শ্লোক", "গীতা", "উপনিষদ", "কৃষ্ণ", "ভগবান", "ঈশ্বর কৃপা", "moksha", "shloka", "mantra", "oṁ")
            val hasForcedReligion = religiousTriggers.any { lowerAnswer.contains(it) }
            if (hasForcedReligion) {
                issues.add(
                    QualityIssue(
                        type = QualityIssueType.FORCED_RELIGIOUS_IN_SECULAR,
                        description = "Forced religious or scriptural concepts into a secular question.",
                        suggestedFix = "Remove religious terms and provide purely factual objective explanation.",
                        severity = IssueSeverity.CRITICAL
                    )
                )
                relevanceScore -= 50
                naturalnessScore -= 40
            }
        }

        // Core entity relevance
        val queryWords = lowerQuery.split("\\s+".toRegex()).filter { it.length > 3 && !it.contains("what") && !it.contains("কী") }
        if (queryWords.isNotEmpty() && intent.primaryIntent != QuestionIntentType.GREETING && intent.primaryIntent != QuestionIntentType.AI_IDENTITY) {
            val matches = queryWords.count { lowerAnswer.contains(it) }
            val hasTopicMatch = intent.detectedTopic?.let { topic ->
                val lowerTopic = topic.lowercase(Locale.ROOT)
                lowerAnswer.contains(lowerTopic) ||
                (lowerTopic.contains("gita") && (lowerAnswer.contains("গীতা") || lowerAnswer.contains("gita"))) ||
                (lowerTopic.contains("গীতা") && (lowerAnswer.contains("গীতা") || lowerAnswer.contains("gita"))) ||
                (lowerTopic.contains("krishna") && (lowerAnswer.contains("কৃষ্ণ") || lowerAnswer.contains("krishna"))) ||
                (lowerTopic.contains("shiva") && (lowerAnswer.contains("শিব") || lowerAnswer.contains("shiva"))) ||
                (lowerTopic.contains("karma") && (lowerAnswer.contains("কর্ম") || lowerAnswer.contains("karma"))) ||
                (lowerTopic.contains("dharma") && (lowerAnswer.contains("ধর্ম") || lowerAnswer.contains("dharma")))
            } ?: false

            if (matches == 0 && !hasTopicMatch && !lowerAnswer.contains("dharma") && !lowerAnswer.contains("ধর্ম") && contextState.activeSubject == null) {
                issues.add(
                    QualityIssue(
                        type = QualityIssueType.IRRELEVANT_CONTENT,
                        description = "Answer does not appear to reference key entities from the user's question.",
                        severity = IssueSeverity.HIGH
                    )
                )
                relevanceScore -= 40
            }
        }

        // -------------------------------------------------------------
        // 2. CONTEXT CONSISTENCY & PRONOUN RESOLUTION
        // -------------------------------------------------------------
        if (contextState.threadTurnCount > 0 && contextState.previousTopic != null && contextState.activeSubject != null) {
            // Check for topic bleeding
            if (contextState.previousTopic != contextState.activeSubject &&
                !lowerQuery.contains(contextState.previousTopic!!.lowercase(Locale.ROOT)) &&
                lowerAnswer.contains(contextState.previousTopic!!.lowercase(Locale.ROOT)) &&
                intent.primaryIntent != QuestionIntentType.FOLLOW_UP_MODIFICATION
            ) {
                issues.add(
                    QualityIssue(
                        type = QualityIssueType.TOPIC_BLEEDING,
                        description = "Accidentally dragged previous topic '${contextState.previousTopic}' into new subject '${contextState.activeSubject}'.",
                        suggestedFix = "Purge mention of the old topic and focus on current active subject.",
                        severity = IssueSeverity.HIGH
                    )
                )
                contextScore -= 45
            }
        }

        // Check if pronoun remains unresolved or echoed verbatim
        if ((lowerQuery.contains("his") || lowerQuery.contains("her") || lowerQuery.contains("its") || lowerQuery.contains("তার") || lowerQuery.contains("এর") || lowerQuery.contains("তাঁর")) &&
            contextState.activeSubject != null
        ) {
            val subjectTokens = contextState.activeSubject!!.lowercase(Locale.ROOT)
                .split("\\s+".toRegex())
                .map { it.trim('(', ')', ',', '.') }
                .filter { it.length >= 3 && it != "lord" && it != "sri" && it != "shri" }
            val hasSubjectResolved = subjectTokens.any { lowerAnswer.contains(it) } ||
                    (contextState.activeDeity?.let { deity ->
                        deity.lowercase(Locale.ROOT).split("\\s+".toRegex())
                            .map { it.trim('(', ')', ',', '.') }
                            .filter { it.length >= 3 && it != "lord" && it != "sri" }
                            .any { lowerAnswer.contains(it) }
                    } ?: false)
            if (!hasSubjectResolved) {
                issues.add(
                    QualityIssue(
                        type = QualityIssueType.PRONOUN_UNRESOLVED,
                        description = "Follow-up question pronouns were not properly tied to '${contextState.activeSubject}'.",
                        suggestedFix = "Explicitly anchor the response to the subject.",
                        severity = IssueSeverity.MEDIUM
                    )
                )
                contextScore -= 25
            }
        }

        // -------------------------------------------------------------
        // 3. FACTUAL SAFETY & ANTI-HALLUCINATION
        // -------------------------------------------------------------
        val hasInventedMantraFlag = lowerAnswer.contains("fake_mantra") || lowerAnswer.contains("invented_verse") ||
                lowerAnswer.contains("কাল্পনিক মন্ত্র") || lowerAnswer.contains("বানোয়াট শ্লোক")
        if (hasInventedMantraFlag) {
            issues.add(
                QualityIssue(
                    type = QualityIssueType.SCRIPTURE_MANTRA_FABRICATION,
                    description = "Detected fabricated or invented mantra/verse flag.",
                    suggestedFix = "Replace with canonical scripture text or state that mantra is unverified.",
                    severity = IssueSeverity.CRITICAL
                )
            )
            factualAccuracyScore -= 70
            hallucinationRiskScore += 90
        }

        // Chapter/verse hallucination detector (e.g. Gita 25.100, Gita 19)
        val gitaChapterMatch = "gita\\s*([1-9][0-9]?)\\.?([0-9]+)?|গীতা\\s*([১-৯][০-৯]?)".toRegex(RegexOption.IGNORE_CASE)
            .find(lowerAnswer)
        if (gitaChapterMatch != null) {
            val chStr = gitaChapterMatch.groupValues[1].toIntOrNull()
            if (chStr != null && chStr > 18) {
                issues.add(
                    QualityIssue(
                        type = QualityIssueType.SCRIPTURE_MANTRA_FABRICATION,
                        description = "Detected non-existent chapter number '$chStr' in Bhagavad Gita (Gita has only 18 chapters).",
                        suggestedFix = "Correct chapter reference or remove invalid citation.",
                        severity = IssueSeverity.CRITICAL
                    )
                )
                factualAccuracyScore -= 60
                hallucinationRiskScore += 80
            }
        }

        // -------------------------------------------------------------
        // 4. NATURAL CONVERSATIONAL TONE & ANTI-ROBOTIC CHECKS
        // -------------------------------------------------------------
        // Repeated self-introduction check:
        val hasSelfIntro = lowerAnswer.contains("i am dharma ai") || lowerAnswer.contains("আমি dharma ai") ||
                lowerAnswer.contains("i am vedanova ai") || lowerAnswer.contains("আমি বেদনোভা")
        val isExplicitIdentityInquiry = intent.primaryIntent in listOf(
            QuestionIntentType.AI_IDENTITY,
            QuestionIntentType.CREATOR_IDENTITY
        ) || lowerQuery.contains("who are you") || lowerQuery.contains("তুমি কে")

        if (hasSelfIntro && !isExplicitIdentityInquiry && (contextState.threadTurnCount > 0 || history.isNotEmpty())) {
            issues.add(
                QualityIssue(
                    type = QualityIssueType.REPEATED_SELF_INTRODUCTION,
                    description = "Repeatedly introduces the AI in an ongoing conversation.",
                    suggestedFix = "Remove the self-introduction and answer directly.",
                    severity = IssueSeverity.MEDIUM
                )
            )
            naturalnessScore -= 30
        }

        // Repeating user question check:
        val startsWithEchoEn = lowerAnswer.startsWith("you asked:") || lowerAnswer.startsWith("you asked,") ||
                lowerAnswer.startsWith("regarding your question about")
        val startsWithEchoBn = lowerAnswer.startsWith("আপনি জানতে চেয়েছেন") || lowerAnswer.startsWith("আপনার প্রশ্ন ছিল") ||
                lowerAnswer.startsWith("আপনি জিজ্ঞেস করেছেন")
        if (startsWithEchoEn || startsWithEchoBn) {
            issues.add(
                QualityIssue(
                    type = QualityIssueType.REPEATING_USER_QUESTION,
                    description = "Answer unnecessarily echoes the user's question before answering.",
                    suggestedFix = "Strip the question echo and deliver the answer directly.",
                    severity = IssueSeverity.MEDIUM
                )
            )
            naturalnessScore -= 25
        }

        // Robotic clichés:
        val roboticPhrases = listOf(
            "as an ai language model",
            "as an artificial intelligence",
            "একটি এআই মডেল হিসেবে",
            "in conclusion, as previously stated",
            "based on my programmed algorithms"
        )
        for (phrase in roboticPhrases) {
            if (lowerAnswer.contains(phrase)) {
                issues.add(
                    QualityIssue(
                        type = QualityIssueType.ROBOTIC_PHRASING,
                        description = "Contains robotic cliché phrase: '$phrase'.",
                        suggestedFix = "Replace with human-like, natural conversational phrasing.",
                        severity = IssueSeverity.MEDIUM
                    )
                )
                naturalnessScore -= 25
            }
        }

        // Excessive repetition of identical sentences:
        val sentences = draftAnswer.split("।", "\n", ".").map { it.trim() }.filter { it.length > 20 }
        val duplicateSentences = sentences.groupingBy { it.lowercase(Locale.ROOT) }.eachCount().filter { it.value > 1 }
        if (duplicateSentences.isNotEmpty()) {
            issues.add(
                QualityIssue(
                    type = QualityIssueType.REPETITIVE_CONTENT,
                    description = "Detected redundant identical sentences repeated multiple times: ${duplicateSentences.keys.first().take(40)}...",
                    suggestedFix = "Deduplicate repeated sentences.",
                    severity = IssueSeverity.MEDIUM
                )
            )
            naturalnessScore -= 35
            clarityScore -= 25
        }

        // -------------------------------------------------------------
        // 5. ANSWER LENGTH CONTROL
        // -------------------------------------------------------------
        val wordCount = draftAnswer.split("\\s+".toRegex()).size

        when (complexity) {
            QuestionComplexity.SIMPLE_FACTUAL -> {
                // Should be direct and concise (< 50 words for math/simple facts unless requested detailed)
                val maxAllowedWords = if (lowerQuery.matches(".*\\b(\\d+\\s*[+\\-*/^%]\\s*\\d+)\\b.*".toRegex())) 40 else 100
                if (wordCount > maxAllowedWords && intent.styleRequest != ResponseStyleRequest.DETAILED) {
                    issues.add(
                        QualityIssue(
                            type = QualityIssueType.EXCESSIVE_VERBOSITY,
                            description = "Simple factual question received an overly long answer ($wordCount words).",
                            suggestedFix = "Condense to direct, concise factual response.",
                            severity = IssueSeverity.MEDIUM
                        )
                    )
                    lengthScore -= 35
                }
            }
            QuestionComplexity.CONVERSATIONAL -> {
                if (wordCount > 100 && intent.primaryIntent == QuestionIntentType.GREETING) {
                    issues.add(
                        QualityIssue(
                            type = QualityIssueType.EXCESSIVE_VERBOSITY,
                            description = "Casual greeting received an overly long response ($wordCount words).",
                            suggestedFix = "Keep greeting warm, natural, and brief.",
                            severity = IssueSeverity.LOW
                        )
                    )
                    lengthScore -= 20
                }
            }
            QuestionComplexity.COMPLEX_REASONING -> {
                if (wordCount < 40) {
                    issues.add(
                        QualityIssue(
                            type = QualityIssueType.INSUFFICIENT_COMPLETENESS,
                            description = "Complex philosophical/reasoning question received an overly short answer ($wordCount words).",
                            suggestedFix = "Provide structured, multi-dimensional explanation with textual grounding.",
                            severity = IssueSeverity.MEDIUM
                        )
                    )
                    lengthScore -= 30
                }
            }
            else -> {}
        }

        // -------------------------------------------------------------
        // 6. LOGICAL CONTRADICTION CHECK
        // -------------------------------------------------------------
        val hasContradiction = (lowerAnswer.contains("সর্বদা সত্য") && lowerAnswer.contains("কখনই সত্য নয়")) ||
                (lowerAnswer.contains("is always true") && lowerAnswer.contains("is never true")) ||
                (lowerAnswer.contains("is entirely personal") && lowerAnswer.contains("has no personal aspect whatsoever"))
        if (hasContradiction) {
            issues.add(
                QualityIssue(
                    type = QualityIssueType.CONTRADICTION_DETECTED,
                    description = "Detected conflicting/contradictory assertions in the same answer.",
                    suggestedFix = "Reconcile perspectives using Sampradaya distinction (e.g. Advaita vs Dvaita).",
                    severity = IssueSeverity.HIGH
                )
            )
            logicalConsistencyScore -= 50
        }

        // -------------------------------------------------------------
        // 7. UNCERTAINTY HANDLING
        // -------------------------------------------------------------
        val asksUncertainObscureFact = lowerQuery.contains("গোপন তথ্য") || lowerQuery.contains("অজ্ঞাত শ্লোক") ||
                lowerQuery.contains("secret verse") || lowerQuery.contains("obscure unknown") ||
                lowerQuery.contains("unknown sect") || intent.primaryIntent == QuestionIntentType.UNKNOWN_GROUNDING
        val alreadyAcknowledgedUncertainty = lowerAnswer.contains("not certain") || lowerAnswer.contains("unverified") ||
                lowerAnswer.contains("শতভাগ প্রামাণিক") || lowerAnswer.contains("অনুমানমূলক")
        if (asksUncertainObscureFact && !hasCanonicalSource && !alreadyAcknowledgedUncertainty) {
            isUncertain = true
            uncertaintyReason = "Specific obscure request lacks verified canonical citation."
            issues.add(
                QualityIssue(
                    type = QualityIssueType.UNVERIFIED_UNCERTAIN_DETAIL,
                    description = "Query requests unverified obscure detail. Epistemic humility required.",
                    suggestedFix = "Acknowledge uncertainty naturally instead of guessing.",
                    severity = IssueSeverity.MEDIUM
                )
            )
        }

        // Bound scores between 0 and 100
        relevanceScore = relevanceScore.coerceIn(0, 100)
        contextScore = contextScore.coerceIn(0, 100)
        factualAccuracyScore = factualAccuracyScore.coerceIn(0, 100)
        logicalConsistencyScore = logicalConsistencyScore.coerceIn(0, 100)
        clarityScore = clarityScore.coerceIn(0, 100)
        naturalnessScore = naturalnessScore.coerceIn(0, 100)
        lengthScore = lengthScore.coerceIn(0, 100)
        hallucinationRiskScore = hallucinationRiskScore.coerceIn(0, 100)

        val overallScore = ((relevanceScore * 2 + contextScore * 2 + factualAccuracyScore * 3 +
                logicalConsistencyScore + clarityScore + naturalnessScore + lengthScore) / 11)
            .coerceIn(0, 100)

        // A draft passes if there are no detected issues, overall score is high, and hallucination risk is low
        val hasBlockingIssues = issues.any { it.severity == IssueSeverity.CRITICAL || it.severity == IssueSeverity.HIGH }
        val isPassed = issues.isEmpty() && overallScore >= 80 && hallucinationRiskScore <= 20
        val needsCorrection = issues.isNotEmpty() || hasBlockingIssues || overallScore < 80 || hallucinationRiskScore > 20

        return AnswerQualityEvaluationResult(
            isPassed = isPassed,
            overallScore = overallScore,
            relevanceScore = relevanceScore,
            contextScore = contextScore,
            factualAccuracyScore = factualAccuracyScore,
            logicalConsistencyScore = logicalConsistencyScore,
            clarityScore = clarityScore,
            naturalnessScore = naturalnessScore,
            lengthAppropriatenessScore = lengthScore,
            hallucinationRiskScore = hallucinationRiskScore,
            questionComplexity = complexity,
            detectedIssues = issues,
            needsCorrection = needsCorrection,
            isUncertain = isUncertain,
            uncertaintyReason = uncertaintyReason
        )
    }
}
