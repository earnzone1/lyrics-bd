package com.example.domain.ai

import com.example.data.model.KnowledgeEntity
import java.util.Locale

data class CanonicalDharmaEntry(
    val id: String,
    val titleBn: String,
    val titleEn: String,
    val category: String, // VEDAS, UPANISHADS, GITA, RAMAYANA, MAHABHARATA, PURANAS, DARSHANA, YOGA, VEDANTA, MANTRAS, STOTRAS, FESTIVALS, TERMINOLOGY
    val primaryScripture: String,
    val chapterVerseRef: String,
    val sanskritText: String = "",
    val transliteration: String = "",
    val definitionBn: String,
    val definitionEn: String,
    val expositionBn: String,
    val expositionEn: String,
    val historicalBioBn: String = "",
    val historicalBioEn: String = "",
    val significanceBn: String,
    val significanceEn: String,
    val keyConcepts: List<String> = emptyList(),
    val crossReferences: List<String> = emptyList(),
    val sampradayaPerspectives: Map<String, String> = emptyMap()
) {
    fun toKnowledgeEntity(): KnowledgeEntity {
        val fullExplanation = buildString {
            append(expositionBn)
            if (historicalBioBn.isNotBlank()) {
                append("\n\n📜 **ঐতিহাসিক ও শাস্ত্রীয় প্রেক্ষাপট:**\n$historicalBioBn")
            }
            if (significanceBn.isNotBlank()) {
                append("\n\n🌟 **আধ্যাত্মিক তাৎপর্য:**\n$significanceBn")
            }
            if (sampradayaPerspectives.isNotEmpty()) {
                append("\n\n🏛️ **বিভিন্ন সম্প্রদায়ের দর্শন ও দৃষ্টিভঙ্গি:**")
                sampradayaPerspectives.forEach { (sampradaya, view) ->
                    append("\n• **$sampradaya:** $view")
                }
            }
        }

        return KnowledgeEntity(
            title = titleBn,
            category = category,
            subcategory = primaryScripture,
            language = "Bengali (বাংলা)",
            sanskritText = sanskritText,
            transliteration = transliteration,
            banglaMeaning = definitionBn,
            englishMeaning = definitionEn,
            explanation = fullExplanation,
            scripture = primaryScripture,
            chapter = "",
            verse = "",
            reference = chapterVerseRef,
            source = primaryScripture,
            sourceType = "Primary Canonical Scripture",
            verificationStatus = "Verified",
            confidenceScore = 0.99f,
            tags = (keyConcepts + crossReferences + listOf(titleEn, category)).joinToString(", "),
            createdBy = "Deep Canonical Knowledge Base",
            updatedBy = "Dharma AI Core Verification"
        )
    }
}

object DeepDharmaKnowledgeBase {

    private val canonicalEntries = listOf(
        // 1. KRISHNA
        CanonicalDharmaEntry(
            id = "krishna",
            titleBn = "শ্রীকৃষ্ণ (Lord Krishna)",
            titleEn = "Lord Krishna",
            category = "DEITY_AVATARA",
            primaryScripture = "শ্রীমদ্ভগবদ্গীতা, শ্রীমদ্ভাগবত পুরাণ (১০ম স্কন্ধ), মহাভারত",
            chapterVerseRef = "গীতা ৪.৭-৮, ১৮.৬৬; ভাগবত ১০.১.১",
            sanskritText = "यदा यदा हि धर्मस्य ग्लानिर्भवति भारत। अभ्युत्थानमधर्मस्य तदात्मानं सृजाम्यहम्॥",
            transliteration = "Yadā yadā hi dharmasya glānirbhavati bhārata | Abhyutthānamadharmasya tadātmānaṁ sṛjāmyaham ||",
            definitionBn = "শ্রীকৃষ্ণ সনাতন ধর্মে পূর্ণ পুরুষোত্তম পরমেশ্বর ভগবান এবং পরম তত্ত্ব (পরব্রহ্ম)। তিনি শ্রীমদ্ভগবদ্গীতার দিব্য প্রবক্তা এবং ধর্মসংস্থাপক।",
            definitionEn = "Lord Krishna is the Supreme Personality of Godhead (Svayam Bhagavan) in Sanatan Dharma, the divine speaker of the Bhagavad Gita, and the supreme protector and restorer of Dharma.",
            expositionBn = "দ্বাপর যুগের শেষভাগে মথুরায় কংসের কারাগারে শ্রীকৃষ্ণের আবির্ভাব ঘটে। গোকুল ও বৃন্দাবনে তাঁর বাল্যলীলা ও গোপীদের সঙ্গে অপ্রাকৃত প্রেমলীলা ভক্তিতত্ত্বের পরাকাষ্ঠা। পরবর্তীতে মথুরায় কংসবধ, দ্বারকা নগরী স্থাপন এবং মহাভারতের কুরুক্ষেত্র যুদ্ধে পাণ্ডবদের পক্ষে সারথি হিসেবে ধর্মযুদ্ধে নেতৃত্বদান ও অর্জুনকে দিব্য গীতার উপদেশ প্রদান তাঁর লীলার মূল অংশ।",
            expositionEn = "Lord Krishna manifested during the Dvapara Yuga in Mathura. His childhood pastimes in Vrindavan symbolize supreme devotional love (Madhurya Prema). In the Mahabharata war, as the divine charioteer to Arjuna, He delivered the eternal wisdom of the Bhagavad Gita on the battlefield of Kurukshetra, guiding righteousness to victory.",
            historicalBioBn = "পৌরাণিক ও ঐতিহাসিক শাস্ত্রীয় ধারা অনুসারে শ্রীকৃষ্ণ বৃষ্ণি/যদুবংশের রাজকুমার ছিলেন, যিনি দ্বাপর যুগে অধর্মের বিনাশ ও ধর্ম সংরক্ষণের জন্য অবতীর্ণ হয়েছিলেন। কুরুক্ষেত্র যুদ্ধ শেষে গান্ধারীর শাপ এবং পরবর্তীতে প্রভাস তীর্থে নিজ ধামে প্রত্যাবর্তনের মাধ্যমে দ্বাপর যুগের সমাপ্তি ও কলিযুগের সূচনা ঘটে।",
            historicalBioEn = "According to scriptural history, Krishna appeared in the Yadu dynasty in the Dvapara Yuga. He restored cosmic righteousness by vanquishing tyrannical rulers, guided the Pandavas through Kurukshetra, and His departure to His eternal abode marked the advent of Kali Yuga.",
            significanceBn = "শ্রীকৃষ্ণের গুরুত্ব সনাতন ধর্মের কেন্দ্রবিন্দুতে। তিনি গীতার মাধ্যমে নিষ্কাম কর্মযোগ, জ্ঞানযোগ ও শরণাগতি ভক্তিযোগের সমন্বয়ী পথ মানবজাতিকে উপহার দিয়েছেন। তিনি সকল জীবের পরম আশ্রয় ও মুক্তির উৎস।",
            significanceEn = "Krishna is of paramount importance because He harmonized Karma Yoga (selfless duty), Jnana Yoga (spiritual knowledge), and Bhakti Yoga (unconditional surrender) in the Bhagavad Gita, providing a universal roadmap for liberation.",
            keyConcepts = listOf("Purna Avatara", "Bhagavad Gita", "Nishkama Karma", "Sharanagati", "Vrindavana Leela", "Dharma Samsthapana"),
            crossReferences = listOf("gita", "mahabharata", "bhagavata", "vaishnavism"),
            sampradayaPerspectives = mapOf(
                "Gaudiya Vaishnavism" to "Svayam Bhagavan (Supreme Fountainhead of all Avataras)",
                "Advaita Vedanta" to "Saguna Brahman and Supreme Jagadguru who illuminates knowledge of the Atman",
                "Vishishtadvaita" to "Supreme Narayana descended in divine human form to redeem loving devotees"
            )
        ),

        // 2. BHAGAVAD GITA
        CanonicalDharmaEntry(
            id = "gita",
            titleBn = "শ্রীমদ্ভগবদ্গীতা (Bhagavad Gita)",
            titleEn = "Bhagavad Gita",
            category = "GITA",
            primaryScripture = "মহাভারত (ভীষ্ম পর্ব, অধ্যায় ২৩–৪০)",
            chapterVerseRef = "১৮টি অধ্যায়, ৭০০টি শ্লোক",
            sanskritText = "कर्मण्येवाधिकारस्ते मा फलेषु कदाचन। मा कर्मफलहेतुर्भूर्मा ते सङ्गोऽस्त्वकर्मणि॥",
            transliteration = "Karmaṇyevādhikāraste mā phaleṣu kadācana | Mā karmaphalaheturbhūrmā te saṅgo'stvakarmaṇi || (BG 2.47)",
            definitionBn = "শ্রীমদ্ভগবদ্গীতা মহাভারতের ভীষ্মপর্বের অন্তর্গত ৭০০ শ্লোকবিশিষ্ট একটি সর্বজনীন ও প্রামাণিক শাস্ত্র, যা কুরুক্ষেত্রের রণক্ষেত্রে ভগবান শ্রীকৃষ্ণ অর্জুনকে উপদেশ দিয়েছিলেন।",
            definitionEn = "The Bhagavad Gita is a sacred 700-verse Hindu scripture comprising chapters 23–40 of the Bhishma Parva of the Mahabharata, spoken by Lord Krishna to Arjuna.",
            expositionBn = "গীতা মোট ১৮টি অধ্যায়ে বিভক্ত। প্রথম ৬টি অধ্যায়ে কর্মযোগ (স্বার্থহীন কর্ম ও মন নিয়ন্ত্রণ), মধ্যবর্তী ৬টি অধ্যায়ে ভক্তিযোগ (ভগবান ও শরণাগতি তত্ত্ব), এবং শেষ ৬টি অধ্যায়ে জ্ঞানযোগ (প্রকৃতি, পুরুষ ও পরমাত্মা তত্ত্ব) বিস্তারিতভাবে ব্যাখ্যা করা হয়েছে। জীবনের দ্বিধা, মোহ ও বিষাদ কাটিয়ে স্বধর্মে প্রতিষ্ঠিত হওয়ার অমর দর্শন গীতা।",
            expositionEn = "The Gita is structured in 18 chapters: Chapters 1-6 elaborate Karma Yoga; Chapters 7-12 illuminate Bhakti Yoga; Chapters 13-18 delve into Jnana Yoga. It serves as an eternal handbook for resolving moral dilemmas, mastering the mind, and achieving spiritual liberation.",
            significanceBn = "গীতা প্রস্থানত্রয়ী (উপনিষদ, ব্রহ্মসূত্র ও গীতা)-এর অন্যতম স্তম্ভ। এটি কোনো স্থান বা কালের মধ্যে সীমাবদ্ধ নয়; দৈনন্দিন কর্মজীবনের সঙ্গে গভীর আধ্যাত্মিক সত্যের নিখুঁত সমন্বয় প্রদান করে।",
            significanceEn = "As a pillar of the Prasthanatrayi, the Gita offers practical synthesis between mundane active life and the highest transcendental wisdom of self-realization.",
            keyConcepts = listOf("Nishkama Karma", "Sthitaprajna", "Atman Immortality", "Viswarupa Darshana", "Bhakti Surrender"),
            crossReferences = listOf("krishna", "mahabharata", "upanishads", "advaita")
        ),

        // 3. DHARMA (CONCEPT)
        CanonicalDharmaEntry(
            id = "dharma",
            titleBn = "ধর্ম (Dharma)",
            titleEn = "Dharma",
            category = "TERMINOLOGY",
            primaryScripture = "মহাভারত (কর্ণ পর্ব ৬৯.৫৮), বৈশেষিক সূত্র ১.১.২",
            chapterVerseRef = "ধারণাদ্ধর্মমিত্যাহুর্ধর্মেণ বিধৃতাঃ প্রজাঃ",
            sanskritText = "धारणाद्धर्म इत्याहुर्धर्मेण विधृताः प्रजाः। यत्स्याद्धारणसंयुक्तं स धर्म इति निश्चयः॥",
            transliteration = "Dhāraṇāddharma ityāhurdharmeṇa vidhṛtāḥ prajāḥ | Yatsyāddhāraṇasaṁyuktaṁ sa dharma iti niścayaḥ ||",
            definitionBn = "ধর্ম শব্দটি সংস্কৃত 'ধৃ' ধাতু থেকে নিষ্পন্ন, যার অর্থ ধারণ করা। যা বিশ্বব্রহ্মাণ্ড, সমাজ ও ব্যক্তিসত্ত্বাকে বিশৃঙ্খলা থেকে ধারণ করে ও সার্বিক ভারসাম্য রক্ষা করে, তাই ধর্ম।",
            definitionEn = "Dharma originates from the Sanskrit root 'Dhri' (to uphold/sustain). It signifies the cosmic order, righteousness, moral duty, and inherent nature that sustains creation.",
            expositionBn = "সনাতন দর্শনে ধর্ম কেবল ধর্মীয় আচার নয়। এর চারটি প্রধান প্রকার: ১) সনাতন ধর্ম (শাশ্বত মহাজাগতিক সত্য), ২) বর্ণাশ্রম/স্বধর্ম (ব্যক্তির যোগ্যতা ও জীবনের পর্যায়ভিত্তিক কর্তব্য), ৩) সাধারণ ধর্ম (অহিংসা, সত্য, অস্তেয়, শৌচ, ইন্দ্রিয়নিগ্রহ প্রভৃতি সর্বজনীন নৈতিক গুণাবলী), ৪) আপদ্ধর্ম (সংকটের সময় বিশেষ বিধান)।",
            expositionEn = "In Vedic thought, Dharma encompasses: 1) Sanatana Dharma (eternal cosmic truth), 2) Svadharma (personal inherent duties), 3) Sadharana Dharma (universal ethical virtues like non-violence, truth, cleanliness), and 4) Apaddharma (special conduct during acute crisis).",
            significanceBn = "চতুর্বর্গের (ধর্ম, অর্থ, কাম, মোক্ষ) প্রথম ও প্রধান ভিত্তি হলো ধর্ম। ধর্মভিত্তিক অর্থ ও কামই মানুষকে মোক্ষের পথে চালিত করে।",
            significanceEn = "Dharma is the foremost of the Purusharthas (Dharma, Artha, Kama, Moksha), providing the ethical bedrock necessary for spiritual liberation.",
            keyConcepts = listOf("Purushartha", "Svadharma", "Sadharana Dharma", "Ritam", "Satya"),
            crossReferences = listOf("karma", "moksha", "gita", "upanishads")
        ),

        // 4. KARMA (CONCEPT)
        CanonicalDharmaEntry(
            id = "karma",
            titleBn = "কর্ম ও কর্মফল তত্ত্ব (Karma Theory)",
            titleEn = "Karma and Rebirth",
            category = "TERMINOLOGY",
            primaryScripture = "বৃহদারণ্যক উপনিষদ ৪.৪.৫, শ্রীমদ্ভগবদ্গীতা ২.৪৭ ও ৩.৯",
            chapterVerseRef = "যথাচারী তথা ভবতি সাধুকারী সাধুর্ভবতি",
            sanskritText = "यथाकारी यथाचारी तथा भवति साधुकारी साधुर्भवति पापकारी पापो भवति।",
            transliteration = "Yathākārī yathācārī tathā bhavati sādhukārī sādhurbhavati pāpakārī pāpo bhavati | (Brihadaranyaka 4.4.5)",
            definitionBn = "কর্ম তত্ত্ব হলো কারণ ও ফলাফলের মহাজাগতিক বিধান। প্রত্যেক চিন্তা, বাক্য ও কর্মের একটি সুনির্দিষ্ট প্রতিক্রিয়া বা ফল সৃষ্টি হয়, যা জীবকে ভোগ করতে হয়।",
            definitionEn = "The Law of Karma is the universal principle of cause and effect: every thought, word, and action generates a corresponding result that shapes one's present and future existence.",
            expositionBn = "কর্ম মূলত তিন প্রকার: ১) সঞ্চিত কর্ম (পূর্বজন্মসমূহের পুঞ্জীভূত সংস্কার), ২) প্রারব্ধ কর্ম (বর্তমান জীবনে ভোগের জন্য উন্মোচিত অংশ), ৩) ক্রিয়মাণ/আগামী কর্ম (বর্তমান জীবনে যেসব নতুন কর্ম মানুষ করছে)। নিষ্কাম কর্মযোগ ও আত্মজ্ঞানের মাধ্যমে সঞ্চিত ও আগামী কর্মের বন্ধন বিনষ্ট হয়।",
            expositionEn = "Karma is classified into: 1) Sanchita Karma (accumulated past impressions), 2) Prarabdha Karma (fructifying karma currently being experienced), and 3) Agami/Kriyamana Karma (actions currently being performed). Selfless devotion and spiritual realization dissolve the bondage of karma.",
            significanceBn = "কর্মবাদ ব্যক্তির নিজের ভাগ্যের দায়িত্ব নিজের হাতে তুলে দেয়। এটি নিয়তিবাদ নয়, বরং সচেতন সদ্ব্যবহার ও নিষ্কাম কর্মের মাধ্যমে আত্মউন্নয়নের পথ নির্দেশ করে।",
            significanceEn = "Karma empowers the individual with total moral accountability, replacing fatalism with conscious self-mastery and spiritual elevation.",
            keyConcepts = listOf("Sanchita", "Prarabdha", "Kriyamana", "Nishkama Karma", "Samsara"),
            crossReferences = listOf("dharma", "moksha", "gita")
        ),

        // 4b. KARMA YOGA
        CanonicalDharmaEntry(
            id = "karma_yoga",
            titleBn = "কর্মযোগ ও নিষ্কাম কর্ম (Karma Yoga & Nishkama Karma)",
            titleEn = "Karma Yoga and Selfless Action",
            category = "GITA",
            primaryScripture = "শ্রীমদ্ভগবদ্গীতা (২য় ও ৩য় অধ্যায়)",
            chapterVerseRef = "গীতা ২.৪৭, ৩.৮, ৩.১৯",
            sanskritText = "कर्मण्येवाधिकारस्ते मा फलेषु कदाचन। मा कर्मफलहेतुर्भूर्मा ते सङ्गोऽस्त्वकर्मणि॥",
            transliteration = "Karmaṇyevādhikāraste mā phaleṣu kadācana | Mā karmaphalaheturbhūrmā te saṅgo'stvakarmaṇi || (Gita 2.47)",
            definitionBn = "কর্মযোগ হলো কর্মফলের প্রতি আসক্তি বর্জন করে ঈশ্বরার্পিত চিত্তে বা লোকহিতার্থে নিঃস্বার্থভাবে কর্তব্য কর্ম সম্পাদনের সনাতন আধ্যাত্মিক পথ।",
            definitionEn = "Karma Yoga is the spiritual discipline of performing duty selflessly without attachment to the results, offering actions to the Divine.",
            expositionBn = "শ্রীমদ্ভগবদ্গীতায় ভগবান শ্রীকৃষ্ণ নিষ্ক্রিয়তা বা কর্মত্যাগের পরিবর্তে অনাসক্তভাবে কর্ম করার শিক্ষা দিয়েছেন। গীতায় বলা হয়েছে কর্মফল ত্যাগ করাই প্রকৃত যোগ। নিঃস্বার্থ কর্মের মাধ্যমে চিত্তশুদ্ধি ঘটে এবং জীব বন্ধনহীন হয়ে আত্মজ্ঞানের অধিকারী হয়।",
            expositionEn = "Lord Krishna teaches in the Bhagavad Gita that selfless action without attachment to fruits purifies the mind and leads to liberation without creating karmic bondages.",
            significanceBn = "কর্মযোগ দৈনন্দিন জীবনের কর্মক্ষেত্রে প্রতিটি কাজকে পূজায় রূপান্তরিত করে। এটি কর্মহীন সন্ন্যাস নয়, বরং কর্মের মাঝে পরম অনাসক্তি।",
            significanceEn = "Karma Yoga harmonizes active daily duties with high spiritual consciousness, teaching duty with inner detached peace.",
            keyConcepts = listOf("Karma Yoga", "Nishkama Karma", "কর্মযোগ", "নিষ্কাম কর্ম", "কর্ম যোগ", "দৈনন্দিন জীবনে প্রয়োগ", "Gita 2.47"),
            crossReferences = listOf("gita", "karma", "krishna", "dharma")
        ),

        // 5. SHIVA (DEITY & PHILOSOPHY)
        CanonicalDharmaEntry(
            id = "shiva",
            titleBn = "মহাদেব শিব (Lord Shiva)",
            titleEn = "Lord Shiva (Mahadeva)",
            category = "DEITY_AVATARA",
            primaryScripture = "শ্বেতাশ্বতর উপনিষদ, শ্রী রুদ্রম (যজুর্বেদ), শিব পুরাণ",
            chapterVerseRef = "শ্বেতাশ্বতর ৩.১১, ৩.২০; ঋগ্বেদ ৭.৫৯.১২",
            sanskritText = "ॐ नमः शिवाय। त्र्यम्बकं यजामहे सुगन्धिं पुष्टिवर्धनम्।",
            transliteration = "Om Namaḥ Śivāya | Tryambakaṁ yajāmahe sugandhiṁ puṣṭivardhanam ||",
            definitionBn = "মহাদেব শিব সনাতন ধর্মে পরম মঙ্গলময়, নিষ্কল ব্রহ্ম এবং ত্রিমূর্তির অন্তর্গত সংহারকর্তা ও পরম যোগীশ্বর।",
            definitionEn = "Lord Shiva is the Supreme Auspicious Divinity (Mahadeva), the primordial ascetic (Yogeshwara), the embodiment of pure consciousness, and the cosmic transformer.",
            expositionBn = "কৈলাসবাসী শিব ত্যাগ, তপস্যা, ক্ষমা ও বৈরাগ্যের মূর্ত প্রতীক। তিনি আশুতোষ (দ্রুত সন্তুষ্ট হন) এবং ভোলেবাবা। সংহারকর্তা রূপে তিনি সৃষ্টির মোহ ও অন্ধকার ধ্বংস করে পুনরায় নতুনের সূচনা করেন। শিবের পঞ্চাক্ষর মন্ত্র 'ॐ নমঃ শিবায়' এবং মহামৃত্যুঞ্জয় মন্ত্র অশুভ নাশ ও মোক্ষ লাভে অতুলনীয়।",
            expositionEn = "Shiva symbolizes supreme detachment, meditation, and cosmic dance (Nataraja). As the transformer, He dissolves ignorance and ego, leading the seeker to transcendent pure awareness.",
            significanceBn = "শৈবধর্ম ও ভারতীয় যোগদর্শনের কেন্দ্রবিন্দুতে মহাদেব শিব বিরাজমান। মহাশিবরাত্রি তাঁর প্রধান ব্রত।",
            significanceEn = "Shiva is the primordial master of Yoga and supreme focal point of Shaiva philosophy.",
            keyConcepts = listOf("Panchakshara", "Maha Mrityunjaya", "Nataraja", "Ardhanarishvara", "Shivaratri"),
            crossReferences = listOf("upanishads", "darshanas", "yoga")
        ),

        // 6. GAYATRI MANTRA
        CanonicalDharmaEntry(
            id = "gayatri",
            titleBn = "গায়ত্রী মহামন্ত্র (Gayatri Mantra)",
            titleEn = "Gayatri Mantra",
            category = "MANTRAS",
            primaryScripture = "ঋগ্বেদ (মণ্ডল ৩, সূক্ত ৬২, ঋক ১০), যজুর্বেদ",
            chapterVerseRef = "ঋষি: বিশ্বামিত্র, ছন্দ: গায়ত্রী, দেবতা: সবিতৃ",
            sanskritText = "ॐ भूर्भुवः स्वः तत्सवितुर्वरेण्यं भर्गो देवस्य धीमहि धियो यो नः प्रचोदयात्॥",
            transliteration = "Oṁ Bhūr Bhuvaḥ Svaḥ Tat Savitur Vareṇyaṁ Bhargo Devasya Dhīmahi Dhiyo Yo Naḥ Pracodayāt ||",
            definitionBn = "গায়ত্রী মহামন্ত্র বেদের সার এবং সনাতন ধর্মের সর্বপ্রধান বৈদিক আলোকবর্ষী প্রার্থনা। এটি দিব্য জ্ঞান ও প্রজ্ঞার জাগরণের জন্য সূর্যদেব সবিতার প্রতি নিবেদিত।",
            definitionEn = "The Gayatri Mantra is the quintessential Vedic prayer from the Rigveda (3.62.10) addressed to Savitr (the divine illuminator) for enlightenment of the intellect.",
            expositionBn = "মন্ত্রটির সারার্থ: 'আমরা সেই পরম তেজস্বী, সর্বস্রষ্টা সবিতৃ দেবের দিব্য জ্যোতিকে ধ্যান করি; তিনি আমাদের বুদ্ধিবৃত্তিকে সত্য ও ধর্মের পথে পরিচালিত করুন।' এই মন্ত্র জপের মাধ্যমে মানসিক একাগ্রতা, আত্মিক শুদ্ধি ও দিব্য মেধা বিকশিত হয়।",
            expositionEn = "Meaning: 'We meditate on that adorable transcendental effulgence of the Divine Creator Savitr; may He illuminate and direct our intellect.' It purifies consciousness and bestows wisdom.",
            significanceBn = "গায়ত্রী মন্ত্র ত্রিসন্ধ্যা এবং নিয়মিত জপের সর্বশ্রেষ্ঠ বৈদিক ভিত্তি। এটি সকল বৈদিক জ্ঞানের জননী স্বরূপ।",
            significanceEn = "Revered as the mother of the Vedas, Gayatri Japa is foundational to spiritual disciplines across all classical traditions.",
            keyConcepts = listOf("Savitr", "Vishvamitra", "Vedic Wisdom", "Sandhyavandanam", "Dhiyah Enlightenment"),
            crossReferences = listOf("vedas", "upanishads", "shiva")
        ),

        // 7. MAHA MRITYUNJAYA MANTRA
        CanonicalDharmaEntry(
            id = "mahamrityunjaya",
            titleBn = "মহামৃত্যুঞ্জয় মন্ত্র (Maha Mrityunjaya Mantra)",
            titleEn = "Maha Mrityunjaya Mantra",
            category = "MANTRAS",
            primaryScripture = "ঋগ্বেদ (৭.৫৯.১২), শুক্ল যজুর্বেদ (৩.৬০), তৈত্তিরীয় সংহিতা",
            chapterVerseRef = "ঋষি: মৃকণ্ডু / বশিষ্ঠ, দেবতা: ত্র্যম্বক (শিব)",
            sanskritText = "ॐ त्र्यम्बकं यजामहे सुगन्धिं पुष्टिवर्धनम्। उर्वारुकमिव बन्धनान्मृत्यschemaोर्मुक्षीय मामृतात्॥",
            transliteration = "Oṁ Tryambakaṁ yajāmahe sugandhiṁ puṣṭivardhanam | Urvārukamiva bandhanānmṛtyormukṣīya māmṛtāt ||",
            definitionBn = "মহামৃত্যুঞ্জয় মন্ত্র ঋগ্বেদের অন্যতম সঞ্জীবনী ও মোক্ষপ্রদায়ী মন্ত্র, যা মৃত্যুভয়, রোগ-ব্যাধি ও অকালমৃত্যুর হাত থেকে রক্ষা এবং আত্মিক অমৃতত্ত্বের জন্য শিবের উদ্দেশ্যে উচ্চারিত হয়।",
            definitionEn = "The Maha Mrityunjaya Mantra is the great death-conquering Rigvedic mantra dedicated to Tryambaka (Three-eyed Shiva) for healing, longevity, and liberation.",
            expositionBn = "অর্থ: 'আমরা ত্রিনেত্রযুক্ত, সুবাসিত ও পুষ্টিবর্ধক ভগবান শিবের আরাধনা করি। শশা বা খরমুজ যেমন পেকে গেলে সহজেই লতার বন্ধন থেকে মুক্ত হয়, তেমনি আমরা যেন সংসার ও মৃত্যুর বন্ধন থেকে মুক্ত হয়ে অমৃতত্ত্ব লাভ করি।' এটি গভীর দৈহিক ও মানসিক প্রশান্তি প্রদান করে।",
            expositionEn = "Essence: 'We worship the three-eyed Lord Shiva who is fragrant and nourishes all beings. As a ripe cucumber is effortlessly detached from the vine, may we be liberated from the bondage of mortality and attain immortality.'",
            significanceBn = "শারীরিক সুস্থতা, বিপদমুক্তি ও অন্তিম মোক্ষ লাভের জন্য এই মহামন্ত্রের জপ সনাতন ধর্মে অত্যন্ত প্রভাবশালী।",
            significanceEn = "Widely practiced for health, protection from fear and distress, and spiritual liberation from the cycle of birth and death.",
            keyConcepts = listOf("Tryambaka", "Amritatva", "Rudra Japa", "Healing & Peace"),
            crossReferences = listOf("shiva", "vedas")
        ),

        // 8. UPANISHADS & ADVAITA
        CanonicalDharmaEntry(
            id = "upanishads",
            titleBn = "মুখ্য উপনিষদ ও বেদান্ত দর্শন (Upanishads & Vedanta)",
            titleEn = "The Upanishads and Vedanta",
            category = "UPANISHADS",
            primaryScripture = "ঈশ, কেন, কঠ, প্রশ্ন, মুণ্ডক, মাণ্ডূক্য, তৈত্তিরীয়, ঐতরেয়, ছান্দোগ্য, বৃহদারণ্যক, শ্বেতাশ্বতর",
            chapterVerseRef = "চারটি মহাবাক্য: প্রজ্ঞানং ব্রহ্ম, অহং ব্রহ্মাস্মি, তত্ত্বমসি, অয়মাত্মা ব্রহ্ম",
            sanskritText = "तत्त्वमसि (छान्दोग्य ६.८.७) | अहं ब्रह्मास्मि (बृहदारण्यक १.४.१०) | सत्यं ज्ञानमनन्तं ब्रह्म (तैत्तिरीय २.१.१)",
            transliteration = "Tat Tvam Asi (Chandogya 6.8.7) | Aham Brahmāsmi (Brihadaranyaka 1.4.10)",
            definitionBn = "উপনিষদসমূহ বেদের জ্ঞানকাণ্ড বা বেদান্ত। এতে ব্রহ্ম, আত্মা, জগৎ এবং মুক্তির পরম সত্য বৈজ্ঞানিক ও দার্শনিক যুক্তির মাধ্যমে উন্মোচিত হয়েছে।",
            definitionEn = "The Upanishads represent the culmination of Vedic wisdom (Vedanta), expounding the non-dual truth of Brahman, Atman, and transcendent realization.",
            expositionBn = "উপনিষদের কেন্দ্রীয় শিক্ষা হলো: জীবাত্মা এবং পরমব্রহ্ম মৌলিকভাবে অভিন্ন। মায়া বা অবিদ্যাবশত মানুষ নিজেকে দেহ-মন রূপে সীমাবদ্ধ মনে করে সংসার চক্রে আবর্তিত হয়। আত্মজ্ঞানের মাধ্যমে অহংকারের বিলুপ্তি ঘটলে পরম নির্বাণ বা মোক্ষ লাভ হয়। শঙ্করাচার্যের অদ্বৈত বেদান্ত, রামানুজের বিশিষ্টাদ্বৈত এবং মধ্বাচার্যের দ্বৈত দর্শনের উৎস এই উপনিষদ।",
            expositionEn = "The core thesis is the metaphysical reality of Brahman: pure, non-dual consciousness. Through self-inquiry (Atma Vichara) and spiritual realization, ignorance (Avidya) is dissolved, leading to Moksha.",
            significanceBn = "উপনিষদ বিশ্ব দর্শনের অমূল্য সম্পদ, যা শঙ্করাচার্য, স্বামী বিবেকানন্দ এবং আধুনিক বিজ্ঞানীদেরও গভীরভাবে অনুপ্রাণিত করেছে।",
            significanceEn = "The Upanishads provide the foundational metaphysics of Indian philosophy and universal spiritual self-realization.",
            keyConcepts = listOf("Brahman", "Atman", "Maya", "Mahavakyas", "Moksha", "Jnana"),
            crossReferences = listOf("advaita", "gita", "vedas")
        ),

        // 9. SIX ASTIKA DARSHANAS (6 PHILOSOPHIES)
        CanonicalDharmaEntry(
            id = "darshanas",
            titleBn = "ষড়দর্শন (Six Orthodox Philosophical Systems)",
            titleEn = "The Six Astika Darshanas",
            category = "DARSHANA",
            primaryScripture = "ন্যায় সূত্র (গৌতম), বৈশেষিক সূত্র (কণাদ), সাংখ্য সূত্র (কপিল), যোগ সূত্র (পতঞ্জলি), মীমাংসা সূত্র (জৈমিনি), ব্রহ্ম সূত্র (ব্যাস)",
            chapterVerseRef = "৬টি প্রামাণিক আস্তিক দর্শন",
            sanskritText = "न्याय-वैशेषिक-सांख्य-योग-मीमांसा-वेदान्त षड्दर्शनानि।",
            transliteration = "Nyāya, Vaiśeṣika, Sāṁkhya, Yoga, Mīmāṁsā, Vedānta ṣaḍdarśanāni",
            definitionBn = "সনাতন দর্শনের ৬টি আস্তিক ধারা যা বেদের প্রামাণ্য স্বীকার করে যুক্তিনির্ভর তত্ত্ব অনুসন্ধান করে: ন্যায়, বৈশেষিক, সাংখ্য, যোগ, পূর্ব মীমাংসা ও উত্তর মীমাংসা (বেদান্ত)।",
            definitionEn = "The Six Astika Darshanas are the six orthodox schools of Hindu philosophy that accept Vedic authority: Nyaya (logic), Vaisheshika (atomism), Samkhya (dual cosmology), Yoga (mind control/union), Mimamsa (ritual hermeneutics), and Vedanta (metaphysics).",
            expositionBn = "১) ন্যায়: প্রমাণ ও যুক্তির বিজ্ঞান। ২) বৈশেষিক: পদার্থের পরমাণুবাদীয় বিশ্লেষণ। ৩) সাংখ্য: পুরুষ (চৈতন্য) ও প্রকৃতি (জড়)-র দ্বৈত বিশ্লেষণ। ৪) যোগ: পতঞ্জলির অষ্টঅঙ্গ যোগ (যম, নিয়ম, আসন, প্রাণায়াম, প্রত্যাহার, ধারণা, ধ্যান, সমাধি)। ৫) পূর্ব মীমাংসা: বৈদিক যজ্ঞ ও ধর্মতত্ত্ব। ৬) বেদান্ত: উপনিষদের সার আত্মজ্ঞান ও ব্রহ্মতত্ত্ব।",
            expositionEn = "Each school addresses ontology, epistemology, and soteriology from a rigorous philosophical lens, guiding seekers from empirical logic to ultimate spiritual liberation.",
            significanceBn = "ষড়দর্শন ভারতীয় মেধার যৌক্তিকতা, গভীরতা ও শৃঙ্খলার শ্রেষ্ঠ নিদর্শন।",
            significanceEn = "They constitute the intellectual and contemplative framework of Indian classical philosophy.",
            keyConcepts = listOf("Pramana", "Purusha-Prakriti", "Ashtanga Yoga", "Brahma Sutras", "Logic & Realization"),
            crossReferences = listOf("yoga", "upanishads", "advaita")
        ),

        // 10. RAMAYANA
        CanonicalDharmaEntry(
            id = "ramayana",
            titleBn = "শ্রীমদ্ রামায়ণ (Ramayana)",
            titleEn = "The Ramayana",
            category = "RAMAYANA",
            primaryScripture = "বাল্মীকি রামায়ণ (৭টি কাণ্ড, ২৪,০০০ শ্লোক)",
            chapterVerseRef = "বালকাণ্ড, অযোধ্যাকাণ্ড, অরণ্যকাণ্ড, কিষ্কিন্ধাকাণ্ড, সুন্দরকাণ্ড, লঙ্কাকাণ্ড, উত্তরকাণ্ড",
            sanskritText = "रामो विग्रहवान् धर्मः साधुः सत्यपराक्रमः।",
            transliteration = "Rāmo vigrahavān dharmaḥ sādhuḥ satyaparākramaḥ | (Aranya Kanda 37.13)",
            definitionBn = "রামায়ণ হলো মহর্ষি বাল্মীকি রচিত ভারতের আদিকাব্য, যা মর্যাদা পুরুষোত্তম ভগবান শ্রীরামচন্দ্রের আদর্শ জীবন ও সত্যধর্মের প্রতিষ্ঠার ইতিহাস।",
            definitionEn = "The Ramayana is the Adi Kavya (first epic poem) composed by Sage Valmiki, narrating the virtuous life and righteous reign of Lord Rama (Maryada Purushottama).",
            expositionBn = "শ্রীরামচন্দ্র পিতৃভক্তি, সত্যনিষ্ঠা, একপত্নীব্রত ও প্রজাবাৎসল্যের চরম পরাকাষ্ঠা। সীতা মাতা সতিত্ব ও সহনশীলতার প্রতীক, লক্ষ্মণ ও ভরত ভ্রাতৃপ্রেমের আদর্শ, এবং ভক্ত হনুমানজি নিঃশর্ত সেবার পরাকাষ্ঠা। রাবণবধের মাধ্যমে অধর্মের ওপর সত্যের বিজয় অর্জিত হয়।",
            expositionEn = "Lord Rama exemplifies the embodiment of Dharma in human conduct as an ideal son, brother, husband, and king (Rama Rajya). The epic imparts timeless moral and spiritual lessons.",
            significanceBn = "পারিবারিক, সামাজিক ও রাষ্ট্রীয় জীবনে ধর্মের যথাযথ প্রয়োগের ক্ষেত্রে রামায়ণের শিক্ষা তুলনাহীন।",
            significanceEn = "The Ramayana serves as a foundational ethical compass for societal, familial, and personal righteousness.",
            keyConcepts = listOf("Maryada Purushottama", "Rama Rajya", "Hanuman Bhakti", "Pitri Bhakti", "Satya"),
            crossReferences = listOf("mahabharata", "dharma")
        ),

        // 11. MAHABHARATA
        CanonicalDharmaEntry(
            id = "mahabharata",
            titleBn = "মহাভারত (The Mahabharata)",
            titleEn = "The Mahabharata",
            category = "MAHABHARATA",
            primaryScripture = "কৃষ্ণ দ্বৈপায়ন বেদব্যাস রচিত মহাভারত (১৮টি পর্ব, ১,০০,০০০ শ্লোক)",
            chapterVerseRef = "আদি পর্ব থেকে স্বর্গারোহণ পর্ব; ভীষ্ম পর্বে গীতা; শান্তি পর্বে রাজধর্ম",
            sanskritText = "यतो धर्मस्ततो जयः। यन्नेहास्ति न कुत्रचित्।",
            transliteration = "Yato dharmastato jayaḥ | Yannehāsti na kutracit ||",
            definitionBn = "মহাভারত বিশ্বের সর্ববৃহৎ মহাকাব্য ও পঞ্চম বেদ হিসেবে গণ্য, যা মানবচরিত্রের সকল জটিলতা এবং ধর্মের সূক্ষ্ম গতি বিস্তারিতভাবে উন্মোচন করেছে।",
            definitionEn = "The Mahabharata is the monumental epic composed by Sage Vyasa, encompassing 100,000 verses across 18 Parvas, portraying the intricate dimensions of Dharma and human destiny.",
            expositionBn = "কুরু ও পাণ্ডবদের মধ্যকার সিংহাসনের দ্বন্দ্ব, পাশাখেলা, দ্রৌপদীর লাঞ্ছনা, বনবাস ও কুরুক্ষেত্রের ১৮ দিনের মহাযুদ্ধ এর মূল ঘটনাবলী। এর কেন্দ্রীয় বার্তা: 'যতো ধর্মস্ততো জয়ঃ' (যেখানে ধর্ম, সেখানেই জয়)। শান্তি পর্বে ভীষ্ম পিতামহ যুধিষ্ঠিরকে রাজধর্ম, মোক্ষধর্ম ও আপদ্ধর্মের গভীর শিক্ষা দিয়েছেন।",
            expositionEn = "Highlighting the Kurukshetra war and the discourse of Krishna's Bhagavad Gita, the Mahabharata declares that virtue ultimately triumphs over greed and adharma.",
            significanceBn = "মানুষের মনস্তত্ত্ব, রাজনীতি, ন্যায়শাস্ত্র ও আধ্যাত্মিকতার এমন পূর্ণাঙ্গ আকর বিশ্বসাহিত্যে বিরল।",
            significanceEn = "It serves as an encyclopedic masterpiece on statecraft, ethics, psychology, and spiritual wisdom.",
            keyConcepts = listOf("Yato Dharmastato Jayah", "Kurukshetra", "Shanti Parva", "Bhishma", "Pandavas & Kauravas"),
            crossReferences = listOf("gita", "krishna", "dharma", "ramayana")
        ),

        // 9. VEDAS (HIGHEST SCRIPTURAL TIER)
        CanonicalDharmaEntry(
            id = "vedas",
            titleBn = "বেদ (The Four Vedas)",
            titleEn = "The Vedas (Rig, Sama, Yajur, Atharva)",
            category = "VEDAS",
            primaryScripture = "ঋগ্বেদ, সামবেদ, যজুর্বেদ ও অথর্ববেদ",
            chapterVerseRef = "ঋগ্বেদ সংহিতা ১.১৬৪.৪৬ (একং সদ্বিপ্রা বহুধা বদন্তি)",
            sanskritText = "एकं सद् विप्रा बहुधा वदन्त्यग्निं यमं मातरिश्वानमाहुः।",
            transliteration = "Ekaṁ sad viprā bahudhā vadantyagniṁ yamaṁ mātariśvānamāhuḥ ||",
            definitionBn = "বেদ সনাতন ধর্মের সর্বোচ্চ প্রামাণ্য অপৌরুষেয় শ্রুতিশাস্ত্র। বেদ চার ভাগে বিভক্ত: ঋগ্বেদ, সামবেদ, যজুর্বেদ ও অথর্ববেদ। প্রতিটি বেদের চারটি অংশ: সংহিতা, ব্রাহ্মণ, আরণ্যক ও উপনিষদ।",
            definitionEn = "The Vedas are the foundational and supreme authority (Apaurusheya Shruti) in Sanatana Dharma, classified into Rigveda, Samaveda, Yajurveda, and Atharvaveda, each with Samhita, Brahmana, Aranyaka, and Upanishad sections.",
            expositionBn = "সনাতন শাস্ত্রীয় শ্রেণিবিন্যাসে বেদ সর্বোচ্চ স্তর (Primary Scripture)। ঋগ্বেদে মূলত স্তোত্র ও ঋকসমূহ সংকলিত, সামবেদে সঙ্গীত ও সুরযুক্ত স্তোত্র, যজুর্বেদে যজ্ঞীয় ক্রিয়া ও প্রার্থনা, এবং অথর্ববেদে দৈনন্দিন জীবন, শান্তি ও চিকিৎসাবিদ্যার সমৃদ্ধ সংকলন রয়েছে। বেদের মহাবাক্য 'একং সদ্বিপ্রা বহুধা বদন্তি' সনাতন ধর্মের সর্বজনীন ও বহুত্ববাদী ঐক্যের মূল ভিত্তি।",
            expositionEn = "The Vedas occupy the paramount position in the Hindu scriptural hierarchy. Rigveda preserves cosmic hymns, Samaveda sacred melodies, Yajurveda liturgical procedures, and Atharvaveda societal well-being and sciences.",
            significanceBn = "সমগ্র সনাতন ধর্মের দার্শনিক ও নৈতিক কাঠামোর আদি উৎস বেদ। যে কোনো শাস্ত্রীয় বিরোধে বেদের সিদ্ধান্তই চূড়ান্ত বলে গণ্য হয়।",
            significanceEn = "The Vedas are the ultimate touchstone of orthodoxy (Astika Pramana) across all Sanatan philosophical traditions.",
            keyConcepts = listOf("Shruti", "Apaurusheya", "Rigveda", "Samaveda", "Yajurveda", "Atharvaveda", "Ekam Sat"),
            crossReferences = listOf("upanishads", "gita", "dharma")
        ),

        // 10. UPANISHADS (VEDANTA SHRUTI)
        CanonicalDharmaEntry(
            id = "upanishads",
            titleBn = "উপনিষদ (The Upanishads)",
            titleEn = "The Upanishads (Vedanta)",
            category = "UPANISHADS",
            primaryScripture = "মুখ্য ১০/১১টি উপনিষদ (ঈশ, কেন, কঠ, প্রশ্ন, মুণ্ডক, মাণ্ডূক্য, তৈত্তিরীয়, ঐতরেয়, ছান্দোগ্য, বৃহদারণ্যক, শ্বেতাশ্বতর)",
            chapterVerseRef = "ছান্দোগ্য ৬.৮.৭ (তত্ত্বমসি), বৃহদারণ্যক ১.৪.১০ (অহং ব্রহ্মাস্মি)",
            sanskritText = "तत्त्वमसि श्वेतकेतो। अहम् ब्रह्मास्मि। अयमात्मा ब्रह्म। प्रज्ञानं ब्रह्म।",
            transliteration = "Tat tvam asi śvetaketo | Aham brahmāsmi | Ayamātmā brahma | Prajñānaṁ brahma ||",
            definitionBn = "উপনিষদ বেদের জ্ঞানকাণ্ড এবং বেদান্তের মূল ভিত্তি। এতে জীব, জগৎ ও পরমব্রহ্মের স্বরূপ এবং আত্মজ্ঞান দ্বারা মোক্ষ লাভের পরম সত্য উদ্ভাসিত হয়েছে।",
            definitionEn = "The Upanishads constitute the Jnana Kanda (philosophical essence) of the Vedas, elucidating the non-dual reality of Brahman, the immortality of Atman, and supreme liberation.",
            expositionBn = "উপনিষদের চারটি প্রধান মহাবাক্য সনাতন অধ্যাত্মবিদ্যার সারকথা: ১) 'প্রজ্ঞানং ব্রহ্ম' (ঋগ্বেদ/ঐতরেয়), ২) 'অহং ব্রহ্মাস্মি' (যজুর্বেদ/বৃহদারণ্যক), ৩) 'তত্ত্বমসি' (সামবেদ/ছান্দোগ্য), ৪) 'অয়মাত্মা ব্রহ্ম' (অথর্ববেদ/মাণ্ডূক্য)। উপনিষদ বাহ্যিক যজ্ঞের চেয়ে অন্তরের আত্মজ্ঞান ও ব্রহ্মানুভূতির উপর জোর দেয়।",
            expositionEn = "Containing the four Mahavakyas, the Upanishads shift the focus from external rituals to internal contemplative realization of the transcendent Divine Self.",
            significanceBn = "আদি শংকরাচার্য, রামানুজ ও মধ্বাচার্য প্রস্থানত্রয়ীর ভিত্তি হিসেবে উপনিষদের ওপর তাঁদের যুগান্তকারী ভাষ্য রচনা করেছেন।",
            significanceEn = "The Upanishads form the primary spiritual scripture guiding all Vedantic traditions and philosophical inquiries.",
            keyConcepts = listOf("Brahman", "Atman", "Mahavakya", "Tat Tvam Asi", "Moksha", "Vedanta"),
            crossReferences = listOf("vedas", "gita", "darshanas")
        ),

        // 11. PURANAS
        CanonicalDharmaEntry(
            id = "puranas",
            titleBn = "পুরাণ (The Ashtadasha Mahapuranas)",
            titleEn = "The Puranas",
            category = "PURANAS",
            primaryScripture = "অষ্টাদশ মহাপুরাণ (বিষ্ণু, ভাগবত, শিব, মার্কণ্ডেয়, পদ্ম, মৎস্য, কুর্ম ইত্যাদি)",
            chapterVerseRef = "পুরাণের পঞ্চলক্ষণ: সর্গ, প্রতিসর্গ, বংশ, মন্বন্তর ও বংশানুচরিত",
            sanskritText = "सर्गश्च प्रतिसर्गश्च वंशो मन्वन्तराणि च। वंशानुचरितं चैव पुराणं पञ्चलक्षणम्॥",
            transliteration = "Sargaśca pratisargaśca vaṁśo manvantarāṇi ca | Vaṁśānucaritaṁ caiva purāṇaṁ pañcalakṣaṇam ||",
            definitionBn = "পুরাণ হলো প্রাচীন ইতিহাস, সৃষ্টিতত্ত্ব, ভক্তি ও ধর্মীয় উপাখ্যানের সমৃদ্ধ আকর গ্রন্থ। অষ্টাদশ মহাপুরাণ ও বহু উপপুরাণ সনাতন সংস্কৃতির বিস্তার ও নৈতিক শিক্ষার মূল অবলম্বন।",
            definitionEn = "The Puranas are vast anthologies of cosmology, genealogy, spiritual parables, and devotional narratives, traditionally categorized into 18 Mahapuranas and numerous Upa-puranas.",
            expositionBn = "পুরাণসমূহের বৈশিষ্ট্য হলো তারা জটিল বৈদিক দর্শনকে সাধারণ মানুষের বোধগম্য রূপক ও কাহিনীর মাধ্যমে উপস্থাপন করে। পুরাণে সৃষ্টি (সর্গ), প্রলয় ও পুনর্নির্মাণ (প্রতিসর্গ), দেব-ঋষিদের বংশাবলী, মন্বন্তর এবং রাজাদের ইতিহাস বিধৃত হয়েছে। বৈষ্ণব, শৈব ও শাক্ত পুরাণে পরম সত্যকে যথাক্রমে বিষ্ণু, শিব ও মহাশক্তির মাধ্যমে পরমেশ্বর রূপে বর্ণনা করা হয়েছে।",
            expositionEn = "The Puranas illuminate Vedic philosophy through narrative allegories and sacred biographies across Vaishnava, Shaiva, and Shakta traditions.",
            significanceBn = "দৈনন্দিন ভক্তিমূলক জীবন, ব্রত, তীর্থযাত্রা ও মন্দিরের আচারাদি প্রধানত পুরাণ দ্বারা পরিচালিত।",
            significanceEn = "They bridge classical philosophy with popular religious observances, pilgrimage, and temple traditions.",
            keyConcepts = listOf("Mahapuranas", "Pancha Lakshana", "Bhagavata", "Shiva Purana", "Bhakti", "Cosmology"),
            crossReferences = listOf("krishna", "shiva", "mahabharata")
        ),

        // 12. AGAMAS AND TANTRAS
        CanonicalDharmaEntry(
            id = "agamas_tantras",
            titleBn = "আগম ও প্রামাণিক তন্ত্র (Agamas & Tantras)",
            titleEn = "Agamas and Tantras",
            category = "AGAMAS_TANTRAS",
            primaryScripture = "শৈবাগাম (২৮টি), শাক্তাগাম/রুদ্রযামল, বৈষ্ণব পাঞ্চরাত্র ও বৈখানস সংহিতা",
            chapterVerseRef = "চতুর্পাদ: জ্ঞানপাদ, যোগপাদ, ক্রিয়াপাদ ও চর্যাপাদ",
            sanskritText = "ज्ञानयोगक्रियाचर्यापादैरुपनिबद्धम्।",
            transliteration = "Jñāna-yoga-kriyā-caryā-pādairupanibaddham ||",
            definitionBn = "আগম ও তন্ত্র সনাতন ধর্মের প্রত্যক্ষ উপাসনাপদ্ধতি, মন্দির স্থাপত্য, প্রতিমা লক্ষণ, দীক্ষা ও অভ্যন্তরীণ কুলকুণ্ডলিনী যোগের বিধিমালার প্রামাণিক শাস্ত্র।",
            definitionEn = "Agamas and authentic Tantras are comprehensive liturgical texts governing temple architecture, iconographic consecration, ritual worship, initiation (Diksha), and esoteric spiritual discipline.",
            expositionBn = "আগমশাস্ত্র মূলত চার ভাগে বিন্যস্ত: জ্ঞানপাদ (দর্শন ও ব্রহ্মতত্ত্ব), যোগপাদ (ধ্যান ও প্রাণায়াম), ক্রিয়াপাদ (মন্দির নির্মাণ ও প্রতিমা প্রতিষ্ঠা), এবং চর্যাপাদ (দৈনন্দিন পূজা ও উৎসব বিধি)। তিনটি মূল ধারা: শৈবাগাম, শাক্ত তন্ত্র এবং বৈষ্ণব পাঞ্চরাত্র ও বৈখানস আগম। প্রামাণিক তন্ত্রে যোগসাধনা ও শুদ্ধ সাত্ত্বিক ভক্তির বিধান রয়েছে; কোনো ধরনের কুসংস্কার বা কাল্পনিক সৃষ্টি তন্ত্রের মূল শিক্ষা নয়।",
            expositionEn = "Agamas articulate four pillars: Jnana (wisdom), Yoga (contemplative discipline), Kriya (temple construction and deity installation), and Charya (devotional rituals).",
            significanceBn = "ভারতের প্রায় সকল ঐতিহাসিক মন্দিরের পূজা পদ্ধতি এবং সাধকের অভ্যন্তরীণ শক্তিসঞ্চার আগম ও তন্ত্র নির্দেশিত বিধির ওপর প্রতিষ্ঠিত।",
            significanceEn = "They govern the operational worship in major traditional Hindu temples across India and Nepal.",
            keyConcepts = listOf("Shaiva Agamas", "Pancharatra", "Shakta Tantra", "Kriya Pada", "Temple Architecture"),
            crossReferences = listOf("shiva", "upanishads", "vedas")
        ),

        // 13. TRADITION & PHILOSOPHICAL DIFFERENCES (ADVAITA, VISHISHTADVAITA, DVAITA, SECTARIAN HARMONY)
        CanonicalDharmaEntry(
            id = "sampradaya_differences",
            titleBn = "বেদান্ত সম্প্রদায় ও ঐতিহ্যগত মতভেদ: অদ্বৈত, বিশিষ্টাদ্বৈত ও দ্বৈতবাদ (Sampradaya & Philosophical Perspectives)",
            titleEn = "Tradition and Philosophical Differences (Advaita, Vishishtadvaita, Dvaita)",
            category = "DARSHANA",
            primaryScripture = "ব্রহ্মসূত্র ভাষ্য (শংকর, রামানুজ, মধ্ব), ঋগ্বেদ ১.১৬৪.৪৬",
            chapterVerseRef = "ব্রহ্মসূত্র ১.১.১ (অথাতো ব্রহ্মজিজ্ঞাসা)",
            sanskritText = "एकं सद् विप्रा बहुधा वदन्ति। अथातो ब्रह्मजिज्ञासा॥",
            transliteration = "Ekaṁ sad viprā bahudhā vadanti | Athāto brahmajijñāsā ||",
            definitionBn = "সনাতন ধর্মে একই পরম সত্যকে উপলব্ধি করার জন্য প্রামাণিক বিভিন্ন ঐতিহ্য ও সম্প্রদায়ের দৃষ্টিভঙ্গি রয়েছে। কোনো একটি ব্যাখ্যাকে একমাত্র সত্য দাবি না করে শাস্ত্রীয় ভিন্নতাকে স্বাভাবিক ও শ্রদ্ধার সঙ্গে গ্রহণ করা হয়।",
            definitionEn = "Sanatan Dharma embraces diverse authentic theological traditions (Sampradayas) interpreting the relationship between Jiva (soul), Jagat (world), and Brahman (Supreme Divine).",
            expositionBn = "প্রধান তিনটি দার্শনিক দৃষ্টিভঙ্গি:\n১) অদ্বৈত বেদান্ত (আদি শংকরাচার্য): জীবাত্মা ও পরব্রহ্ম স্বরূপত এক ও অভিন্ন; জগৎ নাম-রূপের মায়া, এবং কেবল আত্মজ্ঞানই পরম মোক্ষ।\n২) বিশিষ্টাদ্বৈত (শ্রী রামানুজাচার্য): জীবাত্মা ও জগৎ পরমেশ্বরের শরীর বা গুণবিশেষ; তাদের স্বতন্ত্র অস্তিত্ব রয়েছে এবং নারায়ণের প্রতি অচলা ভক্তিতেই মোক্ষ লাভ হয়।\n৩) দ্বৈত বেদান্ত (শ্রী মধ্বাচার্য): ঈশ্বর ও জীবের মধ্যে শাশ্বত ও বাস্তব ভেদ রয়েছে; হরি বা বিষ্ণুই একমাত্র স্বতন্ত্র পরম তত্ত্ব।\n\nএছাড়া শৈব, শাক্ত ও বৈষ্ণব উপাসনায় নিজ নিজ ইষ্টদেবতাকে পরম রূপে দেখা হলেও, ঋগ্বেদের 'একং সদ্বিপ্রা বহুধা বদন্তি' নীতি অনুযায়ী সকলে একই অখণ্ড পরমচেতনার বিভিন্ন প্রকাশ হিসেবে পরিগণিত হয়।",
            expositionEn = "Advaita asserts essential non-duality; Vishishtadvaita qualified non-duality with eternal devotion to Narayana; Dvaita asserts eternal distinction between God and individual souls. Different traditions view their Ishta Devata as Supreme while recognizing the ultimate singularity of Divine Truth.",
            significanceBn = "এই বহুত্ববাদ সনাতন ধর্মের আধ্যাত্মিক পরমতসহিষ্ণুতা ও গভীরতার অনন্য নিদর্শন। এক ঐতিহ্যকে অন্যের ওপর জোর করে চাপিয়ে দেওয়া শাস্ত্রসম্মত নয়।",
            significanceEn = "This philosophical pluralism reflects the spiritual maturity of Sanatan Dharma, celebrating multiple pathways to the ultimate truth.",
            keyConcepts = listOf("Advaita", "Vishishtadvaita", "Dvaita", "Sampradaya Harmony", "Ekam Sat", "অদ্বৈত", "দ্বৈত", "বিশিষ্টাদ্বৈত", "শঙ্কর", "মধ্ব", "রামানুজ", "মতভেদ", "পার্থক্য"),
            crossReferences = listOf("vedas", "upanishads", "gita")
        )
    )

    fun findDeepKnowledge(query: String): CanonicalDharmaEntry? = searchCanonicalKnowledge(query)

    fun searchCanonicalKnowledge(query: String): CanonicalDharmaEntry? {
        val lower = query.lowercase(Locale.ROOT).trim()

        if (lower.contains("কর্মযোগ") || lower.contains("karma yoga") || lower.contains("নিষ্কাম কর্ম")) {
            canonicalEntries.firstOrNull { it.id == "karma_yoga" }?.let { return it }
        }
        if (lower.contains("ভগবদ্গীতা") || lower.contains("গীতা") || lower.contains("gita")) {
            if (lower.contains("কর্ম") || lower.contains("karma")) {
                canonicalEntries.firstOrNull { it.id == "karma_yoga" }?.let { return it }
            }
            canonicalEntries.firstOrNull { it.id == "gita" }?.let { return it }
        }
        if (lower.contains("শিব") || lower.contains("shiva") || lower.contains("মহাদেব")) {
            canonicalEntries.firstOrNull { it.id == "shiva" }?.let { return it }
        }
        if (lower.contains("কৃষ্ণ") || lower.contains("krishna")) {
            canonicalEntries.firstOrNull { it.id == "krishna" }?.let { return it }
        }
        if (lower.contains("গায়ত্রী") || lower.contains("gayatri")) {
            canonicalEntries.firstOrNull { it.id == "gayatri" }?.let { return it }
        }
        if (lower.contains("মৃত্যুঞ্জয়") || lower.contains("mrityunjaya")) {
            canonicalEntries.firstOrNull { it.id == "mahamrityunjaya" }?.let { return it }
        }
        if (lower.contains("কর্ম") || lower.contains("karma")) {
            canonicalEntries.firstOrNull { it.id == "karma" }?.let { return it }
        }
        if (lower.contains("ধর্ম") || lower.contains("dharma")) {
            canonicalEntries.firstOrNull { it.id == "dharma" }?.let { return it }
        }

        for (entry in canonicalEntries) {
            if (entry.id == lower ||
                lower.contains(entry.id) ||
                lower.contains(entry.titleBn.lowercase(Locale.ROOT)) ||
                lower.contains(entry.titleEn.lowercase(Locale.ROOT)) ||
                entry.keyConcepts.any { lower.contains(it.lowercase(Locale.ROOT)) } ||
                lower.contains(entry.category.lowercase(Locale.ROOT))) {
                return entry
            }
        }

        // Tokenized fallback (excluding generic stop tokens like mantra/sloka)
        val genericStopWords = setOf("মন্ত্র", "শ্লোক", "অর্থ", "দেবতা", "ধর্ম", "কী", "কেন", "mantra", "sloka", "vedic")
        val tokens = lower.split("\\s+".toRegex()).filter { it.length > 2 && it !in genericStopWords }
        for (token in tokens) {
            for (entry in canonicalEntries) {
                if (entry.titleBn.contains(token) || entry.titleEn.contains(token, ignoreCase = true) ||
                    entry.keyConcepts.any { it.contains(token, ignoreCase = true) }) {
                    return entry
                }
            }
        }

        return null
    }

    fun getAllEntries(): List<CanonicalDharmaEntry> = canonicalEntries
}
