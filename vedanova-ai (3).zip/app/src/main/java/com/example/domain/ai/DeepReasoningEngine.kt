package com.example.domain.ai

import com.example.data.dao.KnowledgeDao
import com.example.data.model.KnowledgeEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale
import java.util.UUID

/**
 * Meaningful internal confidence classifications (No fake percentage generation).
 */
enum class ReasoningConfidence {
    HIGH_CONFIDENCE,
    SUPPORTED,
    PARTIALLY_SUPPORTED,
    INSUFFICIENT_EVIDENCE
}

/**
 * Strict evidence classification according to canonical authority & domain type.
 */
enum class EvidenceClassification {
    CANONICAL,               // Direct Shruti/Smriti, Gita, Upanishads, Vedas, Puranas, Authentic Sanskrit
    GENERAL_KNOWLEDGE,       // Verified empirical, scientific, geographic, linguistic or factual general knowledge
    REASONED_INTERPRETATION, // Philosophical deduction or practical application derived from canonical premises
    ORIGINAL_WRITING,        // AI literary reflection, essay, prayer explicitly flagged as non-canonical
    UNCERTAIN                // Unverified or insufficient evidence
}

/**
 * Planned format for the response.
 */
enum class AnswerPlanFormat {
    SHORT_ANSWER,
    DETAILED_EXPLANATION,
    STEP_BY_STEP,
    SCRIPTURAL_REFERENCE,
    EXAMPLE_DRIVEN,
    COMPARISON,
    CLARIFICATION_QUESTION
}

/**
 * Structured evidence item collected during the retrieval and evaluation phase.
 */
data class EvidenceItem(
    val id: String = UUID.randomUUID().toString(),
    val title: String,
    val content: String,
    val source: String,
    val scripture: String = "",
    val reference: String = "",
    val sanskritText: String = "",
    val transliteration: String = "",
    val classification: EvidenceClassification,
    val relevanceScore: Float,
    val confidence: Float,
    val scripturalTier: ScripturalSourceTier = ScripturalSourceTier.determineScripturalTier(source, scripture),
    val truthCategory: TruthCategory = when (classification) {
        EvidenceClassification.CANONICAL -> TruthCategory.SCRIPTURAL_TEXT
        EvidenceClassification.GENERAL_KNOWLEDGE -> TruthCategory.HISTORICAL_SCHOLARLY_FACT
        EvidenceClassification.ORIGINAL_WRITING -> TruthCategory.ORIGINAL_AI_WRITING
        EvidenceClassification.REASONED_INTERPRETATION -> TruthCategory.TRADITIONAL_INTERPRETATION
        EvidenceClassification.UNCERTAIN -> TruthCategory.MODERN_INTERPRETATION
    }
)

/**
 * Decomposed sub-task for complex or multi-part questions.
 */
data class DecomposedSubTask(
    val id: String = UUID.randomUUID().toString(),
    val subQuestion: String,
    val questionType: String, // "DEFINITION", "SCRIPTURAL_TEACHING", "CANONICAL_REFERENCE", "PRACTICAL_APPLICATION", "COMPARISON"
    val targetAspect: String,
    val retrievedEvidence: List<EvidenceItem> = emptyList(),
    val reasonedSubAnswer: String? = null
)

/**
 * Contradiction check result.
 */
data class ContradictionCheckResult(
    val hasContradiction: Boolean,
    val contradictionReason: String? = null,
    val conflictingContext: String? = null,
    val correctionApplied: Boolean = false,
    val revisedReasoning: String? = null
)

/**
 * Complete reasoning outcome produced by DeepReasoningEngine.
 */
data class DeepReasoningResult(
    val originalQuery: String,
    val resolvedQuery: String,
    val detectedLanguage: String,
    val intentAnalysis: IntentAnalysisResult,
    val isDecomposed: Boolean,
    val subTasks: List<DecomposedSubTask>,
    val gatheredEvidence: List<EvidenceItem>,
    val answerPlan: AnswerPlanFormat,
    val confidenceLevel: ReasoningConfidence,
    val confidenceScore: Float,
    val contradictionCheck: ContradictionCheckResult,
    val finalAnswer: String,
    val sanskritVerse: String? = null,
    val transliteration: String? = null,
    val references: List<String> = emptyList(),
    val topKnowledgeSource: String = "Deep Canonical Reasoning Engine",
    val scriptureReference: String = "",
    val isVerifiedSource: Boolean = true,
    val isInsufficientEvidence: Boolean = false,
    val reasoningDurationMs: Long = 0L
)

/**
 * Real Multi-Step Deep Reasoning Engine for Dharma AI.
 *
 * Pipeline:
 * 1. User Question Understanding (Multilingual: Bengali, English, Mixed)
 * 2. Context Retrieval & Reference Resolution (ContextMemoryManager)
 * 3. Question Decomposition (Splits complex queries into sub-tasks)
 * 4. Relevant Knowledge Retrieval (DeepDharmaKnowledgeBase, KnowledgeDao, GeneralKnowledgeEngine)
 * 5. Evidence Classification & Evaluation (CANONICAL, GENERAL_KNOWLEDGE, REASONED_INTERPRETATION, etc.)
 * 6. Logical Reasoning & Synthesis (Premise-driven, factually grounded)
 * 7. Contradiction Check (Against context, verified sources, and safety)
 * 8. Answer Planning (Short, Detailed, Step-by-step, etc.)
 * 9. Final Response Generation
 */
object DeepReasoningEngine {

    suspend fun reason(
        query: String,
        history: List<Pair<String, String>> = emptyList(),
        contextState: ConversationContextState = ConversationContextState(),
        knowledgeDao: KnowledgeDao? = null,
        temperature: Float = 0.2f
    ): DeepReasoningResult = withContext(Dispatchers.Default) {
        val startTime = System.currentTimeMillis()
        val rawQuery = query.trim()

        // 1. Language Detection & Normalization
        val detectedLanguage = detectQueryLanguage(rawQuery)
        val normalizedQuery = normalizeQuery(rawQuery)

        // 2. Context Integration & Anaphora / Reference Resolution
        val resolvedQuery = resolveContextualReferences(normalizedQuery, history, contextState)

        // 3. Intent Understanding
        val intentAnalysis = DharmaIntentEngine.analyze(
            query = resolvedQuery,
            history = history
        )

        // 4. Question Decomposition (Multi-part analysis)
        val subTasks = decomposeQuestion(resolvedQuery, intentAnalysis, contextState)
        val isDecomposed = subTasks.size > 1

        // 5. Multi-Source Knowledge Retrieval & Evidence Collection
        val gatheredEvidence = retrieveEvidence(
            resolvedQuery = resolvedQuery,
            subTasks = subTasks,
            intent = intentAnalysis,
            contextState = contextState,
            knowledgeDao = knowledgeDao
        )

        // 6. Evidence Evaluation & Confidence Assessment
        val (confidenceLevel, confidenceScore) = evaluateEvidence(gatheredEvidence, intentAnalysis)

        // 7. Answer Planning
        val answerPlan = planAnswerFormat(
            query = resolvedQuery,
            intent = intentAnalysis,
            subTasks = subTasks,
            evidence = gatheredEvidence
        )

        // 8. Logical Reasoning & Synthesis
        val (initialAnswer, topSanskrit, topTranslit, topRefs) = synthesizeAnswer(
            resolvedQuery = resolvedQuery,
            originalQuery = rawQuery,
            detectedLanguage = detectedLanguage,
            intent = intentAnalysis,
            subTasks = subTasks,
            evidence = gatheredEvidence,
            plan = answerPlan,
            confidence = confidenceLevel,
            contextState = contextState
        )

        // 9. Contradiction Detection & Self-Correction
        val contradictionResult = checkContradictions(
            query = resolvedQuery,
            proposedAnswer = initialAnswer,
            evidence = gatheredEvidence,
            contextState = contextState,
            history = history
        )

        val finalAnswer = if (contradictionResult.hasContradiction && contradictionResult.revisedReasoning != null) {
            contradictionResult.revisedReasoning
        } else {
            initialAnswer
        }

        val elapsedMs = System.currentTimeMillis() - startTime

        val primaryEvidence = gatheredEvidence.firstOrNull { it.classification == EvidenceClassification.CANONICAL }
            ?: gatheredEvidence.firstOrNull()

        DeepReasoningResult(
            originalQuery = rawQuery,
            resolvedQuery = resolvedQuery,
            detectedLanguage = detectedLanguage,
            intentAnalysis = intentAnalysis,
            isDecomposed = isDecomposed,
            subTasks = subTasks,
            gatheredEvidence = gatheredEvidence,
            answerPlan = answerPlan,
            confidenceLevel = confidenceLevel,
            confidenceScore = confidenceScore,
            contradictionCheck = contradictionResult,
            finalAnswer = finalAnswer,
            sanskritVerse = topSanskrit,
            transliteration = topTranslit,
            references = if (topRefs.isNotEmpty()) topRefs else primaryEvidence?.let { listOf("${it.scripture} ${it.reference}".trim()) } ?: emptyList(),
            topKnowledgeSource = primaryEvidence?.source ?: "Dharma AI Deep Reasoning Engine",
            scriptureReference = primaryEvidence?.let { "${it.scripture} ${it.reference}".trim() } ?: "Authentic Dharma Exegesis",
            isVerifiedSource = confidenceLevel != ReasoningConfidence.INSUFFICIENT_EVIDENCE,
            isInsufficientEvidence = confidenceLevel == ReasoningConfidence.INSUFFICIENT_EVIDENCE,
            reasoningDurationMs = elapsedMs
        )
    }

    // ==========================================
    // 1. Language Detection & Normalization
    // ==========================================

    fun detectQueryLanguage(query: String): String {
        val bengaliChars = query.count { it in '\u0980'..'\u09FF' }
        val latinChars = query.count { it in 'A'..'Z' || it in 'a'..'z' }
        return when {
            bengaliChars > 0 && latinChars > 0 -> "Mixed (বাংলা + English)"
            bengaliChars > latinChars -> "Bengali (বাংলা)"
            latinChars > 0 -> "English"
            else -> "Bengali (বাংলা)"
        }
    }

    fun normalizeQuery(query: String): String {
        return query.trim()
            .replace("\\s+".toRegex(), " ")
    }

    // ==========================================
    // 2. Context Integration & Reference Resolution
    // ==========================================

    fun resolveContextualReferences(
        query: String,
        history: List<Pair<String, String>>,
        contextState: ConversationContextState
    ): String {
        val lower = query.lowercase(Locale.ROOT).trim()

        // 1. Check if query is directly contextual ("তাহলে এটা কি শুধু পূজার সঙ্গে সম্পর্কিত?", "এটা কি শুধু পূজার সাথে যুক্ত?")
        if ((lower.contains("এটা কি") || lower.contains("এটি কি") || lower.contains("এটা কি শুধু") || lower.contains("তাহলে এটা কি")) &&
            contextState.activeSubject != null
        ) {
            val subject = contextState.activeSubject
            val cleanQuery = query.replace("তাহলে", "")
                .replace("এটা", subject)
                .replace("এটি", subject)
                .replace("এইটা", subject)
                .trim()
            return cleanQuery
        }

        // 2. "তার মূল শিক্ষা কী?" / "এর মূল শিক্ষা কী?" / "What is its main teaching?"
        if (lower.contains("মূল শিক্ষা") || lower.contains("main teaching") || lower.contains("core message")) {
            val subject = contextState.activeSubject ?: contextState.activeScripture ?: "সনাতন ধর্ম"
            return "$subject এর মূল শিক্ষা ও তাৎপর্য কী?"
        }

        // 3. "আগের কথাটা একটু বুঝিয়ে বলো" / "পূর্বের বিষয়টি বিস্তার করো"
        if (lower.contains("আগের কথা") || lower.contains("আগের পয়েন্ট") || lower.contains("আগের বিষয়টি") || lower.contains("explain earlier point")) {
            val previousSnippet = contextState.lastAiResponseSnippet ?: contextState.activeSubject ?: "পূর্ববর্তী আলোচনা"
            return "$previousSnippet এর বিশদ ও সুস্পষ্ট ব্যাখ্যা"
        }

        // 4. "এটার অর্থ কী?" / "এর মানে কী?"
        if (lower.contains("এটার অর্থ") || lower.contains("এর অর্থ") || lower.contains("এর মানে") || lower == "অর্থ কী?" || lower == "মানে কী?") {
            val target = contextState.activeMantra ?: contextState.activeSubject ?: contextState.activeScripture ?: "বর্তমান বিষয়"
            return "$target এর অর্থ, শাস্ত্রীয় বঙ্গানুবাদ ও ভাবার্থ"
        }

        // 5. Standard ContextMemoryManager resolver
        return ContextMemoryManager.resolveMultiTurnQuery(query, history, contextState)
    }

    // ==========================================
    // 3. Question Decomposition
    // ==========================================

    fun decomposeQuestion(
        query: String,
        intent: IntentAnalysisResult,
        contextState: ConversationContextState
    ): List<DecomposedSubTask> {
        val lower = query.lowercase(Locale.ROOT)
        val tasks = mutableListOf<DecomposedSubTask>()

        // Case A: Complex Composite Question (e.g. "ভগবদ্গীতায় কর্মযোগ কী এবং দৈনন্দিন জীবনে এর প্রয়োগ কী?")
        val hasGitaKarmaYoga = (lower.contains("কর্মযোগ") || lower.contains("কর্ম যোগ") || lower.contains("karma yoga")) &&
                (lower.contains("গীতা") || lower.contains("ভগবদ্গীতা") || lower.contains("gita"))
        val hasPracticalApplication = lower.contains("দৈনন্দিন") || lower.contains("জীবনে প্রয়োগ") || lower.contains("প্রয়োগ কী") ||
                lower.contains("daily life") || lower.contains("how to apply") || lower.contains("ব্যবহারিক")

        if (hasGitaKarmaYoga && hasPracticalApplication) {
            tasks.add(DecomposedSubTask(subQuestion = "কর্মযোগের মূল স্বরূপ ও সংজ্ঞা কী?", questionType = "DEFINITION", targetAspect = "Karma Yoga Concept"))
            tasks.add(DecomposedSubTask(subQuestion = "শ্রীমদ্ভগবদ্গীতায় কর্মযোগ সম্পর্কে কী শিক্ষা দেওয়া হয়েছে?", questionType = "SCRIPTURAL_TEACHING", targetAspect = "Gita Teachings on Karma Yoga"))
            tasks.add(DecomposedSubTask(subQuestion = "কর্মযোগ সম্পর্কিত প্রামাণিক শাস্ত্রীয় শ্লোক ও তথ্যসূত্র কী?", questionType = "CANONICAL_REFERENCE", targetAspect = "Gita Chapter 2 Verse 47 Shloka"))
            tasks.add(DecomposedSubTask(subQuestion = "দৈনন্দিন জীবনে নিঃস্বার্থ কর্মযোগ কীভাবে প্রয়োগ করা যায়?", questionType = "PRACTICAL_APPLICATION", targetAspect = "Daily Life Practical Application"))
            return tasks
        }

        // Case B: Composite Distinction / Comparison (e.g. "জ্ঞান ও ভক্তির মধ্যে পার্থক্য কী?")
        if ((lower.contains("পার্থক্য") || lower.contains("তুলনা") || lower.contains("difference between") || lower.contains("vs")) &&
            (lower.contains("জ্ঞান") || lower.contains("ভক্তি") || lower.contains("কর্ম") || lower.contains("অদ্বৈত") || lower.contains("দ্বৈত"))
        ) {
            tasks.add(DecomposedSubTask(subQuestion = "উভয় ধারণার স্বতন্ত্র সংজ্ঞা ও স্বরূপ কী?", questionType = "DEFINITION", targetAspect = "Concepts Definition"))
            tasks.add(DecomposedSubTask(subQuestion = "শাস্ত্রীয় প্রেক্ষাপটে উভয়ের তুলনামূলক তাৎপর্য কী?", questionType = "COMPARISON", targetAspect = "Philosophical Comparison"))
            tasks.add(DecomposedSubTask(subQuestion = "শাস্ত্র কী সমন্বয় বা সিদ্ধান্তের নির্দেশ দেয়?", questionType = "SCRIPTURAL_TEACHING", targetAspect = "Harmonious Synthesis"))
            return tasks
        }

        // Case C: Practice / How-To (e.g. "ধ্যান কী এবং এটি কীভাবে করতে হয়?")
        if ((lower.contains("ধ্যান") || lower.contains("জপ") || lower.contains("পূজা") || lower.contains("meditation")) &&
            (lower.contains("কীভাবে") || lower.contains("কিভাবে") || lower.contains("পদ্ধতি") || lower.contains("how to"))
        ) {
            tasks.add(DecomposedSubTask(subQuestion = "বিষয়টির শাস্ত্রীয় তাৎপর্য ও স্বরূপ কী?", questionType = "DEFINITION", targetAspect = "Core Concept"))
            tasks.add(DecomposedSubTask(subQuestion = "শাস্ত্রীয় বিধিমতে এটি অনুশীলনের ধাপে ধাপে নিয়ম কী?", questionType = "PRACTICAL_APPLICATION", targetAspect = "Step-by-Step Procedure"))
            return tasks
        }

        // Default Single-Question Task
        tasks.add(DecomposedSubTask(
            subQuestion = query,
            questionType = when (intent.primaryIntent) {
                QuestionIntentType.DHARMA_DEFINITION -> "DEFINITION"
                QuestionIntentType.CANONICAL_SCRIPTURE -> "CANONICAL_REFERENCE"
                QuestionIntentType.PHILOSOPHY_AND_DARSHANA -> "SCRIPTURAL_TEACHING"
                else -> "GENERAL_EXPOSITION"
            },
            targetAspect = intent.detectedTopic ?: "Dharma Topic"
        ))

        return tasks
    }

    // ==========================================
    // 4. Knowledge Retrieval & Evidence Collection
    // ==========================================

    suspend fun retrieveEvidence(
        resolvedQuery: String,
        subTasks: List<DecomposedSubTask>,
        intent: IntentAnalysisResult,
        contextState: ConversationContextState,
        knowledgeDao: KnowledgeDao?
    ): List<EvidenceItem> {
        val evidenceList = mutableListOf<EvidenceItem>()
        val seenIds = mutableSetOf<String>()

        // 1. Search Deep Canonical Knowledge Base
        val canonicalMatch = DeepDharmaKnowledgeBase.findDeepKnowledge(resolvedQuery)
            ?: (intent.detectedTopic?.let { DeepDharmaKnowledgeBase.findDeepKnowledge(it) })
            ?: (contextState.activeSubject?.let { DeepDharmaKnowledgeBase.findDeepKnowledge(it) })

        if (canonicalMatch != null) {
            seenIds.add(canonicalMatch.id)
            evidenceList.add(
                EvidenceItem(
                    id = canonicalMatch.id,
                    title = canonicalMatch.titleBn,
                    content = canonicalMatch.expositionBn,
                    source = canonicalMatch.primaryScripture,
                    scripture = canonicalMatch.primaryScripture,
                    reference = canonicalMatch.chapterVerseRef,
                    sanskritText = canonicalMatch.sanskritText,
                    transliteration = canonicalMatch.transliteration,
                    classification = EvidenceClassification.CANONICAL,
                    relevanceScore = 0.98f,
                    confidence = 0.99f
                )
            )
        }

        // 2. Search Local KnowledgeDao (if database available)
        if (knowledgeDao != null) {
            try {
                val dbMatches = knowledgeDao.findMatchingPublishedKnowledge(resolvedQuery)
                for (item in dbMatches) {
                    if (item.id.toString() !in seenIds) {
                        seenIds.add(item.id.toString())
                        evidenceList.add(
                            EvidenceItem(
                                id = item.id.toString(),
                                title = item.title,
                                content = item.explanation.ifBlank { item.answer.ifBlank { item.banglaMeaning } },
                                source = item.source.ifBlank { item.scripture },
                                scripture = item.scripture,
                                reference = item.reference,
                                sanskritText = item.sanskritText,
                                transliteration = item.transliteration,
                                classification = if (item.sourceType.contains("Scripture", ignoreCase = true) || item.scripture.isNotBlank())
                                    EvidenceClassification.CANONICAL
                                else
                                    EvidenceClassification.REASONED_INTERPRETATION,
                                relevanceScore = 0.92f,
                                confidence = item.confidenceScore
                            )
                        )
                    }
                }
            } catch (e: Exception) {
                // DAO fallback handled safely
            }
        }

        // 3. Search General Knowledge Engine (Science, Geography, History, Tech)
        val gkMatch = GeneralKnowledgeEngine.findGeneralKnowledge(resolvedQuery)
        if (gkMatch != null && gkMatch.id !in seenIds) {
            seenIds.add(gkMatch.id)
            evidenceList.add(
                EvidenceItem(
                    id = gkMatch.id,
                    title = gkMatch.titleBn,
                    content = "${gkMatch.shortSummaryBn}\n${gkMatch.fullExplanationBn}",
                    source = gkMatch.references.firstOrNull() ?: "General Knowledge & Empirical Science Foundation",
                    scripture = "",
                    reference = "",
                    sanskritText = "",
                    transliteration = "",
                    classification = EvidenceClassification.GENERAL_KNOWLEDGE,
                    relevanceScore = 0.95f,
                    confidence = 0.99f
                )
            )
        }

        // 4. Sub-task evidence augmentation for multi-part questions (e.g. Gita Karma Yoga + Daily Life)
        for (subTask in subTasks) {
            if (subTask.questionType == "PRACTICAL_APPLICATION") {
                val practicalEvidence = createPracticalApplicationEvidence(subTask.targetAspect, canonicalMatch)
                if (practicalEvidence != null && practicalEvidence.id !in seenIds) {
                    seenIds.add(practicalEvidence.id)
                    evidenceList.add(practicalEvidence)
                }
            }
        }

        // Sort retrieved evidence according to verified scriptural hierarchy:
        // Vedas > Upanishads > Gita > Ramayana > Mahabharata > Puranas > Agamas/Tantras > Commentaries
        return evidenceList.sortedWith(
            compareBy<EvidenceItem> { it.scripturalTier.priorityRank }
                .thenByDescending { it.confidence }
        )
    }

    private fun createPracticalApplicationEvidence(aspect: String, canonical: CanonicalDharmaEntry?): EvidenceItem? {
        if (canonical?.id == "karma_yoga" || canonical?.id == "karma" || canonical?.id == "gita" ||
            aspect.contains("Karma Yoga", ignoreCase = true) ||
            aspect.contains("Practical Application", ignoreCase = true)
        ) {
            return EvidenceItem(
                id = "karma_yoga_practical",
                title = "দৈনন্দিন জীবনে কর্মযোগের প্রয়োগ",
                content = "১. কর্তব্যবোধ: ব্যক্তিগত লাভ-লোকসানের ঊর্ধ্বে উঠে সততা ও নিষ্ঠার সাথে কর্ম করা।\n২. ফলের আসক্তি বর্জন: কর্মের ফলাফল ঈশ্বরের চরণে বা সমাজের কল্যাণে সমর্পণ করা।\n৩. মনঃসংযোগ ও চিত্তশুদ্ধি: অহংকারমুক্ত হয়ে সেবা মনোভাব নিয়ে কর্ম সম্পাদন।",
                source = "শ্রীমদ্ভগবদ্গীতা ২য় ও ৩য় অধ্যায় ভিত্তিক দার্শনিক প্রয়োগ",
                scripture = "শ্রীমদ্ভগবদ্গীতা",
                reference = "৩য় অধ্যায় (কর্মযোগ)",
                sanskritText = "योगस्थः कुरु कर्माणि सङ्गं त्यक्त्वा धनञ्जय।",
                transliteration = "yogasthaḥ kuru karmāṇi saṅgaṁ tyaktvā dhanañjaya |",
                classification = EvidenceClassification.REASONED_INTERPRETATION,
                relevanceScore = 0.95f,
                confidence = 0.96f
            )
        }
        return null
    }

    // ==========================================
    // 5. Evidence Evaluation & Confidence
    // ==========================================

    fun evaluateEvidence(
        evidence: List<EvidenceItem>,
        intent: IntentAnalysisResult
    ): Pair<ReasoningConfidence, Float> {
        if (evidence.isEmpty()) {
            return Pair(ReasoningConfidence.INSUFFICIENT_EVIDENCE, 0.20f)
        }

        val hasCanonical = evidence.any { it.classification == EvidenceClassification.CANONICAL }
        val hasGeneral = evidence.any { it.classification == EvidenceClassification.GENERAL_KNOWLEDGE }
        val maxConfidence = evidence.maxOfOrNull { it.confidence } ?: 0.5f

        return when {
            hasCanonical && maxConfidence >= 0.95f -> Pair(ReasoningConfidence.HIGH_CONFIDENCE, 0.98f)
            hasGeneral && maxConfidence >= 0.90f -> Pair(ReasoningConfidence.HIGH_CONFIDENCE, 0.96f)
            evidence.any { it.classification == EvidenceClassification.REASONED_INTERPRETATION } -> Pair(ReasoningConfidence.SUPPORTED, 0.88f)
            maxConfidence >= 0.70f -> Pair(ReasoningConfidence.PARTIALLY_SUPPORTED, 0.75f)
            else -> Pair(ReasoningConfidence.INSUFFICIENT_EVIDENCE, 0.35f)
        }
    }

    // ==========================================
    // 6. Answer Planning
    // ==========================================

    fun planAnswerFormat(
        query: String,
        intent: IntentAnalysisResult,
        subTasks: List<DecomposedSubTask>,
        evidence: List<EvidenceItem>
    ): AnswerPlanFormat {
        val lower = query.lowercase(Locale.ROOT)

        if (intent.styleRequest == ResponseStyleRequest.CONCISE || lower.contains("সংক্ষেপে") || lower.contains("ছোট করে")) {
            return AnswerPlanFormat.SHORT_ANSWER
        }
        if (subTasks.size > 1) {
            return AnswerPlanFormat.DETAILED_EXPLANATION
        }
        if (subTasks.any { it.questionType == "COMPARISON" } || lower.contains("পার্থক্য")) {
            return AnswerPlanFormat.COMPARISON
        }
        if (subTasks.any { it.questionType == "PRACTICAL_APPLICATION" } || lower.contains("কীভাবে") || lower.contains("পদ্ধতি")) {
            return AnswerPlanFormat.STEP_BY_STEP
        }
        if (intent.primaryIntent == QuestionIntentType.CANONICAL_SCRIPTURE || intent.primaryIntent == QuestionIntentType.MANTRA_AND_STOTRA) {
            return AnswerPlanFormat.SCRIPTURAL_REFERENCE
        }
        return AnswerPlanFormat.DETAILED_EXPLANATION
    }

    // ==========================================
    // 7. Logical Reasoning & Synthesis
    // ==========================================

    fun synthesizeAnswer(
        resolvedQuery: String,
        originalQuery: String,
        detectedLanguage: String,
        intent: IntentAnalysisResult,
        subTasks: List<DecomposedSubTask>,
        evidence: List<EvidenceItem>,
        plan: AnswerPlanFormat,
        confidence: ReasoningConfidence,
        contextState: ConversationContextState
    ): Tuple4<String, String?, String?, List<String>> {
        val isEnglish = detectedLanguage.contains("English", ignoreCase = true) && !detectedLanguage.contains("Bengali", ignoreCase = true)

        // Case 1: Insufficient Evidence / Unknown Case (Strict Scripture Safety & Zero Fabrication)
        if (confidence == ReasoningConfidence.INSUFFICIENT_EVIDENCE || evidence.isEmpty()) {
            val insufficientMsg = if (isEnglish) {
                "Sufficient canonical scripture or verified evidence is currently unavailable for this query. To uphold the sanctity and authenticity of Sanatan scriptures, VedaNova AI refrains from speculation and never invents mantras, shlokas, chapter/verse numbers, or unverified claims."
            } else {
                "এই নির্দিষ্ট তথ্যটির বিষয়ে আমাদের প্রামাণিক শাস্ত্রীয় ভাণ্ডারে সুনির্দিষ্ট তথ্য অপ্রতুল বা অপর্যাপ্ত। ভুল বা অপ্রমাণিত উত্তর দেওয়ার চেয়ে বিরত থাকা ও স্পষ্ট জানানো শ্রেয় যে এর প্রামাণিক শাস্ত্রীয় সূত্র এই মুহূর্তে অনুপলব্ধ। সনাতন শাস্ত্রের বিশুদ্ধতা ও মর্যাদা রক্ষার্থে কোনো অনুমানভিত্তিক উত্তর, মনগড়া মন্ত্র, শ্লোক বা তথ্যসূত্র প্রদান করা হয় না।"
            }
            return Tuple4(insufficientMsg, null, null, emptyList())
        }

        // Case 2: Multi-Turn Context Follow-Up (e.g. "তাহলে এটা কি শুধু পূজার সঙ্গে সম্পর্কিত?")
        val lowerOrig = originalQuery.lowercase(Locale.ROOT)
        if ((lowerOrig.contains("এটা কি শুধু পূজার") || lowerOrig.contains("পূজার সাথে") || lowerOrig.contains("পূজার সঙ্গে")) &&
            (contextState.activeSubject?.contains("কর্ম", ignoreCase = true) == true || resolvedQuery.contains("কর্ম", ignoreCase = true))
        ) {
            val contextSpecificAnswer = if (isEnglish) {
                "No, Karma is not restricted solely to rituals or worship (Puja). In Sanatana Dharma, Karma encompasses all physical, verbal, and mental actions performed in daily life. While ritual worship is a form of spiritual karma (Upasana Karma), one's professional duties, moral conduct, selfless service, and everyday choices are all integral aspects of Karma."
            } else {
                "না, কর্ম শুধুমাত্র পূজা বা আচার-অনুষ্ঠানের মধ্যে সীমাবদ্ধ নয়। সনাতন দর্শনে মানুষের কায়িক (শারীরিক), বাচনিক (কথাবার্তা) ও মানসিক (চিন্তাভাবনা) — এই তিন স্তরের প্রতিটি কাজই 'কর্ম'।\n\nপূজা ও উপাসনা হলো আত্মিক সাধনামূলক কর্ম (উপাসনা কর্ম), তবে প্রাত্যহিক দায়িত্ব পালন, সততার সাথে জীবিকা নির্বাহ, পরোপকার ও নৈতিক আচরণও কর্মের অবিচ্ছেদ্য অংশ।"
            }
            return Tuple4(
                contextSpecificAnswer,
                null,
                null,
                listOf("শ্রীমদ্ভগবদ্গীতা ৩য় অধ্যায় (কর্মযোগ)", "উপনিষদ ও বেদান্ত দর্শন")
            )
        }

        // Case 3: Complex Multi-Part Decomposed Synthesis (e.g. Karma Yoga in Gita + Daily Life Application)
        if (subTasks.size > 1) {
            val canonical = evidence.firstOrNull { it.classification == EvidenceClassification.CANONICAL }
            val practical = evidence.firstOrNull { it.classification == EvidenceClassification.REASONED_INTERPRETATION }
            val hasPracticalRequest = subTasks.any { it.questionType == "PRACTICAL_APPLICATION" } ||
                    lowerOrig.contains("দৈনন্দিন") || lowerOrig.contains("প্রয়োগ") || lowerOrig.contains("daily life")

            val synthesizedText = buildString {
                if (isEnglish) {
                    append("### 🕉️ Philosophical Doctrine & Teachings\n\n")
                    if (canonical != null) {
                        append("${canonical.content}\n\n")
                    }
                    if (!canonical?.sanskritText.isNullOrBlank()) {
                        append("📖 **Canonical Shloka:**\n")
                        append("```\n${canonical?.sanskritText}\n```\n")
                        if (!canonical?.transliteration.isNullOrBlank()) {
                            append("*${canonical?.transliteration}*\n\n")
                        }
                    }
                    if (practical != null || hasPracticalRequest) {
                        append("### 🌟 Practical Application in Daily Life\n\n")
                        append("${practical?.content ?: "The essence of Karma Yoga in daily life is performing one's duties sincerely without obsessive attachment to the fruits, dedicating actions to the divine and society."}\n")
                    }
                } else {
                    append("### 🕉️ শাস্ত্রীয় তত্ত্ব ও দর্শন\n\n")
                    if (canonical != null) {
                        append("${canonical.content}\n\n")
                    }
                    if (!canonical?.sanskritText.isNullOrBlank()) {
                        append("📖 **মূল শাস্ত্রীয় শ্লোক:**\n")
                        append("> ${canonical?.sanskritText}\n")
                        if (!canonical?.transliteration.isNullOrBlank()) {
                            append("> *(${canonical?.transliteration})*\n\n")
                        }
                    }
                    if (practical != null || hasPracticalRequest) {
                        append("### 🌟 দৈনন্দিন জীবনে ব্যবহারিক প্রয়োগ\n\n")
                        append("${practical?.content ?: "কর্মযোগের মূল সূত্র হলো ফলাকাঙ্ক্ষা বর্জন করে পরমেশ্বরে সমর্পণপূর্বক নিজ কর্তব্য পালন করা। দৈনন্দিন জীবনে সততা, কর্তব্যনিষ্ঠা ও নিঃস্বার্থ সেবাই হলো কর্মযোগের প্রত্যক্ষ ব্যবহারিক প্রয়োগ।"}\n")
                    }
                }
            }.trim()

            val refs = evidence.mapNotNull {
                if (it.scripture.isNotBlank() && it.reference.isNotBlank()) "${it.scripture} (${it.reference})"
                else if (it.source.isNotBlank()) it.source
                else null
            }.distinct()

            return Tuple4(
                synthesizedText,
                canonical?.sanskritText?.ifBlank { null },
                canonical?.transliteration?.ifBlank { null },
                refs
            )
        }

        // Case 4: General Knowledge Synthesis
        val gkEvidence = evidence.firstOrNull { it.classification == EvidenceClassification.GENERAL_KNOWLEDGE }
        if (gkEvidence != null) {
            return Tuple4(
                gkEvidence.content,
                null,
                null,
                listOf(gkEvidence.source)
            )
        }

        // Case 5: Single Canonical Evidence Synthesis
        val primary = evidence.firstOrNull { it.classification == EvidenceClassification.CANONICAL } ?: evidence.first()
        val structuredAnswer = buildString {
            if (plan == AnswerPlanFormat.SHORT_ANSWER) {
                append(primary.content.lines().firstOrNull() ?: primary.content)
            } else {
                append(primary.content)
            }

            if (plan != AnswerPlanFormat.SHORT_ANSWER && primary.sanskritText.isNotBlank()) {
                append("\n\n📖 **মূল সংস্কৃত শ্লোক / মন্ত্র:**\n")
                append("> ${primary.sanskritText}")
                if (primary.transliteration.isNotBlank()) {
                    append("\n> *(${primary.transliteration})*")
                }
            }
        }.trim()

        val refs = listOfNotNull(
            if (primary.scripture.isNotBlank() && primary.reference.isNotBlank()) "${primary.scripture} (${primary.reference})"
            else if (primary.source.isNotBlank()) primary.source
            else null
        )

        return Tuple4(
            structuredAnswer,
            primary.sanskritText.ifBlank { null },
            primary.transliteration.ifBlank { null },
            refs
        )
    }

    // ==========================================
    // 8. Contradiction Detection
    // ==========================================

    fun checkContradictions(
        query: String,
        proposedAnswer: String,
        evidence: List<EvidenceItem>,
        contextState: ConversationContextState,
        history: List<Pair<String, String>>
    ): ContradictionCheckResult {
        val lowerAnswer = proposedAnswer.lowercase(Locale.ROOT)
        val lowerQuery = query.lowercase(Locale.ROOT)

        // Contradiction Rule 1: Claiming Karma Yoga teaches renunciation of work altogether (contradicts Gita 3.4, 3.8)
        if (lowerQuery.contains("কর্মযোগ") || lowerQuery.contains("karma yoga")) {
            if (lowerAnswer.contains("কর্ম ত্যাগ করাই") || lowerAnswer.contains("সব কাজ ছেড়ে দেওয়া") || lowerAnswer.contains("abandon all work")) {
                val corrected = proposedAnswer.replace("সব কাজ ছেড়ে দেওয়া", "কর্মফল ত্যাগ করে নিষ্কামভাবে কর্তব্য কর্ম করা")
                return ContradictionCheckResult(
                    hasContradiction = true,
                    contradictionReason = "Karma Yoga teaches renunciation of attachment to fruits (Karmaphala tyaga), not the abandonment of action itself (Gita 3.8).",
                    correctionApplied = true,
                    revisedReasoning = corrected
                )
            }
        }

        // Contradiction Rule 2: Deity mismatch check against active conversation subject
        if (contextState.activeDeity != null && !lowerQuery.contains("শিব") && !lowerQuery.contains("কৃষ্ণ") && !lowerQuery.contains("দুর্গা")) {
            val activeDeityLower = contextState.activeDeity.lowercase(Locale.ROOT)
            if (activeDeityLower.contains("shiva") && lowerAnswer.contains("ভগবান শ্রীকৃষ্ণকে নিবেদিত")) {
                return ContradictionCheckResult(
                    hasContradiction = true,
                    contradictionReason = "Active subject is Lord Shiva, but response mistakenly mentions Lord Krishna.",
                    correctionApplied = true,
                    revisedReasoning = proposedAnswer.replace("ভগবান শ্রীকৃষ্ণকে নিবেদিত", "ভগবান শিবের উদ্দেশ্যে নিবেদিত")
                )
            }
        }

        return ContradictionCheckResult(hasContradiction = false)
    }
}

/**
 * Utility 4-tuple for clean internal data synthesis.
 */
data class Tuple4<A, B, C, D>(
    val first: A,
    val second: B,
    val third: C,
    val fourth: D
)
