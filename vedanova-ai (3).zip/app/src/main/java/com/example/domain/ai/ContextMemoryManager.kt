package com.example.domain.ai

import java.util.Locale
import java.util.UUID

data class ConversationTurn(
    val id: String = UUID.randomUUID().toString(),
    val userQuery: String,
    val aiResponse: String,
    val intentDetected: String,
    val resolvedSubject: String?,
    val timestamp: Long = System.currentTimeMillis()
)

data class ConversationContextState(
    val sessionId: String = UUID.randomUUID().toString(),
    val activeSubject: String? = null,
    val activeTopic: String? = null,
    val previousTopic: String? = null,
    val activeDomain: String = "DHARMA", // "DHARMA", "SCIENCE", "TECH", "MATH", "GEOGRAPHY", "HISTORY", "GENERAL"
    val activeDeity: String? = null,
    val activeDeityKey: String? = null, // "SHIVA", "KRISHNA", "DURGA", "GANESHA", "SARASWATI", "LAKSHMI", "SURYA", "HANUMAN"
    val activeScripture: String? = null,
    val activeConcept: String? = null, // "Karma Yoga", "Bhakti Yoga", "Dharma", "Moksha", etc.
    val activeMantra: String? = null,
    val activeMantraSanskrit: String? = null,
    val activeMantraMeaning: String? = null,
    val activeMantraSource: String? = null,
    val activeChapter: String? = null,
    val subTopic: String? = null,
    val lastDetectedLanguage: String = "Bengali (বাংলা)",
    val threadTurnCount: Int = 0,
    val contextSummary: String = "Fresh Context",
    val recentTurns: List<ConversationTurn> = emptyList(),
    val isAwaitingMantraDisambiguation: Boolean = false,
    val isGenuinelyAmbiguous: Boolean = false,
    val ambiguityClarificationPrompt: String? = null,
    val lastAiResponseSnippet: String? = null
)

data class MultiIntentAnalysis(
    val isGreeting: Boolean = false,
    val isCreatorInquiry: Boolean = false,
    val isIdentityInquiry: Boolean = false,
    val isDeityInquiry: Boolean = false,
    val isMantraRequest: Boolean = false,
    val isMeaningRequest: Boolean = false,
    val isSourceRequest: Boolean = false,
    val isChantingMethodRequest: Boolean = false,
    val isAnotherMantraRequest: Boolean = false,
    val isMantraClarificationAnswer: Boolean = false,
    val isBroadMantraInquiry: Boolean = false,
    val isFollowUpModification: Boolean = false,
    val isTopicSwitch: Boolean = false,
    val followUpAction: String? = null,
    val detectedDeity: String? = null,
    val detectedScripture: String? = null,
    val detectedConcept: String? = null,
    val detectedGeneralTopic: String? = null,
    val detectedDomain: String = "DHARMA",
    val detectedMantra: String? = null,
    val detectedTopic: String? = null,
    val detectedSubTopic: String? = null,
    val isShortFollowUp: Boolean = false,
    val shortFollowUpType: String? = null, // "WHY", "HOW", "EXPLAIN_MORE", "WHAT_ABOUT_THIS", "WHAT_DOES_THAT_MEAN", "GIVE_EXAMPLE", "TELL_ME_MORE"
    val isAmbiguousReference: Boolean = false,
    val primaryIntent: String = "GENERAL_DHARMA",
    val secondaryIntents: List<String> = emptyList()
)

object ContextMemoryManager {

    // In-memory Session Cache for Multi-Turn API & UI conversations (SessionId -> State)
    private val sessionStore = mutableMapOf<String, ConversationContextState>()

    fun getOrCreateSession(sessionId: String): ConversationContextState {
        return sessionStore.getOrPut(sessionId) {
            ConversationContextState(sessionId = sessionId)
        }
    }

    fun updateSession(sessionId: String, updatedState: ConversationContextState) {
        sessionStore[sessionId] = updatedState
    }

    fun clearSession(sessionId: String) {
        sessionStore.remove(sessionId)
    }

    fun recordTurn(
        previousState: ConversationContextState,
        userQuery: String,
        aiResponse: String,
        intentDetected: String,
        resolvedSubject: String?
    ): ConversationContextState {
        val newTurn = ConversationTurn(
            userQuery = userQuery,
            aiResponse = aiResponse.take(300),
            intentDetected = intentDetected,
            resolvedSubject = resolvedSubject
        )
        // Keep a rolling window of recent turns to avoid memory overflow or prompt bloat
        val updatedTurns = (previousState.recentTurns + newTurn).takeLast(6)
        val currentSubj = resolvedSubject ?: previousState.activeSubject ?: previousState.activeTopic

        val summaryParts = listOfNotNull(
            previousState.activeDeity?.let { "Deity: $it" },
            previousState.activeScripture?.let { "Scripture: $it" },
            previousState.activeConcept?.let { "Concept: $it" },
            currentSubj?.let { "Subject: $it" }
        ).distinct()

        return previousState.copy(
            recentTurns = updatedTurns,
            threadTurnCount = previousState.threadTurnCount + 1,
            lastAiResponseSnippet = aiResponse.take(250),
            activeSubject = currentSubj ?: previousState.activeSubject,
            contextSummary = if (summaryParts.isNotEmpty()) summaryParts.joinToString(" | ") else "Active Thread"
        )
    }

    fun analyzeMultiIntent(query: String, previousState: ConversationContextState): MultiIntentAnalysis {
        val q = query.trim().lowercase(Locale.ROOT)

        val isCreator = q.contains("কে বানিয়েছে") || q.contains("কে তৈরি করেছে") || q.contains("কে বানিয়েছে") ||
                q.contains("কে বানাইছে") || q.contains("creator কে") || q.contains("নির্মাতা কে") ||
                q.contains("প্রস্তুতকারক") || q.contains("আবিষ্কারক") || q.contains("বানিয়েছে কে") ||
                q.contains("বানিয়েছে কে") || q.contains("তৈরি করেছে কে") ||
                q.contains("who created you") || q.contains("who made you") || q.contains("who is your creator") ||
                q.contains("who built you") || q.contains("who developed you") || q.contains("your creator") ||
                q.contains("who created dharma ai") || q.contains("creator of dharma ai") ||
                q.contains("মহামতি মিলন চন্দ্র") || q.contains("মিলন চন্দ্র") || q.contains("milon chandra")

        val isIdentity = !isCreator && (
                q.contains("তুমি কে") || q.contains("তোমার নাম কি") || q.contains("তোমার নাম কী") ||
                q.contains("তোমার পরিচয়") || q.contains("who are you") || q.contains("what is your name") ||
                q == "who are you?" || q == "who are you" || q.startsWith("tell me about yourself")
                )

        val isGreeting = !isCreator && (
                q.startsWith("নমস্কার") || q.startsWith("প্রণাম") || q.startsWith("কেমন আছো") ||
                q.startsWith("কেমন আছেন") || q == "hello" || q == "hi" || q == "namaste" ||
                q.startsWith("শুভ সকাল") || q.startsWith("শুভ সন্ধ্যা") || q.startsWith("শুভ রাত্রি") ||
                q == "ধন্যবাদ" || q == "thanks" || q == "thank you" || q.startsWith("ভালো থেকো")
                )

        // Short Follow-Up Detection (Requirement 4)
        val shortFollowUpType = when {
            q in listOf("why?", "why", "why so?", "why is that?", "why so", "কেন?", "কেন", "কেন এমন?", "কেন হয়?", "কেন হয়?") -> "WHY"
            q in listOf("how?", "how", "how so?", "how to do it?", "কীভাবে?", "কিভাবে?", "কীভাবে করব?", "কিভাবে করব?", "কীভাবে করবো?", "কিভাবে করবো?") -> "HOW"
            q in listOf("explain more.", "explain more", "more details", "আরও বলো", "আরো বলো", "আরও বিশদে বলো", "বিস্তারিত বলো", "আরেকটু বলো", "আরেকটু বিস্তারিত বলো") -> "EXPLAIN_MORE"
            q in listOf("tell me more.", "tell me more", "tell me more details", "আরও জানতে চাই", "আরো জানতে চাই", "আরেকটু খুলে বলো") -> "TELL_ME_MORE"
            q in listOf("what about this?", "what about this", "and this?", "তাহলে এটা?", "তাহলে এটা কি?", "তাহলে এটা কী?", "এটা সম্পর্কে কী?") -> "WHAT_ABOUT_THIS"
            q in listOf("what does that mean?", "what does that mean", "what does it mean?", "what does it mean", "এটার মানে কী?", "এটার মানে কি?", "এর মানে কী?", "এর মানে কি?", "মানে কী?", "মানে কি?") -> "WHAT_DOES_THAT_MEAN"
            q in listOf("give an example.", "give an example", "an example", "example please", "একটি উদাহরণ দাও", "একটি দৃষ্টান্ত দাও", "উদাহরণ দিন", "উদাহরণ দাও") -> "GIVE_EXAMPLE"
            else -> null
        }
        val isShortFollowUp = shortFollowUpType != null

        val hasPronoun = isShortFollowUp || q.contains("তার") || q.contains("তাঁর") || q.contains("উহার") ||
                q.contains("এর") || q.contains("ওর") || q.contains("এটার") || q.contains("ওটার") ||
                q.contains("এইটা") || q.contains("ওইটা") || q.contains("সেটার") || q.contains("সেটির") ||
                q.contains("এটি") || q.contains("এটা") || q.contains("তা") || q.contains("উহা") ||
                q.contains("এখানে") || q.contains("সেখানে") || q.contains("একইটা") || q.contains("অন্যটা") ||
                q.contains("আগেরটা") || q.contains("পরেরটা") || q.contains("আরেকটা") || q.contains("আরেকটি") ||
                q.contains("মন্ত্রটার") || q.contains("মন্ত্রটির") || q.contains("শ্লোকটার") || q.contains("শ্লোকটির") ||
                q.contains("মানে কী") || q.contains("মানে কি") || q.contains("কার?") || q.contains("কার") ||
                q.contains("কোথা থেকে") || q.contains("his ") || q.contains("her ") || q.contains("its ") ||
                q.contains("it ") || q.endsWith(" it") || q.contains(" it?") || q.contains("from it") ||
                q.contains("this ") || q.contains("that ") || q.contains("another ") || q.contains("previous ")

        // Follow-Up Actions
        var isFollowUp = false
        var followUpAction: String? = null

        when {
            q.contains("ছোট করে বলো") || q.contains("সংক্ষেপে বলো") || q.contains("make it shorter") || q.contains("shorten this") || q == "ছোট করো" || q == "সংক্ষেপে" -> {
                isFollowUp = true
                followUpAction = "SHORTEN"
            }
            q.contains("বাংলায় লেখো") || q.contains("বাংলায় বলো") || q.contains("in bengali") || q.contains("translate to bengali") -> {
                isFollowUp = true
                followUpAction = "TRANSLATE_BENGALI"
            }
            q.contains("ইংরেজিতে বলো") || q.contains("in english") || q.contains("translate to english") -> {
                isFollowUp = true
                followUpAction = "TRANSLATE_ENGLISH"
            }
            q.contains("আগের পয়েন্টটা") || q.contains("আগের পয়েন্ট") || q.contains("explain the previous point") || q.contains("explain that point") -> {
                isFollowUp = true
                followUpAction = "ELABORATE_PREVIOUS"
            }
            q.contains("চালিয়ে যাও") || q.contains("তারপরে") || q.contains("continue") || q.contains("go on") -> {
                isFollowUp = true
                followUpAction = "CONTINUE"
            }
            q.contains("তুমি আগে কী বলেছিলে") || q.contains("আগে কি বলেছিলে") || q.contains("what did you say earlier") -> {
                isFollowUp = true
                followUpAction = "RECALL_EARLIER"
            }
        }

        val isMantra = q.contains("মন্ত্র") || q.contains("স্তোত্র") || q.contains("শ্লোক") ||
                q.contains("mantra") || q.contains("stotra") || q.contains("verse") ||
                q.contains("shloka") || q.contains("জপ") || q.contains("প্রণাম মন্ত্র") || q.contains("তারক")

        val isMeaning = q.contains("অর্থ") || q.contains("অনুবাদ") || q.contains("ভাবার্থ") ||
                q.contains("ব্যাখ্যা") || q.contains("মানে কী") || q.contains("মানে কি") ||
                q.contains("মানে") || q.contains("meaning") || q.contains("translate") ||
                q.contains("explain") || q.contains("significance")

        val isSource = q.contains("কোথায় পাওয়া যায়") || q.contains("কোথায় পাওয়া যায়") ||
                q.contains("কোথা থেকে এসেছে") || q.contains("কোথা থেকে") ||
                q.contains("উৎস") || q.contains("কোন শাস্ত্রে") || q.contains("কোন্ গ্রন্থে") ||
                q.contains("source") || q.contains("scripture") || q.contains("which book") ||
                q.contains("reference") || q.contains("origin") || q.contains("কোথায় আছে")

        val isDeityIdentity = q.contains("এটা কার") || q.contains("এটি কার") || q.contains("কার মন্ত্র") ||
                q.contains("কোন দেবতার") || q.contains("কার শ্লোক") || q.contains("who is this for") ||
                q.contains("which deity")

        val isChanting = q.contains("কীভাবে জপ") || q.contains("কিভাবে জপ") ||
                q.contains("জপের নিয়ম") || q.contains("জপের নিয়ম") || q.contains("how to chant") || q.contains("procedure")

        val isAnother = q.contains("আরেকটা") || q.contains("আরেকটি") || q.contains("অন্য একটি") ||
                q.contains("অন্যান্য") || q.contains("another") || q.contains("one more") ||
                q.contains("more mantras") || q.contains("আরেকটা দাও") || q.contains("আরেকটি দাও") ||
                q.contains("অন্যটা দাও") || q.contains("আরেকটা শ্লোক") || q.contains("আরেকটি শ্লোক")

        // 1. Explicit Deity Detection
        val detectedDeityExplicit = when {
            q.contains("শিব") || q.contains("shiva") || q.contains("মহাদেব") || q.contains("ভোলানাথ") || q.contains("রুদ্র") -> "Lord Shiva (মহাদেব শিব)"
            q.contains("কৃষ্ণ") || q.contains("krishna") || q.contains("গোবিন্দ") -> "Lord Krishna (শ্রীকৃষ্ণ)"
            q.contains("নারায়ণ") || q.contains("বিষ্ণু") || q.contains("vishnu") || q.contains("narayana") -> "Lord Vishnu (শ্রীবিষ্ণু / নারায়ণ)"
            q.contains("দুর্গা") || q.contains("durga") || q.contains("চণ্ডী") || q.contains("মহিষাসুরমর্দিনী") -> "Maa Durga (মা দুর্গা)"
            q.contains("কালী") || q.contains("kali") || q.contains("শ্যামা") -> "Maa Kali (মা কালী)"
            q.contains("গণেশ") || q.contains("ganesha") || q.contains("সিদ্ধিদাতা") || q.contains("গণপতি") -> "Lord Ganesha (শ্রীগণেশ)"
            q.contains("সরস্বতী") || q.contains("saraswati") || q.contains("বাগদেবী") -> "Maa Saraswati (মা সরস্বতী)"
            q.contains("লক্ষ্মী") || q.contains("lakshmi") || q.contains("মহালক্ষ্মী") || q.contains("কমলা") -> "Maa Lakshmi (মা লক্ষ্মী)"
            q.contains("রাম") || q.contains("rama") || q.contains("শ্রীরাম") || q.contains("রঘুপতি") -> "Lord Rama (শ্রীরামচন্দ্র)"
            q.contains("গায়ত্রী") || q.contains("gayatri") || q.contains("সবিতা") || q.contains("সূর্য") || q.contains("surya") -> "Surya / Gayatri Devata (সূর্যদেব / গায়ত্রী)"
            q.contains("হনুমান") || q.contains("hanuman") || q.contains("বজরংবলী") -> "Lord Hanuman (শ্রীহনুমানজী)"
            else -> null
        }

        // 2. Explicit Scripture Detection
        val detectedScriptureExplicit = when {
            q.contains("গীতা") || q.contains("gita") || q.contains("bhagavad gita") -> "Bhagavad Gita (শ্রীমদ্ভগবদ্গীতা)"
            q.contains("উপনিষদ") || q.contains("upanishad") -> "Mukhya Upanishads (উপনিষদ)"
            q.contains("ঋগ্বেদ") || q.contains("বেদ") || q.contains("veda") -> "Vedas (বেদ সংহিতা)"
            q.contains("চণ্ডী") || q.contains("দেবী মাহাত্ম্য") -> "Devi Mahatmya (শ্রীশ্রীচণ্ডী)"
            q.contains("ভাগবত") || q.contains("ভাগবত পুরাণ") || q.contains("bhagavata") -> "Srimad Bhagavata Purana (শ্রীমদ্ভাগবত পুরাণ)"
            q.contains("মহাভারত") || q.contains("mahabharata") -> "Mahabharata (মহাভারত)"
            q.contains("রামায়ণ") || q.contains("ramayana") -> "Ramayana (রামায়ণ)"
            else -> null
        }

        // 3. Explicit Dharma Concept Detection (e.g. Karma Yoga, Bhakti, Moksha)
        val detectedConceptExplicit = when {
            q.contains("কর্মযোগ") || q.contains("karma yoga") || q.contains("নিষ্কাম কর্ম") || q.contains("nishkama karma") -> "Karma Yoga (কর্মযোগ ও নিষ্কাম কর্ম)"
            q.contains("ভক্তিযোগ") || q.contains("bhakti yoga") -> "Bhakti Yoga (ভক্তিযোগ)"
            q.contains("জ্ঞানযোগ") || q.contains("jnana yoga") -> "Jnana Yoga (জ্ঞানযোগ)"
            q.contains("রাজযোগ") || q.contains("raja yoga") -> "Raja Yoga (রাজযোগ)"
            q.contains("কর্মফল") || q.contains("karma theory") || (q.contains("karma") && !q.contains("yoga")) || (q.contains("কর্ম") && !q.contains("যোগ")) -> "Karma (কর্ম ও কর্মফল)"
            q.contains("মোক্ষ") || q.contains("moksha") || q.contains("মুক্তি") || q.contains("liberation") -> "Moksha (মোক্ষ ও মুক্তি)"
            q.contains("ধর্ম") || q.contains("dharma") -> "Dharma (সনাতন ধর্ম ও সার্বিক কর্তব্য)"
            q.contains("ধ্যান") || q.contains("meditation") || q.contains("dhyana") -> "Dhyana (ধ্যান ও একাগ্রতা)"
            q.contains("পূজা") || q.contains("puja") || q.contains("অর্চনা") -> "Puja (পূজা ও অর্চনা পদ্ধতি)"
            q.contains("জপ") || q.contains("japa") -> "Japa (নাম জপ ও সাধনা)"
            q.contains("অদ্বৈত") || q.contains("advaita") -> "Advaita Vedanta (অদ্বৈত বেদান্ত)"
            q.contains("দ্বৈত") || q.contains("dvaita") -> "Dvaita Vedanta (দ্বৈত বেদান্ত)"
            else -> null
        }

        // 4. Explicit General Knowledge Topic Detection (Science, Tech, Math, Geography, History)
        val detectedGeneralTopicExplicit = when {
            q.contains("photosynthesis") || q.contains("সালোকসংশ্লেষণ") || q.contains("chlorophyll") -> "Photosynthesis (সালোকসংশ্লেষণ)"
            q.contains("gravity") || q.contains("মহাকর্ষ") || q.contains("অভিকর্ষ") -> "Universal Gravitation (মহাকর্ষ)"
            q.contains("solar system") || q.contains("সৌরজগৎ") || (q.contains("গ্রহ") && !q.contains("গ্রহদোষ")) -> "Solar System (সৌরজগৎ)"
            q.contains("speed of light") || q.contains("আলোর গতি") || q.contains("আলোর বেগ") -> "Speed of Light (আলোর গতি)"
            q.contains("water cycle") || q.contains("পানি চক্র") || q.contains("জলচক্র") -> "Water Cycle (জলচক্র)"
            q.contains("dna") || q.contains("ডিএনএ") || q.contains("genetics") || q.contains("বংশগতি") -> "DNA & Genetics (ডিএনএ ও বংশগতি)"
            q.contains("artificial intelligence") || q.contains("কৃত্রিম বুদ্ধিমত্তা") || q.contains("what is ai") || q.contains("ai কি") -> "Artificial Intelligence (কৃত্রিম বুদ্ধিমত্তা)"
            q.contains("python") || q.contains("পাইথন") -> "Python Programming (পাইথন প্রোগ্রামিং)"
            q.contains("internet") || q.contains("ইন্টারনেট") || q.contains("world wide web") -> "Internet & Web (ইন্টারনেট)"
            q.contains("pythagoras") || q.contains("পীথাগোরাস") || q.contains("পাইথাগোরাস") -> "Pythagorean Theorem (পীথাগোরাসের উপপাদ্য)"
            q.contains("mount everest") || q.contains("মাউন্ট এভারেস্ট") || (q.contains("এভারেস্ট") && !q.contains("কলি")) -> "Mount Everest (মাউন্ট এভারেস্ট)"
            q.contains("paris") || q.contains("প্যারিস") || q.contains("capital of france") || q.contains("ফ্রান্সের রাজধানী") -> "Paris, France (প্যারিস ও ফ্রান্স)"
            q.contains("dhaka") || q.contains("ঢাকা") || q.contains("capital of bangladesh") || q.contains("বাংলাদেশের রাজধানী") -> "Dhaka, Bangladesh (ঢাকা, বাংলাদেশ)"
            q.contains("world war") || q.contains("দ্বিতীয় বিশ্বযুদ্ধ") -> "World War II (দ্বিতীয় বিশ্বযুদ্ধ)"
            else -> null
        }

        // Domain Classification (DHARMA vs SCIENCE / TECH / MATH / GEOGRAPHY / HISTORY / GENERAL)
        val detectedDomain = when {
            detectedGeneralTopicExplicit != null -> when {
                q.contains("photosynthesis") || q.contains("সালোকসংশ্লেষণ") || q.contains("gravity") || q.contains("মহাকর্ষ") || q.contains("solar") || q.contains("সৌরজগৎ") || q.contains("speed of light") || q.contains("আলোর গতি") || q.contains("water cycle") || q.contains("জলচক্র") || q.contains("dna") || q.contains("ডিএনএ") -> "SCIENCE"
                q.contains("ai") || q.contains("artificial intelligence") || q.contains("কৃত্রিম বুদ্ধিমত্তা") || q.contains("python") || q.contains("পাইথন") || q.contains("internet") || q.contains("ইন্টারনেট") -> "TECH"
                q.contains("pythagoras") || q.contains("পীথাগোরাস") || q.contains("পাইথাগোরাস") || q.contains("math") || q.contains("গণিত") -> "MATH"
                q.contains("everest") || q.contains("এভারেস্ট") || q.contains("paris") || q.contains("প্যারিস") || q.contains("dhaka") || q.contains("ঢাকা") -> "GEOGRAPHY"
                q.contains("world war") || q.contains("দ্বিতীয় বিশ্বযুদ্ধ") -> "HISTORY"
                else -> "GENERAL"
            }
            detectedDeityExplicit != null || detectedScriptureExplicit != null || detectedConceptExplicit != null -> "DHARMA"
            hasPronoun && previousState.activeDomain != "DHARMA" -> previousState.activeDomain
            else -> if (isGeneralKnowledgeTopic(q)) "GENERAL" else "DHARMA"
        }

        // Detect Sub-topic (e.g. duty / Karma in Gita)
        val detectedSubTopic = when {
            q.contains("duty") || q.contains("কর্তব্য") || q.contains("কর্ম") -> "DUTY_AND_KARMA"
            q.contains("devotion") || q.contains("ভক্তি") || q.contains("শরণাগতি") -> "BHAKTI_SURRENDER"
            q.contains("knowledge") || q.contains("জ্ঞান") || q.contains("আত্মজ্ঞান") -> "JNANA_SELF_REALIZATION"
            q.contains("meditation") || q.contains("ধ্যান") -> "MEDITATION"
            else -> null
        }

        // Context Correction & Topic Switch Detection (Requirement 2 & Requirement 6)
        val currentSubject = previousState.activeSubject ?: previousState.activeTopic
        val isTopicSwitch = when {
            // Explicit domain shift (e.g. Dharma -> Science/Tech/Math/GK)
            detectedGeneralTopicExplicit != null && previousState.activeDomain == "DHARMA" && currentSubject != null -> true
            // Explicit domain shift (e.g. Science/Tech/Math/GK -> Dharma)
            (detectedDeityExplicit != null || detectedScriptureExplicit != null || detectedConceptExplicit != null) && previousState.activeDomain != "DHARMA" && currentSubject != null -> true
            // Explicit deity shift (e.g. Shiva -> Durga)
            detectedDeityExplicit != null && previousState.activeDeity != null && detectedDeityExplicit != previousState.activeDeity -> true
            // Explicit scripture shift (e.g. Gita -> Chandi)
            detectedScriptureExplicit != null && previousState.activeScripture != null && detectedScriptureExplicit != previousState.activeScripture -> true
            // Explicit concept shift without pronoun continuation
            detectedConceptExplicit != null && currentSubject != null && !currentSubject.contains(detectedConceptExplicit, ignoreCase = true) && !detectedConceptExplicit.contains(currentSubject, ignoreCase = true) && !hasPronoun -> true
            else -> false
        }

        val detectedDeity = detectedDeityExplicit ?: (if (hasPronoun && !isTopicSwitch) previousState.activeDeity else null)
        val detectedScripture = detectedScriptureExplicit ?: (if (hasPronoun && !isTopicSwitch) previousState.activeScripture else null)
        val detectedConcept = detectedConceptExplicit ?: (if (hasPronoun && !isTopicSwitch) previousState.activeConcept else null)
        val detectedGeneral = detectedGeneralTopicExplicit ?: (if (hasPronoun && !isTopicSwitch && previousState.activeDomain != "DHARMA") previousState.activeSubject else null)

        val detectedMantra = when {
            q.contains("মহামৃত্যুঞ্জয়") || q.contains("mrityunjaya") || q.contains("ত্র্যম্বক") -> "Maha Mrityunjaya Mantra (মহামৃত্যুঞ্জয় মন্ত্র)"
            q.contains("গায়ত্রী") || q.contains("gayatri") -> "Gayatri Mantra (গায়ত্রী মন্ত্র)"
            q.contains("হরে কৃষ্ণ") || q.contains("মহামন্ত্র") -> "Hare Krishna Mahamantra (হরে কৃষ্ণ মহামন্ত্র)"
            q.contains("ওঁ নমঃ শিবায়") || q.contains("শিব পঞ্চাক্ষর") || q.contains("নমঃ শিবায়") || q.contains("নমঃ শিবায়") -> "Shiva Panchakshari Mantra (ওঁ নমঃ শিবায়)"
            q.contains("ওঁ গং গণপতয়ে") || q.contains("গণেশ মন্ত্র") -> "Ganesha Beej Mantra (ওঁ গং গণপতয়ে নমঃ)"
            q.contains("ওঁ নমো নারায়ণায়") || q.contains("নারায়ণ মন্ত্র") || q.contains("বিষ্ণু মন্ত্র") -> "Vishnu Ashtakshari Mantra (ওঁ নমো নারায়ণায়)"
            q.contains("ওঁ দুং দুর্গায়ৈ") || q.contains("দুর্গা বীজ") -> "Durga Beej Mantra (ওঁ দুং দুর্গায়ৈ নমঃ)"
            q.contains("ওঁ ঐং সরস্বত্যৈ") || q.contains("সরস্বতী বীজ") -> "Saraswati Beej Mantra (ওঁ ঐং সরস্বত্যৈ নমঃ)"
            q.contains("ওঁ শ্রীং মহালক্ষ্ম্যৈ") || q.contains("লক্ষ্মী বীজ") -> "Lakshmi Beej Mantra (ওঁ শ্রীং মহালক্ষ্ম্যৈ নমঃ)"
            q.contains("ওঁ সূর্যায় নমঃ") || q.contains("সূর্য প্রণাম") -> "Surya Pranam Mantra (ওঁ সূর্যায় নমঃ)"
            q.contains("শ্রী রাম জয় রাম") || q.contains("তারক মন্ত্র") -> "Rama Taraka Mantra (শ্রী রাম জয় রাম জয় জয় রাম)"
            hasPronoun && previousState.activeMantra != null && !isTopicSwitch -> previousState.activeMantra
            else -> null
        }

        val secondaryList = mutableListOf<String>()
        if (isCreator) secondaryList.add("CREATOR_IDENTITY")
        if (isIdentity) secondaryList.add("AI_IDENTITY")
        if (isMantra) secondaryList.add("MANTRA_TEXT")
        if (isMeaning) secondaryList.add("MEANING")
        if (isSource) secondaryList.add("CANONICAL_SOURCE")
        if (isDeityIdentity) secondaryList.add("DEITY_IDENTITY")
        if (isChanting) secondaryList.add("CHANTING_PROCEDURE")
        if (isAnother) secondaryList.add("ANOTHER_MANTRA")
        if (isFollowUp) secondaryList.add("FOLLOW_UP_$followUpAction")
        if (isShortFollowUp) secondaryList.add("SHORT_FOLLOW_UP_$shortFollowUpType")

        val primaryIntent = when {
            isCreator -> "CREATOR_IDENTITY"
            isIdentity -> "AI_IDENTITY"
            isGreeting -> "GREETING"
            detectedDomain != "DHARMA" -> "GENERAL_KNOWLEDGE"
            isFollowUp -> "FOLLOW_UP_MODIFICATION"
            isShortFollowUp -> "SHORT_FOLLOW_UP"
            isDeityIdentity -> "DEITY_IDENTITY_QUERY"
            isAnother && (detectedScripture?.contains("Gita", ignoreCase = true) == true || previousState.activeScripture?.contains("Gita", ignoreCase = true) == true) -> "ANOTHER_GITA_SHLOKA"
            isAnother -> "ANOTHER_MANTRA_REQUEST"
            isMeaning && isSource && isMantra -> "MULTI_INTENT_MANTRA_DECOMPOSITION"
            isMeaning && isSource -> "MULTI_INTENT_SOURCE_AND_MEANING"
            isMeaning -> "MANTRA_MEANING_QUERY"
            isSource -> "SCRIPTURE_SOURCE_QUERY"
            isChanting -> "CHANTING_PROCEDURE_QUERY"
            isMantra -> "MANTRA_REQUEST"
            detectedDeity != null && hasPronoun -> "DEITY_FOLLOW_UP"
            detectedDeity != null -> "DEITY_INQUIRY"
            detectedConcept != null -> "CONCEPT_INQUIRY"
            else -> "GENERAL_DHARMA"
        }

        return MultiIntentAnalysis(
            isGreeting = isGreeting,
            isCreatorInquiry = isCreator,
            isIdentityInquiry = isIdentity,
            isDeityInquiry = detectedDeity != null,
            isMantraRequest = isMantra,
            isMeaningRequest = isMeaning,
            isSourceRequest = isSource,
            isChantingMethodRequest = isChanting,
            isAnotherMantraRequest = isAnother,
            isMantraClarificationAnswer = false,
            isBroadMantraInquiry = false,
            isFollowUpModification = isFollowUp,
            isTopicSwitch = isTopicSwitch,
            followUpAction = followUpAction,
            detectedDeity = detectedDeity,
            detectedScripture = detectedScripture,
            detectedConcept = detectedConcept,
            detectedGeneralTopic = detectedGeneral,
            detectedDomain = detectedDomain,
            detectedMantra = detectedMantra,
            detectedTopic = detectedGeneral ?: detectedConcept ?: detectedDeity ?: detectedScripture ?: detectedMantra,
            detectedSubTopic = detectedSubTopic,
            isShortFollowUp = isShortFollowUp,
            shortFollowUpType = shortFollowUpType,
            isAmbiguousReference = false,
            primaryIntent = primaryIntent,
            secondaryIntents = secondaryList
        )
    }

    fun extractContextEntities(query: String, previousState: ConversationContextState): ConversationContextState {
        val analysis = analyzeMultiIntent(query, previousState)

        // Context Purging upon topic switch (Requirement 2 & Requirement 6)
        val resolvedDeity = if (analysis.isTopicSwitch) analysis.detectedDeity else (analysis.detectedDeity ?: previousState.activeDeity)
        val resolvedScripture = if (analysis.isTopicSwitch) analysis.detectedScripture else (analysis.detectedScripture ?: previousState.activeScripture)
        val resolvedConcept = if (analysis.isTopicSwitch) analysis.detectedConcept else (analysis.detectedConcept ?: previousState.activeConcept)
        val resolvedGeneral = if (analysis.isTopicSwitch) analysis.detectedGeneralTopic else (analysis.detectedGeneralTopic ?: if (analysis.detectedDomain != "DHARMA") previousState.activeSubject else null)
        val resolvedMantra = if (analysis.isTopicSwitch) analysis.detectedMantra else (analysis.detectedMantra ?: previousState.activeMantra)

        val currentTopic = analysis.detectedTopic ?: previousState.activeTopic
        val resolvedSubject = resolvedGeneral ?: resolvedConcept ?: resolvedMantra ?: resolvedDeity ?: resolvedScripture ?: previousState.activeSubject

        val summaryParts = listOfNotNull(
            resolvedDeity?.let { "Deity: $it" },
            resolvedScripture?.let { "Scripture: $it" },
            resolvedConcept?.let { "Concept: $it" },
            resolvedGeneral?.let { "Topic: $it" },
            resolvedMantra?.let { "Mantra/Verse: $it" }
        )
        val summary = if (summaryParts.isNotEmpty()) summaryParts.joinToString(" | ") else "General Context"

        return previousState.copy(
            activeSubject = resolvedSubject,
            activeTopic = currentTopic,
            previousTopic = if (analysis.isTopicSwitch) (previousState.activeSubject ?: previousState.activeTopic) else previousState.previousTopic,
            activeDomain = analysis.detectedDomain,
            activeDeity = resolvedDeity,
            activeScripture = resolvedScripture,
            activeConcept = resolvedConcept,
            activeMantra = resolvedMantra,
            subTopic = analysis.detectedSubTopic ?: (if (!analysis.isTopicSwitch) previousState.subTopic else null),
            threadTurnCount = previousState.threadTurnCount + 1,
            contextSummary = summary
        )
    }

    fun resolveMultiTurnQuery(
        query: String,
        history: List<Pair<String, String>>,
        contextState: ConversationContextState
    ): String {
        val trimmed = query.trim()
        val lower = trimmed.lowercase(Locale.ROOT)
        val isQueryEnglish = !trimmed.any { it in '\u0980'..'\u09FF' }
        val analysis = analyzeMultiIntent(query, contextState)

        // Case 0: Ambiguous Reference Check with No Context (Requirement 6)
        val isPurePronoun = lower in listOf(
            "what is his mantra?", "what is his mantra", "what is her mantra?", "his mantra?", "his mantra",
            "who is he?", "who is he", "who is she?", "who is she", "who is this?", "who is this",
            "tell me about him", "tell me about her", "what about him?", "what about her?",
            "তার মন্ত্র কী?", "তার মন্ত্র কি?", "তাঁর মন্ত্র কী?", "তাঁর মন্ত্র কি?", "তিনি কে?", "সে কে?",
            "তার নাম কী?", "তাঁর নাম কী?", "তার কথা বলো", "তাঁর কথা বলো"
        )
        if (isPurePronoun && contextState.activeDeity == null && contextState.activeSubject == null && history.isEmpty()) {
            return if (isQueryEnglish) {
                "AMBIGUOUS_CLARIFICATION: Could you please clarify which specific deity, person, or scripture you are referring to so I can provide an accurate answer?"
            } else {
                "AMBIGUOUS_CLARIFICATION: আপনি কোন নির্দিষ্ট দেবতা, ব্যক্তিত্ব বা শাস্ত্রীয় প্রসঙ্গ সম্পর্কে জানতে চাচ্ছেন, অনুগ্রহ করে একটু স্পষ্ট করে উল্লেখ করবেন কি? (যেমন: মহাদেব শিব, শ্রীকৃষ্ণ, মা দুর্গা ইত্যাদি)"
            }
        }

        // Case 1: Follow-Up Action modification (e.g. "ছোট করে বলো", "বাংলায় লেখো")
        if (analysis.isFollowUpModification && contextState.lastAiResponseSnippet != null) {
            when (analysis.followUpAction) {
                "SHORTEN" -> return if (isQueryEnglish) "Concise summary of previous response: ${contextState.lastAiResponseSnippet}" else "আগের উত্তরের সংক্ষিপ্ত সারমর্ম: ${contextState.lastAiResponseSnippet}"
                "TRANSLATE_BENGALI" -> return "পূর্ববর্তী উত্তরের সহজ বাংলা অনুবাদ: ${contextState.lastAiResponseSnippet}"
                "TRANSLATE_ENGLISH" -> return "English translation of the previous response: ${contextState.lastAiResponseSnippet}"
                "ELABORATE_PREVIOUS" -> return if (isQueryEnglish) "Elaborate further on previous response: ${contextState.lastAiResponseSnippet}" else "পূর্ববর্তী মূল পয়েন্টের বিশদ ব্যাখ্যা: ${contextState.lastAiResponseSnippet}"
                "CONTINUE" -> return if (isQueryEnglish) "Continue next part of discussion: ${contextState.lastAiResponseSnippet}" else "পূর্ববর্তী আলোচনার পরবর্তী অংশ বিস্তার: ${contextState.lastAiResponseSnippet}"
                "RECALL_EARLIER" -> return if (isQueryEnglish) "Earlier discussion summary: ${contextState.contextSummary}" else "আমরা পূর্বে আলোচনা করছিলাম: ${contextState.contextSummary}"
            }
        }

        // Case 2: Combined Intent + Context (Requirement 5)
        // User: Tell me about Bhagavad Gita. -> User: Give me a shloka about duty from it.
        val isDutyShloka = (lower.contains("duty") || lower.contains("কর্তব্য") || lower.contains("কর্ম")) &&
                (lower.contains("shloka") || lower.contains("verse") || lower.contains("শ্লোক")) &&
                (lower.contains("from it") || lower.contains("from the gita") || lower.contains("from gita") ||
                 lower.contains("এখান থেকে") || lower.contains("এর থেকে") ||
                 contextState.activeScripture?.contains("Gita", ignoreCase = true) == true)

        if (isDutyShloka) {
            return if (isQueryEnglish) {
                "Authentic shloka about duty (Karma Yoga) from the Bhagavad Gita (such as Chapter 2 Verse 47) with Sanskrit text, translation, and philosophical explanation"
            } else {
                "শ্রীমদ্ভগবদ্গীতা থেকে কর্তব্য ও নিষ্কাম কর্মযোগ বিষয়ক প্রামাণিক শ্লোক (যেমন ২.৪৭ শ্লোক), মূল সংস্কৃত পাঠ, অন্বয় ও বঙ্গানুবাদ"
            }
        }

        // Case 3: Concept Meaning in Daily Life Pronoun Resolution (Requirement 1)
        // User: What is Karma Yoga? -> User: What does it mean in daily life?
        val alreadyExplicitConcept = (lower.contains("কর্মযোগ") || lower.contains("karma yoga")) &&
                (lower.contains("গীতা") || lower.contains("gita"))
        val hasDailyLife = lower.contains("daily life") || lower.contains("দৈনন্দিন জীবন") || lower.contains("দৈনন্দিন জীবনে") ||
                lower.contains("in practice") || lower.contains("বাস্তব জীবনে") || lower.contains("জীবনে প্রয়োগ") ||
                lower.contains("প্রয়োগ কী") || lower.contains("প্রয়োগ কি") || lower.contains("প্রয়োগ কি") || lower.contains("প্রয়োগ কী")
        val hasItOrMeaning = lower.contains("it") || lower.contains("এর") || lower.contains("এটার") || lower.contains("উহার") ||
                lower.contains("তার") || lower.contains("mean") || lower.contains("অর্থ") || lower.contains("মানে")
        if (!alreadyExplicitConcept && hasDailyLife && (hasItOrMeaning || contextState.activeConcept != null || contextState.activeSubject != null)) {
            val concept = contextState.activeConcept ?: contextState.activeSubject ?: "Karma Yoga"
            return if (isQueryEnglish) {
                "What does $concept mean and how is it applied in daily life?"
            } else {
                "$concept এর অর্থ এবং দৈনন্দিন জীবনে এর ব্যবহারিক প্রয়োগ ও তাৎপর্য"
            }
        }

        // Case 4: Deity Main Mantra Pronoun Resolution (Requirement 1)
        // User: Tell me about Shiva. -> User: What is his main mantra?
        val queryTokens = lower.split("\\s+".toRegex()).map { it.trim(',', '.', '?', '!', '।', ':', ';') }
        val hasStandalonePronoun = queryTokens.any { it in setOf("his", "her", "its", "it", "তার", "তাঁর", "উনার", "তারটা", "তাঁরটা", "উনারটা", "এর") }
        val hasMantraRequest = lower.contains("mantra") || lower.contains("মন্ত্র") || lower.contains("শ্লোক") || lower.contains("স্তোত্র")
        if (hasMantraRequest && (hasStandalonePronoun || lower.contains("main mantra") || lower.contains("মূল মন্ত্র") || lower.contains("প্রধান মন্ত্র"))) {
            val deity = contextState.activeDeity ?: "Lord Shiva (মহাদেব শিব)"
            return if (isQueryEnglish) {
                "What is $deity's main authentic mantra, Sanskrit text, canonical source, and spiritual meaning?"
            } else {
                "$deity এর প্রামাণিক মূল ও প্রধান মন্ত্র (পঞ্চাক্ষর বা বীজ ও প্রণাম মন্ত্র), সংস্কৃত পাঠ, শাস্ত্রীয় উৎস ও অর্থ"
            }
        }

        // Case 5: Short Follow-Up Questions (Requirement 4)
        // Understand short follow-ups: Why?, How?, Explain more., What about this?, What does that mean?, Give an example., Tell me more.
        if (analysis.isShortFollowUp) {
            val target = contextState.activeConcept ?: contextState.activeSubject ?: contextState.activeDeity ?: contextState.activeScripture ?: "বর্তমান বিষয়টি"
            return if (isQueryEnglish) {
                when (analysis.shortFollowUpType) {
                    "WHY" -> "Why is $target significant, and what is its core reason and spiritual purpose?"
                    "HOW" -> "How is $target practiced and applied in life step-by-step?"
                    "EXPLAIN_MORE" -> "Detailed explanation and deeper scriptural analysis of $target"
                    "TELL_ME_MORE" -> "Please elaborate further with more depth and insights on $target"
                    "WHAT_ABOUT_THIS" -> "Further contextual explanation and related aspects of $target"
                    "WHAT_DOES_THAT_MEAN" -> "What is the precise meaning, definition, and significance of $target?"
                    "GIVE_EXAMPLE" -> "Give an authentic scriptural and practical example of $target"
                    else -> "Further details regarding $target"
                }
            } else {
                when (analysis.shortFollowUpType) {
                    "WHY" -> "$target এর পেছনের মূল কারণ, উদ্দেশ্য ও তাৎপর্য কী?"
                    "HOW" -> "$target কীভাবে জীবনে বাস্তবায়ন ও অনুশীলন করতে হয়?"
                    "EXPLAIN_MORE" -> "$target সম্পর্কে আরও গভীর, প্রামাণিক ও বিস্তারিত ব্যাখ্যা"
                    "TELL_ME_MORE" -> "$target সম্পর্কে আরও তথ্য ও তাৎপর্য বিস্তার"
                    "WHAT_ABOUT_THIS" -> "$target সম্পর্কিত বিশেষ দিক ও প্রাসঙ্গিক ব্যাখ্যা"
                    "WHAT_DOES_THAT_MEAN" -> "$target এর মূল অর্থ, সংজ্ঞা ও ভাবার্থ কী?"
                    "GIVE_EXAMPLE" -> "$target এর একটি বাস্তব ও শাস্ত্রীয় দৃষ্টান্ত ও উদাহরণ"
                    else -> "$target সম্পর্কিত বিস্তারিত ব্যাখ্যা"
                }
            }
        }

        // Case 6: Deity topic switch with particle ("এবার দুর্গারটা দাও" / "এবার শিবেরটা")
        if (lower.contains("এবার দুর্গার") || lower.contains("দুর্গারটা")) {
            return "মা দুর্গার প্রামাণিক বীজ ও প্রণাম মন্ত্র"
        }
        if (lower.contains("এবার শিবের") || lower.contains("শিবেরটা")) {
            return "ভগবান শিবের প্রামাণিক পঞ্চাক্ষর মন্ত্র"
        }
        if (lower.contains("এবার গণেশের") || lower.contains("গণেশেরটা")) {
            return "ভগবান শ্রীগণেশের প্রামাণিক বীজ মন্ত্র"
        }
        if (lower.contains("এবার বিষ্ণুর") || lower.contains("বিষ্ণুরটা")) {
            return "ভগবান শ্রীবিষ্ণুর প্রামাণিক অষ্টাক্ষর মন্ত্র"
        }

        // Case 7: Meaning follow up ("এর অর্থ কী?" / "এর মানে কী?" / "its meaning")
        val hasMeaningFollowUp = (lower == "মানে কী?" || lower == "মানে কি?" ||
                lower == "এর অর্থ কি?" || lower == "এর অর্থ কী?" || lower == "অর্থ কী?" || lower == "অর্থ কি?" ||
                lower.contains("এর অর্থ") || lower.contains("এর মানে") || lower.contains("এটার অর্থ") ||
                lower.contains("its meaning"))
        if (hasMeaningFollowUp) {
            val target = contextState.activeMantra ?: contextState.activeConcept ?: contextState.activeSubject
            if (target != null) {
                return if (isQueryEnglish) {
                    "What is the authentic meaning and spiritual significance of $target?"
                } else {
                    "$target এর শাস্ত্রীয় সংস্কৃত অর্থ, বাংলা অনুবাদ ও ভাবার্থ"
                }
            }
        }

        // Case 8: Deity identity follow up ("এটা কার?" / "এটি কার মন্ত্র?")
        if (lower.contains("এটা কার") || lower.contains("এটি কার") || lower.contains("কার মন্ত্র") || lower == "এটা কার?") {
            val target = contextState.activeMantra ?: contextState.activeSubject
            if (target != null) {
                return "$target কোন পরমেশ্বর বা দেবতার উদ্দেশ্যে নিবেদিত এবং তাঁর পরিচয়"
            }
        }

        // Case 9: Source follow up ("এটা কোথা থেকে এসেছে?" / "কোথায় পাওয়া যায়?" / "কোন শাস্ত্রে আছে?")
        val hasSourceFollowUp = (lower.contains("কোথা থেকে এসেছে") || lower.contains("কোথায় পাওয়া যায়") || lower.contains("কোথায় পাওয়া যায়") ||
                lower.contains("কোন শাস্ত্রে আছে") || lower.contains("where is it found") ||
                lower in listOf("উৎস কী?", "উৎস কি?", "উৎস কী", "উৎস কি", "এর উৎস কী?", "এর উৎস কি?"))
        if (hasSourceFollowUp) {
            val target = contextState.activeMantra ?: contextState.activeSubject ?: contextState.activeScripture
            if (target != null) {
                return if (isQueryEnglish) {
                    "What is the authentic scriptural source and textual reference of $target?"
                } else {
                    "$target এর প্রামাণিক শাস্ত্রীয় গ্রন্থসূত্র ও বৈদিক প্রসঙ্গ"
                }
            }
        }

        // Case 10: Another mantra or verse follow up ("আরেকটা দাও" / "আরেকটি মন্ত্র বলো" / "আরেকটা শ্লোক দাও")
        if (analysis.isAnotherMantraRequest) {
            if (contextState.activeScripture?.contains("Gita", ignoreCase = true) == true || lower.contains("শ্লোক")) {
                return "শ্রীমদ্ভগবদ্গীতার আরেকটি প্রামাণিক শ্লোক ও বঙ্গানুবাদ"
            }
            if (contextState.activeDeity != null) {
                return "${contextState.activeDeity} এর আরেকটি প্রামাণিক বৈদিক বা পৌরাণিক মন্ত্র"
            }
            return "আরেকটি প্রামাণিক শাস্ত্রীয় বৈদিক মন্ত্র ও অর্থ"
        }

        return trimmed
    }

    private fun isGeneralKnowledgeTopic(query: String): Boolean {
        val q = query.lowercase(Locale.ROOT)
        return q.contains("photosynthesis") || q.contains("সালোকসংশ্লেষণ") ||
                q.contains("gravity") || q.contains("মহাকর্ষ") ||
                q.contains("solar system") || q.contains("সৌরজগৎ") ||
                q.contains("speed of light") || q.contains("আলোর গতি") ||
                q.contains("water cycle") || q.contains("পানি চক্র") ||
                q.contains("dna") || q.contains("ডিএনএ") ||
                q.contains("artificial intelligence") || q.contains("কৃত্রিম বুদ্ধিমত্তা") ||
                q.contains("python") || q.contains("পাইথন") ||
                q.contains("internet") || q.contains("ইন্টারনেট") ||
                q.contains("pythagoras") || q.contains("পীথাগোরাস") ||
                q.contains("mount everest") || q.contains("এভারেস্ট") ||
                q.contains("capital of france") || q.contains("প্যারিস") ||
                q.contains("capital of bangladesh") || q.contains("ঢাকা")
    }
}
