package com.example.domain.ai

import java.util.Locale

enum class QuestionIntentType {
    DHARMA_DEFINITION,       // "What is Krishna / Gita / Dharma?" -> Essence / Concept
    DHARMA_EXPOSITION,       // "Tell me about Krishna / Mahabharata" -> Comprehensive narrative / Bio
    DHARMA_HISTORICAL,       // "Who was Krishna / Shankara / Rama?" -> Historical / Avatara identity
    DHARMA_SIGNIFICANCE,     // "Why is Krishna important? / Why celebrate Diwali?" -> Spiritual & philosophical importance
    CANONICAL_SCRIPTURE,     // Specific verses, mantras, Vedas, Upanishads, Gita citations
    MANTRA_AND_STOTRA,       // Mantra text, meaning, chanting method
    RITUAL_AND_FESTIVAL,     // Tithi, Panchanga, Puja, Fasting, Auspicious dates
    PHILOSOPHY_AND_DARSHANA, // Advaita, Dvaita, Samkhya, Yoga, Nyaya, Vaisheshika, Mimamsa
    CREATIVE_WRITING,        // Essays, reflections, stories, prayers, summaries, speeches, notes
    GENERAL_KNOWLEDGE,       // Science, history, geography, math, tech, language, daily life
    CREATOR_IDENTITY,        // "Who created you?" / "তোমাকে কে বানিয়েছে?"
    AI_IDENTITY,             // "Who are you?" / "তুমি কে?"
    SYSTEM_HEALTH_CHECK,     // "কোনো সমস্যা আছে?" / "Check yourself"
    GREETING,                // "নমস্কার", "Hello", "How are you?"
    FOLLOW_UP_MODIFICATION,  // "Make it shorter", "Now write in Bengali", "Explain previous point"
    UNKNOWN_GROUNDING        // Knowledge not verified
}

enum class ResponseStyleRequest {
    CONCISE,                 // Short answer requested ("সংক্ষেপে", "ছোট করে", "short")
    DETAILED,                // Deep detailed analysis ("বিস্তারিত", "detailed", "in-depth")
    SIMPLE,                  // Beginner-friendly simple language ("সহজ ভাষায়", "simple")
    SCHOLARLY,               // Philosophical/academic exegesis ("পাণ্ডিত্যপূর্ণ", "scholarly")
    STEP_BY_STEP,            // Step-by-step instructions ("ধাপে ধাপে", "step by step")
    BALANCED                 // Standard natural length
}

enum class CreativeWritingType {
    NONE,
    ESSAY,                   // "প্রবন্ধ", "রচনা", "essay"
    REFLECTION,              // "আধ্যাত্মিক ভাবনা", "devotional reflection", "spiritual thought"
    STORY,                   // "গল্প", "story", "parable"
    PRAYER_COMPOSITION,      // "প্রার্থনা রচনা", "prayer", "devotional hymn"
    EXPLANATION_ARTICLE,     // "বিশ্লেষণমূলক নিবন্ধ", "article", "expository piece"
    SUMMARY,                 // "সারসংক্ষেপ", "summary", "gist"
    STUDY_NOTES,             // "স্টাডি নোট", "study notes", "bullet points"
    QA_LESSON,               // "প্রশ্নোত্তর পাঠ", "lesson"
    SOCIAL_CAPTION,          // "ক্যাপশন", "social media caption", "status"
    SPEECH,                  // "বক্তব্য", "ভাষণ", "speech"
    POEM,                    // "ভক্তিমূলক কবিতা", "কবিতা", "poem", "devotional poem", "poetry"
    PUJA_GREETING,           // "পূজার শুভেচ্ছা", "উৎসবের শুভেচ্ছা", "puja greeting", "blessings"
    ORIGINAL_MANTRA_COMPOSITION // "নতুন মন্ত্র/শ্লোক রচনা", "original shloka composition"
}

data class IntentAnalysisResult(
    val primaryIntent: QuestionIntentType,
    val subIntents: List<String>,
    val detectedTopic: String?,
    val isDharmaRelated: Boolean,
    val styleRequest: ResponseStyleRequest,
    val creativeWritingType: CreativeWritingType,
    val targetLanguage: String, // "Bengali", "English", "Sanskrit", "Mixed"
    val isFollowUp: Boolean,
    val followUpAction: String? = null // "SHORTEN", "TRANSLATE_BENGALI", "TRANSLATE_ENGLISH", "ELABORATE_PREVIOUS", "CONTINUE"
)

object DharmaIntentEngine {

    fun analyze(query: String, history: List<Pair<String, String>> = emptyList()): IntentAnalysisResult {
        val raw = query.trim()
        val lower = raw.lowercase(Locale.ROOT)

        // 1. Target Language Detection
        val targetLanguage = when {
            raw.any { it in '\u0980'..'\u09FF' } && raw.any { it in 'a'..'z' || it in 'A'..'Z' } -> "Bengali + English (Mixed)"
            raw.any { it in '\u0980'..'\u09FF' } -> "Bengali"
            raw.any { it in '\u0900'..'\u097F' } -> "Sanskrit"
            else -> "English"
        }

        // 2. Response Style Request Detection
        val style = when {
            lower.contains("সংক্ষেপে") || lower.contains("ছোট করে") || lower.contains("এক লাইনে") ||
            lower.contains("make it short") || lower.contains("make it shorter") || lower.contains("short answer") ||
            lower.contains("briefly") || lower.contains("concise") || lower.contains("in brief") -> ResponseStyleRequest.CONCISE

            lower.contains("বিস্তারিত") || lower.contains("বিশদভাবে") || lower.contains("গভীরভাবে") ||
            lower.contains("detailed") || lower.contains("in detail") || lower.contains("in-depth") ||
            lower.contains("comprehensive") -> ResponseStyleRequest.DETAILED

            lower.contains("সহজ ভাষায়") || lower.contains("সহজ করে") || lower.contains("সহজভাবে") ||
            lower.contains("simple") || lower.contains("simply") || lower.contains("for beginner") ||
            lower.contains("like i am 5") -> ResponseStyleRequest.SIMPLE

            lower.contains("পাণ্ডিত্যপূর্ণ") || lower.contains("শাস্ত্রীয়ভাবে") || lower.contains("তাত্ত্বিক") ||
            lower.contains("scholarly") || lower.contains("academic") || lower.contains("philosophical") -> ResponseStyleRequest.SCHOLARLY

            lower.contains("ধাপে ধাপে") || lower.contains("পর্যায়ক্রমে") || lower.contains("নিয়মাবলী") ||
            lower.contains("step by step") || lower.contains("steps") || lower.contains("instructions") -> ResponseStyleRequest.STEP_BY_STEP

            else -> ResponseStyleRequest.BALANCED
        }

        // 3. Creative Writing Type Detection
        val writingType = when {
            // New Mantra/Shloka Composition request (MUST be checked before general mantra)
            (lower.contains("নতুন মন্ত্র") || lower.contains("নতুন শ্লোক") || lower.contains("মন্ত্র তৈরি") ||
             lower.contains("মন্ত্র বানাও") || lower.contains("শ্লোক বানাও") || lower.contains("শ্লোক রচনা") ||
             lower.contains("নতুন একটি মন্ত্র") || lower.contains("নতুন একটি শ্লোক") ||
             lower.contains("write a new mantra") || lower.contains("compose a new mantra") ||
             lower.contains("create a mantra") || lower.contains("compose a shloka") || lower.contains("new devotional shloka") ||
             lower.contains("compose a devotional verse")) -> CreativeWritingType.ORIGINAL_MANTRA_COMPOSITION

            lower.contains("কবিতা") || lower.contains("কাব্য") || lower.contains("poem") || lower.contains("poetry") -> CreativeWritingType.POEM

            lower.contains("পূজার শুভেচ্ছা") || lower.contains("পূজা শুভেচ্ছা") || lower.contains("উৎসবের শুভেচ্ছা") ||
            lower.contains("শুভেচ্ছা বার্তা") || lower.contains("শুভেচ্ছা লিখ") || lower.contains("শুভেচ্ছা লেখ") ||
            lower.contains("puja greeting") || lower.contains("festive greeting") || lower.contains("spiritual greeting") ||
            lower.contains("দীபாவলির শুভেচ্ছা") || lower.contains("শিবরাত্রির শুভেচ্ছা") -> CreativeWritingType.PUJA_GREETING

            lower.contains("প্রবন্ধ") || lower.contains("রচনা") || lower.contains("essay") -> CreativeWritingType.ESSAY
            lower.contains("প্রতিফলন") || lower.contains("ভাবনা") || lower.contains("reflection") || lower.contains("spiritual thought") -> CreativeWritingType.REFLECTION
            lower.contains("গল্প") || lower.contains("কাহিনী") || lower.contains("story") || lower.contains("parable") || lower.contains("tale") -> CreativeWritingType.STORY
            lower.contains("প্রার্থনা") || lower.contains("prayer") || lower.contains("devotional composition") || lower.contains("স্তুতি লেখ") -> CreativeWritingType.PRAYER_COMPOSITION
            lower.contains("নিবন্ধ") || lower.contains("article") || lower.contains("editorial") || lower.contains("নতুন লেখা") || lower.contains("লেখা তৈরি") -> CreativeWritingType.EXPLANATION_ARTICLE
            lower.contains("সারসংক্ষেপ") || lower.contains("সারমর্ম") || lower.contains("summary") || lower.contains("gist") -> CreativeWritingType.SUMMARY
            lower.contains("নোট") || lower.contains("স্টাডি নোট") || lower.contains("notes") || lower.contains("study notes") || lower.contains("bullet points") -> CreativeWritingType.STUDY_NOTES
            lower.contains("প্রশ্নোত্তর") || lower.contains("পাঠ") || lower.contains("q&a") || lower.contains("lesson") -> CreativeWritingType.QA_LESSON
            lower.contains("ক্যাপশন") || lower.contains("স্ট্যাটাস") || lower.contains("caption") || lower.contains("status") -> CreativeWritingType.SOCIAL_CAPTION
            lower.contains("বক্তব্য") || lower.contains("ভাষণ") || lower.contains("speech") || lower.contains("address") -> CreativeWritingType.SPEECH
            else -> CreativeWritingType.NONE
        }

        // 4. Follow-up Action Detection
        var isFollowUp = false
        var followUpAction: String? = null

        if (history.isNotEmpty()) {
            when {
                lower.contains("ছোট করে বলো") || lower.contains("সংক্ষেপে বলো") || lower.contains("make it shorter") || lower.contains("shorten") -> {
                    isFollowUp = true
                    followUpAction = "SHORTEN"
                }
                lower.contains("বাংলায় লেখো") || lower.contains("বাংলায় লিখুন") || lower.contains("in bengali") || lower.contains("translate to bengali") -> {
                    isFollowUp = true
                    followUpAction = "TRANSLATE_BENGALI"
                }
                lower.contains("in english") || lower.contains("translate to english") || lower.contains("ইংরেজিতে বলো") -> {
                    isFollowUp = true
                    followUpAction = "TRANSLATE_ENGLISH"
                }
                lower.contains("আগের পয়েন্টটা") || lower.contains("আগের পয়েন্ট") || lower.contains("previous point") || lower.contains("explain that point") -> {
                    isFollowUp = true
                    followUpAction = "ELABORATE_PREVIOUS"
                }
                lower.contains("চালিয়ে যাও") || lower.contains("তারপরে") || lower.contains("continue") || lower.contains("go on") -> {
                    isFollowUp = true
                    followUpAction = "CONTINUE"
                }
                lower.contains("তুমি আগে কী বলেছিলে") || lower.contains("what did you say earlier") || lower.contains("what were we talking about") -> {
                    isFollowUp = true
                    followUpAction = "RECALL_EARLIER"
                }
            }
        }

        // 5. Creator Identity
        if (isCreator(lower)) {
            return IntentAnalysisResult(
                primaryIntent = QuestionIntentType.CREATOR_IDENTITY,
                subIntents = listOf("CREATOR_IDENTITY", "FOUNDER_ATTRIBUTION"),
                detectedTopic = "Sri Milon Chandra",
                isDharmaRelated = false,
                styleRequest = style,
                creativeWritingType = writingType,
                targetLanguage = targetLanguage,
                isFollowUp = false
            )
        }

        // 6. AI Identity
        if (isAiIdentity(lower)) {
            return IntentAnalysisResult(
                primaryIntent = QuestionIntentType.AI_IDENTITY,
                subIntents = listOf("AI_IDENTITY", "CAPABILITY_OVERVIEW"),
                detectedTopic = "Dharma AI",
                isDharmaRelated = false,
                styleRequest = style,
                creativeWritingType = writingType,
                targetLanguage = targetLanguage,
                isFollowUp = false
            )
        }

        // 7. System Health Check
        if (isSystemHealth(lower)) {
            return IntentAnalysisResult(
                primaryIntent = QuestionIntentType.SYSTEM_HEALTH_CHECK,
                subIntents = listOf("SYSTEM_HEALTH_CHECK", "DIAGNOSTIC_VERIFICATION"),
                detectedTopic = "System Diagnostic",
                isDharmaRelated = false,
                styleRequest = style,
                creativeWritingType = writingType,
                targetLanguage = targetLanguage,
                isFollowUp = false
            )
        }

        // 8. Simple Greeting
        if (isGreeting(lower)) {
            return IntentAnalysisResult(
                primaryIntent = QuestionIntentType.GREETING,
                subIntents = listOf("GREETING", "POLITE_CONVERSATION"),
                detectedTopic = "Greeting",
                isDharmaRelated = false,
                styleRequest = style,
                creativeWritingType = writingType,
                targetLanguage = targetLanguage,
                isFollowUp = false
            )
        }

        // 9. Follow-Up Modification Intent
        if (isFollowUp && followUpAction != null) {
            return IntentAnalysisResult(
                primaryIntent = QuestionIntentType.FOLLOW_UP_MODIFICATION,
                subIntents = listOf("FOLLOW_UP", followUpAction),
                detectedTopic = "Conversation Memory",
                isDharmaRelated = true,
                styleRequest = style,
                creativeWritingType = writingType,
                targetLanguage = targetLanguage,
                isFollowUp = true,
                followUpAction = followUpAction
            )
        }

        // 10. Creative Writing Intent
        val hasCreativeWritingVerb = lower.contains("লেখো") || lower.contains("লিখুন") || lower.contains("রচনা করো") ||
                lower.contains("তৈরি করো") || lower.contains("write") || lower.contains("compose") || lower.contains("craft")

        if (writingType != CreativeWritingType.NONE || (hasCreativeWritingVerb && (lower.contains("something about") || lower.contains("সম্পর্কে কিছু")))) {
            val topic = extractSubject(raw)
            return IntentAnalysisResult(
                primaryIntent = QuestionIntentType.CREATIVE_WRITING,
                subIntents = listOf("CREATIVE_WRITING", writingType.name, "ORIGINAL_COMPOSITION"),
                detectedTopic = topic,
                isDharmaRelated = isDharmaTopic(lower),
                styleRequest = style,
                creativeWritingType = if (writingType == CreativeWritingType.NONE) CreativeWritingType.EXPLANATION_ARTICLE else writingType,
                targetLanguage = targetLanguage,
                isFollowUp = false
            )
        }

        // 11. General Knowledge (Science, Math, World History, Geography, Tech)
        val isGeneral = isGeneralKnowledge(lower)
        if (isGeneral && !isDharmaTopic(lower)) {
            val topic = extractSubject(raw)
            return IntentAnalysisResult(
                primaryIntent = QuestionIntentType.GENERAL_KNOWLEDGE,
                subIntents = listOf("GENERAL_KNOWLEDGE", "OBJECTIVE_EDUCATION"),
                detectedTopic = topic,
                isDharmaRelated = false,
                styleRequest = style,
                creativeWritingType = writingType,
                targetLanguage = targetLanguage,
                isFollowUp = false
            )
        }

        // 12. Fine-grained Dharma Intent Differentiation
        val (dharmaIntent, subList) = differentiateDharmaIntent(lower, raw)

        return IntentAnalysisResult(
            primaryIntent = dharmaIntent,
            subIntents = subList,
            detectedTopic = extractSubject(raw),
            isDharmaRelated = true,
            styleRequest = style,
            creativeWritingType = writingType,
            targetLanguage = targetLanguage,
            isFollowUp = false
        )
    }

    private fun differentiateDharmaIntent(lower: String, raw: String): Pair<QuestionIntentType, List<String>> {
        // Differentiation 1: Definition / Essence ("What is Krishna?", "What is Gita?", "What is Karma?", "ধর্ম কী?", "কর্ম কী?")
        val isDefinition = lower.startsWith("what is ") || lower.startsWith("what are ") ||
                lower.endsWith(" কী?") || lower.endsWith(" কি?") || lower.endsWith(" কাকে বলে?") ||
                lower.endsWith(" কী") || lower.endsWith(" কি") || lower.contains("কাকে বলে") ||
                lower.contains("এর সংজ্ঞা") || lower.contains("definition of") || lower.contains("meaning of dharma")

        // Differentiation 2: Historical / Avatara advent ("Who was Krishna?", "Who was Rama?", "কৃষ্ণ কে ছিলেন?", "শঙ্করাচার্য কে ছিলেন?")
        val isHistorical = lower.startsWith("who was ") || lower.startsWith("who were ") ||
                lower.contains("কে ছিলেন") || lower.contains("ঐতিহাসিক") || lower.contains("historical") ||
                lower.contains("কখন এসেছিলেন") || lower.contains("জীবনী") || lower.contains("biography of")

        // Differentiation 3: Significance / Importance ("Why is Krishna important?", "Why is Gita important?", "গীতার গুরুত্ব কী?", "কেন একাদশী পালন করা হয়?")
        val isSignificance = lower.startsWith("why is ") || lower.startsWith("why are ") ||
                lower.contains("গুরুত্ব কী") || lower.contains("গুরুত্ব কি") || lower.contains("কেন পালন") ||
                lower.contains("কেন গুরুত্বপূর্ণ") || lower.contains("কেন প্রয়োজন") || lower.contains("why do we") ||
                lower.contains("significance of") || lower.contains("importance of") || lower.contains("benefits of")

        // Differentiation 4: Comprehensive Exposition / Narrative ("Tell me about Krishna", "Explain about Gita", "কৃষ্ণ সম্পর্কে বলো", "রামায়ণ সম্পর্কে বলুন")
        val isExposition = lower.startsWith("tell me about") || lower.startsWith("explain about") ||
                lower.contains("সম্পর্কে বলো") || lower.contains("সম্পর্কে বলুন") || lower.contains("সম্পর্কে জানতে চাই") ||
                lower.contains("সম্পর্কে আলোচনা") || lower.contains("বলো তো") || lower.contains("overview of")

        // Differentiation 5: Mantras and Stotras
        val isMantra = lower.contains("মন্ত্র") || lower.contains("স্তোত্র") || lower.contains("শ্লোক") ||
                lower.contains("mantra") || lower.contains("stotra") || lower.contains("shloka") ||
                lower.contains("জপ") || lower.contains("প্রণাম")

        // Differentiation 6: Ritual and Festival / Panchanga
        val isRitual = lower.contains("তিথি") || lower.contains("পঞ্জিকা") || lower.contains("উৎসব") ||
                lower.contains("পূজা") || lower.contains("ব্রত") || lower.contains("একাদশী") ||
                lower.contains("কাল পূজা") || lower.contains("আজ কোন তিথি") || lower.contains("festival") ||
                lower.contains("panchanga") || lower.contains("tithi")

        // Differentiation 7: Philosophy and Darshana
        val isPhilosophy = lower.contains("দর্শন") || lower.contains("অদ্বৈত") || lower.contains("দ্বৈত") ||
                lower.contains("বেদান্ত") || lower.contains("সাংখ্য") || lower.contains("ন্যায়") ||
                lower.contains("যোগ") || lower.contains("মীমাংসা") || lower.contains("মায়াবাদ") ||
                lower.contains("philosophy") || lower.contains("darshana") || lower.contains("brahman")

        // Differentiation 8: Canonical Scripture
        val isScripture = lower.contains("বেদ") || lower.contains("উপনিষদ") || lower.contains("গীতা") ||
                lower.contains("রামায়ণ") || lower.contains("মহাভারত") || lower.contains("পুরাণ") ||
                lower.contains("veda") || lower.contains("upanishad") || lower.contains("gita") ||
                lower.contains("ramayana") || lower.contains("mahabharata") || lower.contains("purana")

        return when {
            isMantra -> QuestionIntentType.MANTRA_AND_STOTRA to listOf("MANTRA_AND_STOTRA", "SACRED_HYMNOLOGY")
            isRitual -> QuestionIntentType.RITUAL_AND_FESTIVAL to listOf("RITUAL_AND_FESTIVAL", "CALENDAR_PRACTICE")
            isPhilosophy -> QuestionIntentType.PHILOSOPHY_AND_DARSHANA to listOf("PHILOSOPHY_AND_DARSHANA", "DARSHANA_EXEGESIS")
            isSignificance -> QuestionIntentType.DHARMA_SIGNIFICANCE to listOf("DHARMA_SIGNIFICANCE", "SPIRITUAL_IMPORTANCE")
            isHistorical -> QuestionIntentType.DHARMA_HISTORICAL to listOf("DHARMA_HISTORICAL", "AVATARA_CHRONOLOGY")
            isDefinition -> QuestionIntentType.DHARMA_DEFINITION to listOf("DHARMA_DEFINITION", "ONTOLOGICAL_ESSENCE")
            isExposition -> QuestionIntentType.DHARMA_EXPOSITION to listOf("DHARMA_EXPOSITION", "NARRATIVE_SYNTHESIS")
            isScripture -> QuestionIntentType.CANONICAL_SCRIPTURE to listOf("CANONICAL_SCRIPTURE", "CANONICAL_TEXT")
            else -> QuestionIntentType.DHARMA_EXPOSITION to listOf("GENERAL_DHARMA", "DHARMA_STUDY")
        }
    }

    private fun isCreator(q: String): Boolean {
        return q.contains("কে বানিয়েছে") || q.contains("কে তৈরি করেছে") || q.contains("কে বানিয়েছে") ||
                q.contains("কে বানাইছে") || q.contains("creator কে") || q.contains("নির্মাতা কে") ||
                q.contains("বানিয়েছে কে") || q.contains("বানিয়েছে কে") || q.contains("তৈরি করেছে কে") ||
                q.contains("who created you") || q.contains("who made you") || q.contains("who is your creator") ||
                q.contains("who built you") || q.contains("who developed you") || q.contains("your creator") ||
                q.contains("who created dharma ai") || q.contains("creator of dharma ai") ||
                q.contains("মিলন চন্দ্র") || q.contains("milon chandra")
    }

    private fun isAiIdentity(q: String): Boolean {
        return (q.contains("তুমি কে") || q.contains("তোমার নাম কি") || q.contains("তোমার নাম কী") ||
                q.contains("তোমার পরিচয়") || q.contains("who are you") || q.contains("what is your name") ||
                q == "who are you?" || q == "who are you" || q.startsWith("tell me about yourself")) && !isCreator(q)
    }

    private fun isSystemHealth(q: String): Boolean {
        return q.contains("কোনো সমস্যা আছে") || q.contains("কোন সমস্যা আছে") || q.contains("সবকিছু ঠিক আছে") ||
                q.contains("সব ঠিক আছে") || q.contains("তোমার কোনো সমস্যা আছে") || q.contains("তোমার কোন সমস্যা আছে") ||
                q.contains("কি সমস্যা হচ্ছে") || q.contains("কী সমস্যা হচ্ছে") || q.contains("check yourself") ||
                q.contains("system ঠিক আছে") || q.contains("সিস্টেম ঠিক আছে") || q.contains("is everything ok") ||
                q.contains("is there any problem") || q.contains("check system") || q.contains("system health")
    }

    private fun isGreeting(q: String): Boolean {
        val tokens = listOf("হাই", "হ্যালো", "নমস্কার", "প্রণাম", "hello", "hi", "namaste", "hey", "শুভ সকাল", "শুভ সন্ধ্যা", "শুভ রাত্রি", "ধন্যবাদ", "thanks", "thank you", "কেমন আছো", "কেমন আছেন", "how are you")
        return tokens.any { q.trim() == it || q.trim() == "$it?" || q.trim() == "$it!" }
    }

    private fun isGeneralKnowledge(q: String): Boolean {
        val generalKeywords = listOf(
            // Science
            "সালোকসংশ্লেষণ", "photosynthesis", "মহাকর্ষ", "gravity", "পরমাণু", "atom", "আপেক্ষিকতা", "relativity",
            "ডিএনএ", "dna", "কোষ", "cell biology", "সূর্যজগৎ", "solar system", "গ্রহ", "planet", "ব্ল্যাকহোল", "black hole",
            "নিউটনের সূত্র", "newton's law", "আলোর গতি", "speed of light", "পানি চক্র", "water cycle",
            // Geography
            "রাজধানী", "capital of", "পাহাড়", "mountain", "নদী", "river", "মহাদেশ", "continent", "মহাসাগর", "ocean",
            "বায়ুমণ্ডল", "atmosphere", "হিমালয়", "himalayas", "আমাজন", "amazon rainforest",
            // History
            "দ্বিতীয় বিশ্বযুদ্ধ", "world war", "মুঘল সাম্রাজ্য", "mughal empire", "ফরাসি বিপ্লব", "french revolution",
            "শিল্প বিপ্লব", "industrial revolution", "আইনস্টাইন", "einstein", "গ্যালিলিও", "galileo",
            // Tech & Math
            "কম্পিউটার", "computer", "কৃত্রিম বুদ্ধিমত্তা", "artificial intelligence", "অ্যালগরিদম", "algorithm",
            "ইন্টারনেট", "internet", "পাইথাগোরাস", "pythagoras", "মৌলিক সংখ্যা", "prime number", "সমীকরণ", "equation",
            // Daily / Language
            "ব্যাকরণ", "grammar", "সন্ধি", "সমাস", "tense", "noun", "verb", "ভিটামিন", "vitamin", "পুষ্টি", "nutrition"
        )
        return generalKeywords.any { q.contains(it) }
    }

    private fun isDharmaTopic(q: String): Boolean {
        val dharmaKeywords = listOf(
            "কৃষ্ণ", "krishna", "শিব", "shiva", "রাম", "rama", "বিষ্ণু", "vishnu", "দুর্গা", "durga", "কালী", "kali",
            "গণেশ", "ganesha", "সরস্বতী", "saraswati", "লক্ষ্মী", "lakshmi", "হনুমান", "hanuman",
            "বেদ", "veda", "উপনিষদ", "upanishad", "গীতা", "gita", "পুরাণ", "purana", "রামায়ণ", "ramayana", "মহাভারত", "mahabharata",
            "ধর্ম", "dharma", "কর্ম", "karma", "মোক্ষ", "moksha", "মায়া", "maya", "আত্মা", "atman", "ব্রহ্ম", "brahman",
            "মন্ত্র", "mantra", "স্তোত্র", "stotra", "পূজা", "puja", "তিথি", "tithi", "একাদশী", "ekadashi", "শিবরাত্রি", "shivaratri",
            "অদ্বৈত", "advaita", "যোগ", "yoga", "ধ্যান", "meditation", "ভক্তি", "bhakti", "জ্ঞান", "jnana"
        )
        return dharmaKeywords.any { q.contains(it) }
    }

    private fun extractSubject(raw: String): String {
        var clean = raw.trim()
        val removePrefixes = listOf(
            "What is the ", "What is ", "What are ", "Who was ", "Who is ", "Why is ", "Why do we ",
            "Tell me about ", "Explain about ", "Explain ", "Write an essay on ", "Write a story about ",
            "Write a reflection on ", "Write about ", "Write something about ", "Compose a poem on ",
            "Write a poem on ", "Write a prayer on ", "Write a speech on ", "Write a greeting on ",
            "Compose a mantra on ", "Create a shloka on ",
            "কী?", "কি?", "কাকে বলে?", "সম্পর্কে বলো", "সম্পর্কে বলুন", "সম্পর্কে লিখুন",
            "একটি প্রবন্ধ লেখো", "একটি গল্প লেখো", "একটি ধর্মীয় গল্প লেখো", "একটি প্রার্থনা লেখো",
            "একটি প্রার্থনা লিখে দাও", "একটি ভক্তিমূলক কবিতা লেখো", "একটি কবিতা লেখো", "একটি কবিতা লিখে দাও",
            "একটি পূজার শুভেচ্ছা লিখো", "একটি পূজার শুভেচ্ছা লেখো", "পূজার শুভেচ্ছা বার্তা লেখো",
            "একটি সুন্দর ধর্মীয় বক্তব্য বানাও", "একটি ধর্মীয় বক্তব্য বানাও", "একটি বক্তব্য বানাও",
            "একটি নতুন মন্ত্র তৈরি করো", "একটি নতুন শ্লোক রচনা করো", "একটি নতুন মন্ত্র বানাও",
            "এই বিষয় নিয়ে একটি নতুন লেখা তৈরি করো", "একটি নতুন লেখা তৈরি করো", "একটি রচনা লেখো",
            "নিয়ে একটি", "নিয়ে একটা", "নিয়ে", "সম্পর্কে", "একটি", "একটা"
        )
        for (prefix in removePrefixes) {
            clean = clean.replace(prefix, "", ignoreCase = true).trim()
        }
        return clean.ifBlank { "সনাতন ধর্ম ও আত্মিক চেতনা" }
    }
}
