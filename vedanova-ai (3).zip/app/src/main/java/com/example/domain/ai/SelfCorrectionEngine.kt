package com.example.domain.ai

import java.util.Locale

data class SelfCorrectionPipelineResult(
    val finalAnswer: String,
    val wasCorrected: Boolean,
    val attemptsCount: Int,
    val logs: List<SelfCorrectionLog>,
    val finalEvaluation: AnswerQualityEvaluationResult,
    val safestFallbackUsed: Boolean = false
)

object SelfCorrectionEngine {

    const val MAX_REVISION_ATTEMPTS = 2

    /**
     * Executes the iterative Self-Correction Pipeline:
     * Draft -> Quality Evaluation -> Surgical Correction -> Re-evaluation -> Final Verification.
     * Guaranteed termination with at most MAX_REVISION_ATTEMPTS revisions.
     */
    fun processAndRefine(
        query: String,
        draftAnswer: String,
        contextState: ConversationContextState,
        intent: IntentAnalysisResult,
        detectedLanguage: String,
        hasCanonicalSource: Boolean,
        canonicalReference: String? = null,
        history: List<Pair<String, String>> = emptyList()
    ): SelfCorrectionPipelineResult {
        val logs = mutableListOf<SelfCorrectionLog>()
        var currentAnswer = draftAnswer
        var attempts = 0
        var wasCorrected = false
        var fallbackUsed = false

        logs.add(
            SelfCorrectionLog(
                stepName = "1. Initial Draft Synthesis",
                status = "PASSED",
                detail = "Initial answer formulated based on query intent and retrieved knowledge."
            )
        )

        var evaluation = AnswerQualityEvaluator.evaluateDraft(
            query = query,
            draftAnswer = currentAnswer,
            contextState = contextState,
            intent = intent,
            hasCanonicalSource = hasCanonicalSource,
            canonicalReference = canonicalReference,
            history = history
        )

        // Loop up to MAX_REVISION_ATTEMPTS times
        while (evaluation.needsCorrection && attempts < MAX_REVISION_ATTEMPTS) {
            attempts++
            wasCorrected = true

            val issueDescriptions = evaluation.detectedIssues.joinToString("; ") { "${it.type}: ${it.description}" }
            logs.add(
                SelfCorrectionLog(
                    stepName = "2. Quality Evaluation (Attempt $attempts)",
                    status = "FLAGGED",
                    detail = "Issues detected: $issueDescriptions"
                )
            )

            // Apply targeted surgical correction based on detected issues
            currentAnswer = applySurgicalCorrections(
                currentAnswer = currentAnswer,
                issues = evaluation.detectedIssues,
                query = query,
                contextState = contextState,
                intent = intent,
                detectedLanguage = detectedLanguage,
                hasCanonicalSource = hasCanonicalSource,
                canonicalReference = canonicalReference
            )

            logs.add(
                SelfCorrectionLog(
                    stepName = "3. Targeted Revision (Attempt $attempts)",
                    status = "ADJUSTED",
                    detail = "Corrected problematic parts: Refined naturalness, removed echoes/robotic tropes, and enforced domain safety."
                )
            )

            // Re-evaluate the corrected draft
            evaluation = AnswerQualityEvaluator.evaluateDraft(
                query = query,
                draftAnswer = currentAnswer,
                contextState = contextState,
                intent = intent,
                hasCanonicalSource = hasCanonicalSource,
                canonicalReference = canonicalReference,
                history = history
            )
        }

        // Check if still failing after MAX_REVISION_ATTEMPTS (Termination Safety)
        if (!evaluation.isPassed) {
            fallbackUsed = true
            currentAnswer = generateSafeFallbackResponse(
                query = query,
                intent = intent,
                detectedLanguage = detectedLanguage,
                evaluation = evaluation,
                canonicalReference = canonicalReference
            )
            logs.add(
                SelfCorrectionLog(
                    stepName = "4. Safe Fallback Termination",
                    status = "ADJUSTED",
                    detail = "Max revisions reached ($MAX_REVISION_ATTEMPTS). Substituted safest verified response without speculation or hallucinations."
                )
            )

            // Final evaluation of safe fallback
            evaluation = AnswerQualityEvaluator.evaluateDraft(
                query = query,
                draftAnswer = currentAnswer,
                contextState = contextState,
                intent = intent,
                hasCanonicalSource = hasCanonicalSource,
                canonicalReference = canonicalReference,
                history = history
            )
        } else {
            logs.add(
                SelfCorrectionLog(
                    stepName = "4. Final Verification Check",
                    status = "PASSED",
                    detail = "Answer satisfied all 9 self-check dimensions: Quality Score = ${evaluation.overallScore}/100, Hallucination Risk = ${evaluation.hallucinationRiskScore}."
                )
            )
        }

        return SelfCorrectionPipelineResult(
            finalAnswer = currentAnswer,
            wasCorrected = wasCorrected,
            attemptsCount = attempts,
            logs = logs,
            finalEvaluation = evaluation,
            safestFallbackUsed = fallbackUsed
        )
    }

    /**
     * Applies surgical corrections targeting specific detected issues.
     */
    private fun applySurgicalCorrections(
        currentAnswer: String,
        issues: List<QualityIssue>,
        query: String,
        contextState: ConversationContextState,
        intent: IntentAnalysisResult,
        detectedLanguage: String,
        hasCanonicalSource: Boolean,
        canonicalReference: String?
    ): String {
        var revised = currentAnswer
        val isBengali = detectedLanguage.contains("Bengali", ignoreCase = true)

        for (issue in issues) {
            when (issue.type) {
                QualityIssueType.REPEATED_SELF_INTRODUCTION -> {
                    // Strip repetitive AI self-introductions in ongoing conversation
                    revised = revised.replace("(?i)^\\s*(I am (Dharma|VedaNova) AI(,\\s*created by [^.]+)?\\.?\\s*)+".toRegex(), "")
                    revised = revised.replace("(?i)^\\s*(আমি (Dharma|VedaNova) AI(,\\s*নির্মাতা [^.]+)?\\.?\\s*)+".toRegex(), "")
                    revised = revised.replace("(?i)^\\s*(নমস্কার[,!\\s]+আমি (Dharma|VedaNova) AI(,\\s*নির্মাতা [^.]+)?\\.?\\s*)+".toRegex(), "")
                }

                QualityIssueType.REPEATING_USER_QUESTION -> {
                    // Strip echoing of user prompt
                    revised = revised.replace("(?i)^\\s*You asked[:,-]?\\s*.*?\\?\\s*".toRegex(), "")
                    revised = revised.replace("(?i)^\\s*Regarding your question about.*?[:,-]\\s*".toRegex(), "")
                    revised = revised.replace("(?i)^\\s*আপনি জানতে চেয়েছেন[:,-]?\\s*.*?\\?\\s*".toRegex(), "")
                    revised = revised.replace("(?i)^\\s*আপনার প্রশ্ন ছিল[:,-]?\\s*.*?\\?\\s*".toRegex(), "")
                }

                QualityIssueType.ROBOTIC_PHRASING -> {
                    // Replace robotic clichés with natural phrasing
                    revised = revised.replace("(?i)as an ai language model,?\\s*".toRegex(), "")
                    revised = revised.replace("(?i)as an artificial intelligence,?\\s*".toRegex(), "")
                    revised = revised.replace("(?i)একটি এআই মডেল হিসেবে,?\\s*".toRegex(), "")
                    revised = revised.replace("(?i)in conclusion, as previously stated,?\\s*".toRegex(), "In summary, ")
                    revised = revised.replace("(?i)based on my programmed algorithms,?\\s*".toRegex(), "Based on verified sources, ")
                }

                QualityIssueType.FORCED_RELIGIOUS_IN_SECULAR -> {
                    // Remove forced religious terms from secular math/science answers
                    revised = revised.replace("(?i)ওঁ|ॐ|om|শ্লোক|মন্ত্র|বেদ|উপনিষদ|শ্রীকৃষ্ণ|ভগবান|moksha|shloka|mantra".toRegex(), "")
                        .replace("  +", " ")
                        .trim()
                }

                QualityIssueType.REPETITIVE_CONTENT -> {
                    // Deduplicate repeated sentences or lines
                    val lines = revised.lines()
                    val seen = mutableSetOf<String>()
                    val uniqueLines = mutableListOf<String>()
                    for (line in lines) {
                        val trimmed = line.trim()
                        if (trimmed.isEmpty() || seen.add(trimmed.lowercase(Locale.ROOT))) {
                            uniqueLines.add(line)
                        }
                    }
                    revised = uniqueLines.joinToString("\n")
                }

                QualityIssueType.TOPIC_BLEEDING -> {
                    // If previous topic was dragged in, clean out explicit mentions of it
                    val prev = contextState.previousTopic
                    if (prev != null) {
                        revised = revised.replace("(?i)\\b$prev\\b".toRegex(), contextState.activeSubject ?: "")
                    }
                }

                QualityIssueType.EXCESSIVE_VERBOSITY -> {
                    // Condense overly long answer for simple factual question
                    val math = GeneralKnowledgeEngine.tryEvaluateMath(query)
                    if (math != null) {
                        revised = math.first
                    } else {
                        val paragraphs = revised.split("\n\n").filter { it.isNotBlank() }
                        if (paragraphs.size > 1) {
                            revised = paragraphs.first()
                        } else {
                            val sentences = revised.split("।", ".").filter { it.isNotBlank() }
                            if (sentences.isNotEmpty()) {
                                val delim = if (isBengali) "। " else ". "
                                revised = sentences.take(2).joinToString(delim).trim() + (if (isBengali) "।" else ".")
                            }
                        }
                    }
                }

                QualityIssueType.SCRIPTURE_MANTRA_FABRICATION -> {
                    // Remove fabricated mantra/verse and replace with canonical clarification
                    if (isBengali) {
                        revised = "সনাতন শাস্ত্রীয় বিশুদ্ধতা রক্ষার্থে কোনো কাল্পনিক বা অপ্রমাণিত মন্ত্র/শ্লোক প্রদান করা হয় না। প্রামাণিক বৈদিক ও পৌরাণিক সংহিতায় যে সকল মন্ত্র স্পষ্টভাবে সংরক্ষিত রয়েছে, কেবল সেগুলিই গ্রহণযোগ্য।"
                    } else {
                        revised = "To maintain sacred scriptural integrity, unverified or fabricated mantras/verses are not generated. Only canonical mantras preserved in authorized Shruti and Smriti scriptures are authenticated."
                    }
                }

                QualityIssueType.UNVERIFIED_UNCERTAIN_DETAIL -> {
                    // Epistemic humility
                    val uncertaintyPrefix = if (isBengali) {
                        "এই নির্দিষ্ট তথ্যটি সম্পর্কে আমার কাছে শতভাগ প্রামাণিক বা যাচাইকৃত সূত্র নেই, তাই ভুল তথ্য প্রদান এড়াতে আমি অনুমানমূলক উত্তর দিচ্ছি না। তবে প্রচলিত শাস্ত্রীয় প্রেক্ষাপটে যা জানা যায়:\n\n"
                    } else {
                        "I am not certain about that specific detail, so I do not want to give you an unverified answer. What is canonically established is:\n\n"
                    }
                    if (!revised.contains(uncertaintyPrefix.take(25))) {
                        revised = uncertaintyPrefix + revised
                    }
                }

                else -> {}
            }
        }

        return revised.trim()
    }

    /**
     * Generates a safe, verified fallback response if revision attempts reach limit.
     */
    private fun generateSafeFallbackResponse(
        query: String,
        intent: IntentAnalysisResult,
        detectedLanguage: String,
        evaluation: AnswerQualityEvaluationResult,
        canonicalReference: String?
    ): String {
        val isBengali = detectedLanguage.contains("Bengali", ignoreCase = true)

        if (evaluation.isUncertain) {
            return if (isBengali) {
                "এই নির্দিষ্ট প্রশ্নটি সম্পর্কে প্রামাণিক সূত্রে শতভাগ নিশ্চিত তথ্য সংরক্ষিত নেই। ভুল তথ্য ও বিভ্রান্তি এড়াতে অনুমানমূলক তথ্য প্রদান থেকে বিরত থাকা হচ্ছে।"
            } else {
                "I am not certain about that specific detail, so I do not want to give you an unverified answer. To prevent misinformation, ungrounded speculation is avoided."
            }
        }

        if (intent.primaryIntent == QuestionIntentType.GENERAL_KNOWLEDGE) {
            val mathRes = GeneralKnowledgeEngine.tryEvaluateMath(query)
            if (mathRes != null) {
                return if (isBengali) mathRes.first else mathRes.second
            }
            return if (isBengali) {
                "এই তথ্যটি যাচাইকৃত সাধারণ জ্ঞান অনুসারে প্রামাণিক ও বস্তুনিষ্ঠভাবে পর্যবেক্ষণযোগ্য।"
            } else {
                "This topic is verifiable through standard empirical and scientific principles."
            }
        }

        return if (isBengali) {
            "সনাতন ধর্মের প্রামাণিক নীতি অনুযায়ী, শাস্ত্রীয় জ্ঞানের ক্ষেত্রে শ্রুতি ও স্মৃতি নির্দেশিত সিদ্ধান্তই চূড়ান্ত। আপনার প্রশ্নের বিষয়ে আরও নির্দিষ্ট তথ্য জানতে শাস্ত্রগ্রন্থের নাম বা অধ্যায় উল্লেখ করে অনুসন্ধান করতে পারেন।"
        } else {
            "According to authentic principles of Sanatan Dharma, conclusions grounded in Shruti and Smriti scriptures are authoritative. For deeper verification, you may specify the exact scripture or chapter."
        }
    }
}
