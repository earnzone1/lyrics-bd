package com.example.domain.ai

import java.util.Locale

data class CompositionPlan(
    val title: String,
    val type: CreativeWritingType,
    val isOriginalWriting: Boolean = true,
    val targetLanguage: String,
    val sections: List<CompositionSection>
)

data class CompositionSection(
    val heading: String,
    val content: String
)

object DharmaWritingEngine {

    private const val AI_ORIGINAL_DISCLAIMER_BN = "✍️ **[AI-রচিত মৌলিক রচনা / সাহিত্যিক প্রতিফলন — এটি কোনো প্রামাণিক শাস্ত্রীয় শ্লোক বা প্রাচীন শ্রুতি নয়]**"
    private const val AI_ORIGINAL_DISCLAIMER_EN = "✍️ **[AI-Generated Original Composition & Reflection — Not an authentic ancient canonical scripture]**"
    private const val AI_MANTRA_DISCLAIMER_BN = "✍️ **[এটি AI-এর তৈরি একটি মৌলিক ভক্তিমূলক কাব্যিক শ্লোক — এটি বেদ, উপনিষদ বা গীতার কোনো প্রাচীন প্রামাণিক সনাতন মন্ত্র নয়। শাস্ত্রীয় মন্ত্রের মর্যাদা ও পবিত্রতা রক্ষার্থে এটি সম্পূর্ণ মৌলিক সাহিত্যিক রচনা হিসেবে উপস্থাপিত।]**"
    private const val AI_MANTRA_DISCLAIMER_EN = "✍️ **[This is an AI-crafted original devotional poetic shloka — not an authentic ancient Vedic, Upanishadic, or Gita mantra. Canonical scriptures remain distinct and immutable.]**"

    fun composePiece(
        topic: String,
        type: CreativeWritingType,
        style: ResponseStyleRequest,
        language: String
    ): String {
        val isEnglish = language.contains("English", ignoreCase = true)
        val cleanTopic = topic.ifBlank { if (isEnglish) "Dharma and Righteous Living" else "সনাতন ধর্ম ও আত্মিক চেতনা" }

        val plan = planComposition(cleanTopic, type, isEnglish)
        return renderComposition(plan, isEnglish, style)
    }

    private fun planComposition(topic: String, type: CreativeWritingType, isEnglish: Boolean): CompositionPlan {
        return when (type) {
            CreativeWritingType.ESSAY -> planEssay(topic, isEnglish)
            CreativeWritingType.REFLECTION -> planReflection(topic, isEnglish)
            CreativeWritingType.STORY -> planStory(topic, isEnglish)
            CreativeWritingType.PRAYER_COMPOSITION -> planPrayer(topic, isEnglish)
            CreativeWritingType.EXPLANATION_ARTICLE -> planArticle(topic, isEnglish)
            CreativeWritingType.SUMMARY -> planSummary(topic, isEnglish)
            CreativeWritingType.STUDY_NOTES -> planStudyNotes(topic, isEnglish)
            CreativeWritingType.QA_LESSON -> planQaLesson(topic, isEnglish)
            CreativeWritingType.SOCIAL_CAPTION -> planCaption(topic, isEnglish)
            CreativeWritingType.SPEECH -> planSpeech(topic, isEnglish)
            CreativeWritingType.POEM -> planPoem(topic, isEnglish)
            CreativeWritingType.PUJA_GREETING -> planPujaGreeting(topic, isEnglish)
            CreativeWritingType.ORIGINAL_MANTRA_COMPOSITION -> planOriginalMantra(topic, isEnglish)
            else -> planArticle(topic, isEnglish)
        }
    }

    private fun planEssay(topic: String, isEnglish: Boolean): CompositionPlan {
        return if (isEnglish) {
            CompositionPlan(
                title = "An Essay on $topic",
                type = CreativeWritingType.ESSAY,
                targetLanguage = "English",
                sections = listOf(
                    CompositionSection("1. Introduction", "$topic stands as an essential foundation in the spiritual, moral, and intellectual evolution of human consciousness. Exploring its deeper principles invites us into greater harmony with universal reality."),
                    CompositionSection("2. Philosophical & Ethical Dimensions", "At the heart of $topic lies the principle of inner alignment and universal interconnectedness. Through righteous action, mental discipline, and compassionate awareness, one harmonizes individual aspirations with the greater cosmic order."),
                    CompositionSection("3. Practical Application in Modern Life", "In a world characterized by velocity and material distractions, the wisdom of $topic serves as an anchor of peace, promoting integrity, clarity of intellect, and selfless dedication (Nishkama Seva)."),
                    CompositionSection("4. Conclusion", "Ultimately, embracing the eternal values embodied in $topic is a transformative journey from egocentric confusion to serene self-realization and universal welfare (Lokasangraha).")
                )
            )
        } else {
            CompositionPlan(
                title = "$topic বিষয়ক মৌলিক প্রবন্ধ",
                type = CreativeWritingType.ESSAY,
                targetLanguage = "Bengali",
                sections = listOf(
                    CompositionSection("১. সূচনা ও পরিপ্রেক্ষিত", "$topic কেবল একটি ধারণা বা তত্ত্ব নয়, এটি মানবজীবনের আত্মিক উন্মেষ ও সামগ্রিক ভারসাম্যের এক শাশ্বত ভিত্তি। এর নিহিত অর্থ জীবনের গভীর সত্যকে স্পর্শ করে।"),
                    CompositionSection("২. দার্শনিক ও নৈতিক তাৎপর্য", "$topic-এর কেন্দ্রীয় বার্তা হলো অন্তর্জগতের শুদ্ধি ও সত্যের প্রতি অবিচল নিষ্ঠা। স্বার্থপরতার ঊর্ধ্বে উঠে সর্বভূতে ঈশ্বরের উপস্থিতি অনুভব করা এবং নিষ্কাম কর্মের মাধ্যমে মানবকল্যাণে নিয়োজিত হওয়াই এর চরম সার্থকতা।"),
                    CompositionSection("৩. আধুনিক জীবনে প্রাসঙ্গিকতা", "ব্যস্ত ও ভোগবাদী আধুনিক সমাজে $topic মানুষের মনে স্থিরতা, শুভবুদ্ধি ও পরম শান্তির আলোকবর্তিকা প্রজ্বলিত করে। এটি বিভ্রান্তিকে দূর করে সত্যের পথ নির্দেশ করে।"),
                    CompositionSection("৪. উপসংহার", "পরিশেষে বলা যায়, $topic-এর মহিমাময় আদর্শকে হৃদয়ে ধারণ করে জীবন পরিচালনা করলেই আত্মিক মুক্তি ও সার্বিক কল্যাণ (লোকসংগ্রহ) সম্ভব।")
                )
            )
        }
    }

    private fun planReflection(topic: String, isEnglish: Boolean): CompositionPlan {
        return if (isEnglish) {
            CompositionPlan(
                title = "Spiritual Contemplation: $topic",
                type = CreativeWritingType.REFLECTION,
                targetLanguage = "English",
                sections = listOf(
                    CompositionSection("Quiet Observation", "When the mind becomes silent and turns inward, the sublime essence of $topic emerges like morning dew upon a lotus petal."),
                    CompositionSection("The Inner Dialogue", "Beyond the turbulence of transient desires lies an enduring tranquility. In contemplating $topic, we remember that we are not isolated fragments, but expressions of an indivisible divine consciousness."),
                    CompositionSection("Closing Aspiration", "May this contemplation dissolve the shadows of ignorance and awaken the eternal light of divine love within our hearts.")
                )
            )
        } else {
            CompositionPlan(
                title = "অন্তর্দৃষ্টি ও আধ্যাত্মিক ভাবনা: $topic",
                type = CreativeWritingType.REFLECTION,
                targetLanguage = "Bengali",
                sections = listOf(
                    CompositionSection("শান্ত মনের পর্যবেক্ষণ", "যখন চিত্তের চঞ্চলতা স্তব্ধ হয়ে অন্তর্মুখী হয়, তখন $topic-এর দিব্য উপলব্ধি প্রভাতসূর্যের আলোর মতো হৃদয়ে প্রস্ফুটিত হয়।"),
                    CompositionSection("আত্মিক উপলব্ধি", "অনিত্য জগতের ক্ষণস্থায়ী প্রাপ্তির পেছনে ছুটে চলার মাঝে আত্মানুসন্ধানই একমাত্র ধ্রুবতারা। $topic নিয়ে ভাবলে মনে হয়—আমরা কোনো বিচ্ছিন্ন সত্তা নই, বরং সেই অখণ্ড পরমাত্মারই অংশ।"),
                    CompositionSection("শুভ সংকল্প", "এই নির্মল চিন্তা আমাদের অহংকার ও আসক্তিকে দূর করে আত্মশুদ্ধি ও সর্বজীবে প্রেমের জাগরণ ঘটাক।")
                )
            )
        }
    }

    private fun planStory(topic: String, isEnglish: Boolean): CompositionPlan {
        return if (isEnglish) {
            CompositionPlan(
                title = "The Parable of the Quiet Stream and $topic",
                type = CreativeWritingType.STORY,
                targetLanguage = "English",
                sections = listOf(
                    CompositionSection("The Seeker's Journey", "Once upon a time, at the foothills of the sacred Himalayas, a young seeker approached an elderly saint asking, 'Revered Master, how may I truly realize the depth of $topic?'"),
                    CompositionSection("The Master's Lesson", "The master gently guided the seeker to a mountain stream. 'Observe this water,' the master said. 'When troubled, it reflects nothing; but when still and unattached, the entire sky and stars shine clearly upon it.'"),
                    CompositionSection("The Moral Realization", "The seeker bowed, understanding that $topic is not found in outward noise, but in an unblemished, selfless, and tranquil heart.")
                )
            )
        } else {
            CompositionPlan(
                title = "একটি শিক্ষণীয় আধ্যাত্মিক কাহিনী: $topic",
                type = CreativeWritingType.STORY,
                targetLanguage = "Bengali",
                sections = listOf(
                    CompositionSection("জিজ্ঞাসুর যাত্রা", "হিমালয়ের এক নির্জন তপোবনে এক তরুণ শিষ্য তার গুরুর কাছে এসে বিনীতভাবে জিজ্ঞাসা করল, 'হে গুরুদেব, আমি কীভাবে $topic-এর গভীর সত্যকে জীবনে উপলব্ধি করতে পারি?'"),
                    CompositionSection("গুরুদেবের দৃষ্টান্ত", "গুরুদেব স্নেহভরে শিষ্যকে একটি প্রবাহমান পাহাড়ি ঝরনার কাছে নিয়ে গেলেন। তিনি বললেন, 'বৎস, এই নদীর জল যখন কাদা ও তরঙ্গে বিক্ষুব্ধ থাকে, তখন এতে আকাশের কোনো প্রতিচ্ছবি দেখা যায় না। কিন্তু জল যখন স্থির ও নির্মল হয়, তখন সমগ্র অনন্ত আকাশ এতে প্রতিফলিত হয়।'"),
                    CompositionSection("উপসংহার ও শিক্ষা", "শিষ্য নতশিরে অনুধাবন করল—$topic কোনো বাহ্যিক তর্কে নয়, বরং কামনাহীন, পবিত্র ও শান্ত হৃদয়েই প্রকাশিত হয়।")
                )
            )
        }
    }

    private fun planPrayer(topic: String, isEnglish: Boolean): CompositionPlan {
        return if (isEnglish) {
            CompositionPlan(
                title = "Original Prayer for $topic",
                type = CreativeWritingType.PRAYER_COMPOSITION,
                targetLanguage = "English",
                sections = listOf(
                    CompositionSection("Invocation", "O Supreme Divine Presence, Source of all Light, Peace, and Truth—"),
                    CompositionSection("Supplication", "Bestow upon us purity of thought, speech, and deed. Lead us along the path of $topic, grant us strength to rise above selfishness, and illuminate our intellect with transcendental wisdom."),
                    CompositionSection("Universal Peace Benediction", "May all beings everywhere be happy, may all beings be free from suffering. Om Shanti, Shanti, Shanti.")
                )
            )
        } else {
            CompositionPlan(
                title = "মৌলিক প্রার্থনা রচনা: $topic",
                type = CreativeWritingType.PRAYER_COMPOSITION,
                targetLanguage = "Bengali",
                sections = listOf(
                    CompositionSection("প্রণতি ও স্তুতি", "হে সর্বব্যাপী পরমেশ্বর, হে নিখিল জগতের মঙ্গলবিধাতা—"),
                    CompositionSection("আন্তরিক নিবেদন", "আমাদের অন্তর থেকে সকল মলিনতা ও অহংকার দূর করে দিন। $topic-এর আদর্শে যেন আমরা সত্য, ক্ষমা ও নিষ্কাম সেবার পথে অবিচল থাকতে পারি। আমাদের মতিকে সর্বদা ধর্মে ও সদ্বিবেকে পরিচালিত করুন।"),
                    CompositionSection("শান্তিবাচন", "জগতের সকল জীব সুখী হোক, নিরোগ হোক এবং মঙ্গল প্রত্যক্ষ করুক। ওঁ শান্তি! শান্তি! শান্তি!")
                )
            )
        }
    }

    private fun planArticle(topic: String, isEnglish: Boolean): CompositionPlan {
        return if (isEnglish) {
            CompositionPlan(
                title = "Analytical Study: $topic",
                type = CreativeWritingType.EXPLANATION_ARTICLE,
                targetLanguage = "English",
                sections = listOf(
                    CompositionSection("Key Premise", "$topic encompasses profound insights into self-discipline, conscious evolution, and moral stewardship."),
                    CompositionSection("Core Mechanics & Analysis", "Understanding $topic requires analyzing how deliberate intention transforms personal habits into enduring spiritual virtues."),
                    CompositionSection("Synthesis", "By maintaining cognitive clarity and selfless dedication, one attains both inner peace and outward excellence.")
                )
            )
        } else {
            CompositionPlan(
                title = "$topic: বিশ্লেষণমূলক পর্যালোচনা",
                type = CreativeWritingType.EXPLANATION_ARTICLE,
                targetLanguage = "Bengali",
                sections = listOf(
                    CompositionSection("মূল প্রতিপাদ্য", "$topic আত্মবিকাশ, ন্যায়পরায়ণতা ও চেতনার রূপান্তরের এক গভীর ক্ষেত্র উন্মোচন করে।"),
                    CompositionSection("গভীর পর্যালোচনা", "এর তাত্ত্বিক মূল্যায়নে দেখা যায় যে, সততা ও একাগ্রতার সাথে অভ্যাসের অনুশীলন মানুষকে যেকোনো প্রতিকূলতায় স্থির ও শক্তিশালী রাখে।"),
                    CompositionSection("সারমর্ম", "জ্ঞান ও বাস্তব আচরণের সামঞ্জস্যপূর্ণ মেলবন্ধনই $topic-এর প্রকৃত তাৎপর্য।")
                )
            )
        }
    }

    private fun planSummary(topic: String, isEnglish: Boolean): CompositionPlan {
        return if (isEnglish) {
            CompositionPlan(
                title = "Summary Gist: $topic",
                type = CreativeWritingType.SUMMARY,
                targetLanguage = "English",
                sections = listOf(
                    CompositionSection("Key Takeaways", "• Essence: $topic represents fundamental alignment with truth and duty.\n• Core Principle: Emphasizes selfless action and intellectual purification.\n• Outcome: Leads to enduring clarity, peace, and spiritual harmony.")
                )
            )
        } else {
            CompositionPlan(
                title = "$topic-এর সারসংক্ষেপ",
                type = CreativeWritingType.SUMMARY,
                targetLanguage = "Bengali",
                sections = listOf(
                    CompositionSection("মূল বিন্দুসমূহ", "• সারমর্ম: $topic হলো সত্য, ন্যায় ও আত্মিক শৃঙ্খলার সমন্বিত রূপ।\n• প্রধান শিক্ষা: নিঃস্বার্থ কর্তব্যপালন ও মানসিক প্রশান্তি অর্জন।\n• ফলশ্রুতি: বিভ্রান্তি দূরীকরণ এবং আত্মউন্নয়ন ও সর্বজনীন কল্যাণ সাধন।")
                )
            )
        }
    }

    private fun planStudyNotes(topic: String, isEnglish: Boolean): CompositionPlan {
        return if (isEnglish) {
            CompositionPlan(
                title = "Study Notes on $topic",
                type = CreativeWritingType.STUDY_NOTES,
                targetLanguage = "English",
                sections = listOf(
                    CompositionSection("1. Definition & Foundation", "• Term: $topic\n• Primary Scope: Ethical foundation, mental discipline, and philosophical inquiry."),
                    CompositionSection("2. Essential Principles", "• Selfless Duty (Nishkama Bhava)\n• Moral Integrity (Satya & Ahimsa)\n• Cognitive Balance (Sthitaprajna state)"),
                    CompositionSection("3. Reflection Questions", "• How does $topic apply to modern decision-making?\n• What are the practical steps to implement its virtues daily?")
                )
            )
        } else {
            CompositionPlan(
                title = "$topic-এর পূর্ণাঙ্গ স্টাডি নোট",
                type = CreativeWritingType.STUDY_NOTES,
                targetLanguage = "Bengali",
                sections = listOf(
                    CompositionSection("১. পরিচয় ও পটভূমি", "• বিষয়: $topic\n• ক্ষেত্র: নীতিশাস্ত্র, আধ্যাত্মিক দর্শন ও বাস্তব আচরণবিধি।"),
                    CompositionSection("২. প্রধান স্তম্ভসমূহ", "• নিষ্কাম দৃষ্টিভঙ্গি ও কর্তব্যবোধ\n• চিত্তশুদ্ধি ও অহিংসা\n• প্রজ্ঞার অবিচল স্থিতি"),
                    CompositionSection("৩. অনুশীলনের বিষয়", "• প্রাত্যহিক আচরণে কীভাবে এর প্রভাব বজায় রাখা যায়?\n• আত্মবিশ্লেষণের মাধ্যমে কীভাবে নিজের গুণাবলি বৃদ্ধি করা সম্ভব?")
                )
            )
        }
    }

    private fun planQaLesson(topic: String, isEnglish: Boolean): CompositionPlan {
        return if (isEnglish) {
            CompositionPlan(
                title = "Q&A Study Lesson: $topic",
                type = CreativeWritingType.QA_LESSON,
                targetLanguage = "English",
                sections = listOf(
                    CompositionSection("Q1: What is the main teaching of $topic?", "A: The central teaching is upholding righteousness, self-mastery, and recognizing divine unity in all life."),
                    CompositionSection("Q2: How does one practice this in daily life?", "A: By performing one's duties honestly without egoistic attachment to selfish outcomes.")
                )
            )
        } else {
            CompositionPlan(
                title = "প্রশ্নোত্তর পাঠ: $topic",
                type = CreativeWritingType.QA_LESSON,
                targetLanguage = "Bengali",
                sections = listOf(
                    CompositionSection("প্রশ্ন ১: $topic-এর মূল শিক্ষা কী?", "উত্তর: সত্যে প্রতিষ্ঠিত থাকা, স্বার্থপরতা ত্যাগ করে দায়িত্ব পালন করা এবং সকল জীবের প্রতি সহানুভূতিশীল হওয়া।"),
                    CompositionSection("প্রশ্ন ২: দৈনন্দিন জীবনে কীভাবে এটি প্রয়োগ করা যায়?", "উত্তর: প্রতিটি কাজের পূর্বে শুভ সংকল্প গ্রহণ করা এবং ফলাফলের প্রতি অতিরিক্ত মোহমুক্ত হয়ে নিষ্ঠার সাথে কর্তব্য করা।")
                )
            )
        }
    }

    private fun planCaption(topic: String, isEnglish: Boolean): CompositionPlan {
        return if (isEnglish) {
            CompositionPlan(
                title = "Social Caption: $topic",
                type = CreativeWritingType.SOCIAL_CAPTION,
                targetLanguage = "English",
                sections = listOf(
                    CompositionSection("Caption", "\"When righteousness leads the way, peace naturally follows. 🕉️ In quiet reflection, we discover the eternal beauty of $topic. #Dharma #SpiritualWisdom #InnerPeace #Mindfulness\"")
                )
            )
        } else {
            CompositionPlan(
                title = "সোশ্যাল মিডিয়া ক্যাপশন: $topic",
                type = CreativeWritingType.SOCIAL_CAPTION,
                targetLanguage = "Bengali",
                sections = listOf(
                    CompositionSection("ক্যাপশন", "\"যেখানে সত্য ও ধর্ম প্রতিষ্ঠিত, সেখানেই প্রকৃত শান্তি ও আনন্দ। 🕉️ $topic-এর আলো আমাদের সকলের হৃদয়কে আলোকিত করুক। #সনাতনধর্ম #আধ্যাত্মিকতা #শান্তি #সদ্বিবেক\"")
                )
            )
        }
    }

    private fun planSpeech(topic: String, isEnglish: Boolean): CompositionPlan {
        return if (isEnglish) {
            CompositionPlan(
                title = "Address on $topic",
                type = CreativeWritingType.SPEECH,
                targetLanguage = "English",
                sections = listOf(
                    CompositionSection("Opening", "Respected elders, dear seekers, and friends: Namaste."),
                    CompositionSection("Main Body", "We gather today to reflect upon $topic—a subject that touches the deepest core of our collective consciousness. In an age of rapid change, anchoring ourselves in timeless values is the greatest gift we can offer to future generations."),
                    CompositionSection("Call to Action", "Let us pledge not merely to discuss these ideals, but to live them through every thought, word, and deed. Thank you. Om Shanti.")
                )
            )
        } else {
            CompositionPlan(
                title = "$topic বিষয়ে সংক্ষিপ্ত বক্তব্য / ভাষণ",
                type = CreativeWritingType.SPEECH,
                targetLanguage = "Bengali",
                sections = listOf(
                    CompositionSection("ভাষণের প্রারম্ভিক সম্বোধন", "শ্রদ্ধেয় সুধীবৃন্দ, জ্ঞানপিপাসু সজ্জন ও উপস্থিত প্রিয় বন্ধুবর্গ—সবাইকে আমার আন্তরিক নমস্কার ও প্রণাম।"),
                    CompositionSection("মূল বক্তব্য", "আজকের এই শুভ মুহূর্তে আমরা একত্রিত হয়েছি $topic নিয়ে আলোচনা করতে। সময়ের পরিবর্তনের সাথে সাথে বস্তুগত উন্নতি হলেও অন্তরের শান্তি ও মানবিক মূল্যবোধের চর্চা সবচেয়ে বেশি জরুরি। $topic আমাদের শেখায় কীভাবে সত্যের পথে অবিচল থেকে আত্মউন্নয়ন ও সমাজকল্যাণ সম্ভব।"),
                    CompositionSection("সমাপনী আহ্বান", "আসুন, আমরা কেবল কথায় নয়, আমাদের প্রতিটি কাজের মাধ্যমে এই পবিত্র আদর্শকে জীবনে রূপায়িত করি। সবাইকে ধন্যবাদ। ওঁ শান্তি! শান্তি! শান্তি!")
                )
            )
        }
    }

    private fun planPoem(topic: String, isEnglish: Boolean): CompositionPlan {
        return if (isEnglish) {
            CompositionPlan(
                title = "Devotional Poem on $topic",
                type = CreativeWritingType.POEM,
                targetLanguage = "English",
                sections = listOf(
                    CompositionSection("Stanza I — The Seeking Soul", "Within the stillness of the dawn,\nA sacred light begins to gleam;\nThe restless shadows of the mind\nDissolve as in a fading dream.\nIn every heartbeat, soft and deep,\nThy presence guides the path I tread;\nThrough $topic and surrender pure,\nBy eternal truth my soul is led."),
                    CompositionSection("Stanza II — Living Righteousness", "Not in the noise of selfish pride,\nNor in the quest for empty praise,\nTeach me to serve with loving hands,\nAnd walk in virtue all my days.\nLike a steady flame in windless air,\nMay unwavering peace my spirit fill;\nTo see the Divine in every life,\nAnd quietly rest within Thy will."),
                    CompositionSection("Reflection & Essence", "This poem expresses pure devotion (Bhakti), self-dedication to righteous duty, and inner tranquility through the remembrance of the Divine.")
                )
            )
        } else {
            CompositionPlan(
                title = "ভক্তিমূলক কবিতা: $topic",
                type = CreativeWritingType.POEM,
                targetLanguage = "Bengali",
                sections = listOf(
                    CompositionSection("স্তবক ১ — অন্তরের আলো", "অন্তর মাঝে তব আলো জ্বলে,\nমুছে যায় যত অন্ধকার,\nপ্রেমের ধারায় সিক্ত হৃদয়ে\nখুলি তব চরণের দ্বার।\nতোমারি প্রকাশ নিখিল ভুবনে,\nঅনন্ত রূপ, অনন্ত ধারা—\n$topic-এর গভীর পরশে\nজীবন জাগুক শান্তিসঞ্চারা।"),
                    CompositionSection("স্তবক ২ — আত্মনিবেদন ও সেবা", "কর্মের মাঝে তোমারে হেরিব,\nসবারে বাসিব ভালো,\nহে অন্তর্যামী, তব করুণায়\nআঁধার ঘুচায়ে জ্বালো আলো।\nকামনাহীন শান্ত হৃদয়ে\nসঁপিলাম মোর সকল কাজ,\nসত্যের পথে অবিচল থেকে\nতব প্রেমে যেন জুড়াই আজ।"),
                    CompositionSection("কাব্যিক ভাবার্থ ও শিক্ষা", "এই মৌলিক কবিতাটিতে অন্তরের নির্মল ভক্তি, অহংকারহীন আত্মসমর্পণের প্রশান্তি ও সর্বভূতে ঈশ্বরের আলোক দর্শনের আকুলতাকে ছন্দোময় রূপ দেওয়া হয়েছে।")
                )
            )
        }
    }

    private fun planPujaGreeting(topic: String, isEnglish: Boolean): CompositionPlan {
        return if (isEnglish) {
            CompositionPlan(
                title = "Festive Blessings & Puja Greetings: $topic",
                type = CreativeWritingType.PUJA_GREETING,
                targetLanguage = "English",
                sections = listOf(
                    CompositionSection("🌸 Auspicious Greetings", "Wishing you and your family a joyful, peaceful, and spiritually uplifting festive season celebrating $topic. May this sacred occasion illuminate your home and hearts."),
                    CompositionSection("🕉️ Divine Blessings & Prayer", "May the divine grace bestow radiant health, boundless wisdom, prosperous endeavors, and steadfast devotion to truth and kindness upon you and your loved ones."),
                    CompositionSection("🌺 Heartfelt Good Wishes", "May every home be filled with unity, happiness, and supreme peace. Subho Utsav! Warmest blessings and peace to all beings. 🙏✨")
                )
            )
        } else {
            CompositionPlan(
                title = "মাঙ্গলিক পূজার প্রীতি ও শুভকামনা: $topic",
                type = CreativeWritingType.PUJA_GREETING,
                targetLanguage = "Bengali",
                sections = listOf(
                    CompositionSection("🌸 উৎসবের শুভ আগমনী ও প্রীতি", "এই পবিত্র ও পুণ্যময় উৎসবে আপনার ও আপনার পরিবারের সকল সদস্যের প্রতি রইল আন্তরিক প্রীতি ও মাঙ্গলিক শুভেচ্ছা। উৎসবের আনন্দ ও ভক্তির রসে ভরে উঠুক আপনার প্রতিটি ক্ষণ।"),
                    CompositionSection("🕉️ আধ্যাত্মিক আশিস ও প্রার্থনা", "পরম করুণাময়ের অশেষ কৃপায় আপনার জীবন থেকে সকল দুঃখ, মোহ ও অন্ধকার দূরীভূত হোক। আপনার অন্তরে সত্য, প্রজ্ঞা, সহানুভূতি ও আধ্যাত্মিক শান্তির পবিত্র জ্যোতি প্রজ্জ্বলিত থাকুক।"),
                    CompositionSection("🌺 মাঙ্গলিক শুভাশংসা", "সুস্থতা, সুখ, সমৃদ্ধি ও সৌহার্দ্যে সুশোভিত হোক আপনার আগামী দিনগুলো। সর্বজীবে প্রেম ও সৌভ্রাতৃত্বের বন্ধন চিরস্থায়ী হোক। শুভ পূজা ও উৎসবের শুভকামনা! 🙏✨")
                )
            )
        }
    }

    private fun planOriginalMantra(topic: String, isEnglish: Boolean): CompositionPlan {
        return if (isEnglish) {
            CompositionPlan(
                title = "Original Devotional Shloka Composition: $topic",
                type = CreativeWritingType.ORIGINAL_MANTRA_COMPOSITION,
                targetLanguage = "English",
                sections = listOf(
                    CompositionSection("Original Devotional Verse (Poetic Composition)", "हे परमात्मन् जगदाधार नित्यमङ्गलदायक।\nहृदये मे सदा तिष्ठ सत्यधर्मप्रबोधक॥\n\n(Transliteration: He Paramātman jagadādhāra nitya-maṅgala-dāyaka |\nHṛdaye me sadā tiṣṭha satya-dharma-prabodhaka ||)"),
                    CompositionSection("Word-by-Word Meaning & Translation", "• He Paramātman: O Supreme Soul / Divine Consciousness\n• Jagadādhāra: O Foundation and Sustainer of the Cosmos\n• Nitya-maṅgala-dāyaka: Bestower of Eternal Auspiciousness and Grace\n• Hṛdaye me sadā tiṣṭha: Dwell forever within my heart\n• Satya-dharma-prabodhaka: Awakener of Truth, Wisdom, and Righteous Living\n\nPoetic English Translation:\n\"O Supreme Divine Presence, Foundation of all worlds and Giver of eternal auspiciousness—dwell forever within my heart and awaken within me the pure light of Truth and Dharma.\""),
                    CompositionSection("Spiritual Reflection & Canonical Context", "This verse is a modern, original literary and poetic composition intended purely for meditation and devotional appreciation. It is NOT an ancient Vedic Samhita, Upanishadic, or Bhagavad Gita mantra. For traditional rituals and formal mantra-japa, the ancient revealed canonical mantras of the Rishis should be observed with reverence.")
                )
            )
        } else {
            CompositionPlan(
                title = "মৌলিক ভক্তিমূলক শ্লোক রচনা: $topic",
                type = CreativeWritingType.ORIGINAL_MANTRA_COMPOSITION,
                targetLanguage = "Bengali",
                sections = listOf(
                    CompositionSection("মৌলিক ভক্তিমূলক সংস্কৃত শ্লোক (কাব্যিক রচনা)", "হে পরমাত্মন্ জগদাধার নিত্যমঙ্গলদায়ক।\nহৃদয়ে মে সদা তিষ্ঠ সত্যধর্মপ্রবোধক॥\n\n(উচ্চারণ: হে পরমাত্মন্ জগদাধার নিত্যমঙ্গলদায়ক।\nহৃদয়ে মে সদা তিষ্ঠ সত্যধর্মপ্রবোধক॥)"),
                    CompositionSection("পদ্যানুবাদ ও সরলার্থ", "• হে পরমাত্মন্: হে নিখিল ব্রহ্মাণ্ডের পরম চৈতন্য\n• জগদাধার: নিখিল বিশ্বজগতের পরম আশ্রয়\n• নিত্যমঙ্গলদায়ক: সর্বদা কল্যাণ ও শুভ শক্তির বিধানকারী\n• হৃদয়ে মে সদা তিষ্ঠ: আমার অন্তরে সর্বদা বিরাজিত থাকুন\n• সত্যধর্মপ্রবোধক: আমাকে সত্য ও ধর্মের চেতনায় জাগ্রত করুন\n\nবাংলা কাব্যানুবাদ:\n\"হে পরম প্রভু, জগতের মূল, মঙ্গলময় কৃপানিধি,\nহৃদয়ে আমার সদা থাকো তুমি, জাগায়ে ধর্মবিধি।\""),
                    CompositionSection("দার্শনিক তাৎপর্য ও শাস্ত্রীয় সতর্কবার্তা", "এই শ্লোকটি অন্তরের ভক্তিভাব ও কল্যাণকামনা প্রকাশের উদ্দেশ্যে রচিত একটি আধুনিক মৌলিক কাব্যিক শ্লোক। এটি কোনো বৈদিক শ্রুতি বা প্রাচীন প্রামাণিক শাস্ত্রের মূল মন্ত্র নয়। সনাতন ধর্মে প্রামাণিক বিধি ও জপের জন্য বৈদিক ও পৌরাণিক ঋষিপ্রণীত শাস্ত্রীয় মন্ত্রই প্রামাণিক ও অবিকৃত থাকে।")
                )
            )
        }
    }

    private fun renderComposition(plan: CompositionPlan, isEnglish: Boolean, style: ResponseStyleRequest): String {
        val sb = StringBuilder()
        val disclaimer = when (plan.type) {
            CreativeWritingType.ORIGINAL_MANTRA_COMPOSITION ->
                if (isEnglish) AI_MANTRA_DISCLAIMER_EN else AI_MANTRA_DISCLAIMER_BN
            else ->
                if (isEnglish) AI_ORIGINAL_DISCLAIMER_EN else AI_ORIGINAL_DISCLAIMER_BN
        }
        sb.append(disclaimer)
        sb.append("\n\n")
        sb.append("✨ **${plan.title}**\n\n")

        for (section in plan.sections) {
            sb.append("### ${section.heading}\n")
            sb.append("${section.content}\n\n")
        }

        return sb.toString().trim()
    }
}
