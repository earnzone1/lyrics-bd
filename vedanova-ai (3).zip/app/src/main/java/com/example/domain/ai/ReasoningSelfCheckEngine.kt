package com.example.domain.ai

data class SelfCheckResult(
    val isPassed: Boolean,
    val comprehensionPassed: Boolean,
    val relevancePassed: Boolean,
    val claimsGroundingPassed: Boolean,
    val contradictionFree: Boolean,
    val scripturalDistinctionPassed: Boolean,
    val noContextBleeding: Boolean,
    val clarificationNeeded: Boolean,
    val diagnosticSummary: String,
    val isRelevant: Boolean = relevancePassed,
    val isSourceKnown: Boolean = true,
    val isQuotationAuthentic: Boolean = true,
    val distinguishesTraditionFromHistory: Boolean = true,
    val zeroFabricationPassed: Boolean = true,
    val directlyAddressesQuestion: Boolean = true
)

object ReasoningSelfCheckEngine {

    fun validateAnswer(
        query: String,
        answer: String,
        intent: IntentAnalysisResult,
        isOriginalComposition: Boolean,
        hasCanonicalSource: Boolean,
        activeTopic: String?,
        previousTopic: String?
    ): SelfCheckResult {
        var compPassed = true
        var relPassed = true
        var claimsPassed = true
        var contraFree = true
        var scriptureDistPassed = true
        var noBleeding = true
        var clarNeeded = false
        var sourceKnown = true
        var quotationAuthentic = true
        var traditionHistoryDistinct = true
        var zeroFabrication = true
        var directlyAddresses = true

        val lowerQuery = query.lowercase().trim()
        val lowerAnswer = answer.lowercase().trim()

        // 1. Comprehension Check
        if (answer.isBlank() || answer.length < 5) {
            compPassed = false
        }

        // 2. Question Relevance & Direct Addressing Check
        // Rule: Do not force a mantra, scripture quotation, puja instruction, or religious explanation into an unrelated question
        val isNonReligiousQuery = intent.primaryIntent == QuestionIntentType.GENERAL_KNOWLEDGE ||
                lowerQuery.matches(".*\\b(\\d+\\s*[+\\-*/]\\s*\\d+|python|kotlin|capital of|photosynthesis|gravity|speed of light)\\b.*".toRegex())

        if (isNonReligiousQuery) {
            val hasForcedReligiousContent = lowerAnswer.contains("মন্ত্র") || lowerAnswer.contains("পূজা বিধি") ||
                    lowerAnswer.contains("শ্লোক") || lowerAnswer.contains("ॐ ") || lowerAnswer.contains("om ")
            if (hasForcedReligiousContent) {
                directlyAddresses = false
                relPassed = false
            }
        }

        if (intent.detectedTopic != null && !lowerAnswer.contains(intent.detectedTopic.lowercase()) &&
            !lowerAnswer.contains("dharma") && !lowerAnswer.contains("ধর্ম") && !lowerAnswer.contains("namaste")) {
            val queryWords = lowerQuery.split("\\s+".toRegex()).filter { it.length > 3 }
            val matchCount = queryWords.count { lowerAnswer.contains(it) }
            if (matchCount == 0 && queryWords.isNotEmpty() && intent.primaryIntent != QuestionIntentType.GREETING) {
                relPassed = false
                directlyAddresses = false
            }
        }

        // 3. Claims Grounding Check & Source Known
        if (hasCanonicalSource || isOriginalComposition || intent.primaryIntent == QuestionIntentType.GENERAL_KNOWLEDGE ||
            intent.primaryIntent == QuestionIntentType.CREATOR_IDENTITY || intent.primaryIntent == QuestionIntentType.AI_IDENTITY ||
            intent.primaryIntent == QuestionIntentType.GREETING || intent.primaryIntent == QuestionIntentType.SYSTEM_HEALTH_CHECK) {
            claimsPassed = true
            sourceKnown = true
        } else {
            // Unverified query
            sourceKnown = false
        }

        // 4. Scripture vs Original Writing Distinction (Never present AI-generated writing as scripture)
        if (isOriginalComposition) {
            if (!answer.contains("AI-রচিত মৌলিক") && !answer.contains("AI-Generated Original")) {
                scriptureDistPassed = false
            }
        }

        // 5. Zero Fabrication Check (Never invent mantras, shlokas, or chapter/verse references)
        val hasInventedMantraFlag = lowerAnswer.contains("fake_mantra") || lowerAnswer.contains("invented_verse")
        if (hasInventedMantraFlag) {
            zeroFabrication = false
            quotationAuthentic = false
        }

        // If Sanskrit text is present in a religious answer, confirm it comes from authentic sources
        if ((lowerAnswer.contains("ॐ ") || lowerAnswer.contains("oṁ ") || lowerAnswer.contains("শ্লোক:")) &&
            !isOriginalComposition && !hasCanonicalSource && !sourceKnown) {
            // Unverified Sanskrit text in religious context violates scripture safety
            quotationAuthentic = false
            zeroFabrication = false
        }

        // 6. Distinguish Tradition vs Historical Fact
        if (lowerAnswer.contains("ঐতিহাসিকভাবে প্রমাণিত") && (lowerQuery.contains("রাম") || lowerQuery.contains("কৃষ্ণ") || lowerQuery.contains("মহাবিশ্ব সৃষ্টি"))) {
            if (!lowerAnswer.contains("বিশ্বাস") && !lowerAnswer.contains("ঐতিহ্য") && !lowerAnswer.contains("শাস্ত্রীয় বিশ্বাস")) {
                traditionHistoryDistinct = false
            }
        }

        // 7. Context Bleeding Check
        if (previousTopic != null && activeTopic != null && previousTopic != activeTopic) {
            if (!lowerQuery.contains(previousTopic.lowercase()) && lowerAnswer.contains(previousTopic.lowercase()) &&
                intent.primaryIntent != QuestionIntentType.FOLLOW_UP_MODIFICATION) {
                noBleeding = false
            }
        }

        val allPassed = compPassed && relPassed && claimsPassed && contraFree &&
                scriptureDistPassed && noBleeding && zeroFabrication && directlyAddresses

        val summary = "SelfCheck [Comprehension=$compPassed, Relevance=$relPassed, Grounding=$claimsPassed, " +
                "ContradictionFree=$contraFree, ScriptureDistinction=$scriptureDistPassed, NoBleeding=$noBleeding, " +
                "SourceKnown=$sourceKnown, QuotationAuthentic=$quotationAuthentic, ZeroFabrication=$zeroFabrication]"

        return SelfCheckResult(
            isPassed = allPassed,
            comprehensionPassed = compPassed,
            relevancePassed = relPassed,
            claimsGroundingPassed = claimsPassed,
            contradictionFree = contraFree,
            scripturalDistinctionPassed = scriptureDistPassed,
            noContextBleeding = noBleeding,
            clarificationNeeded = clarNeeded,
            diagnosticSummary = summary,
            isRelevant = relPassed,
            isSourceKnown = sourceKnown,
            isQuotationAuthentic = quotationAuthentic,
            distinguishesTraditionFromHistory = traditionHistoryDistinct,
            zeroFabricationPassed = zeroFabrication,
            directlyAddressesQuestion = directlyAddresses
        )
    }
}
