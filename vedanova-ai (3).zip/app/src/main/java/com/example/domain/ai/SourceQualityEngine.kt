package com.example.domain.ai

import java.util.Locale

/**
 * Priority Hierarchy for Religious & Scriptural Sources:
 * 1. Vedas (Samhitas, Brahmanas, Aranyakas)
 * 2. Upanishads (Mukhya Upanishads / Vedanta Shruti)
 * 3. Bhagavad Gita (Prasthanatrayi Smriti)
 * 4. Ramayana (Valmiki Ramayana / Adi Kavya)
 * 5. Mahabharata (Itihasa / Shanti & Anushasana Parvas)
 * 6. Puranas (Ashtadasha Mahapuranas & Upa-Puranas)
 * 7. Agamas / Tantras and recognized traditional texts
 * 8. Established Traditional Commentaries (Adi Shankara, Ramanuja, Madhva, etc.)
 * 9. Other Recognized Texts (Dharmashastras, Astika Darshana Sutras)
 * 10. General Knowledge / Non-Religious Sources
 */
enum class ScripturalSourceTier(
    val priorityRank: Int, // 1 is highest priority
    val canonicalName: String,
    val bengaliName: String,
    val description: String
) {
    VEDAS(
        priorityRank = 1,
        canonicalName = "Vedas",
        bengaliName = "বেদ (সংহিতা ও ব্রাহ্মণ)",
        description = "Four Vedas: Rigveda, Samaveda, Yajurveda, Atharvaveda (Samhitas, Brahmanas, Aranyakas)"
    ),
    UPANISHADS(
        priorityRank = 2,
        canonicalName = "Upanishads",
        bengaliName = "উপনিষদ (বেদান্ত শ্রুতি)",
        description = "Mukhya Upanishads: Isha, Kena, Katha, Prashna, Mundaka, Mandukya, Taittiriya, Aitareya, Chandogya, Brihadaranyaka, Shvetashvatara"
    ),
    BHAGAVAD_GITA(
        priorityRank = 3,
        canonicalName = "Bhagavad Gita",
        bengaliName = "শ্রীমদ্ভগবদ্গীতা (প্রস্থানত্রয়ী স্মৃতি)",
        description = "Bhagavad Gita from the Bhishma Parva of the Mahabharata"
    ),
    RAMAYANA(
        priorityRank = 4,
        canonicalName = "Ramayana",
        bengaliName = "রামায়ণ (আদিকাব্য ইতিহাস)",
        description = "Valmiki Ramayana"
    ),
    MAHABHARATA(
        priorityRank = 5,
        canonicalName = "Mahabharata",
        bengaliName = "মহাভারত (ইতিহাস)",
        description = "Mahabharata composed by Sage Vyasa, including Shanti Parva & Anushasana Parva"
    ),
    PURANAS(
        priorityRank = 6,
        canonicalName = "Puranas",
        bengaliName = "পুরাণ (মহাপুরাণ ও উপপুরাণ)",
        description = "Eighteen Mahapuranas: Bhagavata, Vishnu, Shiva, Markandeya, etc."
    ),
    AGAMAS_TANTRAS(
        priorityRank = 7,
        canonicalName = "Agamas and Tantras",
        bengaliName = "আগম ও প্রামাণিক তন্ত্র",
        description = "Shaiva, Shakta, and Vaishnava Agamas/Pancharatra and recognized traditional texts"
    ),
    TRADITIONAL_COMMENTARIES(
        priorityRank = 8,
        canonicalName = "Established Traditional Commentaries",
        bengaliName = "প্রামাণিক আচার্য ভাষ্য",
        description = "Classical commentaries (Bhashyas) by Adi Shankara, Ramanuja, Madhva, Vallabha, Nimbarka, Sridhara Swami"
    ),
    OTHER_RECOGNIZED_TEXTS(
        priorityRank = 9,
        canonicalName = "Other Recognized Texts",
        bengaliName = "অন্যান্য শাস্ত্রীয় ও সূত্রগ্রন্থ",
        description = "Astika Darshana Sutras, Dharmashastras, and classical traditional compendiums"
    ),
    GENERAL_KNOWLEDGE(
        priorityRank = 10,
        canonicalName = "General Knowledge / Non-Religious",
        bengaliName = "সাধারণ জ্ঞান ও আধুনিক তথ্য",
        description = "Empirical science, math, technology, geography, or non-religious factual sources"
    );

    companion object {
        fun determineScripturalTier(sourceText: String, scripture: String = ""): ScripturalSourceTier {
            return SourceQualityEngine.determineScripturalTier(sourceText, scripture)
        }
    }
}

/**
 * Truth Separation Categories to ensure clear distinction between:
 * - Scriptural Text (original mantras/shlokas)
 * - Traditional Interpretation (classical commentaries/sampradaya doctrines)
 * - Historical / Scholarly Fact (empirically attested history/archaeology)
 * - Modern Interpretation (contemporary analysis and reform context)
 * - Original AI Writing (explicitly labeled creative/devotional compositions)
 */
enum class TruthCategory(
    val englishLabel: String,
    val bengaliLabel: String,
    val description: String
) {
    SCRIPTURAL_TEXT(
        englishLabel = "Scriptural Text",
        bengaliLabel = "শাস্ত্রীয় মূল পাঠ",
        description = "Direct sacred canonical text, mantra, or shloka from verified scriptures (Shruti & Smriti)."
    ),
    TRADITIONAL_INTERPRETATION(
        englishLabel = "Traditional Interpretation",
        bengaliLabel = "ঐতিহ্যবাহী আচার্য ব্যাখ্যা",
        description = "Commentary, exegesis, and philosophical doctrine from established sampradayas and acharyas."
    ),
    HISTORICAL_SCHOLARLY_FACT(
        englishLabel = "Historical / Scholarly Fact",
        bengaliLabel = "ঐতিহাসিক ও গবেষণালব্ধ তথ্য",
        description = "Empirically documented historical, archeological, epigraphical, or philological facts."
    ),
    MODERN_INTERPRETATION(
        englishLabel = "Modern Interpretation",
        bengaliLabel = "আধুনিক পরিপ্রেক্ষিত ও ব্যাখ্যা",
        description = "Contemporary analysis, reform perspectives, and modern contextual understanding."
    ),
    ORIGINAL_AI_WRITING(
        englishLabel = "Original AI Writing",
        bengaliLabel = "AI-রচিত মৌলিক রচনা",
        description = "AI-generated creative spiritual compositions, prayers, stories, or essays, clearly non-scriptural."
    )
}

data class TruthSeparationAnalysis(
    val primaryCategory: TruthCategory,
    val scripturalText: String? = null,
    val traditionalInterpretation: String? = null,
    val historicalScholarlyFact: String? = null,
    val modernInterpretation: String? = null,
    val originalAiWriting: String? = null,
    val isExplicitlySeparated: Boolean = true
)

enum class SourceQualityTier(
    val tierName: String,
    val bengaliLabel: String,
    val baseWeight: Float, // 0.0 - 1.0
    val defaultConfidence: Float,
    val description: String
) {
    PRIMARY_SCRIPTURE(
        tierName = "PRIMARY_SCRIPTURE",
        bengaliLabel = "মৌলিক বৈদিক ও শাস্ত্রীয় উৎস",
        baseWeight = 1.0f,
        defaultConfidence = 0.99f,
        description = "Shruti, Mukhya Upanishads, Bhagavad Gita, Brahma Sutras, and Vedic Samhitas."
    ),
    TRADITIONAL_COMMENTARY(
        tierName = "TRADITIONAL_COMMENTARY",
        bengaliLabel = "প্রামাণিক আচার্য ভাষ্য",
        baseWeight = 0.95f,
        defaultConfidence = 0.95f,
        description = "Classical commentaries (Bhashyas) by Adi Shankaracharya, Ramanuja, Madhva, Abhinavagupta, etc."
    ),
    ACADEMIC_SOURCE(
        tierName = "ACADEMIC_SOURCE",
        bengaliLabel = "একাডেমিক ও গবেষণা সংস্থান",
        baseWeight = 0.88f,
        defaultConfidence = 0.88f,
        description = "Peer-reviewed Indological studies, Critical editions, Bharatiya Vidya Bhavan, Bhandarkar Oriental Research."
    ),
    REPUTABLE_INSTITUTION(
        tierName = "REPUTABLE_INSTITUTION",
        bengaliLabel = "মর্যাদাপূর্ণ আধ্যাত্মিক প্রতিষ্ঠান",
        baseWeight = 0.82f,
        defaultConfidence = 0.85f,
        description = "Gita Press Gorakhpur, Ramakrishna Mission / Belur Math, Chinmaya Mission, Arya Samaj publications."
    ),
    GENERAL_WEBSITE(
        tierName = "GENERAL_WEBSITE",
        bengaliLabel = "সাধারণ তথ্যকোষ ও ওয়েব সংস্থান",
        baseWeight = 0.50f,
        defaultConfidence = 0.55f,
        description = "General informational articles, online encyclopedias, and community compendiums."
    ),
    USER_GENERATED_CONTENT(
        tierName = "USER_GENERATED_CONTENT",
        bengaliLabel = "ব্যবহারকারী প্রদত্ত / অসত্যায়িত বিষয়বস্তু",
        baseWeight = 0.30f,
        defaultConfidence = 0.35f,
        description = "Social forums, unverified blog posts, and ungrounded submissions."
    )
}

data class EvaluatedSource(
    val title: String,
    val tier: SourceQualityTier,
    val citation: String,
    val reliabilityScore: Float, // 0.0 - 1.0
    val verifiedCanonically: Boolean,
    val remarks: String,
    val scripturalTier: ScripturalSourceTier = ScripturalSourceTier.determineScripturalTier(title, citation)
)

object SourceQualityEngine {

    fun determineScripturalTier(sourceText: String, scripture: String = ""): ScripturalSourceTier {
        val s = "$sourceText $scripture".lowercase(Locale.ROOT)
        return when {
            // 1. Vedas
            s.contains("rigveda") || s.contains("ঋগ্বেদ") || s.contains("সামবেদ") || s.contains("samaveda") ||
            s.contains("যজুর্বেদ") || s.contains("yajurveda") || s.contains("অথর্ববেদ") || s.contains("atharvaveda") ||
            s.contains("সংহিতা") || s.contains("samhita") || s.contains("ব্রাহ্মণ") || s.contains("brahmana") ||
            (s.contains("বেদ") && !s.contains("বেদান্ত") && !s.contains("আয়ুর্বেদ") && !s.contains("ব্যাস")) ||
            (s.contains("veda") && !s.contains("vedanta") && !s.contains("ayurveda")) ->
                ScripturalSourceTier.VEDAS

            // 2. Upanishads
            s.contains("উপনিষদ") || s.contains("upanishad") || s.contains("বেদান্ত") || s.contains("vedanta") ||
            s.contains("ছান্দোগ্য") || s.contains("বৃহদারণ্যক") || s.contains("মাণ্ডূক্য") || s.contains("তৈত্তিরীয়") ||
            s.contains("ঈশ") || s.contains("কেন") || s.contains("কঠ") || s.contains("মুণ্ডক") || s.contains("শ্বেতাশ্বতর") ->
                ScripturalSourceTier.UPANISHADS

            // 3. Bhagavad Gita
            s.contains("গীতা") || s.contains("gita") || s.contains("ভগবদ্গীতা") || s.contains("bhagavad") ->
                ScripturalSourceTier.BHAGAVAD_GITA

            // 4. Ramayana
            s.contains("রামায়ণ") || s.contains("ramayana") || s.contains("বাল্মীকি") || s.contains("valmiki") ->
                ScripturalSourceTier.RAMAYANA

            // 5. Mahabharata
            s.contains("মহাভারত") || s.contains("mahabharata") || s.contains("শান্তিপর্ব") || s.contains("shanti parva") ->
                ScripturalSourceTier.MAHABHARATA

            // 6. Puranas
            s.contains("পুরাণ") || s.contains("purana") || s.contains("ভাগবত") || s.contains("bhagavata") ||
            s.contains("বিষ্ণু পুরাণ") || s.contains("শিব পুরাণ") || s.contains("দেবীভাগবত") || s.contains("মার্কণ্ডেয়") ->
                ScripturalSourceTier.PURANAS

            // 7. Agamas & Tantras
            s.contains("আগম") || s.contains("agama") || s.contains("তন্ত্র") || s.contains("tantra") ||
            s.contains("পঞ্চরাত্র") || s.contains("pancharatra") || s.contains("বৈখানস") || s.contains("রুদ্রযামল") ->
                ScripturalSourceTier.AGAMAS_TANTRAS

            // 8. Established Traditional Commentaries
            s.contains("ভাষ্য") || s.contains("bhashya") || s.contains("শংকর") || s.contains("shankara") ||
            s.contains("রামানুজ") || s.contains("ramanuja") || s.contains("মধ্ব") || s.contains("madhva") ||
            s.contains("বল্লভ") || s.contains("vallabha") || s.contains("শ্রীধর") || s.contains("সায়ন") ||
            s.contains("মাধবাচার্য") || s.contains("ভাষ্যকার") ->
                ScripturalSourceTier.TRADITIONAL_COMMENTARIES

            // 9. Other Recognized Texts
            s.contains("সূত্র") || s.contains("sutra") || s.contains("স্মৃতি") || s.contains("smriti") ||
            s.contains("মনুসংহিতা") || s.contains("manu") || s.contains("পতঞ্জলি") || s.contains("পাতঞ্জল") ||
            s.contains("ন্যায়") || s.contains("সাংখ্য") || s.contains("মীমাংসা") ->
                ScripturalSourceTier.OTHER_RECOGNIZED_TEXTS

            // 10. General Knowledge / Non-Religious
            s.contains("science") || s.contains("history") || s.contains("tech") || s.contains("math") ||
            s.contains("geography") || s.contains("general knowledge") ->
                ScripturalSourceTier.GENERAL_KNOWLEDGE

            else -> ScripturalSourceTier.OTHER_RECOGNIZED_TEXTS
        }
    }

    fun categorizeSource(sourceText: String, scripture: String): SourceQualityTier {
        val s = (sourceText + " " + scripture).lowercase()
        return when {
            s.contains("veda") || s.contains("বেদ") || s.contains("upanishad") || s.contains("উপনিষদ") ||
            s.contains("gita") || s.contains("গীতা") || s.contains("samhita") || s.contains("ব্রহ্মসূত্র") ||
            s.contains("brahma sutra") || s.contains("rigveda") || s.contains("yajurveda") ->
                SourceQualityTier.PRIMARY_SCRIPTURE

            s.contains("shankara") || s.contains("bhashya") || s.contains("ভাষ্য") || s.contains("ramanuja") ||
            s.contains("madhva") || s.contains("sridhara") || s.contains("sayana") || s.contains("abhinavagupta") ->
                SourceQualityTier.TRADITIONAL_COMMENTARY

            s.contains("critical edition") || s.contains("indology") || s.contains("bhandarkar") ||
            s.contains("academic") || s.contains("vidya bhavan") || s.contains("oxford") ->
                SourceQualityTier.ACADEMIC_SOURCE

            s.contains("gita press") || s.contains("গীতা প্রেস") || s.contains("belur math") || s.contains("বেলুড় মঠ") ||
            s.contains("ramakrishna") || s.contains("chinmaya") || s.contains("advaita ashrama") ->
                SourceQualityTier.REPUTABLE_INSTITUTION

            s.contains("wikipedia") || s.contains("blog") || s.contains("website") || s.contains("web") ->
                SourceQualityTier.GENERAL_WEBSITE

            else ->
                SourceQualityTier.TRADITIONAL_COMMENTARY
        }
    }

    fun evaluateSources(sources: List<Pair<String, String>>): List<EvaluatedSource> {
        return sources.map { (title, citation) ->
            val tier = categorizeSource(title, citation)
            val scripturalTier = determineScripturalTier(title, citation)
            EvaluatedSource(
                title = title,
                tier = tier,
                citation = citation,
                reliabilityScore = tier.defaultConfidence,
                verifiedCanonically = tier.baseWeight >= 0.85f,
                remarks = "Evaluated via Source Quality Engine (${tier.tierName}, Hierarchy: ${scripturalTier.canonicalName})",
                scripturalTier = scripturalTier
            )
        }
    }

    fun classifyTruthSeparation(
        query: String,
        answer: String,
        sanskritVerse: String?,
        isCreativeWriting: Boolean,
        sourceTier: ScripturalSourceTier?,
        isHistoricalQuery: Boolean = false
    ): TruthSeparationAnalysis {
        val lowerAns = answer.lowercase(Locale.ROOT)

        if (isCreativeWriting || lowerAns.contains("ai-রচিত মৌলিক") || lowerAns.contains("ai-generated original")) {
            return TruthSeparationAnalysis(
                primaryCategory = TruthCategory.ORIGINAL_AI_WRITING,
                originalAiWriting = answer,
                isExplicitlySeparated = true
            )
        }

        val hasScripturalText = !sanskritVerse.isNullOrBlank() ||
                lowerAns.contains("মূল শ্লোক") || lowerAns.contains("মূল সংস্কৃত") ||
                lowerAns.contains("canonical shloka")

        val hasTraditionalInterpretation = lowerAns.contains("সম্প্রদায়") || lowerAns.contains("ভাষ্য") ||
                lowerAns.contains("আচার্য") || lowerAns.contains("ব্যাখ্যা") || lowerAns.contains("তাৎপর্য") ||
                lowerAns.contains("interpretation") || lowerAns.contains("sampradaya")

        val hasHistoricalFact = isHistoricalQuery || lowerAns.contains("ইতিহাস") ||
                lowerAns.contains("ঐতিহাসিক") || lowerAns.contains("historical") ||
                lowerAns.contains("গবেষণা") || lowerAns.contains("scholarly")

        val primaryCategory = when {
            hasScripturalText && (sourceTier == ScripturalSourceTier.VEDAS ||
                                  sourceTier == ScripturalSourceTier.UPANISHADS ||
                                  sourceTier == ScripturalSourceTier.BHAGAVAD_GITA) -> TruthCategory.SCRIPTURAL_TEXT
            hasHistoricalFact -> TruthCategory.HISTORICAL_SCHOLARLY_FACT
            hasTraditionalInterpretation -> TruthCategory.TRADITIONAL_INTERPRETATION
            hasScripturalText -> TruthCategory.SCRIPTURAL_TEXT
            else -> TruthCategory.TRADITIONAL_INTERPRETATION
        }

        return TruthSeparationAnalysis(
            primaryCategory = primaryCategory,
            scripturalText = sanskritVerse,
            traditionalInterpretation = if (hasTraditionalInterpretation) "Traditional commentary & doctrine" else null,
            historicalScholarlyFact = if (hasHistoricalFact) "Historical & scholarly perspective" else null,
            modernInterpretation = if (lowerAns.contains("আধুনিক") || lowerAns.contains("modern")) "Modern application" else null,
            originalAiWriting = null,
            isExplicitlySeparated = true
        )
    }
}

