package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.VedaNovaDatabase
import com.example.data.model.*
import com.example.data.repository.VedaNovaRepository
import com.example.domain.ai.DiagnosticInfo
import com.example.domain.ai.OrchestratedResponse
import com.example.domain.ai.SelfDiagnosticReport
import com.example.domain.api.ApiGatewayRequest
import com.example.domain.api.ApiGatewayResponse
import com.example.domain.voice.FunctionAnnouncementManager
import com.example.domain.voice.VoiceGuideSettings
import com.example.domain.diagnostic.CrashReportingManager
import com.example.domain.image.*
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class ScreenDestination(val title: String, val section: String) {
    DASHBOARD("Control Center", "Core"),
    EXTERNAL_APPS_MONITOR("External Apps Monitor", "External Apps"),
    CAPABILITY_APPROVAL("Capability Approval Center", "External Apps"),
    DAILY_DATA_MONITOR("Daily Data & Festivals", "External Apps"),
    EXTERNAL_APP_SIMULATOR("External App Simulator", "External Apps"),
    IMAGE_GENERATION_CENTER("AI Image & Vision Studio", "AI & Testing"),
    AI_TESTING_LAB("AI Testing Lab", "AI & Testing"),
    API_CENTER("API Manager", "API Platform"),
    API_TESTING("API Testing Console", "API Platform"),
    EXTERNAL_TEST_CLIENT("API Test Client", "API Platform"),
    KNOWLEDGE_CENTER("Knowledge Center", "Knowledge"),
    TEACH_AI("Teach / Command", "Core"),
    PROJECT_MONITOR("Project Monitor", "Operations"),
    REPORTS("User Reports", "Monitoring"),
    DATABASE_CENTER("Database Center", "Infrastructure"),
    USERS("Admin Users & RBAC", "Access Control"),
    ANALYTICS("API Analytics", "Monitoring"),
    LOGS("System Logs", "Monitoring"),
    AUDIT_LOGS("Audit Trail", "Security & Governance"),
    SYSTEM_HEALTH("System Health", "Infrastructure"),
    SECURITY("Security Center", "Security & Governance"),
    BACKUPS("Backup & Restore", "Infrastructure"),
    SETTINGS("Settings", "Core"),
    FUNCTION_MAP("Admin Function Map", "Core"),
    APP_OVERVIEW("App Architecture & Overview", "Core"),
    CRASH_REPORTS("Crash Diagnostic Center", "Monitoring"),
    RESEARCH_CENTER("Web Research & Harvesting Center", "Knowledge"),
    PUBLIC_APP("Public Dharma App", "Client App")
}

data class ImageStudioUiState(
    val prompt: String = "শ্রীকৃষ্ণের একটি দিব্য আধ্যাত্মিক রূপ",
    val aspectRatio: ImageAspectRatio = ImageAspectRatio.SQUARE,
    val quality: ImageQuality = ImageQuality.STANDARD,
    val isDharmaEnhanced: Boolean = true,
    val isGenerating: Boolean = false,
    val activeResult: ImageGenerationResult? = null,
    val activeEntity: GeneratedImageEntity? = null,
    val selectedImage: GeneratedImageEntity? = null,
    val isUnderstanding: Boolean = false,
    val visionQuestion: String = "এই ছবির আধ্যাত্মিক তাৎপর্য ও শাস্ত্রীয় প্রতীক ব্যাখ্যা করুন।",
    val visionResult: ImageUnderstandingResult? = null,
    val toastMessage: String? = null,
    val activeTab: Int = 0 // 0: Studio Playground, 1: Gallery & Records, 2: Vision Analysis, 3: Engine Architecture & Audit
)

data class RealApiTestingState(
    val isTesting: Boolean = false,
    val activeTestingKeyId: Long? = null,
    val lastResult: com.example.data.repository.RealApiTestResult? = null,
    val errorMessage: String? = null
)

data class AdminChatMessage(
    val id: String = java.util.UUID.randomUUID().toString(),
    val sender: String, // "ADMIN" or "AI"
    val message: String,
    val task: DevelopmentTaskEntity? = null,
    val attachedImageUri: String? = null,
    val mediaType: String? = null, // "IMAGE" or "VIDEO"
    val timestamp: Long = System.currentTimeMillis()
)

data class AdminCommandState(
    val instruction: String = "",
    val attachedImageUri: String? = null,
    val attachedMediaType: String? = null,
    val isProcessing: Boolean = false,
    val lastGeneratedTask: DevelopmentTaskEntity? = null,
    val successMessage: String? = null,
    val errorMessage: String? = null,
    val chatHistory: List<AdminChatMessage> = listOf(
        AdminChatMessage(
            sender = "AI",
            message = "নমস্কার অ্যাডমিন! আমি Dharma AI Real Admin Command Center। আপনি স্বাভাবিক ভাষায় নির্দেশ দিতে পারেন:\n• \"Voice ঠিক করো\"\n• \"এই সমস্যাটা খুঁজে ঠিক করো\"\n• \"এই screenshot দেখে সমস্যা বের করো\"\n• \"এই function-টা এই screen-এ যোগ করো\"\n• \"আবার test করো\"\n• \"সবকিছু ঠিক আছে কি না check করো\"\n\nআমি সিস্টেম আর্কিটেকচার বিশ্লেষণ করে প্রস্তাবনা ও টেস্ট প্ল্যান তৈরি করব এবং আপনার অনুমোদনের পর বাস্তব অপারেশন চালাব।"
        )
    )
)

data class ResearchLabState(
    val query: String = "গায়ত্রী মহামন্ত্রের মূল উৎস, অর্থ ও ছন্দ কী?",
    val isLoading: Boolean = false,
    val webResult: com.example.domain.research.WebResearchResult? = null,
    val youtubeResult: com.example.domain.research.YouTubeResearchResult? = null,
    val crossVerificationReport: com.example.domain.research.CrossSourceVerificationReport? = null,
    val mantraShieldResult: com.example.domain.research.MantraVerificationShieldResult? = null,
    val discoveryResults: List<com.example.domain.research.TopicScanResult> = emptyList(),
    val isScanningDiscovery: Boolean = false,
    val discoveryCategories: Set<String> = setOf("Vedic Mantras", "Upanishadic Mantras", "Gita Verses", "Shiva Mantras"),
    val activeTab: Int = 0 // 0: Web & YouTube Research Engine, 1: Mantra Verification Shield, 2: Dharma Discovery Scanner, 3: Candidate Approval Center, 4: Research Issue Center, 5: Research Activity Audit Log
)

data class ExternalClientTestState(
    val baseUrl: String = "https://api.vedanova.ai",
    val apiKey: String = "vn_live_9a87f2e14bc8901ad47e3321",
    val isRunningSuite: Boolean = false,
    val suiteProgress: Float = 0f,
    val testResults: List<com.example.domain.api.RemoteTestResult> = emptyList(),
    val activeTab: Int = 0, // 0: Automated Test Suite (12 Tests), 1: Manual HTTP Playground
    val playgroundEndpoint: String = "/api/v1/chat",
    val playgroundMethod: String = "POST",
    val playgroundBody: String = "{\n  \"query\": \"শ্রীমদ্ভগবদ্গীতার মূল বার্তা কী?\"\n}",
    val playgroundResponse: ApiGatewayResponse? = null,
    val isPlaygroundLoading: Boolean = false
)

data class SystemHealthStatus(
    val backendStatus: String = "GREEN", // GREEN, YELLOW, RED
    val databaseStatus: String = "GREEN",
    val aiProviderStatus: String = "GREEN",
    val apiGatewayStatus: String = "GREEN",
    val knowledgeEngineStatus: String = "GREEN",
    val researchEngineStatus: String = "GREEN",
    val verificationEngineStatus: String = "GREEN",
    val authStatus: String = "GREEN",
    val storageStatus: String = "GREEN",
    val backupStatus: String = "GREEN"
)

data class AiLabTestState(
    val query: String = "",
    val isLoading: Boolean = false,
    val response: OrchestratedResponse? = null,
    val selfDiagnosticReport: SelfDiagnosticReport? = null,
    val selectedLanguageFilter: String = "All",
    val deepDiagnosticMode: Boolean = true, // Requirement #17: Admin Deep Diagnostic Mode
    val error: String? = null
)

data class ApiTestConsoleState(
    val selectedEndpoint: String = "/api/v1/chat",
    val selectedMethod: String = "POST",
    val selectedApiKeyId: Long = 1,
    val customBearerKey: String = "vn_live_9a87f2e14bc8901ad47e3321",
    val requestHeaders: String = "Content-Type: application/json\nAccept: application/json",
    val requestBody: String = "{\n  \"query\": \"গায়ত্রী মন্ত্রের অর্থ ও ঋষি কে?\"\n}",
    val isLoading: Boolean = false,
    val response: ApiGatewayResponse? = null,
    val requestHistory: List<Pair<ApiGatewayRequest, ApiGatewayResponse>> = emptyList()
)

data class TeachAiState(
    val title: String = "",
    val question: String = "",
    val answer: String = "",
    val category: String = "GENERAL_DHARMA",
    val source: String = "Admin Verified Scripture",
    val reference: String = "",
    val sanskritText: String = "",
    val transliteration: String = "",
    val explanation: String = "",
    val saveAsCandidate: Boolean = false,
    val selectedUnknownId: Long? = null,
    val conflictResult: com.example.domain.ai.KnowledgeConflictResult? = null,
    val isSaving: Boolean = false,
    val successMessage: String? = null,
    val errorMessage: String? = null,
    val activeTeachTab: Int = 0 // 0: Teach Knowledge, 1: Unknown Queue, 2: Candidate Approvals, 3: Version History, 4: Usage Analytics
)

class VedaNovaViewModel(application: Application) : AndroidViewModel(application) {
    private val database = VedaNovaDatabase.getInstance(application)
    val repository = VedaNovaRepository(database, application)
    val adminCommandEngine = com.example.domain.command.AdminCommandEngine(application, database)

    // Navigation State
    private val _currentScreen = MutableStateFlow(ScreenDestination.DASHBOARD)
    val currentScreen: StateFlow<ScreenDestination> = _currentScreen.asStateFlow()

    // Auth & Session State
    val currentSession = repository.adminAuthManager.currentSession
    val allUsers = repository.allUsers.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Database Data Streams
    val allKnowledge = repository.allKnowledge.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val publishedKnowledge = repository.publishedKnowledge.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val candidateKnowledge = repository.candidateKnowledge.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allUnknownKnowledge = repository.allUnknownKnowledge.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val pendingUnknownKnowledge = repository.pendingUnknownKnowledge.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val pendingUnknownCount = repository.pendingUnknownCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val allKnowledgeVersions = repository.allKnowledgeVersions.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allUsageLogs = repository.allUsageLogs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val draftKnowledgeItems = repository.draftKnowledgeItems.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val draftKnowledge = draftKnowledgeItems
    val allApiKeys = repository.allApiKeys.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val recentApiLogs = repository.recentApiLogs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allIssues = repository.allIssues.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allReports = repository.allReports.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val recentAuditLogs = repository.recentAuditLogs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val recentSystemLogs = repository.recentSystemLogs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allSettings = repository.allSettings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allBackups = repository.allBackups.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allExternalApps = repository.allExternalApps.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allCapabilityProposals = repository.allCapabilityProposals.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val recentDailyJobLogs = repository.recentDailyJobLogs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val recentCrashReports = repository.recentCrashReports.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val totalCrashCount = repository.totalCrashCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val recentActivityLogs = repository.recentActivityLogs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allDevelopmentTasks = repository.allDevelopmentTasks.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val pendingApprovalTasks = repository.pendingApprovalTasks.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val pendingApprovalTasksCount = repository.pendingApprovalTasksCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)

    // Operational API & Admin Command States
    private val _realApiTestingState = MutableStateFlow(RealApiTestingState())
    val realApiTestingState: StateFlow<RealApiTestingState> = _realApiTestingState.asStateFlow()

    private val _adminCommandState = MutableStateFlow(AdminCommandState())
    val adminCommandState: StateFlow<AdminCommandState> = _adminCommandState.asStateFlow()

    // Phase 6 Research & Harvesting Flows
    val allResearchSources = repository.allResearchSources.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allResearchIssues = repository.allResearchIssues.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val openResearchIssues = repository.openResearchIssues.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val openResearchIssuesCount = repository.openResearchIssuesCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val allKnowledgeCandidates = repository.allKnowledgeCandidates.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val pendingCandidates = repository.pendingCandidates.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val pendingCandidatesCount = repository.pendingCandidatesCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val recentResearchActivityLogs = repository.recentResearchActivityLogs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Phase 6 Research Lab State
    private val _researchLabState = MutableStateFlow(ResearchLabState())
    val researchLabState: StateFlow<ResearchLabState> = _researchLabState.asStateFlow()

    // Phase 5.1 Voice Guide & Announcer
    val voiceAnnouncementManager = FunctionAnnouncementManager(application)
    val voiceSettings = voiceAnnouncementManager.settings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), VoiceGuideSettings())
    val lastAnnouncement = voiceAnnouncementManager.lastAnnouncement.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")

    // Phase 8: Live Voice AI & Call Architecture
    val liveVoiceManager = com.example.domain.voice.LiveVoiceAiManager(application)
    val liveVoiceState = liveVoiceManager.voiceState
    val liveVoiceTranscript = liveVoiceManager.liveTranscript
    val liveVoiceAmplitude = liveVoiceManager.voiceAmplitude
    val liveVoiceError = liveVoiceManager.voiceError
    val isVoiceCallActive = liveVoiceManager.isCallOverlayActive
    val liveVoiceSettings = liveVoiceManager.settings
    val currentlySpeakingText = liveVoiceManager.currentlySpeakingText

    fun toggleSpeakMessage(text: String) {
        liveVoiceManager.toggleSpeak(text)
    }

    fun stopSpeaking() {
        liveVoiceManager.stopSpeaking()
    }

    fun startLiveVoiceCall() {
        liveVoiceManager.startLiveCallSession { recognizedText ->
            sendPublicChatMessage(customQuery = recognizedText, fromVoice = true)
        }
    }

    fun endLiveVoiceCall() {
        liveVoiceManager.endLiveCallSession()
    }

    fun triggerSingleVoiceInput() {
        liveVoiceManager.triggerSingleVoiceInput { recognizedText ->
            _publicChatQuery.value = recognizedText
            sendPublicChatMessage(fromVoice = true)
        }
    }

    fun toggleVoiceMute() {
        liveVoiceManager.toggleMute()
    }

    fun interruptVoiceAndListen() {
        liveVoiceManager.interruptAndListen()
    }

    fun updateLiveVoiceSettings(settings: com.example.domain.voice.LiveVoiceSettings) {
        liveVoiceManager.updateSettings(settings)
    }

    // Metrics
    val knowledgeCount = repository.knowledgeCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 9)
    val totalLogsCount = repository.totalLogsCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val failedLogsCount = repository.failedLogsCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val averageResponseTime = repository.averageResponseTime.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 125.0)
    val pendingIssuesCount = repository.pendingIssuesCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 1)

    // Phase 4: Daily Data State
    private val _selectedDailyRegion = MutableStateFlow(com.example.domain.ai.CalendarRegion.BANGLADESH_DHAKA)
    val selectedDailyRegion: StateFlow<com.example.domain.ai.CalendarRegion> = _selectedDailyRegion.asStateFlow()

    private val _dailyData = MutableStateFlow(com.example.domain.ai.DailyDataEngine.resolveDailyData(com.example.domain.ai.CalendarRegion.BANGLADESH_DHAKA))
    val dailyData: StateFlow<com.example.domain.ai.DailyDataResolution> = _dailyData.asStateFlow()

    private val _isDailyJobRunning = MutableStateFlow(false)
    val isDailyJobRunning: StateFlow<Boolean> = _isDailyJobRunning.asStateFlow()

    private val _dailyJobMessage = MutableStateFlow<String?>(null)
    val dailyJobMessage: StateFlow<String?> = _dailyJobMessage.asStateFlow()

    // Phase 4: External App Sandbox / Simulator State
    private val _simulatorAppId = MutableStateFlow("APP-DHARMAGUIDE-101")
    val simulatorAppId: StateFlow<String> = _simulatorAppId.asStateFlow()

    private val _simulatorRegion = MutableStateFlow(com.example.domain.ai.CalendarRegion.BANGLADESH_DHAKA)
    val simulatorRegion: StateFlow<com.example.domain.ai.CalendarRegion> = _simulatorRegion.asStateFlow()

    private val _simulatorActiveTab = MutableStateFlow(0) // 0: Dynamic Feed, 1: Live Countdown, 2: Capability Discovery, 3: Simulated App Chat, 4: Raw Gateway Inspection
    val simulatorActiveTab: StateFlow<Int> = _simulatorActiveTab.asStateFlow()

    private val _simulatorChatQuery = MutableStateFlow("আজকের তিথি ও পূজার শুভ মুহূর্ত কী?")
    val simulatorChatQuery: StateFlow<String> = _simulatorChatQuery.asStateFlow()

    private val _simulatorChatMessages = MutableStateFlow<List<Pair<String, String>>>(listOf(
        "APP_SYSTEM" to "Connected to VedaNova AI Cloud (API Key: vn_live_app_dharmaguide_a9102c). Scopes: [CALENDAR, CHAT, FESTIVAL, MANTRA]."
    ))
    val simulatorChatMessages: StateFlow<List<Pair<String, String>>> = _simulatorChatMessages.asStateFlow()

    private val _simulatorIsLoading = MutableStateFlow(false)
    val simulatorIsLoading: StateFlow<Boolean> = _simulatorIsLoading.asStateFlow()

    private val _simulatorLastResponse = MutableStateFlow<ApiGatewayResponse?>(null)
    val simulatorLastResponse: StateFlow<ApiGatewayResponse?> = _simulatorLastResponse.asStateFlow()

    private val _selectedAppForDetail = MutableStateFlow<ExternalAppEntity?>(null)
    val selectedAppForDetail: StateFlow<ExternalAppEntity?> = _selectedAppForDetail.asStateFlow()


    // AI Testing Lab Engine & Operational State
    val aiTestingLabEngine = com.example.domain.ai.AiTestingLabEngine(application, database.knowledgeDao())
    private val _aiLabUiState = MutableStateFlow(com.example.domain.ai.AiTestingLabUiState())
    val aiLabUiState: StateFlow<com.example.domain.ai.AiTestingLabUiState> = _aiLabUiState.asStateFlow()

    // Health Matrix & Real Feature Health Map
    val featureHealthAuditor = com.example.domain.health.FeatureHealthAuditor(application, database, repository)
    private val _featureHealthList = MutableStateFlow<List<com.example.domain.health.FeatureHealthItem>>(emptyList())
    val featureHealthList: StateFlow<List<com.example.domain.health.FeatureHealthItem>> = _featureHealthList.asStateFlow()

    private val _isAuditingHealth = MutableStateFlow(false)
    val isAuditingHealth: StateFlow<Boolean> = _isAuditingHealth.asStateFlow()

    private val _lastAuditTimestamp = MutableStateFlow<String?>(null)
    val lastAuditTimestamp: StateFlow<String?> = _lastAuditTimestamp.asStateFlow()

    private val _healthStatus = MutableStateFlow(SystemHealthStatus())
    val healthStatus: StateFlow<SystemHealthStatus> = _healthStatus.asStateFlow()

    // AI Testing Lab Legacy State
    private val _aiLabState = MutableStateFlow(AiLabTestState())
    val aiLabState: StateFlow<AiLabTestState> = _aiLabState.asStateFlow()

    // API Testing Console State
    private val _apiTestState = MutableStateFlow(ApiTestConsoleState())
    val apiTestState: StateFlow<ApiTestConsoleState> = _apiTestState.asStateFlow()

    // External Client State
    private val _externalClientState = MutableStateFlow(ExternalClientTestState())
    val externalClientState: StateFlow<ExternalClientTestState> = _externalClientState.asStateFlow()

    // Step 6: AI Image Generation & Vision Studio State
    val allGeneratedImages = repository.allGeneratedImages.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val recentGeneratedImages = repository.recentGeneratedImages.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val totalGeneratedImagesCount = repository.totalGeneratedImagesCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val successfulImagesCount = repository.successfulImagesCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val failedImagesCount = repository.failedImagesCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val imageEngineState = repository.imageEngineState
    val lastGeneratedImage = repository.lastGeneratedImage

    private val _imageStudioState = MutableStateFlow(ImageStudioUiState())
    val imageStudioState: StateFlow<ImageStudioUiState> = _imageStudioState.asStateFlow()

    // Public App State
    private val _publicChatQuery = MutableStateFlow("")
    val publicChatQuery = _publicChatQuery.asStateFlow()

    private val _publicChatMessages = MutableStateFlow<List<Pair<String, String>>>(listOf(
        "AI" to "নমস্কার! আমি VedaNova AI। সনাতন হিন্দু ধর্ম, বেদ, উপনিষদ, শ্রীমদ্ভগবদ্গীতা, মন্ত্র, পূজা ও দর্শন সম্পর্কে আপনার কোনো প্রশ্ন থাকলে নির্দ্বিধায় জিজ্ঞাসা করুন।"
    ))
    val publicChatMessages = _publicChatMessages.asStateFlow()

    private val _publicClarificationOptions = MutableStateFlow<List<String>>(emptyList())
    val publicClarificationOptions = _publicClarificationOptions.asStateFlow()

    private val _lastPublicResponse = MutableStateFlow<OrchestratedResponse?>(null)
    val lastPublicResponse = _lastPublicResponse.asStateFlow()

    private val _publicIsLoading = MutableStateFlow(false)
    val publicIsLoading = _publicIsLoading.asStateFlow()

    // Global Search State
    private val _globalSearchQuery = MutableStateFlow("")
    val globalSearchQuery = _globalSearchQuery.asStateFlow()

    // Navigation Back Stack
    private val _screenBackStack = mutableListOf<ScreenDestination>()

    init {
        CrashReportingManager.initialize(application, database)
        runFeatureHealthAudit()
    }

    fun navigateTo(destination: ScreenDestination) {
        val prev = _currentScreen.value
        if (prev != destination) {
            _screenBackStack.add(prev)
            if (_screenBackStack.size > 25) {
                _screenBackStack.removeAt(0)
            }
        }
        _currentScreen.value = destination
        CrashReportingManager.updateNavigationContext(
            current = destination.name,
            previous = prev.name,
            action = "Admin navigated from ${prev.title} to ${destination.title}"
        )
        voiceAnnouncementManager.announceNavigation(destination.name)
        viewModelScope.launch {
            val adminUser = currentSession.value.currentUser.username
            repository.logFunctionActivity(
                functionId = destination.name.lowercase(),
                functionName = destination.title,
                section = destination.section,
                previousScreen = prev.name,
                currentScreen = destination.name,
                adminUser = adminUser
            )
        }
    }

    fun navigateBack(): Boolean {
        if (_screenBackStack.isNotEmpty()) {
            val prev = _screenBackStack.removeAt(_screenBackStack.size - 1)
            val current = _currentScreen.value
            _currentScreen.value = prev
            CrashReportingManager.updateNavigationContext(
                current = prev.name,
                previous = current.name,
                action = "Admin navigated back from ${current.title} to ${prev.title}"
            )
            voiceAnnouncementManager.announceNavigation(prev.name)
            return true
        }
        return false
    }

    fun switchAdminUser(user: AdminUserEntity) {
        viewModelScope.launch {
            repository.adminAuthManager.switchUser(user)
        }
    }

    // AI Testing Lab Operational Actions
    fun setAiLabQueryText(text: String) {
        _aiLabUiState.update { it.copy(currentQuery = text, errorMessage = null) }
        _aiLabState.update { it.copy(query = text) }
    }

    fun attachImageToAiLab(uri: android.net.Uri) {
        viewModelScope.launch {
            val attachment = aiTestingLabEngine.processImageUri(uri)
            if (attachment != null) {
                _aiLabUiState.update { it.copy(selectedMedia = attachment, errorMessage = null) }
            } else {
                _aiLabUiState.update { it.copy(errorMessage = "ইমেজ ফাইল লোড করতে ব্যর্থ হয়েছে। অনুগ্রহ করে অন্য ছবি নির্বাচন করুন।") }
            }
        }
    }

    fun attachVideoToAiLab(uri: android.net.Uri) {
        viewModelScope.launch {
            val attachment = aiTestingLabEngine.processVideoUri(uri)
            if (attachment != null) {
                _aiLabUiState.update { it.copy(selectedMedia = attachment, errorMessage = null) }
            } else {
                _aiLabUiState.update { it.copy(errorMessage = "ভিডিও ফাইল লোড করতে ব্যর্থ হয়েছে। অনুগ্রহ করে সমর্থিত MP4/MKV ফাইল নির্বাচন করুন।") }
            }
        }
    }

    fun removeAiLabMedia() {
        _aiLabUiState.update { it.copy(selectedMedia = null) }
    }

    fun runAiTestingLabAnalysis(queryOverride: String? = null) {
        val q = (queryOverride ?: _aiLabUiState.value.currentQuery).trim()
        val media = _aiLabUiState.value.selectedMedia

        if (q.isBlank() && media == null) {
            _aiLabUiState.update { it.copy(errorMessage = "দয়া করে সমস্যার বিবরণ লিখুন অথবা একটি ছবি/ভিডিও যুক্ত করুন।") }
            return
        }

        // Check if user query is an explicit database save instruction
        val lowerQ = q.lowercase()
        val isExplicitSaveCommand = lowerQ.contains("data save করো") || lowerQ.contains("ডাটা সেভ করো") ||
                lowerQ.contains("database-এ save") || lowerQ.contains("save this data") || lowerQ.contains("save to database")

        if (isExplicitSaveCommand) {
            val lastTurnWithAnalysis = _aiLabUiState.value.turns.lastOrNull { it.analysisResult != null }
            if (lastTurnWithAnalysis?.analysisResult != null) {
                val res = lastTurnWithAnalysis.analysisResult
                saveAiLabResultToDatabase(
                    title = res.title,
                    content = res.summary + "\n\n" + res.problems.joinToString("\n") { "• " + it.problem + " (" + it.suggestedFix + ")" },
                    category = "AI_LAB_TEST",
                    turnId = lastTurnWithAnalysis.id
                )
                _aiLabUiState.update { it.copy(currentQuery = "", selectedMedia = null) }
                return
            }
        }

        val userTurn = com.example.domain.ai.LabConversationTurn(
            isUser = true,
            text = if (q.isNotBlank()) q else (if (media?.isVideo == true) "🎥 [ভিডিও আপলোড: ${media.fileName}]" else "📷 [ছবি আপলোড: ${media?.fileName}]"),
            mediaAttachment = media
        )

        _aiLabUiState.update {
            it.copy(
                turns = it.turns + userTurn,
                currentQuery = "",
                selectedMedia = null,
                isAnalyzing = true,
                errorMessage = null
            )
        }

        viewModelScope.launch {
            try {
                val result = aiTestingLabEngine.analyzeProblem(
                    query = if (q.isNotBlank()) q else "Inspect attached media",
                    media = media,
                    history = _aiLabUiState.value.turns
                )

                val aiTurn = com.example.domain.ai.LabConversationTurn(
                    isUser = false,
                    text = result.summary,
                    analysisResult = result
                )

                _aiLabUiState.update {
                    it.copy(
                        turns = it.turns + aiTurn,
                        isAnalyzing = false
                    )
                }
            } catch (e: Exception) {
                _aiLabUiState.update {
                    it.copy(
                        isAnalyzing = false,
                        errorMessage = "বিশ্লেষণ সম্পাদন করতে বিঘ্ন ঘটেছে: ${e.message ?: "AI Service Unavailable"}"
                    )
                }
            }
        }
    }

    fun saveAiLabResultToDatabase(
        title: String,
        content: String,
        category: String = "AI_LAB_TEST",
        turnId: String? = null
    ) {
        viewModelScope.launch {
            _aiLabUiState.update { it.copy(isSavingToDb = true, errorMessage = null) }
            try {
                val insertedId = aiTestingLabEngine.saveKnowledgeToDatabase(
                    title = title,
                    content = content,
                    category = category
                )

                val isVerified = aiTestingLabEngine.verifyDatabasePersistence(insertedId)

                if (isVerified) {
                    // Update turn state if turnId is provided
                    _aiLabUiState.update { state ->
                        val updatedTurns = state.turns.map { turn ->
                            if (turn.id == turnId || (turnId == null && turn.analysisResult != null && !turn.isSavedToDb)) {
                                turn.copy(isSavedToDb = true, savedKnowledgeId = insertedId)
                            } else {
                                turn
                            }
                        }
                        state.copy(
                            turns = updatedTurns,
                            isSavingToDb = false,
                            lastSaveSuccessMessage = "✅ Room Database-এ সফলভাবে সংরক্ষিত ও যাচাইকৃত হয়েছে (Knowledge ID: #KB-$insertedId)"
                        )
                    }
                } else {
                    _aiLabUiState.update {
                        it.copy(
                            isSavingToDb = false,
                            errorMessage = "ডাটাবেসে লেখার পর রেকর্ডটি যাচাই করা যায়নি।"
                        )
                    }
                }
            } catch (e: Exception) {
                _aiLabUiState.update {
                    it.copy(
                        isSavingToDb = false,
                        errorMessage = "ডাটাবেসে সংরক্ষণ ব্যর্থ হয়েছে: ${e.message}"
                    )
                }
            }
        }
    }

    fun clearAiLabHistory() {
        _aiLabUiState.update {
            it.copy(
                turns = emptyList(),
                currentQuery = "",
                selectedMedia = null,
                errorMessage = null,
                lastSaveSuccessMessage = null
            )
        }
    }

    fun dismissAiLabError() {
        _aiLabUiState.update { it.copy(errorMessage = null) }
    }

    fun dismissAiLabSaveMessage() {
        _aiLabUiState.update { it.copy(lastSaveSuccessMessage = null) }
    }

    // AI Lab Actions (Legacy compatibility)
    fun setAiLabQuery(q: String) {
        setAiLabQueryText(q)
    }

    fun runAiLabTest(query: String? = null) {
        runAiTestingLabAnalysis(query)
    }

    // API Testing Console Actions
    fun updateApiTestEndpoint(endpoint: String) {
        val templateBody = when (endpoint) {
            "/api/v1/chat" -> "{\n  \"query\": \"শ্রীমদ্ভগবদ্গীতার ২.৪৭ শ্লোকের অর্থ কী?\"\n}"
            "/api/v1/image/generate" -> "{\n  \"prompt\": \"শ্রীকৃষ্ণের একটি দিব্য রূপ\",\n  \"aspect_ratio\": \"1:1\",\n  \"quality\": \"STANDARD\",\n  \"dharma_enhanced\": true\n}"
            "/api/v1/image/understand" -> "{\n  \"image_file_path\": \"/data/user/0/com.example/files/sacred_images/sample.jpg\",\n  \"question\": \"এই ছবির আধ্যাত্মিক তাৎপর্য ব্যাখ্যা করুন।\"\n}"
            "/api/v1/voice" -> "{\n  \"text\": \"নমস্কার! Dharma AI Voice Assistant\",\n  \"query\": \"নমস্কার\"\n}"
            "/api/v1/research" -> "{\n  \"query\": \"Comparative analysis of Nishkama Karma in Gita vs Upanishadic Renunciation\"\n}"
            "/api/v1/knowledge/search" -> "{\n  \"query\": \"Gayatri Mantra\"\n}"
            "/api/v1/mantra/search" -> "{\n  \"query\": \"Mahamrityunjaya\"\n}"
            "/api/v1/scripture/search" -> "{\n  \"query\": \"Isha Upanishad\"\n}"
            "/api/v1/verify" -> "{\n  \"query\": \"যদা যদা হি ধর্মস্য গ্লানির্ভবতি\"\n}"
            "/api/v1/status" -> ""
            else -> "{\n  \"query\": \"Sanatan Dharma\"\n}"
        }
        val method = if (endpoint.contains("/status")) "GET" else "POST"
        _apiTestState.update { 
            it.copy(selectedEndpoint = endpoint, selectedMethod = method, requestBody = templateBody) 
        }
    }

    fun updateApiTestKey(apiKey: String) {
        _apiTestState.update { it.copy(customBearerKey = apiKey) }
    }

    fun updateApiTestBody(body: String) {
        _apiTestState.update { it.copy(requestBody = body) }
    }

    fun sendApiTestRequest() {
        val state = _apiTestState.value
        viewModelScope.launch {
            _apiTestState.update { it.copy(isLoading = true) }
            val request = ApiGatewayRequest(
                endpoint = state.selectedEndpoint,
                method = state.selectedMethod,
                apiKey = state.customBearerKey,
                body = state.requestBody
            )
            val response = repository.executeGatewayRequest(request)
            _apiTestState.update {
                it.copy(
                    isLoading = false,
                    response = response,
                    requestHistory = listOf(request to response) + it.requestHistory.take(15)
                )
            }
        }
    }

    // ==========================================
    // OPERATIONAL API CONTROL & TESTING ACTIONS
    // ==========================================

    fun testRealApiKey(apiKeyEntity: ApiKeyEntity) {
        viewModelScope.launch {
            _realApiTestingState.update {
                it.copy(isTesting = true, activeTestingKeyId = apiKeyEntity.id, lastResult = null, errorMessage = null)
            }
            val result = repository.executeRealApiTest(apiKeyEntity)
            _realApiTestingState.update {
                it.copy(
                    isTesting = false,
                    activeTestingKeyId = null,
                    lastResult = result,
                    errorMessage = if (!result.isSuccess) result.errorMessage else null
                )
            }
        }
    }

    fun dismissRealApiTestResult() {
        _realApiTestingState.update { it.copy(lastResult = null, errorMessage = null) }
    }

    fun createDharmaApiKey(
        name: String,
        appName: String,
        description: String = "",
        permissions: String = "chat,knowledge,mantra,scripture,puja,research,verify,status,calendar,festival,image_generation,vision,voice",
        expiresInDays: Int = 30,
        rateLimitPerMin: Int = 60,
        dailyLimit: Int = 5000,
        monthlyLimit: Int = 100000,
        provider: String = "Dharma AI Central Gateway",
        endpoint: String = "https://ais-dev-v2q3z47ktmramt3bwyb577-234096854893.asia-southeast1.run.app/api/v1/chat"
    ) {
        viewModelScope.launch {
            repository.createApiKey(
                name = name.trim(),
                appName = appName.trim(),
                description = description.trim(),
                provider = provider,
                endpoint = endpoint,
                permissions = permissions,
                expiresInDays = expiresInDays,
                rateLimit = rateLimitPerMin,
                dailyLimit = dailyLimit,
                monthlyLimit = monthlyLimit
            )
        }
    }

    fun extendApiKeyExpiry(key: ApiKeyEntity, additionalDays: Int) {
        viewModelScope.launch {
            repository.extendApiKeyExpiry(key, additionalDays)
        }
    }

    fun setApiKeyCustomExpiry(key: ApiKeyEntity, newExpiryTimestamp: Long) {
        viewModelScope.launch {
            repository.setApiKeyCustomExpiry(key, newExpiryTimestamp)
        }
    }

    fun rotateApiKey(key: ApiKeyEntity) {
        viewModelScope.launch {
            repository.rotateApiKey(key)
        }
    }

    fun updateApiKeyStatus(key: ApiKeyEntity, newStatus: String) {
        viewModelScope.launch {
            repository.updateApiKeyStatus(key, newStatus)
        }
    }

    fun deleteApiKey(key: ApiKeyEntity) {
        viewModelScope.launch {
            repository.deleteApiKey(key)
        }
    }

    fun saveOperationalApiKey(
        id: Long = 0,
        name: String,
        appName: String,
        description: String = "",
        apiKey: String,
        provider: String,
        endpoint: String,
        model: String,
        status: String = "Active",
        permissions: String = "chat,knowledge,mantra,scripture,puja,research,verify,status,calendar,festival",
        dailyLimit: Int = 5000,
        rateLimitPerMin: Int = 60,
        expiresAt: Long = 0,
        configJson: String = "{}"
    ) {
        viewModelScope.launch {
            val cleanKey = apiKey.trim()
            val masked = if (cleanKey.length > 8) {
                cleanKey.take(6) + "••••••••" + cleanKey.takeLast(4)
            } else {
                "••••••••"
            }
            val entity = ApiKeyEntity(
                id = id,
                name = name.trim(),
                appName = appName.trim(),
                description = description.trim(),
                apiKey = cleanKey,
                maskedKey = masked,
                provider = provider,
                endpoint = endpoint.trim(),
                model = model.trim(),
                status = status,
                permissions = permissions,
                dailyLimit = dailyLimit,
                rateLimitPerMin = rateLimitPerMin,
                expiresAt = expiresAt,
                configJson = configJson
            )
            repository.saveAndActivateApiKey(entity)
        }
    }

    fun toggleApiKeyStatus(apiKeyEntity: ApiKeyEntity) {
        viewModelScope.launch {
            val newStatus = if (apiKeyEntity.status == "Active") "Suspended" else "Active"
            repository.updateApiKeyStatus(apiKeyEntity, newStatus)
        }
    }

    // ==========================================
    // TEACH / COMMAND & DEVELOPMENT PIPELINE
    // ==========================================

    fun updateAdminCommandInstruction(text: String) {
        _adminCommandState.update { it.copy(instruction = text, errorMessage = null) }
    }

    fun setAdminCommandAttachedImage(uri: String?) {
        _adminCommandState.update { it.copy(attachedImageUri = uri, attachedMediaType = if (uri != null) "IMAGE" else null) }
    }

    fun setAdminCommandAttachedMedia(uri: String?, mediaType: String? = "IMAGE") {
        _adminCommandState.update { it.copy(attachedImageUri = uri, attachedMediaType = mediaType) }
    }

    fun sendAdminCommandMessage(customPrompt: String? = null) {
        val prompt = customPrompt?.trim() ?: _adminCommandState.value.instruction.trim()
        val mediaUri = _adminCommandState.value.attachedImageUri
        val mediaType = _adminCommandState.value.attachedMediaType

        if (prompt.isBlank() && mediaUri == null) {
            _adminCommandState.update { it.copy(errorMessage = "কমান্ডের নির্দেশনা বা কোনো মিডিয়া প্রদান করুন।") }
            return
        }

        viewModelScope.launch {
            // Rule 10: Duplicate Command Suppression
            val activePending = database.developmentTaskDao().getActivePendingTasks()
            val duplicateTask = activePending.firstOrNull {
                it.instruction.equals(prompt, ignoreCase = true) ||
                (prompt.isNotBlank() && it.title.contains(prompt.take(20), ignoreCase = true))
            }

            if (duplicateTask != null) {
                val warnMsg = AdminChatMessage(
                    sender = "AI",
                    message = "⚠️ একই নির্দেশনার একটি টাস্ক ইতিমধ্যেই অপেক্ষমাণ রয়েছে (${duplicateTask.taskCode})। ডুপ্লিকেট টাস্ক তৈরি এড়ানো হয়েছে।"
                )
                _adminCommandState.update {
                    it.copy(
                        instruction = "",
                        errorMessage = "ডুপ্লিকেট কমান্ড শনাক্ত হয়েছে (${duplicateTask.taskCode})।",
                        chatHistory = it.chatHistory + warnMsg
                    )
                }
                return@launch
            }

            val adminMsg = AdminChatMessage(
                sender = "ADMIN",
                message = prompt.ifBlank { if (mediaType == "VIDEO") "Attached Video for Analysis" else "Attached Screenshot/Image for Analysis" },
                attachedImageUri = mediaUri,
                mediaType = mediaType
            )

            _adminCommandState.update {
                it.copy(
                    instruction = "",
                    attachedImageUri = null,
                    attachedMediaType = null,
                    isProcessing = true,
                    errorMessage = null,
                    chatHistory = it.chatHistory + adminMsg
                )
            }

            try {
                // Step 1: Understand & Analyze command against current architecture
                val plan = adminCommandEngine.analyzeCommand(
                    instruction = prompt.ifBlank { "Attached Media Analysis & Fix" },
                    attachedMediaUri = mediaUri
                )

                val taskNum = System.currentTimeMillis() % 10000
                val dateStr = java.text.SimpleDateFormat("yyyyMMdd", java.util.Locale.US).format(java.util.Date())
                val timeStr = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date())
                val taskCode = "TASK-$dateStr-$taskNum"

                val initialStatus = if (plan.requiresApproval) "WAITING_FOR_APPROVAL" else "ANALYZING"
                val initialStep = if (plan.requiresApproval) "Waiting for Admin Approval" else "Analyzing"

                val initialLogs = "$timeStr — [UNDERSTAND] Parsed admin command: '${prompt.ifBlank { "Media Analysis" }}'.\n" +
                        "$timeStr — [ANALYZE] Target: ${plan.targetLocation}.\n" +
                        "$timeStr — [PROPOSE] Action: ${plan.title} (Impact: ${plan.impactAssessment}).\n" +
                        "$timeStr — [TEST PLAN] ${plan.testVerificationPlan}"

                val taskEntity = DevelopmentTaskEntity(
                    taskCode = taskCode,
                    title = plan.title,
                    instruction = prompt.ifBlank { "Visual & System Diagnostic Fix" },
                    category = plan.category,
                    targetLocation = plan.targetLocation,
                    requiredComponents = plan.requiredComponents,
                    proposedChanges = plan.proposedChanges,
                    attachedImageUri = mediaUri,
                    status = initialStatus,
                    currentStep = initialStep,
                    impactAssessment = plan.impactAssessment,
                    executionLogs = initialLogs,
                    createdAt = System.currentTimeMillis()
                )

                val taskId = database.developmentTaskDao().insertTask(taskEntity)
                val createdTask = taskEntity.copy(id = taskId)

                repository.adminAuthManager.recordAudit(
                    action = "TASK_CREATED",
                    targetType = "DEVELOPMENT_TASK",
                    targetId = taskCode,
                    details = "Command created: '${plan.title}' on ${plan.targetLocation}."
                )

                if (plan.requiresApproval) {
                    repository.adminAuthManager.recordAudit(
                        action = "APPROVAL_REQUESTED",
                        targetType = "DEVELOPMENT_TASK",
                        targetId = taskCode,
                        details = "AI proposal waiting for Admin approval before execution."
                    )

                    val aiReplyText = "আর্কিটেকচার বিশ্লেষণ সম্পন্ন হয়েছে এবং টাস্ক **${createdTask.taskCode}** তৈরি করা হয়েছে:\n" +
                            "• **ক্যাটাগরি**: ${plan.category}\n" +
                            "• **টার্গেট**: ${plan.targetLocation}\n" +
                            "• **প্রস্তাবিত অ্যাকশন**: ${plan.title}\n" +
                            "• **টেস্ট ভেরিফিকেশন**: ${plan.testVerificationPlan}\n" +
                            "• **সুরক্ষা মূল্যায়ন**: ${plan.impactAssessment}\n\n" +
                            "⚠️ এটি প্রয়োগ করতে নিচের কার্ডে **'Approve & Execute'** বাটনে ক্লিক করুন।"

                    val aiMsg = AdminChatMessage(
                        sender = "AI",
                        message = aiReplyText,
                        task = createdTask
                    )

                    _adminCommandState.update {
                        it.copy(
                            isProcessing = false,
                            lastGeneratedTask = createdTask,
                            successMessage = "টাস্ক ${createdTask.taskCode} অনুমোদনের জন্য অপেক্ষমাণ।",
                            chatHistory = it.chatHistory + aiMsg
                        )
                    }
                } else {
                    // Safe command -> Execute real operation immediately
                    val currentUser = repository.adminAuthManager.currentSession.value.currentUser
                    val execResult = adminCommandEngine.executeTask(
                        task = createdTask,
                        featureHealthAuditor = featureHealthAuditor,
                        adminUsername = currentUser.username,
                        adminRole = currentUser.role
                    )
                    runFeatureHealthAudit()

                    val aiReplyText = if (execResult.isSuccess) {
                        "✅ অপারেশন সফলভাবে বাস্তবায়িত ও ভেরিফাই করা হয়েছে!\n" +
                                "• **টাস্ক কোড**: ${execResult.updatedTask.taskCode}\n" +
                                "• **টার্গেট**: ${execResult.updatedTask.targetLocation}\n" +
                                "• **বিবরণ**: ${execResult.details}\n" +
                                "• **টেস্ট রেজাল্ট**: 100% Passed (${execResult.testResultDetails})\n" +
                                "• **স্ট্যাটাস**: Active & Verified"
                    } else {
                        "❌ অপারেশন এক্সিকিউশনে ত্রুটি হয়েছে!\n" +
                                "• **টাস্ক কোড**: ${execResult.updatedTask.taskCode}\n" +
                                "• **ত্রুটির বিবরণ**: ${execResult.details}\n" +
                                "• **স্ট্যাটাস**: FAILED"
                    }

                    val aiMsg = AdminChatMessage(
                        sender = "AI",
                        message = aiReplyText,
                        task = execResult.updatedTask
                    )

                    _adminCommandState.update {
                        it.copy(
                            isProcessing = false,
                            lastGeneratedTask = execResult.updatedTask,
                            successMessage = if (execResult.isSuccess) execResult.executionSummary else null,
                            errorMessage = if (!execResult.isSuccess) execResult.details else null,
                            chatHistory = it.chatHistory + aiMsg
                        )
                    }
                }
            } catch (e: Exception) {
                val errorMsg = AdminChatMessage(
                    sender = "AI",
                    message = "কমান্ড প্রসেসিংয়ে ত্রুটি ঘটেছে: ${e.message}"
                )
                _adminCommandState.update {
                    it.copy(
                        isProcessing = false,
                        errorMessage = "ত্রুটি: ${e.message}",
                        chatHistory = it.chatHistory + errorMsg
                    )
                }
            }
        }
    }

    fun submitAdminCommand() {
        sendAdminCommandMessage()
    }

    fun approveDevelopmentTask(task: DevelopmentTaskEntity) {
        viewModelScope.launch {
            val currentUser = repository.adminAuthManager.currentSession.value.currentUser
            repository.adminAuthManager.recordAudit(
                action = "TASK_APPROVED",
                targetType = "DEVELOPMENT_TASK",
                targetId = task.taskCode,
                details = "Admin '${currentUser.username}' (${currentUser.role}) approved execution for task '${task.title}'."
            )

            val execResult = adminCommandEngine.executeTask(
                task = task,
                featureHealthAuditor = featureHealthAuditor,
                adminUsername = currentUser.username,
                adminRole = currentUser.role
            )
            runFeatureHealthAudit()

            val updateMsg = if (execResult.isSuccess) {
                AdminChatMessage(
                    sender = "AI",
                    message = "✅ টাস্ক **${task.taskCode}** (${task.title}) আপনার অনুমোদনের পর বাস্তবায়িত ও ভেরিফাই করা হয়েছে।\n" +
                            "• **বিবরণ**: ${execResult.details}\n" +
                            "• **টেস্ট স্ট্যাটাস**: ${execResult.testResultDetails} (100% Passed)\n" +
                            "• **অডিট লগ**: Immutable Audit Trail Saved",
                    task = execResult.updatedTask
                )
            } else {
                AdminChatMessage(
                    sender = "AI",
                    message = "❌ টাস্ক **${task.taskCode}** বাস্তবায়নে ব্যর্থ হয়েছে!\n" +
                            "• **ত্রুটির কারণ**: ${execResult.details}\n" +
                            "• **টেস্ট রেজাল্ট**: FAILED\n" +
                            "• **স্ট্যাটাস**: FAILED",
                    task = execResult.updatedTask
                )
            }

            _adminCommandState.update {
                it.copy(
                    successMessage = if (execResult.isSuccess) "টাস্ক '${task.title}' সফলভাবে এক্সিকিউট ও ভেরিফাই করা হয়েছে!" else null,
                    errorMessage = if (!execResult.isSuccess) "টাস্ক এক্সিকিউশন ব্যর্থ: ${execResult.details}" else null,
                    chatHistory = it.chatHistory + updateMsg,
                    lastGeneratedTask = execResult.updatedTask
                )
            }
        }
    }

    fun rejectDevelopmentTask(task: DevelopmentTaskEntity) {
        viewModelScope.launch {
            val currentUser = repository.adminAuthManager.currentSession.value.currentUser
            val now = System.currentTimeMillis()
            val timeStr = java.text.SimpleDateFormat("HH:mm:ss", java.util.Locale.US).format(java.util.Date(now))
            val rejectedTask = task.copy(
                status = "REJECTED",
                currentStep = "Rejected by Admin",
                completedAt = now,
                executionLogs = task.executionLogs + "\n$timeStr — [REJECTED] Admin '${currentUser.username}' declined proposal. No changes applied to database, configuration, or code."
            )
            database.developmentTaskDao().updateTask(rejectedTask)

            val auditText = "Command: '${task.instruction}' | Decision: REJECTED | Time: $timeStr | " +
                    "Affected: ${task.targetLocation} | Result: NO_CHANGE_APPLIED"

            database.auditLogDao().insertAuditLog(
                AuditLogEntity(
                    adminUsername = currentUser.username,
                    adminRole = currentUser.role,
                    action = "TASK_REJECTED",
                    targetType = task.category,
                    targetId = task.taskCode,
                    details = auditText
                )
            )

            val rejectMsg = AdminChatMessage(
                sender = "AI",
                message = "❌ টাস্ক **${task.taskCode}** অ্যাডমিন কর্তৃক বাতিল করা হয়েছে। কোনো সিস্টেমে পরিবর্তন প্রয়োগ করা হয়নি।",
                task = rejectedTask
            )
            _adminCommandState.update {
                it.copy(
                    successMessage = "টাস্ক '${task.title}' বাতিল করা হয়েছে। কোনো পরিবর্তন করা হয়নি।",
                    chatHistory = it.chatHistory + rejectMsg,
                    lastGeneratedTask = rejectedTask
                )
            }
        }
    }

    fun resolveProblemIssue(issue: IssueEntity) {
        viewModelScope.launch {
            repository.updateIssue(issue.copy(status = "Fixed", resolution = "Resolved by Admin via Project Monitor & verified healthy."))
            repository.adminAuthManager.recordAudit(
                action = "ISSUE_RESOLVED",
                targetType = "ISSUE",
                targetId = issue.issueCode,
                details = "Admin marked issue '${issue.title}' as Fixed and verified in production."
            )
        }
    }

    fun dismissAdminCommandSuccess() {
        _adminCommandState.update { it.copy(successMessage = null, lastGeneratedTask = null) }
    }

    fun dismissAdminCommandError() {
        _adminCommandState.update { it.copy(errorMessage = null) }
    }

    // External Client Testing Actions
    fun setExternalBaseUrl(url: String) {
        _externalClientState.update { it.copy(baseUrl = url) }
    }

    fun setExternalApiKey(key: String) {
        _externalClientState.update { it.copy(apiKey = key) }
    }

    fun setExternalActiveTab(tab: Int) {
        _externalClientState.update { it.copy(activeTab = tab) }
    }

    fun setExternalPlaygroundEndpoint(endpoint: String) {
        val templateBody = when (endpoint) {
            "/api/v1/chat" -> "{\n  \"query\": \"শ্রীমদ্ভগবদ্গীতার মূল বার্তা কী?\"\n}"
            "/api/v1/image/generate" -> "{\n  \"prompt\": \"শ্রীকৃষ্ণের একটি দিব্য রূপ\",\n  \"aspect_ratio\": \"1:1\",\n  \"quality\": \"STANDARD\",\n  \"dharma_enhanced\": true\n}"
            "/api/v1/image/understand" -> "{\n  \"image_file_path\": \"/data/user/0/com.example/files/sacred_images/krishna.jpg\",\n  \"question\": \"এই ছবির আধ্যাত্মিক তাৎপর্য কী?\"\n}"
            "/api/v1/voice" -> "{\n  \"text\": \"নমস্কার! Dharma AI Voice Assistant\",\n  \"query\": \"নমস্কার\"\n}"
            "/api/v1/research" -> "{\n  \"query\": \"Comparative analysis of Karma Yoga and Jnana Yoga\"\n}"
            "/api/v1/knowledge/search" -> "{\n  \"query\": \"Gayatri Mantra\"\n}"
            "/api/v1/mantra/search" -> "{\n  \"query\": \"Mahamrityunjaya\"\n}"
            "/api/v1/scripture/search" -> "{\n  \"query\": \"Isha Upanishad\"\n}"
            "/api/v1/verify" -> "{\n  \"query\": \"যদা যদা হি ধর্মস্য গ্লানির্ভবতি ভারত\"\n}"
            "/api/v1/status" -> ""
            else -> "{\n  \"query\": \"Sanatan Dharma\"\n}"
        }
        val method = if (endpoint.contains("/status")) "GET" else "POST"
        _externalClientState.update {
            it.copy(
                playgroundEndpoint = endpoint,
                playgroundMethod = method,
                playgroundBody = templateBody
            )
        }
    }

    fun setExternalPlaygroundBody(body: String) {
        _externalClientState.update { it.copy(playgroundBody = body) }
    }

    fun executeExternalPlaygroundRequest() {
        val state = _externalClientState.value
        viewModelScope.launch {
            _externalClientState.update { it.copy(isPlaygroundLoading = true) }
            val response = repository.remoteHttpClient.executeRemoteRequest(
                baseUrl = state.baseUrl,
                endpoint = state.playgroundEndpoint,
                method = state.playgroundMethod,
                apiKey = state.apiKey,
                body = state.playgroundBody
            )
            _externalClientState.update {
                it.copy(
                    isPlaygroundLoading = false,
                    playgroundResponse = response
                )
            }
        }
    }

    fun runExternalFullTestSuite() {
        val state = _externalClientState.value
        if (state.isRunningSuite) return

        viewModelScope.launch {
            _externalClientState.update {
                it.copy(isRunningSuite = true, suiteProgress = 0.05f, testResults = emptyList())
            }

            val testCases = listOf(
                Triple("1. API Key Creation & Handshake", "/api/v1/status", "GET" to ""),
                Triple("2. API Key Expiry Validation", "/api/v1/status", "GET" to ""),
                Triple("3. API Key Suspension Check", "/api/v1/chat", "POST" to "{\"query\": \"Dharma\"}"),
                Triple("4. API Key Revocation Enforcement", "/api/v1/chat", "POST" to "{\"query\": \"Dharma\"}"),
                Triple("5. Granular Scope Enforcer (/api/v1/research)", "/api/v1/research", "POST" to "{\"query\": \"Veda\"}"),
                Triple("6. Rate Limiting Enforcer (HTTP 429)", "/api/v1/chat", "POST" to "{\"query\": \"Speed test\"}"),
                Triple("7. Emergency Kill Switch Verification", "/api/v1/status", "GET" to ""),
                Triple("8. Central Request Logging & Auditing", "/api/v1/status", "GET" to ""),
                Triple("9. Application Data Isolation (App A vs App B)", "/api/v1/chat", "POST" to "{\"query\": \"Application isolation check\"}"),
                Triple("10. Shiva Inquiry ('শিব কে?')", "/api/v1/chat", "POST" to "{\"query\": \"শিব কে?\"}"),
                Triple("11. Shiva Mantra ('তাঁর একটি মন্ত্র বলো')", "/api/v1/chat", "POST" to "{\"query\": \"তাঁর একটি মন্ত্র বলো\"}"),
                Triple("12. Context Follow-up ('মন্ত্রটার অর্থ কী?')", "/api/v1/chat", "POST" to "{\"query\": \"মন্ত্রটার অর্থ কী?\"}"),
                Triple("13. Source Reference ('এটা কোথায় পাওয়া যায়?')", "/api/v1/chat", "POST" to "{\"query\": \"এটা কোথায় পাওয়া যায়?\"}"),
                Triple("14. Continued Context ('আরেকটা দাও')", "/api/v1/chat", "POST" to "{\"query\": \"আরেকটা দাও\"}"),
                Triple("15. Daily Dharma Tithi Data ('আজ কী তিথি?')", "/api/v1/chat", "POST" to "{\"query\": \"আজ কী তিথি?\"}"),
                Triple("16. Knowledge Search (/api/v1/knowledge/search)", "/api/v1/knowledge/search", "POST" to "{\"query\": \"Gayatri Mantra\"}"),
                Triple("17. Mantra Search (/api/v1/mantra/search)", "/api/v1/mantra/search", "POST" to "{\"query\": \"Mahamrityunjaya\"}"),
                Triple("18. Scripture Verse Search (/api/v1/scripture/search)", "/api/v1/scripture/search", "POST" to "{\"query\": \"Isha Upanishad\"}"),
                Triple("19. Scriptural Fact Verification (/api/v1/verify)", "/api/v1/verify", "POST" to "{\"query\": \"যদা যদা হি ধর্মস্য গ্লানির্ভবতি ভারত\"}"),
                Triple("20. Like/Dislike Feedback Pipeline", "/api/v1/chat", "POST" to "{\"query\": \"শ্রীমদ্ভগবদ্গীতা\"}"),
                Triple("21. Devotee Report System", "/api/v1/chat", "POST" to "{\"query\": \"Report Pipeline Verification\"}"),
                Triple("22. Admin Issue Center Resolution Handshake", "/api/v1/status", "GET" to ""),
                Triple("23. Human-like Conversational Guardrail", "/api/v1/chat", "POST" to "{\"query\": \"অদ্বৈত বেদান্ত বনাম দ্বৈত বেদান্ত\"}"),
                Triple("24. Audio Waveform & Visualizer State", "/api/v1/status", "GET" to ""),
                Triple("25. Live Voice Call Overlay Engine", "/api/v1/status", "GET" to ""),
                Triple("26. Voice Error & Safety Recovery Guard", "/api/v1/status", "GET" to ""),
                Triple("27. High-Concurrency Stress Test", "/api/v1/chat", "POST" to "{\"query\": \"Stress test payload\"}"),
                Triple("28. Overall System Integrity Verification", "/api/v1/status", "GET" to "")
            )

            val accumulatedResults = mutableListOf<com.example.domain.api.RemoteTestResult>()

            testCases.forEachIndexed { index, (testName, endpoint, methodAndBody) ->
                val (method, body) = methodAndBody
                val testApiKey = when (index) {
                    2 -> "vn_live_suspended_revoked_key_9999"
                    3 -> "vn_live_invalid_bad_key_0000"
                    else -> state.apiKey
                }

                val startTime = System.currentTimeMillis()
                val response = repository.remoteHttpClient.executeRemoteRequest(
                    baseUrl = state.baseUrl,
                    endpoint = endpoint,
                    method = method,
                    apiKey = testApiKey,
                    body = body
                )
                val latency = System.currentTimeMillis() - startTime

                val isSuccess = when (index) {
                    2, 3 -> response.statusCode in listOf(401, 403) // Expected auth failure
                    else -> response.statusCode in 200..299
                }

                val result = com.example.domain.api.RemoteTestResult(
                    testName = testName,
                    endpoint = endpoint,
                    method = method,
                    httpStatusCode = response.statusCode,
                    latencyMs = latency,
                    isSuccess = isSuccess,
                    responseBody = response.jsonBody,
                    requestId = response.requestId,
                    errorDescription = if (!isSuccess) response.statusText else null
                )

                accumulatedResults.add(result)
                val progress = (index + 1).toFloat() / testCases.size.toFloat()
                _externalClientState.update {
                    it.copy(
                        suiteProgress = progress,
                        testResults = accumulatedResults.toList()
                    )
                }
                kotlinx.coroutines.delay(100)
            }

            _externalClientState.update {
                it.copy(isRunningSuite = false, suiteProgress = 1f)
            }
        }
    }

    // Knowledge Actions
    private val _teachAiState = MutableStateFlow(TeachAiState())
    val teachAiState: StateFlow<TeachAiState> = _teachAiState.asStateFlow()

    fun setTeachTab(tab: Int) {
        _teachAiState.update { it.copy(activeTeachTab = tab, successMessage = null, errorMessage = null) }
    }

    fun updateTeachField(
        title: String? = null,
        question: String? = null,
        answer: String? = null,
        category: String? = null,
        source: String? = null,
        reference: String? = null,
        sanskrit: String? = null,
        transliteration: String? = null,
        explanation: String? = null,
        saveAsCandidate: Boolean? = null
    ) {
        _teachAiState.update { current ->
            current.copy(
                title = title ?: current.title,
                question = question ?: current.question,
                answer = answer ?: current.answer,
                category = category ?: current.category,
                source = source ?: current.source,
                reference = reference ?: current.reference,
                sanskritText = sanskrit ?: current.sanskritText,
                transliteration = transliteration ?: current.transliteration,
                explanation = explanation ?: current.explanation,
                saveAsCandidate = saveAsCandidate ?: current.saveAsCandidate,
                conflictResult = null,
                errorMessage = null
            )
        }
    }

    fun prefillTeachFromUnknown(item: UnknownKnowledgeEntity) {
        _teachAiState.update {
            it.copy(
                selectedUnknownId = item.id,
                title = item.userQuestion.take(60),
                question = item.userQuestion,
                answer = "",
                category = item.suggestedCategory.ifBlank { "GENERAL_DHARMA" },
                source = "Admin Verified Teaching",
                reference = "Veda / Gita / Agama Canonicals",
                activeTeachTab = 0,
                successMessage = "Pre-filled question from Unknown Queue (#${item.id})",
                errorMessage = null
            )
        }
    }

    fun clearTeachForm() {
        _teachAiState.update {
            TeachAiState(activeTeachTab = it.activeTeachTab)
        }
    }

    fun checkConflictAndTeachKnowledge(overrideConflict: Boolean = false) {
        val state = _teachAiState.value
        val cleanQ = state.question.trim()
        val cleanAns = state.answer.trim()
        val cleanTitle = state.title.ifBlank { cleanQ.take(60) }

        if (cleanQ.isBlank() && cleanTitle.isBlank()) {
            _teachAiState.update { it.copy(errorMessage = "প্রশ্ন বা শিরোনাম প্রদান করা বাধ্যতামূলক।") }
            return
        }
        if (cleanAns.isBlank()) {
            _teachAiState.update { it.copy(errorMessage = "উত্তর (Answer) প্রদান করা বাধ্যতামূলক।") }
            return
        }

        viewModelScope.launch {
            _teachAiState.update { it.copy(isSaving = true, errorMessage = null) }
            
            // Check Conflict
            if (!overrideConflict) {
                val published = allKnowledge.value
                val conflict = com.example.domain.ai.KnowledgeMatchingEngine.detectConflict(
                    newTitle = cleanTitle,
                    newQuestion = cleanQ,
                    newAnswer = cleanAns,
                    newCategory = state.category,
                    existingList = published
                )
                if (conflict.hasConflict) {
                    _teachAiState.update { it.copy(isSaving = false, conflictResult = conflict) }
                    return@launch
                }
            }

            try {
                if (state.selectedUnknownId != null) {
                    repository.teachFromUnknownQuery(
                        unknownId = state.selectedUnknownId,
                        question = cleanQ,
                        answer = cleanAns,
                        category = state.category,
                        source = state.source,
                        reference = state.reference,
                        saveAsCandidate = state.saveAsCandidate
                    )
                } else {
                    val code = "KB-" + (1000..9999).random()
                    val status = if (state.saveAsCandidate) "CANDIDATE" else "PUBLISHED"
                    val item = KnowledgeEntity(
                        knowledgeCode = code,
                        title = cleanTitle,
                        question = cleanQ,
                        answer = cleanAns,
                        category = state.category,
                        language = "BENGALI",
                        sanskritText = state.sanskritText,
                        transliteration = state.transliteration,
                        banglaMeaning = cleanAns,
                        explanation = state.explanation,
                        source = state.source,
                        reference = state.reference,
                        verificationStatus = status,
                        confidenceScore = 1.0f,
                        version = 1,
                        createdBy = "Admin Knowledge Teacher",
                        updatedBy = "Admin"
                    )
                    val newId = repository.insertKnowledge(item)
                    repository.knowledgeVersionDao.insertVersion(
                        KnowledgeVersionEntity(
                            knowledgeId = newId,
                            versionNumber = 1,
                            title = item.title,
                            question = item.question,
                            answer = item.answer,
                            category = item.category,
                            source = item.source,
                            reference = item.reference,
                            changedBy = "Admin",
                            changeReason = "Taught directly by Admin",
                            diffSummary = "Initial authoritative publication v1."
                        )
                    )
                }

                _teachAiState.update {
                    TeachAiState(
                        activeTeachTab = it.activeTeachTab,
                        successMessage = if (state.saveAsCandidate) "জ্ঞানটি সফলভাবে Candidate হিসেবে সংরক্ষিত হয়েছে (অনুমোদনের জন্য অপেক্ষমাণ)।" else "জ্ঞানটি সফলভাবে যাচাইকৃত ও প্রকাশিত হয়েছে! AI এখন তাৎক্ষণিকভাবে এটি ব্যবহার করতে পারবে।"
                    )
                }
            } catch (e: Exception) {
                _teachAiState.update { it.copy(isSaving = false, errorMessage = "সংরক্ষণে ব্যর্থ: ${e.message}") }
            }
        }
    }

    fun approveCandidateKnowledge(item: KnowledgeEntity) {
        viewModelScope.launch {
            repository.publishCandidate(item)
            _teachAiState.update { it.copy(successMessage = "Candidate '${item.title}' সফলভাবে Approved & Published হয়েছে!") }
        }
    }

    fun rejectCandidateKnowledge(item: KnowledgeEntity, reason: String = "Rejected by Admin") {
        viewModelScope.launch {
            repository.rejectDraftKnowledge(item)
            _teachAiState.update { it.copy(successMessage = "Candidate '${item.title}' সফলভাবে Rejected হয়েছে।") }
        }
    }

    fun ignoreUnknownQuery(item: UnknownKnowledgeEntity) {
        viewModelScope.launch {
            repository.unknownKnowledgeDao.updateUnknown(item.copy(status = "IGNORED", resolvedAt = System.currentTimeMillis()))
        }
    }

    fun recordUsageFeedback(knowledgeId: Long, query: String, isHelpful: Boolean) {
        viewModelScope.launch {
            val score = if (isHelpful) 1 else -1
            if (isHelpful) {
                repository.knowledgeDao.incrementSuccess(knowledgeId)
            }
            repository.knowledgeUsageLogDao.insertUsageLog(
                KnowledgeUsageLogEntity(
                    knowledgeId = knowledgeId,
                    userQuery = query,
                    matchedStrategy = "USER_FEEDBACK",
                    feedbackScore = score,
                    confidence = 1.0f
                )
            )
        }
    }

    fun createKnowledge(item: KnowledgeEntity, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.insertKnowledge(item)
            onComplete()
        }
    }

    fun updateKnowledge(item: KnowledgeEntity, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.updateKnowledge(item)
            onComplete()
        }
    }

    fun deleteKnowledge(item: KnowledgeEntity) {
        viewModelScope.launch {
            repository.deleteKnowledge(item)
        }
    }

    fun approveDraftKnowledge(item: KnowledgeEntity, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.approveDraftKnowledge(item)
            onComplete()
        }
    }

    fun approveDraftCandidate(item: KnowledgeEntity, onComplete: () -> Unit = {}) = approveDraftKnowledge(item, onComplete)

    fun rejectDraftKnowledge(item: KnowledgeEntity, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.rejectDraftKnowledge(item)
            onComplete()
        }
    }

    fun rejectDraftCandidate(item: KnowledgeEntity, onComplete: () -> Unit = {}) = rejectDraftKnowledge(item, onComplete)

    // Emergency Kill-Switch Controls
    val emergencyControlsState = com.example.domain.api.EmergencyControlsManager.controlsState

    fun toggleEmergencyGlobalAi(paused: Boolean, reason: String? = null) {
        com.example.domain.api.EmergencyControlsManager.setGlobalAiPaused(paused, reason)
    }

    fun toggleEmergencyApi(paused: Boolean, reason: String? = null) {
        com.example.domain.api.EmergencyControlsManager.setApiPaused(paused, reason)
    }

    fun toggleEmergencyResearch(paused: Boolean) {
        com.example.domain.api.EmergencyControlsManager.setResearchPaused(paused)
    }

    fun resetAllEmergencyControls() {
        com.example.domain.api.EmergencyControlsManager.resetAllControls()
    }

    // Issues & Reports Actions
    fun updateIssueStatus(issue: IssueEntity, newStatus: String, resolutionNotes: String = "") {
        viewModelScope.launch {
            repository.updateIssue(issue.copy(status = newStatus, resolution = resolutionNotes.ifBlank { issue.resolution }))
        }
    }

    fun createIssue(issue: IssueEntity, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.insertIssue(issue)
            onComplete()
        }
    }

    fun updateReportStatus(report: ReportEntity, newStatus: String, notes: String = "") {
        viewModelScope.launch {
            repository.updateReport(report.copy(status = newStatus, resolutionNotes = notes.ifBlank { report.resolutionNotes }))
        }
    }

    // Backups & DB Actions
    fun createBackup(name: String, type: String, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.createBackup(name, type)
            onComplete()
        }
    }

    fun restoreSeedData(onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.restoreDefaultSeedData()
            onComplete()
        }
    }

    fun updateSetting(key: String, value: String) {
        viewModelScope.launch {
            repository.updateSetting(key, value)
        }
    }

    // Public App Actions
    fun setPublicChatQuery(q: String) {
        _publicChatQuery.value = q
    }

    fun selectClarificationOption(option: String) {
        _publicClarificationOptions.value = emptyList()
        _publicChatQuery.value = option
        sendPublicChatMessage()
    }

    // Phase 3 Intelligence States
    val knowledgeGaps: StateFlow<List<com.example.domain.ai.KnowledgeGapItem>> = MutableStateFlow(
        com.example.domain.ai.KnowledgeGapDetector.detectGaps(20, 15)
    ).asStateFlow()

    val questionLearningReport: StateFlow<com.example.domain.ai.QuestionLearningReport> = MutableStateFlow(
        com.example.domain.ai.QuestionAnalyticsEngine.generateReport()
    ).asStateFlow()

    fun toggleDeepDiagnosticMode() {
        _aiLabState.update { it.copy(deepDiagnosticMode = !it.deepDiagnosticMode) }
    }

    fun createResearchTaskFromGap(gap: com.example.domain.ai.KnowledgeGapItem, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.createResearchTaskFromGap(gap)
            onComplete()
        }
    }

    fun submitPublicFeedback(feedbackText: String, messageSnippet: String, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.submitUserFeedback(feedbackText, messageSnippet)
            onComplete()
        }
    }

    fun resetPublicChat() {
        repository.aiOrchestrator.resetContextState()
        _publicChatMessages.value = listOf(
            "AI" to "নমস্কার! আমি VedaNova AI। সনাতন হিন্দু ধর্ম, বেদ, উপনিষদ, শ্রীমদ্ভগবদ্গীতা, মন্ত্র, পূজা ও দর্শন সম্পর্কে আপনার কোনো প্রশ্ন থাকলে নির্দ্বিধায় জিজ্ঞাসা করুন।"
        )
        _publicClarificationOptions.value = emptyList()
        _lastPublicResponse.value = null
        _publicChatQuery.value = ""
    }

    fun sendPublicChatMessage(customQuery: String? = null, fromVoice: Boolean = false) {
        val q = customQuery?.trim() ?: _publicChatQuery.value.trim()
        if (q.isBlank()) return

        val currentHistory = _publicChatMessages.value
        _publicChatMessages.update { it + ("USER" to q) }
        _publicChatQuery.value = ""
        _publicClarificationOptions.value = emptyList()
        _publicIsLoading.value = true

        if (fromVoice || isVoiceCallActive.value) {
            liveVoiceManager.setAiThinking()
        }

        viewModelScope.launch {
            try {
                val result = repository.processAiConversationTurn(
                    query = q,
                    history = currentHistory
                )
                _lastPublicResponse.value = result
                _publicChatMessages.update { it + ("AI" to result.answer) }
                if (result.isClarificationPrompt && result.clarificationOptions.isNotEmpty()) {
                    _publicClarificationOptions.value = result.clarificationOptions
                }

                // Voice Playback if requested or in live call session
                if (fromVoice || isVoiceCallActive.value || liveVoiceSettings.value.autoSpeakResponse) {
                    liveVoiceManager.speak(result.answer)
                }

                // If intent is image generation, trigger real generation immediately
                if (result.isImageGenerationIntent) {
                    generateImageForPublicChat(result.imagePrompt ?: q)
                }
            } catch (e: Exception) {
                val errText = "নমস্কার। আপনার জিজ্ঞাসার উত্তর প্রস্তুত করতে সাময়িক বিঘ্ন ঘটেছে: ${e.message}। অনুগ্রহ করে পুনরায় জিজ্ঞাসা করুন।"
                _publicChatMessages.update { it + ("AI" to errText) }
                if (fromVoice || isVoiceCallActive.value) {
                    liveVoiceManager.speak(errText)
                }
            } finally {
                _publicIsLoading.value = false
            }
        }
    }

    // ============================================================
    // Step 6: AI Image Generation & Vision Studio Methods
    // ============================================================
    fun generateImageStudio(customPrompt: String? = null) {
        val p = customPrompt?.trim() ?: _imageStudioState.value.prompt.trim()
        if (p.isBlank()) return

        _imageStudioState.update { it.copy(isGenerating = true, toastMessage = null) }
        viewModelScope.launch {
            try {
                val req = ImageGenerationRequest(
                    prompt = p,
                    aspectRatio = _imageStudioState.value.aspectRatio,
                    quality = _imageStudioState.value.quality,
                    isDharmaEnhanced = _imageStudioState.value.isDharmaEnhanced,
                    requestedBy = "Admin Studio"
                )
                val res = repository.generateImage(req, getApplication())
                _imageStudioState.update {
                    it.copy(
                        isGenerating = false,
                        activeResult = res,
                        toastMessage = if (res.status == ImageGenerationStatus.SUCCESS) "চিত্র সফলভাবে তৈরি হয়েছে!" else res.errorMessage
                    )
                }
            } catch (e: Exception) {
                _imageStudioState.update {
                    it.copy(isGenerating = false, toastMessage = "Image generation error: ${e.message}")
                }
            }
        }
    }

    fun generateImageForPublicChat(prompt: String) {
        _imageStudioState.update { it.copy(isGenerating = true) }
        viewModelScope.launch {
            try {
                val req = ImageGenerationRequest(
                    prompt = prompt,
                    aspectRatio = ImageAspectRatio.SQUARE,
                    quality = ImageQuality.STANDARD,
                    isDharmaEnhanced = true,
                    requestedBy = "Public Dharma User"
                )
                val res = repository.generateImage(req, getApplication())
                _imageStudioState.update {
                    it.copy(isGenerating = false, activeResult = res)
                }
                if (res.status == ImageGenerationStatus.SUCCESS) {
                    _publicChatMessages.update {
                        it + ("AI_IMAGE" to (res.localFilePath ?: res.imageUri ?: ""))
                    }
                } else if (res.status == ImageGenerationStatus.NOT_CONFIGURED) {
                    _publicChatMessages.update {
                        it + ("AI" to "Image Generation service বর্তমানে configured নয়। অনুগ্রহ করে API Manager-এ সঠিক API Key প্রদান করুন।")
                    }
                } else {
                    _publicChatMessages.update {
                        it + ("AI" to "চিত্র তৈরিতে সমস্যা দেখা দিয়েছে: ${res.errorMessage ?: "অজ্ঞাত ত্রুটি"}")
                    }
                }
            } catch (e: Exception) {
                _imageStudioState.update { it.copy(isGenerating = false) }
                _publicChatMessages.update {
                    it + ("AI" to "চিত্র তৈরির প্রক্রিয়ায় ত্রুটি: ${e.message}")
                }
            }
        }
    }

    fun saveGeneratedImageToGallery(image: GeneratedImageEntity) {
        viewModelScope.launch {
            val success = repository.saveImageToGallery(image, getApplication())
            _imageStudioState.update {
                it.copy(toastMessage = if (success) "গ্যালারিতে সংরক্ষিত হয়েছে!" else "গ্যালারিতে সংরক্ষণ ব্যর্থ হয়েছে।")
            }
        }
    }

    fun deleteGeneratedImage(image: GeneratedImageEntity) {
        viewModelScope.launch {
            repository.deleteGeneratedImage(image)
            _imageStudioState.update {
                it.copy(
                    toastMessage = "চিত্র সফলভাবে মুছে ফেলা হয়েছে।",
                    selectedImage = if (it.selectedImage?.id == image.id) null else it.selectedImage
                )
            }
        }
    }

    fun understandImageWithVision(imageFilePath: String, question: String) {
        if (imageFilePath.isBlank()) return
        _imageStudioState.update { it.copy(isUnderstanding = true, visionResult = null) }
        viewModelScope.launch {
            try {
                val res = repository.understandImage(imageFilePath, question, getApplication())
                _imageStudioState.update {
                    it.copy(
                        isUnderstanding = false,
                        visionResult = res,
                        toastMessage = if (res.isSuccess) "চিত্র বিশ্লেষণ সম্পন্ন!" else res.errorMessage
                    )
                }
            } catch (e: Exception) {
                _imageStudioState.update {
                    it.copy(isUnderstanding = false, toastMessage = "Vision analysis error: ${e.message}")
                }
            }
        }
    }

    fun setImageStudioPrompt(p: String) {
        _imageStudioState.update { it.copy(prompt = p) }
    }

    fun setImageStudioAspectRatio(r: ImageAspectRatio) {
        _imageStudioState.update { it.copy(aspectRatio = r) }
    }

    fun setImageStudioQuality(q: ImageQuality) {
        _imageStudioState.update { it.copy(quality = q) }
    }

    fun setImageStudioDharmaEnhanced(e: Boolean) {
        _imageStudioState.update { it.copy(isDharmaEnhanced = e) }
    }

    fun setImageStudioTab(tab: Int) {
        _imageStudioState.update { it.copy(activeTab = tab) }
    }

    fun selectImageForStudio(image: GeneratedImageEntity?) {
        _imageStudioState.update { it.copy(selectedImage = image) }
    }

    fun clearImageStudioToast() {
        _imageStudioState.update { it.copy(toastMessage = null) }
    }

    fun setGlobalSearchQuery(q: String) {
        _globalSearchQuery.value = q
    }

    // Phase 4: External App Actions
    fun selectAppForDetail(app: ExternalAppEntity?) {
        _selectedAppForDetail.value = app
    }

    fun updateAppStatus(app: ExternalAppEntity, newStatus: String) {
        viewModelScope.launch {
            repository.updateAppStatus(app, newStatus)
            if (_selectedAppForDetail.value?.id == app.id) {
                _selectedAppForDetail.value = _selectedAppForDetail.value?.copy(status = newStatus)
            }
        }
    }

    fun updateAppScopesAndCapabilities(app: ExternalAppEntity, scopes: String, capabilities: String) {
        viewModelScope.launch {
            repository.updateAppScopesAndCapabilities(app, scopes, capabilities)
            if (_selectedAppForDetail.value?.id == app.id) {
                _selectedAppForDetail.value = _selectedAppForDetail.value?.copy(allowedScopes = scopes, activeCapabilities = capabilities)
            }
        }
    }

    fun updateAppRateLimit(app: ExternalAppEntity, rateLimitPerMin: Int, dailyQuota: Int) {
        viewModelScope.launch {
            repository.updateAppRateLimit(app, rateLimitPerMin, dailyQuota)
            if (_selectedAppForDetail.value?.id == app.id) {
                _selectedAppForDetail.value = _selectedAppForDetail.value?.copy(rateLimitPerMin = rateLimitPerMin, dailyQuota = dailyQuota)
            }
        }
    }

    fun rotateAppApiKey(app: ExternalAppEntity) {
        viewModelScope.launch {
            repository.rotateAppApiKey(app)
        }
    }

    fun registerExternalApp(
        appName: String,
        developerName: String,
        email: String,
        scopes: String,
        capabilities: String,
        rateLimit: Int,
        dailyQuota: Int,
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            repository.registerExternalApp(
                appName = appName,
                developerName = developerName,
                email = email,
                scopes = scopes,
                capabilities = capabilities,
                rateLimit = rateLimit,
                dailyQuota = dailyQuota
            )
            onSuccess()
        }
    }

    // Phase 4: Capability Proposals
    fun approveCapabilityProposal(proposal: CapabilityProposalEntity, notes: String = "Approved by Admin") {
        viewModelScope.launch {
            repository.approveCapabilityProposal(proposal, notes)
        }
    }

    fun rejectCapabilityProposal(proposal: CapabilityProposalEntity, notes: String = "Rejected by Admin") {
        viewModelScope.launch {
            repository.rejectCapabilityProposal(proposal, notes)
        }
    }

    fun disableCapabilityProposal(proposal: CapabilityProposalEntity) {
        viewModelScope.launch {
            repository.disableCapabilityProposal(proposal)
        }
    }

    // Phase 4: Daily Data Actions
    fun selectDailyRegion(region: com.example.domain.ai.CalendarRegion) {
        _selectedDailyRegion.value = region
        _dailyData.value = com.example.domain.ai.DailyDataEngine.resolveDailyData(region)
    }

    fun triggerDailyDataUpdateJob(region: com.example.domain.ai.CalendarRegion = _selectedDailyRegion.value) {
        viewModelScope.launch {
            _isDailyJobRunning.value = true
            _dailyJobMessage.value = "Executing astronomical & calendar reconciliation for ${region.displayName}..."
            try {
                val log = repository.runDailyUpdateJob(region)
                _dailyData.value = com.example.domain.ai.DailyDataEngine.resolveDailyData(region)
                _dailyJobMessage.value = "Successfully updated ${log.updatedRecords} dynamic records for ${region.displayName} in ${log.executionDurationMs}ms."
            } catch (e: Exception) {
                _dailyJobMessage.value = "Error executing daily job: ${e.message}"
            } finally {
                _isDailyJobRunning.value = false
            }
        }
    }

    // Phase 4: External App Sandbox / Simulator Actions
    fun setSimulatorApp(appId: String) {
        _simulatorAppId.value = appId
    }

    fun setSimulatorRegion(region: com.example.domain.ai.CalendarRegion) {
        _simulatorRegion.value = region
    }

    fun setSimulatorActiveTab(tab: Int) {
        _simulatorActiveTab.value = tab
    }

    fun setSimulatorChatQuery(q: String) {
        _simulatorChatQuery.value = q
    }

    fun sendSimulatorChatMessage() {
        val q = _simulatorChatQuery.value.trim()
        if (q.isBlank()) return

        val app = allExternalApps.value.find { it.appId == _simulatorAppId.value } ?: allExternalApps.value.firstOrNull()
        val apiKey = app?.apiKey ?: "vn_live_app_dharmaguide_a9102c"

        _simulatorChatMessages.update { it + ("USER" to q) }
        _simulatorChatQuery.value = ""
        _simulatorIsLoading.value = true

        viewModelScope.launch {
            try {
                val request = ApiGatewayRequest(
                    endpoint = "/api/v1/chat",
                    method = "POST",
                    apiKey = apiKey,
                    body = "{\n  \"query\": \"${q.replace("\"", "\\\"")}\"\n}"
                )
                val response = repository.executeGatewayRequest(request)
                _simulatorLastResponse.value = response
                
                // Extract answer from JSON response
                val answer = extractFieldFromJson(response.jsonBody, "answer") ?: response.jsonBody
                _simulatorChatMessages.update { it + ("AI" to answer) }
            } catch (e: Exception) {
                _simulatorChatMessages.update { it + ("SYSTEM" to "Error communicating with VedaNova API Gateway: ${e.message}") }
            } finally {
                _simulatorIsLoading.value = false
            }
        }
    }

    fun executeSimulatorRawRequest(endpoint: String, method: String = "GET", body: String = "") {
        val app = allExternalApps.value.find { it.appId == _simulatorAppId.value } ?: allExternalApps.value.firstOrNull()
        val apiKey = app?.apiKey ?: "vn_live_app_dharmaguide_a9102c"

        _simulatorIsLoading.value = true
        viewModelScope.launch {
            try {
                val request = ApiGatewayRequest(
                    endpoint = endpoint,
                    method = method,
                    apiKey = apiKey,
                    body = body
                )
                val response = repository.executeGatewayRequest(request)
                _simulatorLastResponse.value = response
            } catch (e: Exception) {
                // Ignore or capture
            } finally {
                _simulatorIsLoading.value = false
            }
        }
    }

    private fun extractFieldFromJson(json: String, field: String): String? {
        val regex = Regex("\"$field\"\\s*:\\s*\"([^\"]+)\"")
        val match = regex.find(json)
        return match?.groupValues?.get(1)?.replace("\\n", "\n")?.replace("\\\"", "\"")
    }

    // Phase 5.1 Voice Guide & Announcer Functions
    fun setVoiceGuideEnabled(enabled: Boolean) {
        voiceAnnouncementManager.setVoiceGuideEnabled(enabled)
    }

    fun setVoiceLanguage(lang: String) {
        voiceAnnouncementManager.setLanguage(lang)
    }

    fun setVoiceSpeed(speed: String) {
        voiceAnnouncementManager.setSpeechSpeed(speed)
    }

    fun setAnnouncementMode(mode: String) {
        voiceAnnouncementManager.setAnnouncementMode(mode)
    }

    fun announceButtonClick(buttonNameBn: String, buttonNameEn: String) {
        voiceAnnouncementManager.announceButtonClick(buttonNameBn, buttonNameEn)
    }

    fun announceSection(sectionNameBn: String, sectionNameEn: String) {
        voiceAnnouncementManager.announceSection(sectionNameBn, sectionNameEn)
    }

    fun testVoiceAnnouncement(textBn: String = "নমস্কার! VedaNova AI ভয়েস গাইড সফলভাবে কাজ করছে।", textEn: String = "Greetings! VedaNova AI Voice Guide is working successfully.") {
        voiceAnnouncementManager.speakCustom(textBn, textEn)
    }

    // Phase 5.1 Crash & Diagnostic Functions
    fun clearAllCrashReports() {
        viewModelScope.launch {
            repository.clearAllCrashReports()
        }
    }

    fun clearAllActivityLogs() {
        viewModelScope.launch {
            repository.clearAllActivityLogs()
        }
    }

    fun triggerDiagnosticCrashTest() {
        val testException = IllegalStateException("Simulated Diagnostic Exception: Verification of Crash Reporting Pipeline & Room DB persistence.")
        CrashReportingManager.recordException(
            screen = _currentScreen.value.name,
            route = _currentScreen.value.name,
            throwable = testException,
            action = "Admin initiated manual diagnostic test crash from Crash Diagnostic Center"
        )
    }

    // Phase 6 Web Research & Harvesting Functions
    fun setResearchTab(tab: Int) {
        _researchLabState.value = _researchLabState.value.copy(activeTab = tab)
    }

    fun updateResearchQuery(q: String) {
        _researchLabState.value = _researchLabState.value.copy(query = q)
    }

    fun toggleDiscoveryCategory(category: String) {
        val current = _researchLabState.value.discoveryCategories.toMutableSet()
        if (current.contains(category)) {
            if (current.size > 1) current.remove(category)
        } else {
            current.add(category)
        }
        _researchLabState.value = _researchLabState.value.copy(discoveryCategories = current)
    }

    fun executeResearchLabSearch(customQuery: String? = null) {
        val q = customQuery ?: _researchLabState.value.query
        if (q.isBlank()) return
        viewModelScope.launch {
            _researchLabState.value = _researchLabState.value.copy(isLoading = true)
            try {
                val web = repository.executeManualWebResearch(q)
                val yt = com.example.domain.research.YouTubeResearchProvider.performYouTubeResearch(q, web.queryId)
                val cross = com.example.domain.research.CrossSourceVerificationEngine.performCrossVerification(q, web.sources, yt.supportingEvidenceSources)
                _researchLabState.value = _researchLabState.value.copy(
                    isLoading = false,
                    webResult = web,
                    youtubeResult = yt,
                    crossVerificationReport = cross
                )
            } catch (e: Exception) {
                _researchLabState.value = _researchLabState.value.copy(isLoading = false)
            }
        }
    }

    fun executeMantraShieldVerification(customQuery: String? = null) {
        val q = customQuery ?: _researchLabState.value.query
        if (q.isBlank()) return
        viewModelScope.launch {
            _researchLabState.value = _researchLabState.value.copy(isLoading = true)
            try {
                val shield = repository.executeManualMantraVerification(q)
                _researchLabState.value = _researchLabState.value.copy(
                    isLoading = false,
                    mantraShieldResult = shield
                )
            } catch (e: Exception) {
                _researchLabState.value = _researchLabState.value.copy(isLoading = false)
            }
        }
    }

    fun runTopicDiscoveryScan() {
        val categories = _researchLabState.value.discoveryCategories.toList()
        viewModelScope.launch {
            _researchLabState.value = _researchLabState.value.copy(isScanningDiscovery = true)
            try {
                val results = repository.runTopicDiscoveryScan(categories)
                _researchLabState.value = _researchLabState.value.copy(
                    isScanningDiscovery = false,
                    discoveryResults = results
                )
            } catch (e: Exception) {
                _researchLabState.value = _researchLabState.value.copy(isScanningDiscovery = false)
            }
        }
    }

    fun approveResearchCandidate(candidateId: String) {
        viewModelScope.launch {
            repository.approveKnowledgeCandidate(candidateId, currentSession.value?.currentUser?.username ?: "Super Admin")
        }
    }

    fun rejectResearchCandidate(candidateId: String, reason: String = "Admin Scholarly Rejection") {
        viewModelScope.launch {
            repository.rejectKnowledgeCandidate(candidateId, reason, currentSession.value?.currentUser?.username ?: "Super Admin")
        }
    }

    fun resolveResearchIssue(reportId: String, status: String, notes: String = "Resolved by Admin") {
        viewModelScope.launch {
            repository.resolveResearchIssue(reportId, status, notes, currentSession.value?.currentUser?.username ?: "Super Admin")
        }
    }

    fun runFeatureHealthAudit() {
        viewModelScope.launch {
            _isAuditingHealth.value = true
            try {
                val isVoiceCallActive = liveVoiceManager.isCallOverlayActive.value
                val isSpeechReady = true
                val voiceErrorMsg = liveVoiceManager.voiceError.value
                val latestCrashCount = totalCrashCount.value
                val pendingReviewTaskCount = pendingApprovalTasksCount.value
                val pendingCandidatesCount = pendingCandidatesCount.value

                val results = featureHealthAuditor.auditAllFeatures(
                    isVoiceCallActive = isVoiceCallActive,
                    isSpeechReady = isSpeechReady,
                    voiceErrorMsg = voiceErrorMsg,
                    latestCrashCount = latestCrashCount,
                    pendingReviewTaskCount = pendingReviewTaskCount,
                    pendingCandidatesCount = pendingCandidatesCount
                )
                _featureHealthList.value = results
                _lastAuditTimestamp.value = java.text.SimpleDateFormat("yyyy-MM-dd HH:mm:ss", java.util.Locale.getDefault()).format(java.util.Date())

                // Update the system matrix health indicators dynamically based on real audit
                val isChatOk = results.any { it.id == "FH-01" && it.status == com.example.domain.health.RealHealthStatus.WORKING }
                val isDbOk = results.any { it.id == "FH-03" && it.status == com.example.domain.health.RealHealthStatus.WORKING }
                val isApiOk = results.any { it.id == "FH-04" && it.status == com.example.domain.health.RealHealthStatus.WORKING }
                val isKnowledgeOk = results.any { it.id == "FH-05" && it.status == com.example.domain.health.RealHealthStatus.WORKING }
                val isResearchOk = results.any { it.id == "FH-07" && (it.status == com.example.domain.health.RealHealthStatus.WORKING || it.status == com.example.domain.health.RealHealthStatus.NEEDS_REVIEW) }
                val isSecurityOk = results.any { it.id == "FH-10" && (it.status == com.example.domain.health.RealHealthStatus.WORKING || it.status == com.example.domain.health.RealHealthStatus.NEEDS_REVIEW) }

                _healthStatus.value = SystemHealthStatus(
                    backendStatus = if (isChatOk && isApiOk) "GREEN" else "RED",
                    databaseStatus = if (isDbOk) "GREEN" else "RED",
                    aiProviderStatus = if (isChatOk) "GREEN" else "YELLOW",
                    apiGatewayStatus = if (isApiOk) "GREEN" else "RED",
                    knowledgeEngineStatus = if (isKnowledgeOk) "GREEN" else "RED",
                    researchEngineStatus = if (isResearchOk) "GREEN" else "YELLOW",
                    verificationEngineStatus = "GREEN",
                    authStatus = "GREEN",
                    storageStatus = if (isDbOk) "GREEN" else "RED",
                    backupStatus = "GREEN"
                )
            } catch (e: Exception) {
                // If health audit encounters unexpected exception
            } finally {
                _isAuditingHealth.value = false
            }
        }
    }

    override fun onCleared() {
        super.onCleared()
        liveVoiceManager.release()
        voiceAnnouncementManager.destroy()
    }
}

