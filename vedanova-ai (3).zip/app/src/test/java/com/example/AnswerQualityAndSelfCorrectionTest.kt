package com.example

import com.example.domain.ai.*
import org.junit.Assert.*
import org.junit.Test

class AnswerQualityAndSelfCorrectionTest {

    // 1. Simple factual questions: Direct, concise answer without unnecessary essay
    @Test
    fun testSimpleFactualQuestion_ComplexityAndConciseness() {
        val intent = IntentAnalysisResult(
            primaryIntent = QuestionIntentType.GENERAL_KNOWLEDGE,
            subIntents = listOf("GEOGRAPHY"),
            detectedTopic = "Paris",
            isDharmaRelated = false,
            styleRequest = ResponseStyleRequest.BALANCED,
            creativeWritingType = CreativeWritingType.NONE,
            targetLanguage = "English",
            isFollowUp = false
        )

        val complexity = AnswerQualityEvaluator.determineComplexity(
            query = "What is the capital of France?",
            intent = intent,
            contextState = ConversationContextState()
        )
        assertEquals(QuestionComplexity.SIMPLE_FACTUAL, complexity)

        // Concise answer passes
        val conciseAnswer = "The capital of France is Paris."
        val eval = AnswerQualityEvaluator.evaluateDraft(
            query = "What is the capital of France?",
            draftAnswer = conciseAnswer,
            contextState = ConversationContextState(),
            intent = intent,
            hasCanonicalSource = true
        )
        assertTrue("Concise answer passes quality evaluation", eval.isPassed)
        assertEquals(0, eval.hallucinationRiskScore)
    }

    // 2. Complex reasoning questions: Requires structured, deep explanation
    @Test
    fun testComplexReasoningQuestion_RequiresDepth() {
        val intent = IntentAnalysisResult(
            primaryIntent = QuestionIntentType.PHILOSOPHY_AND_DARSHANA,
            subIntents = listOf("ADVAITA", "DVAITA"),
            detectedTopic = "Advaita vs Dvaita",
            isDharmaRelated = true,
            styleRequest = ResponseStyleRequest.SCHOLARLY,
            creativeWritingType = CreativeWritingType.NONE,
            targetLanguage = "English",
            isFollowUp = false
        )

        val complexity = AnswerQualityEvaluator.determineComplexity(
            query = "Compare Advaita and Dvaita on the concept of Brahman and Jiva.",
            intent = intent,
            contextState = ConversationContextState()
        )
        assertEquals(QuestionComplexity.COMPLEX_REASONING, complexity)

        // Overly short answer is flagged for insufficient completeness
        val shortStub = "They are different philosophies."
        val evalStub = AnswerQualityEvaluator.evaluateDraft(
            query = "Compare Advaita and Dvaita on the concept of Brahman and Jiva.",
            draftAnswer = shortStub,
            contextState = ConversationContextState(),
            intent = intent,
            hasCanonicalSource = true
        )
        assertTrue(evalStub.detectedIssues.any { it.type == QualityIssueType.INSUFFICIENT_COMPLETENESS })
    }

    // 3. Bengali conversations: Native phrasing & tone preserved
    @Test
    fun testBengaliConversation_RefinementAndNaturalness() {
        val intent = IntentAnalysisResult(
            primaryIntent = QuestionIntentType.DHARMA_DEFINITION,
            subIntents = listOf("KARMA_YOGA"),
            detectedTopic = "কর্মযোগ",
            isDharmaRelated = true,
            styleRequest = ResponseStyleRequest.BALANCED,
            creativeWritingType = CreativeWritingType.NONE,
            targetLanguage = "Bengali",
            isFollowUp = false
        )

        val draft = "কর্মযোগ হলো ফলের আশা ত্যাগ করে ঈশ্বরের উদ্দেশ্যে নিঃস্বার্থভাবে স্বধর্ম পালন করা।"
        val eval = AnswerQualityEvaluator.evaluateDraft(
            query = "কর্মযোগ কী?",
            draftAnswer = draft,
            contextState = ConversationContextState(),
            intent = intent,
            hasCanonicalSource = true
        )
        assertTrue(eval.isPassed)
        assertTrue(eval.naturalnessScore >= 90)
    }

    // 4. English conversations: Accurate evaluation
    @Test
    fun testEnglishConversation_CleanEvaluation() {
        val intent = IntentAnalysisResult(
            primaryIntent = QuestionIntentType.DHARMA_DEFINITION,
            subIntents = listOf("DHARMA"),
            detectedTopic = "Dharma",
            isDharmaRelated = true,
            styleRequest = ResponseStyleRequest.BALANCED,
            creativeWritingType = CreativeWritingType.NONE,
            targetLanguage = "English",
            isFollowUp = false
        )

        val draft = "Dharma signifies that which sustains the cosmic and moral order (Dhriyate anena iti dharmah), encompassing righteousness, duty, and spiritual harmony."
        val eval = AnswerQualityEvaluator.evaluateDraft(
            query = "What is Dharma?",
            draftAnswer = draft,
            contextState = ConversationContextState(),
            intent = intent,
            hasCanonicalSource = true
        )
        assertTrue(eval.isPassed)
        assertTrue(eval.relevanceScore >= 90)
    }

    // 5. Mixed-language conversations (Banglish / mixed queries)
    @Test
    fun testMixedLanguageConversation() {
        val intent = IntentAnalysisResult(
            primaryIntent = QuestionIntentType.DHARMA_DEFINITION,
            subIntents = listOf("GITA"),
            detectedTopic = "Gita",
            isDharmaRelated = true,
            styleRequest = ResponseStyleRequest.BALANCED,
            creativeWritingType = CreativeWritingType.NONE,
            targetLanguage = "Mixed",
            isFollowUp = false
        )

        val draft = "শ্রীমদ্ভগবদ্গীতা হলো মহাভারতের ভীষ্ম পর্বের অংশ, যেখানে Bhagavan Sri Krishna অর্জুনকে বিষাদ মুক্তির দিব্য দর্শন প্রদান করেছেন।"
        val eval = AnswerQualityEvaluator.evaluateDraft(
            query = "Gita er main message ki?",
            draftAnswer = draft,
            contextState = ConversationContextState(),
            intent = intent,
            hasCanonicalSource = true
        )
        assertTrue(eval.isPassed)
    }

    // 6. Multi-turn follow-ups: Contextual continuation
    @Test
    fun testMultiTurnFollowUp_NaturalFlow() {
        val state = ConversationContextState(
            threadTurnCount = 2,
            activeSubject = "Bhagavad Gita",
            activeTopic = "Bhagavad Gita"
        )
        val intent = IntentAnalysisResult(
            primaryIntent = QuestionIntentType.CANONICAL_SCRIPTURE,
            subIntents = listOf("SHLOKA"),
            detectedTopic = "Bhagavad Gita",
            isDharmaRelated = true,
            styleRequest = ResponseStyleRequest.BALANCED,
            creativeWritingType = CreativeWritingType.NONE,
            targetLanguage = "English",
            isFollowUp = true
        )

        val draft = "In Chapter 2, Verse 47 of the Bhagavad Gita, the principle of Nishkama Karma is revealed: 'Karmanye vadhikaraste ma phaleshu kadachana'."
        val eval = AnswerQualityEvaluator.evaluateDraft(
            query = "Give me a verse about duty from it.",
            draftAnswer = draft,
            contextState = state,
            intent = intent,
            hasCanonicalSource = true
        )
        assertTrue(eval.isPassed)
        assertTrue(eval.contextScore >= 95)
    }

    // 7. Topic switching & purge of old subject
    @Test
    fun testTopicSwitching_NoContextBleeding() {
        val state = ConversationContextState(
            threadTurnCount = 3,
            previousTopic = "Lord Shiva",
            activeSubject = "Photosynthesis",
            activeDomain = "SCIENCE"
        )
        val intent = IntentAnalysisResult(
            primaryIntent = QuestionIntentType.GENERAL_KNOWLEDGE,
            subIntents = listOf("SCIENCE"),
            detectedTopic = "Photosynthesis",
            isDharmaRelated = false,
            styleRequest = ResponseStyleRequest.BALANCED,
            creativeWritingType = CreativeWritingType.NONE,
            targetLanguage = "English",
            isFollowUp = false
        )

        // Accidental bleeding of Lord Shiva into photosynthesis is flagged
        val badDraft = "Photosynthesis is the process by which green plants convert light into chemical energy, by the grace of Lord Shiva."
        val eval = AnswerQualityEvaluator.evaluateDraft(
            query = "What is photosynthesis?",
            draftAnswer = badDraft,
            contextState = state,
            intent = intent,
            hasCanonicalSource = true
        )
        assertTrue(eval.detectedIssues.any { it.type == QualityIssueType.TOPIC_BLEEDING || it.type == QualityIssueType.FORCED_RELIGIOUS_IN_SECULAR })
    }

    // 8. Pronoun resolution verification
    @Test
    fun testPronounResolution_InContext() {
        val state = ConversationContextState(
            activeSubject = "Mahadeva Shiva",
            threadTurnCount = 1
        )
        val intent = IntentAnalysisResult(
            primaryIntent = QuestionIntentType.MANTRA_AND_STOTRA,
            subIntents = listOf("MANTRA"),
            detectedTopic = "Shiva Mantra",
            isDharmaRelated = true,
            styleRequest = ResponseStyleRequest.BALANCED,
            creativeWritingType = CreativeWritingType.NONE,
            targetLanguage = "English",
            isFollowUp = true
        )

        val resolvedAnswer = "The principal sacred mantra of Lord Shiva is the Panchakshari Mantra: 'Om Namah Shivaya'."
        val eval = AnswerQualityEvaluator.evaluateDraft(
            query = "What is his main mantra?",
            draftAnswer = resolvedAnswer,
            contextState = state,
            intent = intent,
            hasCanonicalSource = true
        )
        assertTrue("Understands pronoun refers to Shiva", eval.isPassed)
    }

    // 9. Repetitive answer detection & Self-Intro strip
    @Test
    fun testRepetitiveAnswerDetection_AndStripSelfIntro() {
        val state = ConversationContextState(threadTurnCount = 2)
        val intent = IntentAnalysisResult(
            primaryIntent = QuestionIntentType.DHARMA_DEFINITION,
            subIntents = listOf("AHIMSA"),
            detectedTopic = "Ahimsa",
            isDharmaRelated = true,
            styleRequest = ResponseStyleRequest.BALANCED,
            creativeWritingType = CreativeWritingType.NONE,
            targetLanguage = "English",
            isFollowUp = false
        )

        // Draft has repeated AI self-intro on turn 2
        val draftWithIntro = "I am Dharma AI, created by Sri Milon Chandra. Ahimsa is the practice of non-violence in thought, word, and deed."
        val eval = AnswerQualityEvaluator.evaluateDraft(
            query = "What is Ahimsa?",
            draftAnswer = draftWithIntro,
            contextState = state,
            intent = intent,
            hasCanonicalSource = true,
            history = listOf("Hi" to "Namaste!")
        )
        assertTrue(eval.detectedIssues.any { it.type == QualityIssueType.REPEATED_SELF_INTRODUCTION })

        // Self-correction strips the intro
        val result = SelfCorrectionEngine.processAndRefine(
            query = "What is Ahimsa?",
            draftAnswer = draftWithIntro,
            contextState = state,
            intent = intent,
            detectedLanguage = "English",
            hasCanonicalSource = true,
            history = listOf("Hi" to "Namaste!")
        )
        assertTrue("Was corrected", result.wasCorrected)
        assertFalse("Self intro removed", result.finalAnswer.startsWith("I am Dharma AI"))
        assertTrue("Contains core answer", result.finalAnswer.contains("Ahimsa is the practice of non-violence"))
    }

    // 10. Hallucination prevention: Invalid Gita chapter number
    @Test
    fun testHallucinationPrevention_InvalidGitaChapter() {
        val intent = IntentAnalysisResult(
            primaryIntent = QuestionIntentType.CANONICAL_SCRIPTURE,
            subIntents = listOf("GITA"),
            detectedTopic = "Gita",
            isDharmaRelated = true,
            styleRequest = ResponseStyleRequest.BALANCED,
            creativeWritingType = CreativeWritingType.NONE,
            targetLanguage = "English",
            isFollowUp = false
        )

        val hallucinatedDraft = "As stated in Gita 25.12, the supreme soul is eternal."
        val eval = AnswerQualityEvaluator.evaluateDraft(
            query = "What does the Gita say about the soul?",
            draftAnswer = hallucinatedDraft,
            contextState = ConversationContextState(),
            intent = intent,
            hasCanonicalSource = false
        )
        assertTrue(eval.detectedIssues.any { it.type == QualityIssueType.SCRIPTURE_MANTRA_FABRICATION })
        assertTrue("High hallucination risk flagged", eval.hallucinationRiskScore >= 80)
    }

    // 11. Scripture/Mantra safety: Fabricated mantra prevention
    @Test
    fun testScriptureMantraSafety_ReplacesFabrication() {
        val intent = IntentAnalysisResult(
            primaryIntent = QuestionIntentType.MANTRA_AND_STOTRA,
            subIntents = listOf("MANTRA"),
            detectedTopic = "Fake Mantra",
            isDharmaRelated = true,
            styleRequest = ResponseStyleRequest.BALANCED,
            creativeWritingType = CreativeWritingType.NONE,
            targetLanguage = "Bengali",
            isFollowUp = false
        )

        val fakeMantraDraft = "fake_mantra: ওং কাল্পনিকায় স্বাহা"
        val result = SelfCorrectionEngine.processAndRefine(
            query = "একটি নতুন মন্ত্র বানিয়ে দাও",
            draftAnswer = fakeMantraDraft,
            contextState = ConversationContextState(),
            intent = intent,
            detectedLanguage = "Bengali",
            hasCanonicalSource = false
        )
        assertTrue(result.wasCorrected)
        assertFalse("Does not output fake mantra", result.finalAnswer.contains("fake_mantra"))
        assertTrue("Enforces canonical mantra protection", result.finalAnswer.contains("প্রামাণিক") || result.finalAnswer.contains("শাস্ত্রীয়"))
    }

    // 12. Conflicting information detection
    @Test
    fun testConflictingInformationDetection() {
        val intent = IntentAnalysisResult(
            primaryIntent = QuestionIntentType.PHILOSOPHY_AND_DARSHANA,
            subIntents = listOf("BRAHMAN"),
            detectedTopic = "Brahman",
            isDharmaRelated = true,
            styleRequest = ResponseStyleRequest.BALANCED,
            creativeWritingType = CreativeWritingType.NONE,
            targetLanguage = "English",
            isFollowUp = false
        )

        val contradictoryDraft = "Brahman is always true in the physical realm and Brahman is never true in the physical realm."
        val eval = AnswerQualityEvaluator.evaluateDraft(
            query = "Is Brahman physical?",
            draftAnswer = contradictoryDraft,
            contextState = ConversationContextState(),
            intent = intent,
            hasCanonicalSource = false
        )
        assertTrue(eval.detectedIssues.any { it.type == QualityIssueType.CONTRADICTION_DETECTED })
    }

    // 13. Uncertain knowledge handling
    @Test
    fun testUncertainKnowledge_EpistemicHumility() {
        val intent = IntentAnalysisResult(
            primaryIntent = QuestionIntentType.UNKNOWN_GROUNDING,
            subIntents = listOf("OBSCURE"),
            detectedTopic = "Unknown",
            isDharmaRelated = true,
            styleRequest = ResponseStyleRequest.BALANCED,
            creativeWritingType = CreativeWritingType.NONE,
            targetLanguage = "English",
            isFollowUp = false
        )

        val result = SelfCorrectionEngine.processAndRefine(
            query = "What is the secret verse of obscure unknown sect?",
            draftAnswer = "There might be a secret verse in an obscure tradition.",
            contextState = ConversationContextState(),
            intent = intent,
            detectedLanguage = "English",
            hasCanonicalSource = false
        )
        assertTrue("States uncertainty clearly without guessing",
            result.finalAnswer.contains("I am not certain", ignoreCase = true) ||
            result.finalAnswer.contains("unverified", ignoreCase = true)
        )
    }

    // 14. Answer length control: simple math / definition vs essay
    @Test
    fun testAnswerLengthControl_SimpleMath() {
        val intent = IntentAnalysisResult(
            primaryIntent = QuestionIntentType.GENERAL_KNOWLEDGE,
            subIntents = listOf("MATH"),
            detectedTopic = "Arithmetic",
            isDharmaRelated = false,
            styleRequest = ResponseStyleRequest.BALANCED,
            creativeWritingType = CreativeWritingType.NONE,
            targetLanguage = "English",
            isFollowUp = false
        )

        val verboseMathDraft = "When we look at the cosmic numbers and multiply twenty-five by four, we enter an elaborate calculation.\n\n" +
                "In mathematics, multiplication is repeated addition. If you add 25 four times, you get 25 + 25 = 50, then 50 + 25 = 75, then 75 + 25 = 100.\n\n" +
                "Therefore, through this multi-step mathematical analysis across chapters of arithmetic, the definitive result is 100."

        val eval = AnswerQualityEvaluator.evaluateDraft(
            query = "25 * 4",
            draftAnswer = verboseMathDraft,
            contextState = ConversationContextState(),
            intent = intent,
            hasCanonicalSource = true
        )
        assertTrue(eval.detectedIssues.any { it.type == QualityIssueType.EXCESSIVE_VERBOSITY })

        // Self-correction condenses it
        val result = SelfCorrectionEngine.processAndRefine(
            query = "25 * 4",
            draftAnswer = verboseMathDraft,
            contextState = ConversationContextState(),
            intent = intent,
            detectedLanguage = "English",
            hasCanonicalSource = true
        )
        assertTrue(result.wasCorrected)
        assertTrue("Answer is condensed", result.finalAnswer.length < verboseMathDraft.length)
    }

    // 15. Self-correction: Echoing user prompt stripped
    @Test
    fun testSelfCorrection_StripsUserPromptEcho() {
        val intent = IntentAnalysisResult(
            primaryIntent = QuestionIntentType.DHARMA_DEFINITION,
            subIntents = listOf("SATYA"),
            detectedTopic = "Satya",
            isDharmaRelated = true,
            styleRequest = ResponseStyleRequest.BALANCED,
            creativeWritingType = CreativeWritingType.NONE,
            targetLanguage = "English",
            isFollowUp = false
        )

        val draftWithEcho = "You asked: What is Satya? Satya is the supreme virtue of truthfulness in thought, word, and deed."
        val result = SelfCorrectionEngine.processAndRefine(
            query = "What is Satya?",
            draftAnswer = draftWithEcho,
            contextState = ConversationContextState(),
            intent = intent,
            detectedLanguage = "English",
            hasCanonicalSource = true
        )
        assertTrue(result.wasCorrected)
        assertFalse("Prompt echo removed", result.finalAnswer.startsWith("You asked:"))
        assertTrue("Contains pure answer", result.finalAnswer.startsWith("Satya is the supreme virtue"))
    }

    // 16. Correction-loop termination: Strict max attempts, no infinite loops
    @Test
    fun testCorrectionLoopTermination_StrictMaxAttempts() {
        val intent = IntentAnalysisResult(
            primaryIntent = QuestionIntentType.UNKNOWN_GROUNDING,
            subIntents = listOf("UNKNOWN"),
            detectedTopic = "Unresolvable",
            isDharmaRelated = false,
            styleRequest = ResponseStyleRequest.BALANCED,
            creativeWritingType = CreativeWritingType.NONE,
            targetLanguage = "English",
            isFollowUp = false
        )

        // Intentionally bad draft that could resist simple fixes
        val unresolvableDraft = "fake_mantra: invalid ॐ"
        val result = SelfCorrectionEngine.processAndRefine(
            query = "Give me something unknown",
            draftAnswer = unresolvableDraft,
            contextState = ConversationContextState(),
            intent = intent,
            detectedLanguage = "English",
            hasCanonicalSource = false
        )

        assertTrue("Attempts does not exceed MAX_REVISION_ATTEMPTS", result.attemptsCount <= SelfCorrectionEngine.MAX_REVISION_ATTEMPTS)
        assertNotNull("Returns a final verified or safe fallback answer", result.finalAnswer)
        assertTrue("Does not hang or crash", result.finalAnswer.isNotBlank())
    }
}
