package com.example

import com.example.domain.ai.*
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class DeepReasoningEngineTest {

    // 1. Simple question reasoning in Bengali ("কর্ম কী?")
    @Test
    fun testSimpleQuestionReasoning_Bengali() = runBlocking {
        val query = "কর্ম কী?"
        val result = DeepReasoningEngine.reason(
            query = query,
            contextState = ConversationContextState()
        )

        assertNotNull(result)
        assertTrue(result.finalAnswer.isNotBlank())
        assertEquals(ReasoningConfidence.HIGH_CONFIDENCE, result.confidenceLevel)
        assertTrue(result.gatheredEvidence.isNotEmpty())
        assertTrue(result.gatheredEvidence.any { it.classification == EvidenceClassification.CANONICAL })
        assertFalse(result.isInsufficientEvidence)
    }

    // 2. Simple question reasoning in English ("What is karma?")
    @Test
    fun testSimpleQuestionReasoning_English() = runBlocking {
        val query = "What is karma?"
        val result = DeepReasoningEngine.reason(
            query = query,
            contextState = ConversationContextState()
        )

        assertNotNull(result)
        assertTrue(result.finalAnswer.isNotBlank())
        assertEquals("English", result.detectedLanguage)
        assertEquals(ReasoningConfidence.HIGH_CONFIDENCE, result.confidenceLevel)
        assertTrue(result.gatheredEvidence.any { it.classification == EvidenceClassification.CANONICAL })
    }

    // 3. Question nuance recognition (distinguishing "কর্ম কী?" vs "কর্ম করলে কী হয়?" vs "গীতায় কর্ম সম্পর্কে কী বলা হয়েছে?")
    @Test
    fun testQuestionNuances_DistinctIntents() {
        val q1 = "কর্ম কী?"
        val q2 = "কর্ম করলে কী হয়?"
        val q3 = "গীতায় কর্ম সম্পর্কে কী বলা হয়েছে?"

        val intent1 = DharmaIntentEngine.analyze(q1)
        val intent2 = DharmaIntentEngine.analyze(q2)
        val intent3 = DharmaIntentEngine.analyze(q3)

        assertNotNull(intent1)
        assertNotNull(intent2)
        assertNotNull(intent3)

        // All relate to Karma, but represent different sub-intents or query types
        assertTrue(intent1.detectedTopic?.contains("কর্ম") == true)
        assertTrue(intent2.detectedTopic?.contains("কর্ম") == true)
        assertTrue(intent3.detectedTopic?.contains("কর্ম") == true || intent3.detectedTopic?.contains("গীতা") == true)
    }

    // 4. Complex question decomposition ("ভগবদ্গীতায় কর্মযোগ কী এবং দৈনন্দিন জীবনে এর প্রয়োগ কী?")
    @Test
    fun testComplexQuestionDecomposition() = runBlocking {
        val query = "ভগবদ্গীতায় কর্মযোগ কী এবং দৈনন্দিন জীবনে এর প্রয়োগ কী?"
        val result = DeepReasoningEngine.reason(
            query = query,
            contextState = ConversationContextState()
        )

        assertTrue("Query should be decomposed into sub-tasks", result.isDecomposed)
        assertTrue("Sub-tasks count should be at least 3", result.subTasks.size >= 3)
        assertTrue(result.subTasks.any { it.questionType == "DEFINITION" })
        assertTrue(result.subTasks.any { it.questionType == "SCRIPTURAL_TEACHING" })
        assertTrue(result.subTasks.any { it.questionType == "PRACTICAL_APPLICATION" })

        assertTrue(result.finalAnswer.contains("শাস্ত্রীয়") || result.finalAnswer.contains("কর্মযোগ"))
        assertTrue(result.finalAnswer.contains("দৈনন্দিন") || result.finalAnswer.contains("প্রয়োগ"))
    }

    // 5. Mixed-language reasoning ("Karma yoga daily life e kivabe apply korbo?")
    @Test
    fun testMixedLanguageReasoning() = runBlocking {
        val query = "Karma yoga daily life এ কীভাবে apply করব?"
        val result = DeepReasoningEngine.reason(
            query = query,
            contextState = ConversationContextState()
        )

        assertNotNull(result)
        assertTrue(result.finalAnswer.isNotBlank())
        assertTrue(result.gatheredEvidence.isNotEmpty())
    }

    // 6. Context-dependent questions & Anaphora resolution ("কর্ম কী?" -> "তাহলে এটা কি শুধু পূজার সঙ্গে সম্পর্কিত?")
    @Test
    fun testContextDependentFollowUp_AnaphoraResolution() = runBlocking {
        // Step 1: User asks "কর্ম কী?"
        val turn1State = ConversationContextState(
            activeSubject = "কর্ম (Karma)",
            activeTopic = "Karma Doctrine",
            threadTurnCount = 1,
            lastAiResponseSnippet = "কর্ম হলো সকল কায়িক, বাচনিক ও মানসিক ক্রিয়া।"
        )

        // Step 2: User asks follow up "তাহলে এটা কি শুধু পূজার সঙ্গে সম্পর্কিত?"
        val query2 = "তাহলে এটা কি শুধু পূজার সঙ্গে সম্পর্কিত?"
        val result2 = DeepReasoningEngine.reason(
            query = query2,
            contextState = turn1State
        )

        assertNotNull(result2)
        assertTrue("Response should clarify that Karma is not only ritual worship",
            result2.finalAnswer.contains("পূজা") && (result2.finalAnswer.contains("সীমাবদ্ধ নয়") || result2.finalAnswer.contains("নয়") || result2.finalAnswer.contains("কায়িক"))
        )
    }

    // 7. Context resolution for "এর অর্থ কী?" / "তার মূল শিক্ষা কী?"
    @Test
    fun testContextResolution_MeaningsAndTeachings() {
        val context = ConversationContextState(
            activeSubject = "শ্রীমদ্ভগবদ্গীতা",
            activeScripture = "Bhagavad Gita",
            lastAiResponseSnippet = "গীতা হলো মহাভারতের ভীষ্ম পর্বের অংশ।"
        )

        val resolvedMeaning = DeepReasoningEngine.resolveContextualReferences(
            query = "তার মূল শিক্ষা কী?",
            history = listOf("গীতা কী?" to "গীতা হলো পবিত্র শাস্ত্র।"),
            contextState = context
        )

        assertTrue(resolvedMeaning.contains("শ্রীমদ্ভগবদ্গীতা") || resolvedMeaning.contains("মূল শিক্ষা"))
    }

    // 8. Topic Switching: Context purging without context bleeding
    @Test
    fun testTopicSwitching_ContextPurgedCleanly() {
        val previousState = ConversationContextState(
            activeDeity = "Lord Shiva (মহাদেব শিব)",
            activeMantra = "Maha Mrityunjaya Mantra (মহামৃত্যুঞ্জয় মন্ত্র)",
            activeTopic = "Shiva Worship"
        )

        // User switches topic completely to Maa Durga
        val newState = ContextMemoryManager.extractContextEntities(
            query = "মা দুর্গার প্রণাম মন্ত্র কী?",
            previousState = previousState
        )

        assertEquals("Maa Durga (মা দুর্গা)", newState.activeDeity)
        assertNotEquals("Lord Shiva (মহাদেব শিব)", newState.activeDeity)
    }

    // 9. Canonical Evidence Grounding (Never invent scripture verses)
    @Test
    fun testCanonicalEvidenceGrounding_RealVersesOnly() = runBlocking {
        val result = DeepReasoningEngine.reason(
            query = "গায়ত্রী মন্ত্রের সংস্কৃত পাঠ ও উৎস কী?",
            contextState = ConversationContextState()
        )

        assertEquals(ReasoningConfidence.HIGH_CONFIDENCE, result.confidenceLevel)
        assertNotNull(result.sanskritVerse)
        assertTrue(result.sanskritVerse?.contains("गायत्री") == true || result.sanskritVerse?.contains("भर्गो") == true || result.sanskritVerse?.contains("सवितुर्वरेण्यं") == true)
        assertTrue(result.references.any { it.contains("ঋগ্বেদ") || it.contains("Rigveda") || it.contains("Gayatri") })
    }

    // 10. Contradiction Detection & Automatic Reconciliation
    @Test
    fun testContradictionDetection_ReconcilesFlawedStatement() {
        val query = "কর্মযোগ কী?"
        val flawedDraft = "কর্মযোগের মূল তত্ত্ব হলো সব কাজ ছেড়ে দেওয়া এবং নিষ্ক্রিয় হয়ে বসে থাকা।"
        val check = DeepReasoningEngine.checkContradictions(
            query = query,
            proposedAnswer = flawedDraft,
            evidence = emptyList(),
            contextState = ConversationContextState(),
            history = emptyList()
        )

        assertTrue("Contradiction should be caught", check.hasContradiction)
        assertTrue("Correction should replace renunciation of work with renunciation of fruit",
            check.revisedReasoning?.contains("কর্মফল ত্যাগ") == true
        )
    }

    // 11. Insufficient Evidence Handling (No fake fabrication)
    @Test
    fun testInsufficientEvidenceHandling_AdmitsBoundary() = runBlocking {
        val unknownQuery = "xyz987_fictional_unreferenced_deity_ritual_formula_123"
        val result = DeepReasoningEngine.reason(
            query = unknownQuery,
            contextState = ConversationContextState()
        )

        assertEquals(ReasoningConfidence.INSUFFICIENT_EVIDENCE, result.confidenceLevel)
        assertTrue(result.isInsufficientEvidence)
        assertTrue(result.finalAnswer.contains("অপর্যাপ্ত") || result.finalAnswer.contains("অনুপলব্ধ") || result.finalAnswer.contains("unavailable") || result.finalAnswer.contains("বিরত"))
    }

    // 12. No-Crash Fallback Test on edge inputs
    @Test
    fun testNoCrashFallback_EdgeInputs() = runBlocking {
        val edgeQueries = listOf(
            "",
            "   ",
            "???",
            "12345",
            "@#$$%^&*",
            "কর্ম",
            "গীতা",
            "Om",
            "Explain everything in detail"
        )

        for (q in edgeQueries) {
            val res = DeepReasoningEngine.reason(q, contextState = ConversationContextState())
            assertNotNull("Engine must never return null or crash", res)
            assertNotNull(res.finalAnswer)
        }
    }

    // 13. Step 4: Multi-turn Context - Karma Yoga in Daily Life ("What does it mean in daily life?")
    @Test
    fun testMultiTurnContext_KarmaYogaDailyLife() {
        val previousState = ConversationContextState(
            activeSubject = "Karma Yoga (কর্মযোগ ও নিষ্কাম কর্ম)",
            activeConcept = "Karma Yoga (কর্মযোগ ও নিষ্কাম কর্ম)",
            activeTopic = "Karma Yoga"
        )

        // English follow-up
        val resolvedEn = ContextMemoryManager.resolveMultiTurnQuery(
            query = "What does it mean in daily life?",
            history = listOf("What is Karma Yoga?" to "Karma Yoga is the path of selfless action."),
            contextState = previousState
        )
        assertTrue("Understands 'it' as Karma Yoga in daily life",
            resolvedEn.contains("Karma Yoga", ignoreCase = true) && resolvedEn.contains("daily life", ignoreCase = true)
        )

        // Bengali follow-up
        val resolvedBn = ContextMemoryManager.resolveMultiTurnQuery(
            query = "দৈনন্দিন জীবনে এর অর্থ কী?",
            history = listOf("কর্মযোগ কী?" to "কর্মযোগ হলো নিষ্কামভাবে কর্ম সম্পাদনের আধ্যাত্মিক পথ।"),
            contextState = previousState
        )
        assertTrue("Understands 'এর' as Karma Yoga in daily life",
            resolvedBn.contains("কর্মযোগ") && (resolvedBn.contains("দৈনন্দিন জীবনে") || resolvedBn.contains("প্রয়োগ"))
        )
    }

    // 14. Step 4: Multi-turn Context - Deity Main Mantra ("What is his main mantra?")
    @Test
    fun testMultiTurnContext_DeityMainMantra() {
        val previousState = ConversationContextState(
            activeSubject = "Lord Shiva (মহাদেব শিব)",
            activeDeity = "Lord Shiva (মহাদেব শিব)",
            activeTopic = "Lord Shiva"
        )

        // English follow-up
        val resolvedEn = ContextMemoryManager.resolveMultiTurnQuery(
            query = "What is his main mantra?",
            history = listOf("Tell me about Shiva." to "Lord Shiva is Mahadeva."),
            contextState = previousState
        )
        assertTrue("Understands 'his' as Shiva's main mantra",
            resolvedEn.contains("Shiva", ignoreCase = true) && resolvedEn.contains("mantra", ignoreCase = true)
        )

        // Bengali follow-up
        val resolvedBn = ContextMemoryManager.resolveMultiTurnQuery(
            query = "তার প্রধান মন্ত্র কী?",
            history = listOf("শিব সম্পর্কে বলো।" to "মহাদেব শিব পরম কল্যাণময়।"),
            contextState = previousState
        )
        assertTrue("Understands 'তার' as Shiva's main mantra",
            resolvedBn.contains("শিব") && resolvedBn.contains("মন্ত্র")
        )
    }

    // 15. Step 4: Combined Intent + Context - Shloka on Duty from Gita ("Give me a shloka about duty from it.")
    @Test
    fun testCombinedIntentAndContext_ShlokaFromGita() {
        val previousState = ConversationContextState(
            activeSubject = "Bhagavad Gita (শ্রীমদ্ভগবদ্গীতা)",
            activeScripture = "Bhagavad Gita (শ্রীমদ্ভগবদ্গীতা)",
            activeTopic = "Bhagavad Gita"
        )

        val resolved = ContextMemoryManager.resolveMultiTurnQuery(
            query = "Give me a shloka about duty from it.",
            history = listOf("Tell me about Bhagavad Gita." to "Bhagavad Gita is a 700-verse Hindu scripture."),
            contextState = previousState
        )

        assertTrue("Identifies Bhagavad Gita", resolved.contains("Bhagavad Gita") || resolved.contains("শ্রীমদ্ভগবদ্গীতা"))
        assertTrue("Identifies duty / Karma Yoga", resolved.contains("duty") || resolved.contains("Karma Yoga") || resolved.contains("কর্মযোগ"))
        assertTrue("Identifies shloka request", resolved.contains("shloka") || resolved.contains("শ্লোক"))
    }

    // 16. Step 4: Short Follow-Up Questions (Why?, How?, Explain more., Give an example.)
    @Test
    fun testShortFollowUpQuestions() {
        val state = ConversationContextState(
            activeSubject = "Karma Yoga (কর্মযোগ)",
            activeConcept = "Karma Yoga (কর্মযোগ)"
        )

        val whyResolved = ContextMemoryManager.resolveMultiTurnQuery("Why?", emptyList(), state)
        assertTrue(whyResolved.contains("Karma Yoga") || whyResolved.contains("কর্মযোগ"))

        val howResolved = ContextMemoryManager.resolveMultiTurnQuery("How?", emptyList(), state)
        assertTrue(howResolved.contains("Karma Yoga") || howResolved.contains("কর্মযোগ"))

        val explainMoreResolved = ContextMemoryManager.resolveMultiTurnQuery("Explain more.", emptyList(), state)
        assertTrue(explainMoreResolved.contains("Karma Yoga") || explainMoreResolved.contains("কর্মযোগ"))

        val exampleResolved = ContextMemoryManager.resolveMultiTurnQuery("Give an example.", emptyList(), state)
        assertTrue(exampleResolved.contains("Karma Yoga") || exampleResolved.contains("কর্মযোগ"))

        val whatDoesItMean = ContextMemoryManager.resolveMultiTurnQuery("What does that mean?", emptyList(), state)
        assertTrue(whatDoesItMean.contains("Karma Yoga") || whatDoesItMean.contains("কর্মযোগ"))
    }

    // 17. Step 4: Genuinely Ambiguous Reference without context flags clarification prompt
    @Test
    fun testAmbiguousReferenceGuardrail_NoGuessing() {
        val emptyState = ConversationContextState()

        val ambiguousEn = ContextMemoryManager.resolveMultiTurnQuery(
            query = "What is his mantra?",
            history = emptyList(),
            contextState = emptyState
        )
        assertTrue("Flags ambiguous clarification request", ambiguousEn.startsWith("AMBIGUOUS_CLARIFICATION:"))

        val ambiguousBn = ContextMemoryManager.resolveMultiTurnQuery(
            query = "তার মন্ত্র কী?",
            history = emptyList(),
            contextState = emptyState
        )
        assertTrue("Flags ambiguous clarification request in Bengali", ambiguousBn.startsWith("AMBIGUOUS_CLARIFICATION:"))
    }

    // 18. Step 4: Religious vs General Knowledge Separation & Math Calculation
    @Test
    fun testGeneralKnowledgeSeparation_NoReligiousForcing() {
        // Science: Gravity
        val gravityTopic = GeneralKnowledgeEngine.findGeneralKnowledge("What is gravity?")
        assertNotNull("Gravity should be found in General Knowledge", gravityTopic)
        assertEquals("SCIENCE", gravityTopic?.category)
        val gravityAnswer = gravityTopic?.generateAnswer("English") ?: ""
        assertTrue("Answers with physics and gravitation", gravityAnswer.contains("Gravitation", ignoreCase = true) || gravityAnswer.contains("mass", ignoreCase = true))
        assertFalse("Does not force religious dogma into gravity", gravityAnswer.contains("শ্রীকৃষ্ণ") || gravityAnswer.contains("মন্ত্র"))

        // Science: Photosynthesis
        val photoTopic = GeneralKnowledgeEngine.findGeneralKnowledge("সালোকসংশ্লেষণ কী?")
        assertNotNull(photoTopic)
        assertEquals("SCIENCE", photoTopic?.category)

        // Math: Arithmetic Calculation (e.g. "25 * 4")
        val mathResult = GeneralKnowledgeEngine.tryEvaluateMath("25 * 4")
        assertNotNull("Math engine should evaluate 25 * 4", mathResult)
        assertTrue("Calculation should be 100", mathResult?.first?.contains("100") == true)
    }

    // 19. Step 4: Domain Switching & Unrelated Context Purging
    @Test
    fun testDomainSwitching_ContextPurgedCleanly() {
        val dharmaState = ConversationContextState(
            activeDomain = "DHARMA",
            activeSubject = "Lord Shiva (মহাদেব শিব)",
            activeDeity = "Lord Shiva (মহাদেব শিব)"
        )

        // Switching from Dharma to Science topic "What is photosynthesis?"
        val scienceState = ContextMemoryManager.extractContextEntities(
            query = "What is photosynthesis?",
            previousState = dharmaState
        )

        assertEquals("SCIENCE", scienceState.activeDomain)
        assertNull("Deity should be purged when switching to Science", scienceState.activeDeity)
        assertTrue(scienceState.activeSubject?.contains("Photosynthesis") == true)
    }
}
