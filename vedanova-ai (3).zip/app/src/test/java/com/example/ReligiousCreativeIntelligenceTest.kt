package com.example

import com.example.domain.ai.*
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class ReligiousCreativeIntelligenceTest {

    // 1. Creative Story Generation ("একটি ধর্মীয় গল্প লেখো")
    @Test
    fun testOriginalStoryGeneration_IncludesDisclaimerAndStoryStructure() {
        val topic = "সত্য ও নিষ্ঠা"
        val output = DharmaWritingEngine.composePiece(
            topic = topic,
            type = CreativeWritingType.STORY,
            style = ResponseStyleRequest.BALANCED,
            language = "Bengali"
        )

        assertNotNull(output)
        assertTrue("Must include original writing disclaimer", output.contains("AI-রচিত মৌলিক রচনা") || output.contains("কোনো প্রামাণিক শাস্ত্রীয় শ্লোক বা প্রাচীন শ্রুতি নয়"))
        assertTrue("Must have story title", output.contains("গল্প") || output.contains(topic))
        assertTrue("Must contain narrative sections", output.contains("জিজ্ঞাসুর যাত্রা") || output.contains("দৃষ্টান্ত") || output.contains("শিক্ষা"))
    }

    // 2. Original Prayer Generation ("একটি প্রার্থনা লিখে দাও")
    @Test
    fun testOriginalPrayerGeneration_BengaliAndEnglish() {
        val prayerBn = DharmaWritingEngine.composePiece(
            topic = "আত্মশুদ্ধি ও শান্তি",
            type = CreativeWritingType.PRAYER_COMPOSITION,
            style = ResponseStyleRequest.BALANCED,
            language = "Bengali"
        )
        assertTrue(prayerBn.contains("মৌলিক রচনা") || prayerBn.contains("প্রার্থনা"))
        assertTrue(prayerBn.contains("পরমেশ্বর") || prayerBn.contains("শান্তি"))

        val prayerEn = DharmaWritingEngine.composePiece(
            topic = "Inner Peace",
            type = CreativeWritingType.PRAYER_COMPOSITION,
            style = ResponseStyleRequest.BALANCED,
            language = "English"
        )
        assertTrue(prayerEn.contains("AI-Generated Original Composition") || prayerEn.contains("Not an authentic ancient canonical scripture"))
        assertTrue(prayerEn.contains("Prayer") || prayerEn.contains("Supreme"))
    }

    // 3. Devotional Poem Generation ("একটি ভক্তিমূলক কবিতা লেখো")
    @Test
    fun testDevotionalPoemGeneration_WithRhymeAndDevotionalEmotion() {
        val poemBn = DharmaWritingEngine.composePiece(
            topic = "ভক্তি ও ভগবৎপ্রেম",
            type = CreativeWritingType.POEM,
            style = ResponseStyleRequest.BALANCED,
            language = "Bengali"
        )
        assertTrue("Must have original disclaimer", poemBn.contains("মৌলিক রচনা") || poemBn.contains("শ্রুতি নয়"))
        assertTrue("Must have poem title", poemBn.contains("ভক্তিমূলক কবিতা"))
        assertTrue("Must contain lyrical stanzas", poemBn.contains("স্তবক") && poemBn.contains("অন্তর মাঝে তব আলো জ্বলে"))

        val poemEn = DharmaWritingEngine.composePiece(
            topic = "Divine Love",
            type = CreativeWritingType.POEM,
            style = ResponseStyleRequest.BALANCED,
            language = "English"
        )
        assertTrue(poemEn.contains("Devotional Poem"))
        assertTrue(poemEn.contains("Stanza I") && poemEn.contains("Stanza II"))
    }

    // 4. Speech / Discourse Composition ("একটি সুন্দর ধর্মীয় বক্তব্য বানাও")
    @Test
    fun testSpiritualSpeechComposition_IncludesAudienceAddressAndCallToAction() {
        val speech = DharmaWritingEngine.composePiece(
            topic = "মানবসেবা ও ধর্ম",
            type = CreativeWritingType.SPEECH,
            style = ResponseStyleRequest.BALANCED,
            language = "Bengali"
        )
        assertTrue(speech.contains("বক্তব্য") || speech.contains("ভাষণ"))
        assertTrue(speech.contains("শ্রদ্ধেয় সুধীবৃন্দ") || speech.contains("নমস্কার"))
        assertTrue(speech.contains("সমাপনী আহ্বান") || speech.contains("ওঁ শান্তি"))
    }

    // 5. Puja & Festive Greeting ("একটি পূজার শুভেচ্ছা লিখো")
    @Test
    fun testPujaGreetingGeneration_WarmAndAuspicious() {
        val greeting = DharmaWritingEngine.composePiece(
            topic = "শারদীয় দুর্গোৎসব",
            type = CreativeWritingType.PUJA_GREETING,
            style = ResponseStyleRequest.BALANCED,
            language = "Bengali"
        )
        assertTrue(greeting.contains("পূজার প্রীতি") || greeting.contains("শুভেচ্ছা"))
        assertTrue(greeting.contains("উৎসবের শুভ আগমনী") || greeting.contains("আনন্দ"))
        assertTrue(greeting.contains("শুভ পূজা"))
    }

    // 6. Original Mantra/Shloka Composition ("একটি নতুন মন্ত্র তৈরি করো")
    // CRITICAL: Must have strict non-canonical disclaimer and never claim to be ancient scripture
    @Test
    fun testOriginalMantraComposition_StrictDisclaimerNeverClaimedAsScripture() {
        val shlokaBn = DharmaWritingEngine.composePiece(
            topic = "শান্তি ও সত্যনিষ্ঠা",
            type = CreativeWritingType.ORIGINAL_MANTRA_COMPOSITION,
            style = ResponseStyleRequest.BALANCED,
            language = "Bengali"
        )

        // Strict disclaimer checks
        assertTrue("Must have prominent mantra-specific disclaimer",
            shlokaBn.contains("মৌলিক ভক্তিমূলক কাব্যিক শ্লোক") &&
            shlokaBn.contains("বেদ, উপনিষদ বা গীতার কোনো প্রাচীন প্রামাণিক সনাতন মন্ত্র নয়")
        )
        assertTrue("Must include word-by-word meaning", shlokaBn.contains("পদ্যানুবাদ") || shlokaBn.contains("সরলার্থ"))
        assertTrue("Must include philosophical caution", shlokaBn.contains("সনাতন ধর্মে প্রামাণিক বিধি ও জপের জন্য বৈদিক ও পৌরাণিক ঋষিপ্রণীত শাস্ত্রীয় মন্ত্রই প্রামাণিক"))

        val shlokaEn = DharmaWritingEngine.composePiece(
            topic = "Universal Peace",
            type = CreativeWritingType.ORIGINAL_MANTRA_COMPOSITION,
            style = ResponseStyleRequest.BALANCED,
            language = "English"
        )
        assertTrue(shlokaEn.contains("AI-crafted original devotional poetic shloka"))
        assertTrue(shlokaEn.contains("Canonical scriptures remain distinct and immutable"))
    }

    // 7. Intent Engine: Accurately Distinguishes Creative Writing vs Canonical Question
    @Test
    fun testIntentEngine_DistinguishesCreativeVsCanonical() {
        val storyIntent = DharmaIntentEngine.analyze("একটি ধর্মীয় গল্প লেখো")
        assertEquals(QuestionIntentType.CREATIVE_WRITING, storyIntent.primaryIntent)
        assertEquals(CreativeWritingType.STORY, storyIntent.creativeWritingType)

        val poemIntent = DharmaIntentEngine.analyze("ভক্তি নিয়ে একটি ভক্তিমূলক কবিতা লেখো")
        assertEquals(QuestionIntentType.CREATIVE_WRITING, poemIntent.primaryIntent)
        assertEquals(CreativeWritingType.POEM, poemIntent.creativeWritingType)

        val prayerIntent = DharmaIntentEngine.analyze("একটি সুন্দর প্রার্থনা লিখে দাও")
        assertEquals(QuestionIntentType.CREATIVE_WRITING, prayerIntent.primaryIntent)
        assertEquals(CreativeWritingType.PRAYER_COMPOSITION, prayerIntent.creativeWritingType)

        val greetingIntent = DharmaIntentEngine.analyze("একটি পূজার শুভেচ্ছা বার্তা লেখো")
        assertEquals(QuestionIntentType.CREATIVE_WRITING, greetingIntent.primaryIntent)
        assertEquals(CreativeWritingType.PUJA_GREETING, greetingIntent.creativeWritingType)

        val newMantraIntent = DharmaIntentEngine.analyze("একটি নতুন মন্ত্র তৈরি করো")
        assertEquals(QuestionIntentType.CREATIVE_WRITING, newMantraIntent.primaryIntent)
        assertEquals(CreativeWritingType.ORIGINAL_MANTRA_COMPOSITION, newMantraIntent.creativeWritingType)

        // Canonical questions MUST NOT be classified as creative writing
        val canonicalGita = DharmaIntentEngine.analyze("গীতায় কর্ম সম্পর্কে কী বলা হয়েছে?")
        assertNotEquals(QuestionIntentType.CREATIVE_WRITING, canonicalGita.primaryIntent)

        val canonicalGayatri = DharmaIntentEngine.analyze("গায়ত্রী মন্ত্রের অর্থ কী?")
        assertNotEquals(QuestionIntentType.CREATIVE_WRITING, canonicalGayatri.primaryIntent)

        val canonicalKarma = DharmaIntentEngine.analyze("কর্ম কী?")
        assertNotEquals(QuestionIntentType.CREATIVE_WRITING, canonicalKarma.primaryIntent)
    }

    // 8. Fact vs Creative Separation: Classification Flagging
    @Test
    fun testFactVsCreativeSeparation_ClassificationFlags() = runBlocking {
        val orchestrator = AiOrchestrator()

        // Creative Writing Query through Orchestrator
        val creativeResponse = orchestrator.processConversationTurn(
            query = "একটি ধর্মীয় গল্প লেখো"
        )
        assertNotNull(creativeResponse)
        assertEquals(EvidenceClassification.ORIGINAL_WRITING, creativeResponse.diagnosticInfo.evidenceClassification)
        assertTrue(creativeResponse.diagnosticInfo.isOriginalCreativeWriting)
        assertTrue("Creative response must feature original disclaimer",
            creativeResponse.answer.contains("মৌলিক রচনা") || creativeResponse.answer.contains("শ্রুতি নয়")
        )

        // Canonical Query through Orchestrator
        val canonicalResponse = orchestrator.processConversationTurn(
            query = "কর্ম কী?"
        )
        assertNotNull(canonicalResponse)
        assertFalse(canonicalResponse.diagnosticInfo.isOriginalCreativeWriting)
        assertNotEquals(EvidenceClassification.ORIGINAL_WRITING, canonicalResponse.diagnosticInfo.evidenceClassification)
        assertFalse("Canonical response must NOT feature original disclaimer",
            canonicalResponse.answer.contains("AI-রচিত মৌলিক রচনা")
        )
    }

    // 9. Unverified Mantra Safety Guardrail
    @Test
    fun testUnverifiedMantraGuardrail_NeverFabricatesCanonicalMantra() = runBlocking {
        val orchestrator = AiOrchestrator()

        // Request for a non-existent / unverified mantra
        val response = orchestrator.processConversationTurn(
            query = "অজ্ঞাত ৯৯ দেবতার আসল শাস্ত্রীয় গোপন মূল বীজ মন্ত্র কী?"
        )

        assertNotNull(response)
        assertTrue("Should refuse to fabricate unverified Sanskrit mantra",
            response.answer.contains("নিশ্চিত করা সম্ভব হয়নি") ||
            response.answer.contains("মনগড়া") ||
            response.answer.contains("যাচাই") ||
            response.answer.contains("সনাতন শাস্ত্রের বিশুদ্ধতা")
        )
        assertFalse(response.isVerifiedSource)
    }

    // 10. Step 3: Source Hierarchy Priority Test
    @Test
    fun testSourceHierarchy_PriorityRankOrder() {
        // Hierarchy Order: Vedas (1) > Upanishads (2) > Bhagavad Gita (3) > Ramayana (4) > Mahabharata (5) > Puranas (6) > Agamas/Tantras (7) > Traditional Commentaries (8) > Other (9) > General (10)
        assertTrue(ScripturalSourceTier.VEDAS.priorityRank < ScripturalSourceTier.UPANISHADS.priorityRank)
        assertTrue(ScripturalSourceTier.UPANISHADS.priorityRank < ScripturalSourceTier.BHAGAVAD_GITA.priorityRank)
        assertTrue(ScripturalSourceTier.BHAGAVAD_GITA.priorityRank < ScripturalSourceTier.RAMAYANA.priorityRank)
        assertTrue(ScripturalSourceTier.RAMAYANA.priorityRank < ScripturalSourceTier.MAHABHARATA.priorityRank)
        assertTrue(ScripturalSourceTier.MAHABHARATA.priorityRank < ScripturalSourceTier.PURANAS.priorityRank)
        assertTrue(ScripturalSourceTier.PURANAS.priorityRank < ScripturalSourceTier.AGAMAS_TANTRAS.priorityRank)
        assertTrue(ScripturalSourceTier.AGAMAS_TANTRAS.priorityRank < ScripturalSourceTier.TRADITIONAL_COMMENTARIES.priorityRank)
        assertTrue(ScripturalSourceTier.TRADITIONAL_COMMENTARIES.priorityRank < ScripturalSourceTier.OTHER_RECOGNIZED_TEXTS.priorityRank)
        assertTrue(ScripturalSourceTier.OTHER_RECOGNIZED_TEXTS.priorityRank < ScripturalSourceTier.GENERAL_KNOWLEDGE.priorityRank)

        // Tier Determination
        assertEquals(ScripturalSourceTier.VEDAS, ScripturalSourceTier.determineScripturalTier("Rigveda Samhita", "Mandala 10"))
        assertEquals(ScripturalSourceTier.UPANISHADS, ScripturalSourceTier.determineScripturalTier("Katha Upanishad", "1.2.2"))
        assertEquals(ScripturalSourceTier.BHAGAVAD_GITA, ScripturalSourceTier.determineScripturalTier("Bhagavad Gita", "Chapter 2, Verse 47"))
        assertEquals(ScripturalSourceTier.PURANAS, ScripturalSourceTier.determineScripturalTier("Srimad Bhagavata Purana", "Canto 1"))
        assertEquals(ScripturalSourceTier.AGAMAS_TANTRAS, ScripturalSourceTier.determineScripturalTier("Mahanirvana Tantra", "Patala 3"))
        assertEquals(ScripturalSourceTier.TRADITIONAL_COMMENTARIES, ScripturalSourceTier.determineScripturalTier("Shankara Bhashya", "Brahma Sutra 1.1.1"))
    }

    // 11. Step 3: Evidence Sorting by Hierarchy in DeepReasoningEngine
    @Test
    fun testEvidenceSorting_HigherScripturalTierPrioritized() = runBlocking {
        // Gathering evidence for a topic covered across tiers
        val reasonResult = DeepReasoningEngine.reason(
            query = "বেদ উপনিষদ আত্মা ব্রহ্ম",
            contextState = ConversationContextState()
        )
        val evidence = reasonResult.gatheredEvidence
        assertTrue("Evidence must not be empty", evidence.isNotEmpty())

        // Validate that top evidence respects highest available scriptural tier
        val firstEvidence = evidence.first()
        assertTrue(
            "Top evidence should be Vedas, Upanishads or Gita",
            firstEvidence.scripturalTier == ScripturalSourceTier.VEDAS ||
            firstEvidence.scripturalTier == ScripturalSourceTier.UPANISHADS ||
            firstEvidence.scripturalTier == ScripturalSourceTier.BHAGAVAD_GITA
        )
    }

    // 12. Step 3: Truth Separation Analysis
    @Test
    fun testTruthSeparation_ClassificationCategories() {
        val scripturalAnalysis = SourceQualityEngine.classifyTruthSeparation(
            query = "গায়ত্রী মন্ত্র",
            answer = "ওঁ ভূর্ভুবঃ স্বঃ। এটি ঋগ্বেদের ৩য় মণ্ডলের অন্তর্গত মূল শ্লোক।",
            sanskritVerse = "ॐ भूर्भुवः स्वः",
            isCreativeWriting = false,
            sourceTier = ScripturalSourceTier.VEDAS
        )
        assertEquals(TruthCategory.SCRIPTURAL_TEXT, scripturalAnalysis.primaryCategory)
        assertNotNull(scripturalAnalysis.scripturalText)

        val creativeAnalysis = SourceQualityEngine.classifyTruthSeparation(
            query = "একটি কবিতা লেখো",
            answer = "এটি AI-রচিত মৌলিক ভক্তিমূলক কবিতা।",
            sanskritVerse = null,
            isCreativeWriting = true,
            sourceTier = ScripturalSourceTier.GENERAL_KNOWLEDGE
        )
        assertEquals(TruthCategory.ORIGINAL_AI_WRITING, creativeAnalysis.primaryCategory)
        assertTrue(creativeAnalysis.isExplicitlySeparated)

        val historicalAnalysis = SourceQualityEngine.classifyTruthSeparation(
            query = "হরপ্পা সভ্যতার ইতিহাস কী?",
            answer = "সিন্ধু সভ্যতার প্রত্নতাত্ত্বিক গবেষণা ও ঐতিহাসিক তথ্য প্রমাণ করে...",
            sanskritVerse = null,
            isCreativeWriting = false,
            sourceTier = ScripturalSourceTier.GENERAL_KNOWLEDGE,
            isHistoricalQuery = true
        )
        assertEquals(TruthCategory.HISTORICAL_SCHOLARLY_FACT, historicalAnalysis.primaryCategory)
    }

    // 13. Step 3: Tradition Differences / Sampradaya Multi-Perspective
    @Test
    fun testTraditionDifferences_AdvaitaDvaitaHandledObjectively() = runBlocking {
        val result = DeepReasoningEngine.reason(
            query = "অদ্বৈত ও দ্বৈতবাদের মধ্যে পার্থক্য কী?",
            contextState = ConversationContextState()
        )
        assertNotNull(result)
        assertTrue("Must address Advaita", result.finalAnswer.contains("অদ্বৈত") || result.finalAnswer.contains("শঙ্করাচার্য"))
        assertTrue("Must address Dvaita", result.finalAnswer.contains("দ্বৈত") || result.finalAnswer.contains("মাধবাচার্য"))
        assertFalse("Must not have insufficient evidence", result.isInsufficientEvidence)
    }

    // 14. Step 3: Orchestrator Diagnostic Integration
    @Test
    fun testAiOrchestrator_DiagnosticIntegratesTruthAndSelfCheck() = runBlocking {
        val orchestrator = AiOrchestrator()
        val response = orchestrator.processConversationTurn(query = "উপনিষদে ব্রহ্ম সম্পর্কে কী বলা হয়েছে?")

        assertNotNull(response)
        val diag = response.diagnosticInfo
        assertNotNull("DiagnosticInfo must contain truthCategory", diag.truthCategory)
        assertNotNull("DiagnosticInfo must contain truthSeparation", diag.truthSeparation)
        assertNotNull("DiagnosticInfo must contain scripturalSourceTier", diag.scripturalSourceTier)
        assertNotNull("DiagnosticInfo must contain selfCheckResult", diag.selfCheckResult)
        assertTrue("Self check passed", diag.selfCheckResult?.isPassed ?: false)
    }
}
