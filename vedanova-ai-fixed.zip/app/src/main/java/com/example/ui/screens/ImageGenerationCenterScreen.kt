package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.data.model.GeneratedImageEntity
import com.example.domain.image.*
import com.example.ui.components.StatusPill
import com.example.ui.theme.*
import com.example.ui.viewmodel.VedaNovaViewModel
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ImageGenerationCenterScreen(viewModel: VedaNovaViewModel) {
    val state by viewModel.imageStudioState.collectAsStateWithLifecycle()
    val allImages by viewModel.allGeneratedImages.collectAsStateWithLifecycle()
    val totalCount by viewModel.totalGeneratedImagesCount.collectAsStateWithLifecycle()
    val successCount by viewModel.successfulImagesCount.collectAsStateWithLifecycle()
    val failedCount by viewModel.failedImagesCount.collectAsStateWithLifecycle()
    val engineState by viewModel.imageEngineState.collectAsStateWithLifecycle()

    val context = LocalContext.current

    LaunchedEffect(state.toastMessage) {
        state.toastMessage?.let { msg ->
            Toast.makeText(context, msg, Toast.LENGTH_LONG).show()
            viewModel.clearImageStudioToast()
        }
    }

    val sampleSpiritualPrompts = listOf(
        "শ্রীকৃষ্ণের দিব্য রূপ" to "শ্রীকৃষ্ণের একটি দিব্য আধ্যাত্মিক রূপ, ময়ূরপুচ্ছ ও মোহন বাঁশি হাতে বৃন্দাবনের পটভূমি",
        "ধ্যানমগ্ন মহাদেব" to "কৈলাসে ধ্যানমগ্ন ভগবান শিব, জটাজুটে গঙ্গা ও চন্দ্রকলা, প্রশান্ত হিমালয় দৃশ্য",
        "মা দুর্গার রূপ" to "সিংহবাহিনী দেবী দুর্গার দিব্য জ্যোতির্ময় রূপ, স্বর্ণালঙ্কারে ভূষিত ও কল্যাণময়ী দৃষ্টি",
        "বৈদিক যজ্ঞবেদী" to "একটি প্রাচীন বৈদিক যজ্ঞবেদী, ঘৃতাহুতির পবিত্র অগ্নিশিখা ও ধূপধুনোর শান্ত পরিবেশ",
        "গঙ্গা আরতির দৃশ্য" to "বারাণসীর পবিত্র ঘাটে প্রদোষকালে সন্ধ্যার মহা গঙ্গা আরতির আলোকোজ্জ্বল মহিমা",
        "ভগবান শ্রী রামচন্দ্র" to "কোবণ্ড ধনুর্ধারী ভগবান শ্রী রামচন্দ্রের সৌম্য ও ন্যায়নিষ্ঠ রাজকীয় রূপ"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Header Banner
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = Icons.Default.Palette,
                                    contentDescription = null,
                                    tint = MaterialTheme.colorScheme.primary,
                                    modifier = Modifier.size(28.dp)
                                )
                                Spacer(modifier = Modifier.width(10.dp))
                                Text(
                                    text = "Dharma AI Image & Vision Studio",
                                    fontSize = 20.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                            }
                            Text(
                                text = "বাস্তব AI চিত্রণ ও আধ্যাত্মিক রূপ বিশ্লেষণ ইঞ্জিন (Real Generative Engine)",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                            )
                        }
                        StatusPill(
                            text = if (engineState == ImageGenerationStatus.GENERATING) "রেন্ডারিং..." else "সক্রিয়",
                            color = if (engineState == ImageGenerationStatus.GENERATING) StatusYellow else StatusGreen
                        )
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Metrics Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        MetricCardItem(
                            title = "মোট চিত্র",
                            value = totalCount.toString(),
                            icon = Icons.Default.PhotoLibrary,
                            modifier = Modifier.weight(1f)
                        )
                        MetricCardItem(
                            title = "সফল তৈরি",
                            value = successCount.toString(),
                            icon = Icons.Default.CheckCircle,
                            tint = Color(0xFF2E7D32),
                            modifier = Modifier.weight(1f)
                        )
                        MetricCardItem(
                            title = "ব্যর্থ প্রচেষ্টা",
                            value = failedCount.toString(),
                            icon = Icons.Default.Cancel,
                            tint = if (failedCount > 0) Color(0xFFC62828) else Color.Gray,
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            }
        }

        // 2. Tab Navigation
        item {
            val tabs = listOf(
                "🎨 স্টুডিও চিত্রণ" to 0,
                "🖼️ গ্যালারি ও ফাইল" to 1,
                "👁️ ভিশন বিশ্লেষণ" to 2,
                "⚙️ ইঞ্জিন আর্কিটেকচার" to 3
            )
            ScrollableTabRow(
                selectedTabIndex = state.activeTab,
                edgePadding = 0.dp,
                containerColor = Color.Transparent,
                divider = {}
            ) {
                tabs.forEach { (title, index) ->
                    Tab(
                        selected = state.activeTab == index,
                        onClick = { viewModel.setImageStudioTab(index) },
                        text = {
                            Text(
                                text = title,
                                fontWeight = if (state.activeTab == index) FontWeight.Bold else FontWeight.Normal,
                                fontSize = 14.sp
                            )
                        }
                    )
                }
            }
        }

        // 3. Tab Content
        when (state.activeTab) {
            0 -> {
                // TAB 0: Studio Playground
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "চিত্র নির্মাণের বিবরণ (Prompt)",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Spacer(modifier = Modifier.height(8.dp))

                            OutlinedTextField(
                                value = state.prompt,
                                onValueChange = { viewModel.setImageStudioPrompt(it) },
                                modifier = Modifier.fillMaxWidth(),
                                placeholder = { Text("কী ধরনের ছবি তৈরি করতে চান লিখুন...") },
                                minLines = 2,
                                maxLines = 4,
                                shape = RoundedCornerShape(12.dp)
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            // Sample Presets
                            Text(
                                text = "আধ্যাত্মিক থিম সাজেশন:",
                                fontSize = 12.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.primary
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            LazyRow(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                items(sampleSpiritualPrompts) { (label, fullPrompt) ->
                                    SuggestionChip(
                                        onClick = { viewModel.setImageStudioPrompt(fullPrompt) },
                                        label = { Text(label, fontSize = 12.sp) }
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            // Aspect Ratio Selection
                            Text(
                                text = "অনুপাত (Aspect Ratio):",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.SemiBold
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(ImageAspectRatio.values()) { ratio ->
                                    FilterChip(
                                        selected = state.aspectRatio == ratio,
                                        onClick = { viewModel.setImageStudioAspectRatio(ratio) },
                                        label = { Text("${ratio.displayName} (${ratio.ratioStr})", fontSize = 12.sp) }
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            // Quality & Dharma Enhancer Toggle
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(
                                        checked = state.isDharmaEnhanced,
                                        onCheckedChange = { viewModel.setImageStudioDharmaEnhanced(it) }
                                    )
                                    Text(
                                        text = "সনাতন শাস্ত্রীয় নান্দনিকতা বৃদ্ধি (Auto Dharma Enhancer)",
                                        fontSize = 13.sp
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(16.dp))

                            Button(
                                onClick = { viewModel.generateImageStudio() },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = !state.isGenerating && state.prompt.isNotBlank(),
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                if (state.isGenerating) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(20.dp),
                                        color = MaterialTheme.colorScheme.onPrimary,
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text("চিত্র তৈরি হচ্ছে... (Generating Real Image)")
                                } else {
                                    Icon(Icons.Default.AutoAwesome, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("বাস্তব ছবি তৈরি করুন (Generate Image)", fontSize = 15.sp)
                                }
                            }
                        }
                    }
                }

                // Active Generated Result Card
                if (state.activeResult != null) {
                    item {
                        GeneratedImageDetailCard(
                            result = state.activeResult!!,
                            onSaveToGallery = { path, title ->
                                val entity = GeneratedImageEntity(
                                    localFilePath = path,
                                    prompt = title
                                )
                                viewModel.saveGeneratedImageToGallery(entity)
                            },
                            onShare = { path, title ->
                                val intent = ImageStorageManager.getShareIntent(context, path, title)
                                if (intent != null) {
                                    context.startActivity(intent)
                                } else {
                                    Toast.makeText(context, "শেয়ারযোগ্য ফাইল পাওয়া যায়নি।", Toast.LENGTH_SHORT).show()
                                }
                            },
                            onVisionAnalyze = { path ->
                                viewModel.setImageStudioTab(2)
                                viewModel.understandImageWithVision(path, "এই ছবির আধ্যাত্মিক তাৎপর্য ও দর্শন ব্যাখ্যা করুন।")
                            }
                        )
                    }
                }
            }

            1 -> {
                // TAB 1: Image Gallery & Records
                if (allImages.isEmpty()) {
                    item {
                        Card(
                            modifier = Modifier.fillMaxWidth(),
                            shape = RoundedCornerShape(16.dp)
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(32.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(
                                    Icons.Default.PhotoLibrary,
                                    contentDescription = null,
                                    modifier = Modifier.size(48.dp),
                                    tint = MaterialTheme.colorScheme.primary.copy(alpha = 0.5f)
                                )
                                Spacer(modifier = Modifier.height(12.dp))
                                Text(
                                    text = "এখনও কোনো চিত্র তৈরি করা হয়নি।",
                                    fontSize = 16.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    text = "স্টুডিও বা পাবলিক চ্যাটে প্রম্পট দিয়ে চিত্র তৈরি করুন।",
                                    fontSize = 13.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                } else {
                    items(allImages) { imageEntity ->
                        ImageEntityCard(
                            image = imageEntity,
                            onSave = { viewModel.saveGeneratedImageToGallery(imageEntity) },
                            onDelete = { viewModel.deleteGeneratedImage(imageEntity) },
                            onShare = {
                                val intent = ImageStorageManager.getShareIntent(
                                    context,
                                    imageEntity.localFilePath,
                                    imageEntity.prompt
                                )
                                if (intent != null) context.startActivity(intent)
                            },
                            onVision = {
                                viewModel.setImageStudioTab(2)
                                viewModel.selectImageForStudio(imageEntity)
                                viewModel.understandImageWithVision(
                                    imageEntity.localFilePath,
                                    "এই ছবির আধ্যাত্মিক প্রতীক ও শাস্ত্রীয় ব্যাখ্যা দিন।"
                                )
                            }
                        )
                    }
                }
            }

            2 -> {
                // TAB 2: Vision & Understanding
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = "Dharma AI Vision & Image Understanding",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Text(
                                text = "যে কোনো আধ্যাত্মিক বা ধর্মীয় ছবির প্রতীকবিদ্যা, তাৎপর্য ও শাস্ত্রীয় রেফারেন্স বিশ্লেষণ।",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            Spacer(modifier = Modifier.height(16.dp))

                            // If an image is selected from gallery or active result
                            val targetPath = state.selectedImage?.localFilePath
                                ?: state.activeResult?.localFilePath

                            if (targetPath != null && File(targetPath).exists()) {
                                Box(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .height(200.dp)
                                        .clip(RoundedCornerShape(12.dp))
                                        .background(Color.Black)
                                ) {
                                    AsyncImage(
                                        model = File(targetPath),
                                        contentDescription = "Selected for vision",
                                        modifier = Modifier.fillMaxSize(),
                                        contentScale = ContentScale.Fit
                                    )
                                }
                                Spacer(modifier = Modifier.height(12.dp))
                            }

                            OutlinedTextField(
                                value = state.visionQuestion,
                                onValueChange = { q -> /* update question */ },
                                modifier = Modifier.fillMaxWidth(),
                                label = { Text("বিশ্লেষণের প্রশ্ন বা জিজ্ঞাসা") },
                                shape = RoundedCornerShape(12.dp)
                            )

                            Spacer(modifier = Modifier.height(12.dp))

                            Button(
                                onClick = {
                                    val path = targetPath ?: allImages.firstOrNull()?.localFilePath ?: ""
                                    if (path.isNotBlank()) {
                                        viewModel.understandImageWithVision(path, state.visionQuestion)
                                    } else {
                                        Toast.makeText(context, "বিশ্লেষণের জন্য কোনো ছবি নির্বাচিত নেই।", Toast.LENGTH_SHORT).show()
                                    }
                                },
                                modifier = Modifier.fillMaxWidth(),
                                enabled = !state.isUnderstanding,
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                if (state.isUnderstanding) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(20.dp),
                                        color = MaterialTheme.colorScheme.onPrimary,
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text("বিশ্লেষণ চলছে... (Analyzing Symbolism)")
                                } else {
                                    Icon(Icons.Default.Visibility, contentDescription = null)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("ছবি বিশ্লেষণ করুন (Analyze Image)")
                                }
                            }

                            if (state.visionResult != null) {
                                Spacer(modifier = Modifier.height(16.dp))
                                Card(
                                    modifier = Modifier.fillMaxWidth(),
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant)
                                ) {
                                    Column(modifier = Modifier.padding(14.dp)) {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Icon(Icons.Default.Psychology, contentDescription = null, tint = MaterialTheme.colorScheme.primary)
                                            Spacer(modifier = Modifier.width(8.dp))
                                            Text("বিশ্লেষণের ফলাফল:", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                                        }
                                        Spacer(modifier = Modifier.height(8.dp))
                                        Text(
                                            text = state.visionResult!!.analysisText,
                                            fontSize = 14.sp,
                                            lineHeight = 22.sp
                                        )
                                        if (state.visionResult!!.spiritualSignificance.isNotBlank()) {
                                            Spacer(modifier = Modifier.height(8.dp))
                                            Text(
                                                text = "🕉️ ${state.visionResult!!.spiritualSignificance}",
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = MaterialTheme.colorScheme.primary
                                            )
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            3 -> {
                // TAB 3: Engine Architecture & Audit
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            Text(
                                text = "AI Image Engine Architecture & Security",
                                fontWeight = FontWeight.Bold,
                                fontSize = 16.sp
                            )
                            Divider()

                            ArchitectureItem(
                                title = "Active Provider",
                                desc = "Google Gemini Image AI (Multimodal Generation)",
                                icon = Icons.Default.Hub
                            )
                            ArchitectureItem(
                                title = "Model Family",
                                desc = "gemini-2.5-flash-image (Native multimodal generation & editing)",
                                icon = Icons.Default.Memory
                            )
                            ArchitectureItem(
                                title = "Local Persistence",
                                desc = "Room Database (GeneratedImageEntity) & Internal App Storage",
                                icon = Icons.Default.Storage
                            )
                            ArchitectureItem(
                                title = "API Key Security",
                                desc = "Injected via Secure BuildConfig. No hardcoded credentials.",
                                icon = Icons.Default.Lock
                            )
                            ArchitectureItem(
                                title = "Dharma Integrity Protocol",
                                desc = "Preserves reverence for deities, temples, and scriptures. Zero fake mantra fabrication.",
                                icon = Icons.Default.Shield
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun MetricCardItem(
    title: String,
    value: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    tint: Color = MaterialTheme.colorScheme.primary,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(
            modifier = Modifier.padding(12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(22.dp))
            Spacer(modifier = Modifier.height(4.dp))
            Text(text = value, fontWeight = FontWeight.Bold, fontSize = 18.sp)
            Text(text = title, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@Composable
private fun GeneratedImageDetailCard(
    result: ImageGenerationResult,
    onSaveToGallery: (String, String) -> Unit,
    onShare: (String, String) -> Unit,
    onVisionAnalyze: (String) -> Unit
) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "সর্বশেষ তৈরি করা চিত্র (Latest Result)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp
                )
                StatusPill(
                    text = if (result.status == ImageGenerationStatus.SUCCESS) "সফল (SUCCESS)" else result.status.name,
                    color = if (result.status == ImageGenerationStatus.SUCCESS) StatusGreen else StatusRed
                )
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (result.status == ImageGenerationStatus.SUCCESS && result.localFilePath != null) {
                val file = File(result.localFilePath)
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(280.dp)
                        .clip(RoundedCornerShape(12.dp))
                        .background(Color.Black)
                ) {
                    AsyncImage(
                        model = file,
                        contentDescription = result.rawPrompt,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Fit
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Text(
                    text = "মূল প্রম্পট: \"${result.rawPrompt}\"",
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 14.sp
                )
                if (result.enhancedPrompt.isNotBlank()) {
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Enhanced Prompt: ${result.enhancedPrompt}",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Spacer(modifier = Modifier.height(12.dp))

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Button(
                        onClick = { onSaveToGallery(result.localFilePath, result.rawPrompt) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("গ্যালারিতে সেভ", fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = { onShare(result.localFilePath, result.rawPrompt) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("শেয়ার", fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = { onVisionAnalyze(result.localFilePath) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Visibility, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("বিশ্লেষণ", fontSize = 12.sp)
                    }
                }
            } else {
                Text(
                    text = result.errorMessage ?: "চিত্র নির্মাণ সম্পন্ন হয়নি।",
                    color = MaterialTheme.colorScheme.error,
                    fontSize = 14.sp
                )
            }
        }
    }
}

@Composable
private fun ImageEntityCard(
    image: GeneratedImageEntity,
    onSave: () -> Unit,
    onDelete: () -> Unit,
    onShare: () -> Unit,
    onVision: () -> Unit
) {
    val dateStr = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.getDefault()).format(Date(image.createdAt))
    val file = File(image.localFilePath)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            if (file.exists()) {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(Color.Black)
                ) {
                    AsyncImage(
                        model = file,
                        contentDescription = image.prompt,
                        modifier = Modifier.fillMaxSize(),
                        contentScale = ContentScale.Crop
                    )
                }
            } else {
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(MaterialTheme.colorScheme.surfaceVariant),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(Icons.Default.BrokenImage, contentDescription = null)
                }
            }

            Spacer(modifier = Modifier.width(12.dp))

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = image.prompt,
                    fontWeight = FontWeight.Bold,
                    fontSize = 14.sp,
                    maxLines = 2
                )
                Text(
                    text = "$dateStr • ${image.aspectRatio}",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(6.dp))

                Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                    IconButton(onClick = onSave, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Download, contentDescription = "Save", modifier = Modifier.size(16.dp))
                    }
                    IconButton(onClick = onShare, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Share, contentDescription = "Share", modifier = Modifier.size(16.dp))
                    }
                    IconButton(onClick = onVision, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Visibility, contentDescription = "Vision", modifier = Modifier.size(16.dp))
                    }
                    IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color.Red, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }
    }
}

@Composable
private fun ArchitectureItem(title: String, desc: String, icon: androidx.compose.ui.graphics.vector.ImageVector) {
    Row(verticalAlignment = Alignment.Top) {
        Icon(icon, contentDescription = null, tint = MaterialTheme.colorScheme.primary, modifier = Modifier.size(20.dp))
        Spacer(modifier = Modifier.width(10.dp))
        Column {
            Text(text = title, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
            Text(text = desc, fontSize = 12.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}
