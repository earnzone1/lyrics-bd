package com.example.ui.screens

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DevelopmentTaskEntity
import com.example.data.model.KnowledgeEntity
import com.example.data.model.KnowledgeVersionEntity
import com.example.data.model.UnknownKnowledgeEntity
import com.example.domain.ai.KnowledgeConflictResult
import com.example.domain.ai.KnowledgeMatchingEngine
import com.example.ui.components.StatusPill
import com.example.ui.theme.*
import com.example.ui.viewmodel.AdminChatMessage
import com.example.ui.viewmodel.ScreenDestination
import com.example.ui.viewmodel.VedaNovaViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeachAiScreen(viewModel: VedaNovaViewModel) {
    val teachState by viewModel.teachAiState.collectAsState()
    val allUnknown by viewModel.allUnknownKnowledge.collectAsState()
    val pendingUnknownCount by viewModel.pendingUnknownCount.collectAsState()
    val candidates by viewModel.candidateKnowledge.collectAsState()
    val allVersions by viewModel.allKnowledgeVersions.collectAsState()
    val usageLogs by viewModel.allUsageLogs.collectAsState()

    var showConflictDialog by remember { mutableStateOf(false) }
    var showSuccessSnackbar by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(teachState.successMessage) {
        teachState.successMessage?.let {
            snackbarHostState.showSnackbar(it)
        }
    }

    LaunchedEffect(teachState.conflictResult) {
        if (teachState.conflictResult != null && teachState.conflictResult?.hasConflict == true) {
            showConflictDialog = true
        }
    }

    val categories = listOf(
        "GENERAL_CONVERSATION" to "সাধারণ কথোপকথন (Greetings & Intro)",
        "HINDU_DHARMA" to "হিন্দু ধর্মজ্ঞান (Core Sanatan Dharma)",
        "DEITY" to "দেবতাতত্ত্ব (Deities & Avatars)",
        "MANTRA" to "মন্ত্র ও স্তোত্র (Mantras & Stotrams)",
        "SCRIPTURE" to "শাস্ত্রজ্ঞান (Gita, Vedas, Upanishads)",
        "FESTIVAL" to "উৎসব ও ব্রত (Festivals & Vratas)",
        "PUJA" to "পূজাবিধি ও নিয়ম (Puja & Rituals)",
        "BENGALI_MEANINGS" to "বাংলা অর্থ ও ব্যাখ্যা (Meanings)",
        "SANSKRIT_INFO" to "সংস্কৃত ব্যাকরণ ও তত্ত্ব (Sanskrit)"
    )

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 2.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { viewModel.navigateTo(ScreenDestination.DASHBOARD) }) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "Teach AI (জ্ঞান শিক্ষক ও শিক্ষার্থী ব্যবস্থা)",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Badge(
                                        containerColor = SaffronPrimary,
                                        contentColor = Color.White
                                    ) {
                                        Text("Phase 5", style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                                Text(
                                    text = "Human-Guided AI Learning • Conflict Shield • Version Snapshot",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Button(
                            onClick = { viewModel.clearTeachForm() },
                            colors = ButtonDefaults.outlinedButtonColors(),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("নতুন ফর্ম", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }

                // Sub-tabs
                ScrollableTabRow(
                    selectedTabIndex = teachState.activeTeachTab,
                    edgePadding = 16.dp,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = MaterialTheme.colorScheme.onSurface
                ) {
                    Tab(
                        selected = teachState.activeTeachTab == 0,
                        onClick = { viewModel.setTeachTab(0) },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Terminal, contentDescription = null, modifier = Modifier.size(16.dp), tint = SaffronPrimary)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("কমান্ড ও ফিচার তৈরি", fontWeight = FontWeight.Bold)
                            }
                        }
                    )
                    Tab(
                        selected = teachState.activeTeachTab == 1,
                        onClick = { viewModel.setTeachTab(1) },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.School, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("জ্ঞান শেখান")
                            }
                        }
                    )
                    Tab(
                        selected = teachState.activeTeachTab == 2,
                        onClick = { viewModel.setTeachTab(2) },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.HelpOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("অজ্ঞাত প্রশ্ন (${allUnknown.count { it.status == "PENDING" }})")
                            }
                        }
                    )
                    Tab(
                        selected = teachState.activeTeachTab == 3,
                        onClick = { viewModel.setTeachTab(3) },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.FactCheck, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Candidate অনুমোদন (${candidates.size})")
                            }
                        }
                    )
                    Tab(
                        selected = teachState.activeTeachTab == 4,
                        onClick = { viewModel.setTeachTab(4) },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("সংস্করণ ইতিহাস (${allVersions.size})")
                            }
                        }
                    )
                    Tab(
                        selected = teachState.activeTeachTab == 5,
                        onClick = { viewModel.setTeachTab(5) },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Insights, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("ব্যবহার ও ফিডব্যাক")
                            }
                        }
                    )
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when (teachState.activeTeachTab) {
                0 -> AdminCommandTab(viewModel = viewModel)
                1 -> TeachNewKnowledgeTab(
                    state = teachState,
                    categories = categories,
                    onUpdateField = { q, a, t, c, s, r, sk, tr, ex, cand ->
                        viewModel.updateTeachField(
                            question = q,
                            answer = a,
                            title = t,
                            category = c,
                            source = s,
                            reference = r,
                            sanskrit = sk,
                            transliteration = tr,
                            explanation = ex,
                            saveAsCandidate = cand
                        )
                    },
                    onSubmit = { viewModel.checkConflictAndTeachKnowledge(overrideConflict = false) }
                )
                2 -> UnknownKnowledgeQueueTab(
                    unknownList = allUnknown,
                    onTeach = { item -> viewModel.prefillTeachFromUnknown(item) },
                    onIgnore = { item -> viewModel.ignoreUnknownQuery(item) }
                )
                3 -> CandidateApprovalTab(
                    candidates = candidates,
                    onApprove = { item -> viewModel.approveCandidateKnowledge(item) },
                    onReject = { item -> viewModel.rejectCandidateKnowledge(item) }
                )
                4 -> VersionHistoryTab(versions = allVersions)
                5 -> UsageFeedbackTab(usageLogs = usageLogs)
                else -> AdminCommandTab(viewModel = viewModel)
            }
        }
    }

    // Conflict Resolution Dialog
    if (showConflictDialog && teachState.conflictResult != null) {
        val conflict = teachState.conflictResult!!
        AlertDialog(
            onDismissRequest = { showConflictDialog = false },
            icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = AmberAlert) },
            title = {
                Text("⚠️ Knowledge Conflict Detected", fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = conflict.conflictReason,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Divider()
                    Text("অসঙ্গতি ও পার্থক্যের বিবরণ:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    conflict.differences.forEach { diff ->
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "• $diff",
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                    Text(
                        text = "নিয়ম: Admin সিদ্ধান্ত না নেওয়া পর্যন্ত কোনো অসঙ্গতিপূর্ণ তথ্য production-এ সরাসরি প্রকাশ হবে না।",
                        style = MaterialTheme.typography.labelSmall,
                        color = SaffronPrimary
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showConflictDialog = false
                        viewModel.checkConflictAndTeachKnowledge(overrideConflict = true)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
                ) {
                    Text("নতুন সংস্করণ হিসেবে সংরক্ষণ করুন")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showConflictDialog = false }) {
                    Text("বাতিল করুন")
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TeachNewKnowledgeTab(
    state: com.example.ui.viewmodel.TeachAiState,
    categories: List<Pair<String, String>>,
    onUpdateField: (
        question: String?,
        answer: String?,
        title: String?,
        category: String?,
        source: String?,
        reference: String?,
        sanskrit: String?,
        transliteration: String?,
        explanation: String?,
        saveAsCandidate: Boolean?
    ) -> Unit,
    onSubmit: () -> Unit
) {
    var expandedCategory by remember { mutableStateOf(false) }
    var showAdvancedFields by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Pre-filled Indicator from Unknown Queue
        if (state.selectedUnknownId != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SaffronPrimary.copy(alpha = 0.12f)),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, SaffronPrimary.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.HelpCenter, contentDescription = null, tint = SaffronPrimary)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Teaching from Unknown Query Queue (#${state.selectedUnknownId})",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = SaffronPrimary
                            )
                            Text(
                                text = "AI এই প্রশ্নের নির্ভরযোগ্য উত্তর জানে না। আপনি যে উত্তর প্রদান করবেন তা যাচাইকৃত ডাটাবেসে সেভ হবে।",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }

        // Error Banner
        if (state.errorMessage != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = state.errorMessage,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }
        }

        // Core Teaching Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.EditNote, contentDescription = null, tint = SaffronPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "১. প্রশ্ন ও নির্ভুল উত্তর (Core Q&A)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // Question
                    OutlinedTextField(
                        value = state.question,
                        onValueChange = { onUpdateField(it, null, null, null, null, null, null, null, null, null) },
                        label = { Text("প্রশ্ন (User Query / Trigger Question) *") },
                        placeholder = { Text("যেমন: হিন্দু ধর্ম কী? অথবা গায়ত্রী মন্ত্রের অর্থ কী?") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2,
                        shape = RoundedCornerShape(12.dp)
                    )

                    // Answer
                    OutlinedTextField(
                        value = state.answer,
                        onValueChange = { onUpdateField(null, it, null, null, null, null, null, null, null, null) },
                        label = { Text("সঠিক ও প্রামাণ্য উত্তর (Verified Canonical Answer) *") },
                        placeholder = { Text("এখানে প্রামাণ্য, সুস্পষ্ট ও নিরপেক্ষ ব্যাখ্যা লিখুন...") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 4,
                        shape = RoundedCornerShape(12.dp)
                    )

                    // Title
                    OutlinedTextField(
                        value = state.title,
                        onValueChange = { onUpdateField(null, null, it, null, null, null, null, null, null, null) },
                        label = { Text("শিরোনাম বা বিষয়বস্তু (Title / Topic Name)") },
                        placeholder = { Text("যেমন: গায়ত্রী মন্ত্র / হিন্দু ধর্মের পরিচয়") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }
        }

        // Category & Authority Source
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Category, contentDescription = null, tint = SaffronPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "২. ক্যাটাগরি ও শাস্ত্রীয় উৎস (Taxonomy & Source)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // Category Dropdown
                    ExposedDropdownMenuBox(
                        expanded = expandedCategory,
                        onExpandedChange = { expandedCategory = !expandedCategory }
                    ) {
                        OutlinedTextField(
                            value = categories.find { it.first == state.category }?.second ?: state.category,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("ক্যাটাগরি নির্বাচন করুন *") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedCategory) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(),
                            shape = RoundedCornerShape(12.dp)
                        )
                        ExposedDropdownMenu(
                            expanded = expandedCategory,
                            onDismissRequest = { expandedCategory = false }
                        ) {
                            categories.forEach { (catKey, catLabel) ->
                                DropdownMenuItem(
                                    text = { Text(catLabel) },
                                    onClick = {
                                        onUpdateField(null, null, null, catKey, null, null, null, null, null, null)
                                        expandedCategory = false
                                    }
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = state.source,
                            onValueChange = { onUpdateField(null, null, null, null, it, null, null, null, null, null) },
                            label = { Text("উৎস (Source)") },
                            placeholder = { Text("বেদ / গীতা / পুরাণ") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        )
                        OutlinedTextField(
                            value = state.reference,
                            onValueChange = { onUpdateField(null, null, null, null, null, it, null, null, null, null) },
                            label = { Text("সূত্র / রেফারেন্স (Citation)") },
                            placeholder = { Text("ঋগ্বেদ ৩.৬২.১০") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }
            }
        }

        // Advanced Fields (Sanskrit Shloka / Transliteration / Deep Explanation)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showAdvancedFields = !showAdvancedFields },
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.AutoMirrored.Filled.MenuBook, contentDescription = null, tint = SaffronPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "৩. ঐচ্ছিক সংস্কৃত শ্লোক ও বিশ্লেষণ (Advanced)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Icon(
                            if (showAdvancedFields) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = null
                        )
                    }

                    AnimatedVisibility(visible = showAdvancedFields) {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            OutlinedTextField(
                                value = state.sanskritText,
                                onValueChange = { onUpdateField(null, null, null, null, null, null, it, null, null, null) },
                                label = { Text("মূল দেবনাগরী বা সংস্কৃত শ্লোক (Sanskrit Text)") },
                                placeholder = { Text("ॐ भूर्भुवः स्वः...") },
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 2,
                                shape = RoundedCornerShape(12.dp)
                            )
                            OutlinedTextField(
                                value = state.transliteration,
                                onValueChange = { onUpdateField(null, null, null, null, null, null, null, it, null, null) },
                                label = { Text("IAST / উচ্চারণ লিপ্যন্তর (Transliteration)") },
                                placeholder = { Text("oṃ bhūr bhuvaḥ svaḥ...") },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            )
                            OutlinedTextField(
                                value = state.explanation,
                                onValueChange = { onUpdateField(null, null, null, null, null, null, null, null, it, null) },
                                label = { Text("দার্শনিক তাৎপর্য ও মাহাত্ম্য (Detailed Philosophy)") },
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 3,
                                shape = RoundedCornerShape(12.dp)
                            )
                        }
                    }
                }
            }
        }

        // Publishing Strategy & Actions
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "৪. প্রকাশনা ও সুরক্ষা নীতি (Publishing Policy)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SaffronPrimary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = state.saveAsCandidate,
                            onCheckedChange = { onUpdateField(null, null, null, null, null, null, null, null, null, it) }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Save as Candidate (সরাসরি প্রকাশ না করে অনুমোদনের জন্য রাখুন)",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "অনুমোদিত না হওয়া পর্যন্ত AI এই জ্ঞানটি public chat-এ ব্যবহার করবে না।",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = onSubmit,
                            enabled = !state.isSaving && (state.question.isNotBlank() || state.title.isNotBlank()) && state.answer.isNotBlank(),
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            if (state.isSaving) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("যাচাই হচ্ছে...")
                            } else {
                                Icon(
                                    if (state.saveAsCandidate) Icons.Default.BookmarkAdd else Icons.Default.Publish,
                                    contentDescription = null
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(if (state.saveAsCandidate) "Save as Candidate" else "যাচাই ও প্রকাশ করুন")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun UnknownKnowledgeQueueTab(
    unknownList: List<UnknownKnowledgeEntity>,
    onTeach: (UnknownKnowledgeEntity) -> Unit,
    onIgnore: (UnknownKnowledgeEntity) -> Unit
) {
    if (unknownList.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SaffronPrimary, modifier = Modifier.size(56.dp))
                Spacer(modifier = Modifier.height(12.dp))
                Text("কোনো অজ্ঞাত প্রশ্ন পেন্ডিং নেই!", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("AI সকল জিজ্ঞাসার যাচাইকৃত উত্তর প্রদান করতে সক্ষম হয়েছে।", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Queue, contentDescription = null, tint = SaffronPrimary)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "AI Unknown Knowledge Queue",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "ইউজারদের যে সকল প্রশ্নের যাচাইকৃত তথ্য AI এর ডাটাবেসে নেই তা এখানে জমা হয়। এখান থেকে সরাসরি AI-কে শেখাতে পারবেন।",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        items(unknownList) { item ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(
                    1.dp,
                    if (item.status == "PENDING") SaffronPrimary.copy(alpha = 0.6f) else MaterialTheme.colorScheme.outline
                )
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                color = if (item.status == "PENDING") AmberAlert.copy(alpha = 0.2f) else MaterialTheme.colorScheme.primaryContainer,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = item.status,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (item.status == "PENDING") AmberAlert else MaterialTheme.colorScheme.primary
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                color = MaterialTheme.colorScheme.secondaryContainer,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = "Frequency: ${item.frequency}x",
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }

                        Text(
                            text = SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(Date(item.createdAt)),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Text(
                        text = "❓ ${item.userQuestion}",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("🤖 AI Fallback Response:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = SaffronPrimary)
                            Text(item.aiResponse, style = MaterialTheme.typography.bodySmall)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("🔍 Why Unknown: ${item.whyUnknown}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (item.status == "PENDING") {
                            TextButton(onClick = { onIgnore(item) }) {
                                Text("Ignore", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = { onTeach(item) },
                                colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
                            ) {
                                Icon(Icons.Default.School, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("AI-কে শেখান")
                            }
                        } else {
                            Text(
                                text = "✅ Resolved (KB #${item.resolvedKnowledgeId})",
                                style = MaterialTheme.typography.labelMedium,
                                color = EmeraldGreen,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CandidateApprovalTab(
    candidates: List<KnowledgeEntity>,
    onApprove: (KnowledgeEntity) -> Unit,
    onReject: (KnowledgeEntity) -> Unit
) {
    if (candidates.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.Verified, contentDescription = null, tint = EmeraldGreen, modifier = Modifier.size(56.dp))
                Spacer(modifier = Modifier.height(12.dp))
                Text("কোনো Candidate অনুমোদনের জন্য অপেক্ষমাণ নেই", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("সকল নলেজ রেকর্ড যাচাইকৃত অবস্থায় রয়েছে।", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Gavel, contentDescription = null, tint = SaffronPrimary)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("Knowledge Candidate Approval Center", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Text("Lifecycle: Candidate -> Validation Check -> Review -> Approve & Publish (Version v1)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        items(candidates) { candidate ->
            val validation = remember(candidate) { KnowledgeMatchingEngine.validateCandidate(candidate) }

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, if (validation.isValid) EmeraldGreen.copy(alpha = 0.5f) else AmberAlert)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "Code: ${candidate.knowledgeCode.ifBlank { "KB-${candidate.id}" }}",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Surface(
                            color = if (validation.isValid) EmeraldGreen.copy(alpha = 0.15f) else AmberAlert.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    if (validation.isValid) Icons.Default.CheckCircle else Icons.Default.Warning,
                                    contentDescription = null,
                                    tint = if (validation.isValid) EmeraldGreen else AmberAlert,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (validation.isValid) "Validation: Passed" else "Validation: Needs Review",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (validation.isValid) EmeraldGreen else AmberAlert
                                )
                            }
                        }
                    }

                    Text(
                        text = candidate.title.ifBlank { candidate.question },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    if (candidate.question.isNotBlank() && candidate.question != candidate.title) {
                        Text(
                            text = "❓ Question: ${candidate.question}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("📖 Answer:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = SaffronPrimary)
                            Text(candidate.answer.ifBlank { candidate.banglaMeaning }, style = MaterialTheme.typography.bodySmall)
                            if (candidate.source.isNotBlank() || candidate.reference.isNotBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("🏛️ Source: ${candidate.source} (${candidate.reference})", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = { onReject(candidate) },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                        ) {
                            Text("Reject")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { onApprove(candidate) },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Approve & Publish")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun VersionHistoryTab(versions: List<KnowledgeVersionEntity>) {
    if (versions.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("কোনো সংস্করণ রেকর্ড পাওয়া যায়নি।", style = MaterialTheme.typography.bodyMedium)
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.HistoryEdu, contentDescription = null, tint = SaffronPrimary)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("Knowledge Version Control & Audit Trail", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Text("নিয়ম: পুরোনো knowledge কখনো মুছে ফেলা হয় না; প্রতি আপডেটে নতুন সংস্করণ (v1, v2) তৈরি হয়।", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        items(versions) { ver ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Badge(containerColor = SaffronPrimary, contentColor = Color.White) {
                                Text("v${ver.versionNumber}")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(ver.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        }

                        Text(
                            text = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(ver.timestamp)),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Text("📝 Diff / Reason: ${ver.changeReason}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, color = SaffronPrimary)
                    Text("👤 Author / Modifier: ${ver.changedBy}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = ver.answer.take(160) + if (ver.answer.length > 160) "..." else "",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun UsageFeedbackTab(usageLogs: List<com.example.data.model.KnowledgeUsageLogEntity>) {
    if (usageLogs.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("কোনো ব্যবহারের লগ নেই।", style = MaterialTheme.typography.bodyMedium)
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.TrendingUp, contentDescription = null, tint = SaffronPrimary)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("Knowledge Usage & Feedback Loop", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Text("AI response-এ কোন জ্ঞানটি ম্যাচ করেছে, কনফিডেন্স স্কোর কত এবং ইউজারের ফিডব্যাক ট্র্যাকিং।", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        items(usageLogs) { log ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Query: \"${log.userQuery}\"",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(4.dp)) {
                                Text(
                                    text = log.matchedStrategy,
                                    style = MaterialTheme.typography.labelSmall,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Confidence: ${(log.confidence * 100).toInt()}% • KB ID #${log.knowledgeId}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Surface(
                        color = if (log.feedbackScore >= 0) EmeraldGreen.copy(alpha = 0.15f) else MaterialTheme.colorScheme.errorContainer,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = if (log.feedbackScore >= 0) "👍 Positive" else "👎 Correction",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (log.feedbackScore >= 0) EmeraldGreen else MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AdminCommandTab(viewModel: VedaNovaViewModel) {
    val commandState by viewModel.adminCommandState.collectAsState()
    val pendingTasks by viewModel.pendingApprovalTasks.collectAsState()
    val listState = rememberLazyListState()

    var showAttachMenu by remember { mutableStateOf(false) }
    var expandedLogsTaskId by remember { mutableStateOf<String?>(null) }
    var expandedChangesTaskId by remember { mutableStateOf<String?>(null) }
    var confirmDestructiveTask by remember { mutableStateOf<DevelopmentTaskEntity?>(null) }

    val photoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let { viewModel.setAdminCommandAttachedMedia(it.toString(), "IMAGE") }
    }

    val videoLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.GetContent()
    ) { uri ->
        uri?.let { viewModel.setAdminCommandAttachedMedia(it.toString(), "VIDEO") }
    }

    // Auto-scroll on new messages
    LaunchedEffect(commandState.chatHistory.size) {
        if (commandState.chatHistory.isNotEmpty()) {
            listState.animateScrollToItem(commandState.chatHistory.size)
        }
    }

    // Destructive Action Confirmation Dialog (Rule 11)
    confirmDestructiveTask?.let { task ->
        AlertDialog(
            onDismissRequest = { confirmDestructiveTask = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Warning, contentDescription = null, tint = StatusRed, modifier = Modifier.size(24.dp))
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("অতিরিক্ত সুরক্ষা নিশ্চিতকরণ (Destructive Action)", fontWeight = FontWeight.Bold, fontSize = 14.sp)
                }
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                    Text(
                        text = "আপনি কি নিশ্চিত যে আপনি '${task.title}' এক্সিকিউট করতে চান?",
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold
                    )
                    Text(
                        text = "টার্গেট: ${task.targetLocation}\nপ্রভাব: ${task.impactAssessment}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Text(
                        text = "⚠️ এই অপারেশনের পর মুছে ফেলা ডেটাবেস লগ বা কনফিগারেশন রিকভার করা সম্ভব নাও হতে পারে।",
                        style = MaterialTheme.typography.labelSmall,
                        color = StatusRed,
                        fontSize = 10.sp
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val taskToExecute = confirmDestructiveTask
                        confirmDestructiveTask = null
                        taskToExecute?.let { viewModel.approveDevelopmentTask(it) }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusRed)
                ) {
                    Text("হ্যাঁ, এক্সিকিউট করো", color = Color.White, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { confirmDestructiveTask = null }) {
                    Text("বাতিল")
                }
            }
        )
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
    ) {
        // --- Command Center Top Header ---
        Surface(
            color = MaterialTheme.colorScheme.surfaceVariant,
            tonalElevation = 2.dp,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
        ) {
            Column(modifier = Modifier.padding(horizontal = 16.dp, vertical = 10.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(SaffronPrimary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.Terminal, contentDescription = null, tint = SaffronPrimary, modifier = Modifier.size(18.dp))
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Text(
                                    text = "Dharma AI Command Center",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Surface(
                                    color = StatusGreen.copy(alpha = 0.15f),
                                    shape = RoundedCornerShape(4.dp)
                                ) {
                                    Text(
                                        text = "STEP 3 REAL ENGINE",
                                        color = StatusGreen,
                                        style = MaterialTheme.typography.labelSmall,
                                        fontSize = 9.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                                    )
                                }
                            }
                            Text(
                                text = "Understand → Analyze → Propose → Approve → Execute → Test",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                fontSize = 11.sp
                            )
                        }
                    }

                    if (pendingTasks.isNotEmpty()) {
                        Button(
                            onClick = { viewModel.navigateTo(ScreenDestination.PROJECT_MONITOR) },
                            shape = RoundedCornerShape(8.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = StatusYellow)
                        ) {
                            Text("Pending (${pendingTasks.size})", color = Color.Black, fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelSmall)
                        }
                    }
                }
            }
        }

        // --- Notifications / Feedback Banners ---
        commandState.errorMessage?.let { error ->
            Card(
                colors = CardDefaults.cardColors(containerColor = StatusRed.copy(alpha = 0.12f)),
                shape = RoundedCornerShape(0.dp),
                border = BorderStroke(1.dp, StatusRed.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "❌ $error", color = StatusRed, style = MaterialTheme.typography.bodySmall)
                    IconButton(onClick = { viewModel.dismissAdminCommandError() }, modifier = Modifier.size(20.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Dismiss", tint = StatusRed, modifier = Modifier.size(14.dp))
                    }
                }
            }
        }

        commandState.successMessage?.let { success ->
            Card(
                colors = CardDefaults.cardColors(containerColor = StatusGreen.copy(alpha = 0.12f)),
                shape = RoundedCornerShape(0.dp),
                border = BorderStroke(1.dp, StatusGreen.copy(alpha = 0.4f)),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 14.dp, vertical = 8.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StatusGreen, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(text = success, color = MaterialTheme.colorScheme.onSurface, style = MaterialTheme.typography.bodySmall)
                    }
                    IconButton(onClick = { viewModel.dismissAdminCommandSuccess() }, modifier = Modifier.size(20.dp)) {
                        Icon(Icons.Default.Close, contentDescription = "Dismiss", modifier = Modifier.size(14.dp))
                    }
                }
            }
        }

        // --- Quick Command Suggestions Bar ---
        Surface(
            color = MaterialTheme.colorScheme.surface,
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)) {
                Text(
                    text = "দ্রুত নির্দেশনাসমূহ (Quick Admin Commands):",
                    style = MaterialTheme.typography.labelSmall,
                    fontWeight = FontWeight.SemiBold,
                    color = VedicGold,
                    fontSize = 11.sp
                )
                Spacer(modifier = Modifier.height(4.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(
                        "Voice ঠিক করো",
                        "এই সমস্যাটা খুঁজে ঠিক করো",
                        "আবার test করো",
                        "সবকিছু ঠিক আছে কি না check করো"
                    ).forEach { cmd ->
                        SuggestionChip(
                            onClick = {
                                viewModel.updateAdminCommandInstruction(cmd)
                                viewModel.sendAdminCommandMessage(cmd)
                            },
                            label = { Text(cmd, fontSize = 11.sp) },
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.height(28.dp)
                        )
                    }
                }
                Spacer(modifier = Modifier.height(2.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    listOf(
                        "এই screenshot দেখে সমস্যা বের করো",
                        "এই function-টা এই screen-এ যোগ করো"
                    ).forEach { cmd ->
                        SuggestionChip(
                            onClick = {
                                viewModel.updateAdminCommandInstruction(cmd)
                                if (cmd.contains("screenshot")) {
                                    viewModel.setAdminCommandAttachedMedia("android.resource://com.example/drawable/sample_admin_screenshot", "IMAGE")
                                }
                            },
                            label = { Text(cmd, fontSize = 11.sp) },
                            shape = RoundedCornerShape(6.dp),
                            modifier = Modifier.height(28.dp)
                        )
                    }
                }
            }
        }

        // --- Chat Messages List ---
        LazyColumn(
            state = listState,
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth()
                .padding(horizontal = 12.dp),
            verticalArrangement = Arrangement.spacedBy(12.dp),
            contentPadding = PaddingValues(vertical = 12.dp)
        ) {
            items(commandState.chatHistory, key = { it.id }) { message ->
                AdminCommandMessageItem(
                    message = message,
                    isExpandedLogs = expandedLogsTaskId == message.task?.taskCode,
                    onToggleLogs = {
                        expandedLogsTaskId = if (expandedLogsTaskId == message.task?.taskCode) null else message.task?.taskCode
                    },
                    isExpandedChanges = expandedChangesTaskId == message.task?.taskCode,
                    onToggleChanges = {
                        expandedChangesTaskId = if (expandedChangesTaskId == message.task?.taskCode) null else message.task?.taskCode
                    },
                    onApprove = { task ->
                        if (task.impactAssessment.contains("Destructive", ignoreCase = true) || task.category == "DESTRUCTIVE_OPERATION") {
                            confirmDestructiveTask = task
                        } else {
                            viewModel.approveDevelopmentTask(task)
                        }
                    },
                    onReject = { task -> viewModel.rejectDevelopmentTask(task) },
                    onNavigateToMonitor = { viewModel.navigateTo(ScreenDestination.PROJECT_MONITOR) }
                )
            }

            if (commandState.isProcessing) {
                item {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(18.dp),
                            color = SaffronPrimary,
                            strokeWidth = 2.dp
                        )
                        Spacer(modifier = Modifier.width(10.dp))
                        Text(
                            text = "Analyzing codebase architecture, components & test specs...",
                            style = MaterialTheme.typography.bodySmall,
                            color = SaffronLight
                        )
                    }
                }
            }
        }

        // --- Attached Media Preview Banner ---
        if (commandState.attachedImageUri != null) {
            Surface(
                color = MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(1.dp, SaffronPrimary.copy(alpha = 0.5f)),
                shape = RoundedCornerShape(topStart = 8.dp, topEnd = 8.dp),
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 12.dp)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 6.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(
                            if (commandState.attachedMediaType == "VIDEO") Icons.Default.Videocam else Icons.Default.Image,
                            contentDescription = null,
                            tint = SaffronPrimary,
                            modifier = Modifier.size(20.dp)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = if (commandState.attachedMediaType == "VIDEO") "Video Attached for Visual Analysis" else "Screenshot / Image Attached for Diagnostic",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    IconButton(
                        onClick = { viewModel.setAdminCommandAttachedMedia(null) },
                        modifier = Modifier.size(24.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = "Remove Media", tint = StatusRed, modifier = Modifier.size(16.dp))
                    }
                }
            }
        }

        // --- Bottom Command Input Bar ---
        Surface(
            color = MaterialTheme.colorScheme.surface,
            tonalElevation = 4.dp,
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 10.dp, vertical = 8.dp),
                verticalAlignment = Alignment.CenterVertically
            ) {
                // Media Attachment Options
                Box {
                    IconButton(
                        onClick = { showAttachMenu = true },
                        modifier = Modifier.size(38.dp)
                    ) {
                        Icon(
                            Icons.Default.AttachFile,
                            contentDescription = "Attach Media",
                            tint = if (commandState.attachedImageUri != null) SaffronPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    DropdownMenu(
                        expanded = showAttachMenu,
                        onDismissRequest = { showAttachMenu = false }
                    ) {
                        DropdownMenuItem(
                            text = { Text("Attach Screenshot / Image") },
                            leadingIcon = { Icon(Icons.Default.PhotoLibrary, contentDescription = null) },
                            onClick = {
                                showAttachMenu = false
                                try {
                                    photoLauncher.launch("image/*")
                                } catch (e: Exception) {
                                    viewModel.setAdminCommandAttachedMedia("android.resource://com.example/drawable/sample_admin_screenshot", "IMAGE")
                                }
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Attach Video Recording") },
                            leadingIcon = { Icon(Icons.Default.Videocam, contentDescription = null) },
                            onClick = {
                                showAttachMenu = false
                                try {
                                    videoLauncher.launch("video/*")
                                } catch (e: Exception) {
                                    viewModel.setAdminCommandAttachedMedia("android.resource://com.example/raw/sample_admin_video", "VIDEO")
                                }
                            }
                        )
                        DropdownMenuItem(
                            text = { Text("Use Sample Screenshot") },
                            leadingIcon = { Icon(Icons.Default.Image, contentDescription = null) },
                            onClick = {
                                showAttachMenu = false
                                viewModel.setAdminCommandAttachedMedia("android.resource://com.example/drawable/ic_vedic_logo", "IMAGE")
                            }
                        )
                    }
                }

                // Voice Input / Mic Trigger
                IconButton(
                    onClick = {
                        viewModel.triggerSingleVoiceInput()
                    },
                    modifier = Modifier.size(38.dp)
                ) {
                    Icon(
                        Icons.Default.Mic,
                        contentDescription = "Voice Input",
                        tint = VedicGold
                    )
                }

                // Instruction Input Field
                OutlinedTextField(
                    value = commandState.instruction,
                    onValueChange = { viewModel.updateAdminCommandInstruction(it) },
                    placeholder = {
                        Text(
                            "স্বাভাবিক ভাষায় নির্দেশ দিন (যেমন: 'Voice ঠিক করো')...",
                            fontSize = 12.sp,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    },
                    modifier = Modifier
                        .weight(1f)
                        .padding(horizontal = 4.dp),
                    shape = RoundedCornerShape(20.dp),
                    maxLines = 3,
                    colors = OutlinedTextFieldDefaults.colors(
                        focusedBorderColor = SaffronPrimary,
                        unfocusedBorderColor = MaterialTheme.colorScheme.outline
                    )
                )

                // Send Button
                IconButton(
                    onClick = { viewModel.sendAdminCommandMessage() },
                    enabled = !commandState.isProcessing && (commandState.instruction.isNotBlank() || commandState.attachedImageUri != null),
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(
                            if (commandState.isProcessing || (commandState.instruction.isBlank() && commandState.attachedImageUri == null))
                                MaterialTheme.colorScheme.surfaceVariant
                            else SaffronPrimary
                        )
                ) {
                    if (commandState.isProcessing) {
                        CircularProgressIndicator(modifier = Modifier.size(18.dp), color = Color.Black, strokeWidth = 2.dp)
                    } else {
                        Icon(
                            Icons.Default.Send,
                            contentDescription = "Execute Command",
                            tint = if (commandState.instruction.isNotBlank() || commandState.attachedImageUri != null) Color.Black else MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(18.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun AdminCommandMessageItem(
    message: AdminChatMessage,
    isExpandedLogs: Boolean,
    onToggleLogs: () -> Unit,
    isExpandedChanges: Boolean,
    onToggleChanges: () -> Unit,
    onApprove: (DevelopmentTaskEntity) -> Unit,
    onReject: (DevelopmentTaskEntity) -> Unit,
    onNavigateToMonitor: () -> Unit
) {
    val isUser = message.sender == "ADMIN"

    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        if (!isUser) {
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(VedicGold.copy(alpha = 0.2f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.SmartToy, contentDescription = "AI", tint = VedicGold, modifier = Modifier.size(18.dp))
            }
            Spacer(modifier = Modifier.width(8.dp))
        }

        Column(
            modifier = Modifier.widthIn(max = 320.dp),
            horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
        ) {
            // Text Card
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = if (isUser) SaffronPrimary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant
                ),
                shape = RoundedCornerShape(
                    topStart = 14.dp,
                    topEnd = 14.dp,
                    bottomStart = if (isUser) 14.dp else 2.dp,
                    bottomEnd = if (isUser) 2.dp else 14.dp
                ),
                border = BorderStroke(
                    1.dp,
                    if (isUser) SaffronPrimary.copy(alpha = 0.4f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                )
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        text = if (isUser) "ADMIN" else "DHARMA AI CORE",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (isUser) SaffronLight else VedicGold,
                        fontSize = 10.sp
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = message.message,
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 13.sp
                    )

                    // Attached Media Indicator
                    if (message.attachedImageUri != null) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Surface(
                            color = MaterialTheme.colorScheme.surface.copy(alpha = 0.6f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    if (message.mediaType == "VIDEO") Icons.Default.Videocam else Icons.Default.Image,
                                    contentDescription = null,
                                    tint = SaffronPrimary,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (message.mediaType == "VIDEO") "Video Attached" else "Screenshot Attached",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontSize = 10.sp
                                )
                            }
                        }
                    }
                }
            }

            // Embedded Development Task Card
            message.task?.let { task ->
                Spacer(modifier = Modifier.height(8.dp))
                TaskProposalCard(
                    task = task,
                    isExpandedLogs = isExpandedLogs,
                    onToggleLogs = onToggleLogs,
                    isExpandedChanges = isExpandedChanges,
                    onToggleChanges = onToggleChanges,
                    onApprove = { onApprove(task) },
                    onReject = { onReject(task) },
                    onNavigateToMonitor = onNavigateToMonitor
                )
            }
        }

        if (isUser) {
            Spacer(modifier = Modifier.width(8.dp))
            Box(
                modifier = Modifier
                    .size(32.dp)
                    .clip(CircleShape)
                    .background(SaffronPrimary.copy(alpha = 0.25f)),
                contentAlignment = Alignment.Center
            ) {
                Icon(Icons.Default.Person, contentDescription = "Admin", tint = SaffronPrimary, modifier = Modifier.size(18.dp))
            }
        }
    }
}

@Composable
fun TaskProposalCard(
    task: DevelopmentTaskEntity,
    isExpandedLogs: Boolean,
    onToggleLogs: () -> Unit,
    isExpandedChanges: Boolean,
    onToggleChanges: () -> Unit,
    onApprove: () -> Unit,
    onReject: () -> Unit,
    onNavigateToMonitor: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = CosmicNavyElevated),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(
            1.dp,
            when (task.status) {
                "COMPLETED" -> StatusGreen.copy(alpha = 0.6f)
                "WAITING_FOR_APPROVAL" -> StatusYellow.copy(alpha = 0.8f)
                "REJECTED" -> StatusRed.copy(alpha = 0.5f)
                else -> VedicGold.copy(alpha = 0.5f)
            }
        ),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Header Row: Code + Status Pill
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(
                        text = task.taskCode,
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = VedicGold,
                        fontSize = 11.sp
                    )
                    Spacer(modifier = Modifier.width(6.dp))
                    Surface(
                        color = Color(0xFF1E1035),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = "[${task.category}]",
                            color = SaffronLight,
                            style = MaterialTheme.typography.labelSmall,
                            fontSize = 9.sp,
                            modifier = Modifier.padding(horizontal = 4.dp, vertical = 1.dp)
                        )
                    }
                }

                StatusPill(
                    text = task.status,
                    color = when (task.status) {
                        "COMPLETED" -> StatusGreen
                        "FAILED" -> StatusRed
                        "REJECTED" -> StatusRed
                        "WAITING_FOR_APPROVAL" -> StatusYellow
                        else -> SaffronPrimary
                    }
                )
            }

            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = task.title,
                style = MaterialTheme.typography.bodyMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                fontSize = 13.sp
            )

            Text(
                text = "Target: ${task.targetLocation}",
                style = MaterialTheme.typography.bodySmall,
                color = Color.LightGray,
                fontSize = 11.sp
            )

            // Impact Assessment
            Spacer(modifier = Modifier.height(4.dp))
            Surface(
                color = if (task.impactAssessment.contains("Approval") || task.impactAssessment.contains("Critical"))
                    StatusYellow.copy(alpha = 0.15f)
                else StatusGreen.copy(alpha = 0.15f),
                shape = RoundedCornerShape(4.dp)
            ) {
                Text(
                    text = "Impact: ${task.impactAssessment}",
                    color = if (task.impactAssessment.contains("Approval") || task.impactAssessment.contains("Critical")) StatusYellow else StatusGreen,
                    style = MaterialTheme.typography.labelSmall,
                    fontSize = 10.sp,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                )
            }

            // Expandable Proposed Changes
            Spacer(modifier = Modifier.height(6.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggleChanges() }
                    .padding(vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Architecture & Code Actions",
                    style = MaterialTheme.typography.labelSmall,
                    color = SaffronPrimary,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 11.sp
                )
                Icon(
                    if (isExpandedChanges) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = SaffronPrimary,
                    modifier = Modifier.size(16.dp)
                )
            }

            AnimatedVisibility(visible = isExpandedChanges) {
                Surface(
                    color = Color(0xFF090314),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                ) {
                    Text(
                        text = task.proposedChanges,
                        style = MaterialTheme.typography.bodySmall,
                        color = Color.White,
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }

            // Expandable Execution Logs / Test Plan
            Spacer(modifier = Modifier.height(4.dp))
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .clickable { onToggleLogs() }
                    .padding(vertical = 2.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "Pipeline Logs & Test Verifications",
                    style = MaterialTheme.typography.labelSmall,
                    color = VedicGold,
                    fontWeight = FontWeight.SemiBold,
                    fontSize = 11.sp
                )
                Icon(
                    if (isExpandedLogs) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                    contentDescription = null,
                    tint = VedicGold,
                    modifier = Modifier.size(16.dp)
                )
            }

            AnimatedVisibility(visible = isExpandedLogs) {
                Surface(
                    color = Color(0xFF07040D),
                    shape = RoundedCornerShape(6.dp),
                    modifier = Modifier.fillMaxWidth().padding(top = 4.dp)
                ) {
                    Text(
                        text = task.executionLogs.ifBlank { "No execution logs available yet." },
                        style = MaterialTheme.typography.bodySmall,
                        color = Color(0xFF81C784),
                        fontFamily = FontFamily.Monospace,
                        fontSize = 10.sp,
                        modifier = Modifier.padding(8.dp)
                    )
                }
            }

            // Action Buttons for Approval Flow
            if (task.status == "WAITING_FOR_APPROVAL") {
                Spacer(modifier = Modifier.height(10.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedButton(
                        onClick = onReject,
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        border = BorderStroke(1.dp, StatusRed.copy(alpha = 0.6f))
                    ) {
                        Text("Reject", color = StatusRed, fontSize = 11.sp)
                    }

                    Button(
                        onClick = onApprove,
                        modifier = Modifier.weight(1.5f),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = StatusGreen)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Approve & Execute", fontWeight = FontWeight.Bold, color = Color.White, fontSize = 11.sp)
                    }
                }
            } else if (task.status == "COMPLETED") {
                Spacer(modifier = Modifier.height(6.dp))
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Verified, contentDescription = null, tint = StatusGreen, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Live Verified (100% Tests Passed)", color = StatusGreen, fontSize = 10.sp, fontWeight = FontWeight.SemiBold)
                    }
                    TextButton(
                        onClick = onNavigateToMonitor,
                        contentPadding = PaddingValues(0.dp)
                    ) {
                        Text("View Monitor", color = SaffronLight, fontSize = 10.sp)
                    }
                }
            } else if (task.status == "FAILED") {
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    color = StatusRed.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, StatusRed.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = StatusRed, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Execution Failed — Real diagnostic logs captured. No fake success shown.",
                            color = StatusRed,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            } else if (task.status == "REJECTED") {
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    color = Color.DarkGray.copy(alpha = 0.3f),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, Color.Gray.copy(alpha = 0.3f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Block, contentDescription = null, tint = StatusRed, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Declined by Admin — 0 changes applied to database, code, or configuration.",
                            color = Color.LightGray,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
        }
    }
}

