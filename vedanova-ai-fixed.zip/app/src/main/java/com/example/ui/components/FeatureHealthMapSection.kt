package com.example.ui.components

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.health.FeatureHealthItem
import com.example.domain.health.RealHealthStatus
import com.example.ui.theme.*
import com.example.ui.viewmodel.ScreenDestination
import com.example.ui.viewmodel.VedaNovaViewModel

@Composable
fun FeatureHealthMapSection(
    viewModel: VedaNovaViewModel,
    modifier: Modifier = Modifier
) {
    val featureList by viewModel.featureHealthList.collectAsStateWithLifecycle()
    val isAuditing by viewModel.isAuditingHealth.collectAsStateWithLifecycle()
    val lastAuditTimestamp by viewModel.lastAuditTimestamp.collectAsStateWithLifecycle()

    var selectedStatusFilter by remember { mutableStateOf<RealHealthStatus?>(null) }
    var searchQuery by remember { mutableStateOf("") }
    var expandedItemId by remember { mutableStateOf<String?>(null) }

    val filteredList = remember(featureList, selectedStatusFilter, searchQuery) {
        featureList.filter { item ->
            val matchesFilter = selectedStatusFilter == null || item.status == selectedStatusFilter
            val matchesSearch = searchQuery.isBlank() ||
                    item.featureName.contains(searchQuery, ignoreCase = true) ||
                    item.nameBengali.contains(searchQuery, ignoreCase = true) ||
                    item.connectedService.contains(searchQuery, ignoreCase = true) ||
                    item.connectedDatabaseOrDao.contains(searchQuery, ignoreCase = true) ||
                    item.screenName.contains(searchQuery, ignoreCase = true)
            matchesFilter && matchesSearch
        }
    }

    val workingCount = featureList.count { it.status == RealHealthStatus.WORKING }
    val needsReviewCount = featureList.count { it.status == RealHealthStatus.NEEDS_REVIEW }
    val errorCount = featureList.count { it.status == RealHealthStatus.ERROR }
    val offlineCount = featureList.count { it.status == RealHealthStatus.OFFLINE }

    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, SaffronPrimary.copy(alpha = 0.4f)),
        modifier = modifier
            .fillMaxWidth()
            .testTag("feature_health_map_card")
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header Row with Real-Time Indicator & Audit Button
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Box(
                        modifier = Modifier
                            .size(38.dp)
                            .clip(CircleShape)
                            .background(SpiritualTeal.copy(alpha = 0.15f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.HealthAndSafety,
                            contentDescription = "Feature Health Map",
                            tint = SpiritualTeal,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Feature Health Map",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Surface(
                                color = StatusGreen.copy(alpha = 0.15f),
                                shape = RoundedCornerShape(4.dp)
                            ) {
                                Text(
                                    text = "LIVE AUDIT",
                                    color = StatusGreen,
                                    fontSize = 9.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                )
                            }
                        }
                        Text(
                            text = if (lastAuditTimestamp != null) "Last Checked: $lastAuditTimestamp" else "Verifying live subsystem health...",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp
                        )
                    }
                }

                FilledTonalButton(
                    onClick = { viewModel.runFeatureHealthAudit() },
                    enabled = !isAuditing,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = SaffronPrimary.copy(alpha = 0.15f),
                        contentColor = SaffronPrimary
                    ),
                    modifier = Modifier.testTag("run_health_audit_button")
                ) {
                    if (isAuditing) {
                        CircularProgressIndicator(
                            modifier = Modifier.size(14.dp),
                            strokeWidth = 2.dp,
                            color = SaffronPrimary
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Auditing...", fontSize = 11.sp)
                    } else {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Re-Audit", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Real Health Summary Counter Pills
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                HealthSummaryChip(
                    label = "WORKING",
                    count = workingCount,
                    color = StatusGreen,
                    isSelected = selectedStatusFilter == RealHealthStatus.WORKING,
                    onClick = {
                        selectedStatusFilter = if (selectedStatusFilter == RealHealthStatus.WORKING) null else RealHealthStatus.WORKING
                    }
                )
                HealthSummaryChip(
                    label = "REVIEW",
                    count = needsReviewCount,
                    color = StatusYellow,
                    isSelected = selectedStatusFilter == RealHealthStatus.NEEDS_REVIEW,
                    onClick = {
                        selectedStatusFilter = if (selectedStatusFilter == RealHealthStatus.NEEDS_REVIEW) null else RealHealthStatus.NEEDS_REVIEW
                    }
                )
                if (errorCount > 0) {
                    HealthSummaryChip(
                        label = "ERROR",
                        count = errorCount,
                        color = StatusRed,
                        isSelected = selectedStatusFilter == RealHealthStatus.ERROR,
                        onClick = {
                            selectedStatusFilter = if (selectedStatusFilter == RealHealthStatus.ERROR) null else RealHealthStatus.ERROR
                        }
                    )
                }
                if (offlineCount > 0) {
                    HealthSummaryChip(
                        label = "OFFLINE",
                        count = offlineCount,
                        color = Color.Gray,
                        isSelected = selectedStatusFilter == RealHealthStatus.OFFLINE,
                        onClick = {
                            selectedStatusFilter = if (selectedStatusFilter == RealHealthStatus.OFFLINE) null else RealHealthStatus.OFFLINE
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Search Bar for Features
            OutlinedTextField(
                value = searchQuery,
                onValueChange = { searchQuery = it },
                placeholder = { Text("Filter features, services, DAOs...", fontSize = 12.sp) },
                leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(16.dp)) },
                trailingIcon = {
                    if (searchQuery.isNotEmpty()) {
                        IconButton(onClick = { searchQuery = "" }, modifier = Modifier.size(20.dp)) {
                            Icon(Icons.Default.Close, contentDescription = "Clear search", modifier = Modifier.size(14.dp))
                        }
                    }
                },
                singleLine = true,
                shape = RoundedCornerShape(8.dp),
                colors = OutlinedTextFieldDefaults.colors(
                    focusedBorderColor = SaffronPrimary,
                    unfocusedBorderColor = MaterialTheme.colorScheme.outline
                ),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(48.dp)
                    .testTag("feature_health_search_field")
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Real Health Items List
            if (filteredList.isEmpty()) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 16.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = if (isAuditing) "Executing live component verification..." else "No features matched the current filter.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    filteredList.forEach { item ->
                        val isExpanded = expandedItemId == item.id
                        FeatureHealthRowCard(
                            item = item,
                            isExpanded = isExpanded,
                            onToggleExpand = {
                                expandedItemId = if (isExpanded) null else item.id
                            },
                            onNavigate = {
                                viewModel.navigateTo(item.screenDestination)
                            }
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun HealthSummaryChip(
    label: String,
    count: Int,
    color: Color,
    isSelected: Boolean,
    onClick: () -> Unit
) {
    Surface(
        color = if (isSelected) color.copy(alpha = 0.25f) else color.copy(alpha = 0.1f),
        shape = RoundedCornerShape(6.dp),
        border = BorderStroke(1.dp, if (isSelected) color else color.copy(alpha = 0.3f)),
        modifier = Modifier
            .clickable { onClick() }
    ) {
        Row(
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            Box(
                modifier = Modifier
                    .size(8.dp)
                    .clip(CircleShape)
                    .background(color)
            )
            Spacer(modifier = Modifier.width(5.dp))
            Text(
                text = "$label: $count",
                color = color,
                fontWeight = FontWeight.Bold,
                fontSize = 11.sp
            )
        }
    }
}

@Composable
fun FeatureHealthRowCard(
    item: FeatureHealthItem,
    isExpanded: Boolean,
    onToggleExpand: () -> Unit,
    onNavigate: () -> Unit,
    modifier: Modifier = Modifier
) {
    Card(
        colors = CardDefaults.cardColors(
            containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f)
        ),
        shape = RoundedCornerShape(10.dp),
        border = BorderStroke(
            width = 1.dp,
            color = when (item.status) {
                RealHealthStatus.WORKING -> StatusGreen.copy(alpha = 0.3f)
                RealHealthStatus.NEEDS_REVIEW -> StatusYellow.copy(alpha = 0.4f)
                RealHealthStatus.ERROR -> StatusRed.copy(alpha = 0.5f)
                RealHealthStatus.OFFLINE -> Color.Gray.copy(alpha = 0.3f)
            }
        ),
        modifier = modifier
            .fillMaxWidth()
            .clickable { onToggleExpand() }
            .testTag("feature_health_item_${item.id}")
    ) {
        Column(modifier = Modifier.padding(12.dp)) {
            // Main Top Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    modifier = Modifier.weight(1f),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Surface(
                        color = item.status.color.copy(alpha = 0.15f),
                        shape = RoundedCornerShape(4.dp)
                    ) {
                        Text(
                            text = item.id,
                            color = item.status.color,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp,
                            modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                        )
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Column {
                        Text(
                            text = item.featureName,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = item.nameBengali,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            fontSize = 11.sp
                        )
                    }
                }

                // Status Pill
                Surface(
                    color = item.status.color.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, item.status.color.copy(alpha = 0.4f))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = item.status.icon,
                            contentDescription = item.status.label,
                            tint = item.status.color,
                            modifier = Modifier.size(12.dp)
                        )
                        Spacer(modifier = Modifier.width(4.dp))
                        Text(
                            text = item.status.label,
                            color = item.status.color,
                            fontWeight = FontWeight.Bold,
                            fontSize = 10.sp
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Service & DAO badges
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "⚙️ ${item.connectedService.take(35)}${if (item.connectedService.length > 35) "..." else ""}",
                    style = MaterialTheme.typography.bodySmall,
                    color = SaffronLight,
                    fontSize = 11.sp
                )
                Text(
                    text = "🕒 ${item.lastChecked}",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                    fontSize = 10.sp
                )
            }

            Spacer(modifier = Modifier.height(2.dp))

            Text(
                text = "📊 ${item.liveDataCount}",
                style = MaterialTheme.typography.bodySmall,
                color = SpiritualTeal,
                fontWeight = FontWeight.Medium,
                fontSize = 11.sp
            )

            // Error warning banner if applicable
            if (item.errorMessage != null && item.errorMessage.isNotBlank()) {
                Spacer(modifier = Modifier.height(6.dp))
                Surface(
                    color = StatusRed.copy(alpha = 0.15f),
                    shape = RoundedCornerShape(6.dp),
                    border = BorderStroke(1.dp, StatusRed.copy(alpha = 0.4f)),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(6.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = StatusRed, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text(
                            text = "Error: ${item.errorMessage}",
                            color = StatusRed,
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }

            // Expanded Details Section
            AnimatedVisibility(visible = isExpanded) {
                Column(modifier = Modifier.padding(top = 10.dp)) {
                    HorizontalDivider(
                        color = MaterialTheme.colorScheme.outline.copy(alpha = 0.4f),
                        thickness = 0.8.dp
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    Text(
                        text = "🏛️ Connected Database / DAO:",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = SpiritualTeal
                    )
                    Text(
                        text = item.connectedDatabaseOrDao,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = "🔬 Technical Verification Logic:",
                        style = MaterialTheme.typography.labelSmall,
                        fontWeight = FontWeight.Bold,
                        color = VedicGold
                    )
                    Text(
                        text = item.technicalDetails,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface,
                        fontSize = 11.sp
                    )

                    Spacer(modifier = Modifier.height(10.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Destination: ${item.screenName}",
                            style = MaterialTheme.typography.labelSmall,
                            color = SaffronLight,
                            fontSize = 10.sp
                        )

                        Button(
                            onClick = onNavigate,
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                            modifier = Modifier.testTag("launch_screen_button_${item.id}")
                        ) {
                            Text(
                                text = "Open Screen",
                                color = Color.Black,
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Icon(
                                imageVector = Icons.AutoMirrored.Filled.ArrowForward,
                                contentDescription = null,
                                tint = Color.Black,
                                modifier = Modifier.size(12.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
