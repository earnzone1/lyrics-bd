package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ApiKeyEntity
import com.example.ui.components.CodeBlockViewer
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.*
import com.example.ui.viewmodel.ScreenDestination
import com.example.ui.viewmodel.VedaNovaViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ApiCenterScreen(viewModel: VedaNovaViewModel) {
    val apiKeys by viewModel.allApiKeys.collectAsStateWithLifecycle()
    val testState by viewModel.realApiTestingState.collectAsStateWithLifecycle()

    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val snackbarHostState = remember { SnackbarHostState() }
    val coroutineScope = rememberCoroutineScope()

    var showCreateDialog by remember { mutableStateOf(false) }
    var keyToExtend by remember { mutableStateOf<ApiKeyEntity?>(null) }
    var keyToConfig by remember { mutableStateOf<ApiKeyEntity?>(null) }
    var keyToEdit by remember { mutableStateOf<ApiKeyEntity?>(null) }
    var selectedKeyForAction by remember { mutableStateOf<ApiKeyEntity?>(null) }
    var actionDialogType by remember { mutableStateOf<String?>(null) } // "ROTATE", "DELETE"
    var showDocsTab by remember { mutableStateOf(false) }

    // Map of revealed keys (keyId -> isVisible)
    val revealedKeys = remember { mutableStateMapOf<Long, Boolean>() }

    val dateFormat = remember { SimpleDateFormat("dd MMM yyyy", Locale.ENGLISH) }
    val dateTimeFormat = remember { SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.ENGLISH) }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        containerColor = Color.Transparent
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
                .padding(16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Header Banner & Quick Actions
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                modifier = Modifier.weight(1f)
                            ) {
                                Box(
                                    modifier = Modifier
                                        .size(42.dp)
                                        .clip(CircleShape)
                                        .background(SaffronPrimary.copy(alpha = 0.15f)),
                                    contentAlignment = Alignment.Center
                                ) {
                                    Icon(Icons.Default.Key, contentDescription = null, tint = SaffronPrimary, modifier = Modifier.size(24.dp))
                                }
                                Spacer(modifier = Modifier.width(12.dp))
                                Column {
                                    Text(
                                        text = "Dharma AI — API Manager",
                                        style = MaterialTheme.typography.titleLarge,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "Create, control, extend validity, and monitor external client APIs with real Room DB persistence",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = { showCreateDialog = true },
                                colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                                shape = RoundedCornerShape(10.dp)
                            ) {
                                Icon(Icons.Default.Add, contentDescription = null, tint = Color.Black, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Create New API", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            FilterChip(
                                selected = !showDocsTab,
                                onClick = { showDocsTab = false },
                                label = { Text("Active APIs (${apiKeys.size})", fontWeight = FontWeight.SemiBold) },
                                leadingIcon = { Icon(Icons.Default.VpnKey, contentDescription = null, modifier = Modifier.size(14.dp)) }
                            )
                            FilterChip(
                                selected = showDocsTab,
                                onClick = { showDocsTab = true },
                                label = { Text("REST Specifications") },
                                leadingIcon = { Icon(Icons.Default.MenuBook, contentDescription = null, modifier = Modifier.size(14.dp)) }
                            )
                            Spacer(modifier = Modifier.weight(1f))
                            AssistChip(
                                onClick = { viewModel.navigateTo(ScreenDestination.API_TESTING) },
                                label = { Text("API Console", color = SaffronPrimary, fontWeight = FontWeight.Bold) },
                                leadingIcon = { Icon(Icons.Default.Terminal, contentDescription = null, tint = SaffronPrimary, modifier = Modifier.size(14.dp)) }
                            )
                        }
                    }
                }
            }

            // 2. Real API Testing Result Feedback (if triggered)
            testState.lastResult?.let { result ->
                item {
                    Card(
                        colors = CardDefaults.cardColors(
                            containerColor = if (result.isSuccess) StatusGreen.copy(alpha = 0.12f) else StatusRed.copy(alpha = 0.12f)
                        ),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(
                            1.dp,
                            if (result.isSuccess) StatusGreen.copy(alpha = 0.4f) else StatusRed.copy(alpha = 0.4f)
                        )
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        imageVector = if (result.isSuccess) Icons.Default.CheckCircle else Icons.Default.Error,
                                        contentDescription = null,
                                        tint = if (result.isSuccess) StatusGreen else StatusRed,
                                        modifier = Modifier.size(20.dp)
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = if (result.isSuccess) "Real API Gateway Ping Succeeded (HTTP ${result.statusCode})" else "Gateway Ping Failed (HTTP ${result.statusCode})",
                                        style = MaterialTheme.typography.titleSmall,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                }
                                IconButton(
                                    onClick = { viewModel.dismissRealApiTestResult() },
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Icon(Icons.Default.Close, contentDescription = "Dismiss", modifier = Modifier.size(16.dp))
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                                StatusPill(text = "Latency: ${result.latencyMs} ms", color = VedicGold)
                                StatusPill(text = if (result.isSuccess) "Operational" else "Gateway Error", color = if (result.isSuccess) StatusGreen else StatusRed)
                            }

                            if (!result.errorMessage.isNullOrBlank()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Error: ${result.errorMessage}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = StatusRed
                                )
                            }

                            if (result.responseBody.isNotBlank()) {
                                Spacer(modifier = Modifier.height(6.dp))
                                Text(
                                    text = "Preview: ${result.responseBody.take(180)}...",
                                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }

            if (!showDocsTab) {
                // 3. API Keys List Cards
                if (apiKeys.isEmpty()) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(14.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(32.dp),
                                horizontalAlignment = Alignment.CenterHorizontally
                            ) {
                                Icon(Icons.Default.VpnKeyOff, contentDescription = null, tint = MaterialTheme.colorScheme.onSurfaceVariant, modifier = Modifier.size(48.dp))
                                Spacer(modifier = Modifier.height(12.dp))
                                Text("No API Keys created yet", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("Click '+ Create New API' to generate a secure external token.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }

                items(apiKeys, key = { it.id }) { keyItem ->
                    val isCurrentlyTesting = testState.isTesting && testState.activeTestingKeyId == keyItem.id
                    val isKeyRevealed = revealedKeys[keyItem.id] ?: false
                    val now = System.currentTimeMillis()
                    val isExpired = keyItem.expiresAt > 0 && now > keyItem.expiresAt

                    // Compute dynamic status & badge text
                    val (statusLabel, statusColor) = when {
                        isExpired -> "Expired on ${dateFormat.format(Date(keyItem.expiresAt))}" to StatusRed
                        keyItem.status.equals("Suspended", ignoreCase = true) -> "Suspended" to StatusYellow
                        keyItem.status.equals("Revoked", ignoreCase = true) -> "Revoked" to StatusRed
                        keyItem.status.equals("Disabled", ignoreCase = true) -> "Disabled" to StatusYellow
                        keyItem.expiresAt > 0 -> "Active — Expires: ${dateFormat.format(Date(keyItem.expiresAt))}" to StatusGreen
                        else -> "Active — Lifetime" to StatusGreen
                    }

                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(16.dp),
                        border = BorderStroke(
                            1.dp,
                            if (isExpired) StatusRed.copy(alpha = 0.5f)
                            else if (keyItem.status == "Suspended") StatusYellow.copy(alpha = 0.5f)
                            else MaterialTheme.colorScheme.outline
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            // Top Row: Title + Badges
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.Top
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = keyItem.name,
                                            style = MaterialTheme.typography.titleMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = MaterialTheme.colorScheme.onSurface
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        StatusPill(
                                            text = keyItem.provider,
                                            color = if (keyItem.provider.contains("Dharma", ignoreCase = true)) SaffronPrimary else VedicGold
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(2.dp))
                                    Text(
                                        text = "Client / App: ${keyItem.appName}" + if (keyItem.description.isNotBlank()) " • ${keyItem.description}" else "",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                StatusPill(text = statusLabel, color = statusColor)
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Target Endpoint Display
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "Endpoint: ${keyItem.endpoint}",
                                    style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis,
                                    modifier = Modifier.weight(1f)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                TextButton(
                                    onClick = {
                                        clipboardManager.setText(AnnotatedString(keyItem.endpoint))
                                        Toast.makeText(context, "Endpoint copied: ${keyItem.endpoint}", Toast.LENGTH_SHORT).show()
                                    },
                                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 2.dp),
                                    modifier = Modifier.height(24.dp)
                                ) {
                                    Icon(Icons.Default.ContentCopy, contentDescription = "Copy Endpoint", modifier = Modifier.size(12.dp), tint = SpiritualTeal)
                                    Spacer(modifier = Modifier.width(2.dp))
                                    Text("Endpoint", fontSize = 11.sp, color = SpiritualTeal)
                                }
                            }

                            Spacer(modifier = Modifier.height(6.dp))

                            // Masked Key Box with Show/Hide Toggle & Copy Key Button
                            Surface(
                                color = Color(0xFF0C0814),
                                shape = RoundedCornerShape(8.dp),
                                border = BorderStroke(1.dp, Color(0xFF2E1B4E)),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 12.dp, vertical = 8.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(
                                        verticalAlignment = Alignment.CenterVertically,
                                        modifier = Modifier.weight(1f)
                                    ) {
                                        Icon(Icons.Default.Lock, contentDescription = null, tint = VedicGold, modifier = Modifier.size(14.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = if (isKeyRevealed) keyItem.apiKey else keyItem.maskedKey,
                                            style = MaterialTheme.typography.bodyMedium.copy(
                                                fontFamily = FontFamily.Monospace,
                                                fontWeight = FontWeight.SemiBold
                                            ),
                                            color = if (isKeyRevealed) Color.White else VedicGold,
                                            maxLines = 1,
                                            overflow = TextOverflow.Ellipsis
                                        )
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        // Show/Hide Eye Toggle
                                        IconButton(
                                            onClick = { revealedKeys[keyItem.id] = !isKeyRevealed },
                                            modifier = Modifier.size(32.dp)
                                        ) {
                                            Icon(
                                                imageVector = if (isKeyRevealed) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                                contentDescription = if (isKeyRevealed) "Hide Key" else "Show Key",
                                                tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                                modifier = Modifier.size(16.dp)
                                            )
                                        }

                                        // Copy API Key Button
                                        Button(
                                            onClick = {
                                                clipboardManager.setText(AnnotatedString(keyItem.apiKey))
                                                Toast.makeText(context, "API Key copied to clipboard! Keep it confidential.", Toast.LENGTH_SHORT).show()
                                            },
                                            shape = RoundedCornerShape(6.dp),
                                            colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary.copy(alpha = 0.2f)),
                                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                            modifier = Modifier.height(28.dp)
                                        ) {
                                            Icon(Icons.Default.ContentCopy, contentDescription = "Copy Key", tint = SaffronPrimary, modifier = Modifier.size(12.dp))
                                            Spacer(modifier = Modifier.width(4.dp))
                                            Text("Copy Key", color = SaffronPrimary, fontSize = 11.sp, fontWeight = FontWeight.Bold)
                                        }
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Date and Expiry Details Box
                            Surface(
                                color = MaterialTheme.colorScheme.surface.copy(alpha = 0.6f),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(horizontal = 10.dp, vertical = 6.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "Created: ${dateFormat.format(Date(keyItem.createdAt))}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = if (keyItem.expiresAt > 0) {
                                            if (isExpired) "Expired: ${dateFormat.format(Date(keyItem.expiresAt))}"
                                            else "Expires: ${dateFormat.format(Date(keyItem.expiresAt))}"
                                        } else "Validity: Lifetime (No Expiry)",
                                        style = MaterialTheme.typography.labelSmall,
                                        fontWeight = FontWeight.SemiBold,
                                        color = if (isExpired) StatusRed else VedicGold
                                    )
                                    Text(
                                        text = if (keyItem.lastUsed > 0) "Last Used: ${dateTimeFormat.format(Date(keyItem.lastUsed))}" else "Never Used",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = if (keyItem.lastUsed > 0) StatusGreen else MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(10.dp))

                            // Stats Metrics Grid
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column {
                                    Text(text = "Total Requests", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(text = "${keyItem.requestCount}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = SaffronPrimary)
                                }
                                Column {
                                    Text(text = "Error Count", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(text = "${keyItem.errorCount}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = if (keyItem.errorCount > 0) StatusRed else StatusGreen)
                                }
                                Column {
                                    Text(text = "Rate Limit", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(text = "${keyItem.rateLimitPerMin} req/m", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                                }
                                Column {
                                    Text(text = "Daily Quota", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    Text(text = "${keyItem.dailyLimit}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))
                            HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                            Spacer(modifier = Modifier.height(10.dp))

                            // Bottom Action Controls (Extend, Real Test, Suspend/Activate, Config, Rotate, Delete)
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                // Extend API Expiry Button (মেয়াদ বৃদ্ধি)
                                Button(
                                    onClick = { keyToExtend = keyItem },
                                    colors = ButtonDefaults.buttonColors(containerColor = CosmicNavyElevated),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                                    border = BorderStroke(1.dp, VedicGold.copy(alpha = 0.6f))
                                ) {
                                    Icon(Icons.Default.HourglassBottom, contentDescription = null, tint = VedicGold, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Extend Expiry", color = VedicGold, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                }

                                Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                    // Real Gateway HTTP Test
                                    IconButton(
                                        onClick = { viewModel.testRealApiKey(keyItem) },
                                        enabled = !isCurrentlyTesting
                                    ) {
                                        if (isCurrentlyTesting) {
                                            CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp, color = SaffronPrimary)
                                        } else {
                                            Icon(Icons.Default.PlayArrow, contentDescription = "Run Test", tint = SpiritualTeal)
                                        }
                                    }

                                    // View cURL / Config
                                    IconButton(
                                        onClick = { keyToConfig = keyItem }
                                    ) {
                                        Icon(Icons.Default.Code, contentDescription = "View Config", tint = VedicGold)
                                    }

                                    // Suspend / Activate Toggle
                                    IconButton(
                                        onClick = {
                                            val newStatus = if (keyItem.status == "Active") "Suspended" else "Active"
                                            viewModel.updateApiKeyStatus(keyItem, newStatus)
                                            Toast.makeText(context, "${keyItem.name} marked as $newStatus", Toast.LENGTH_SHORT).show()
                                        }
                                    ) {
                                        Icon(
                                            imageVector = if (keyItem.status == "Active") Icons.Default.PauseCircle else Icons.Default.PlayCircle,
                                            contentDescription = "Toggle Status",
                                            tint = if (keyItem.status == "Active") StatusYellow else StatusGreen
                                        )
                                    }

                                    // Rotate Key Token
                                    IconButton(
                                        onClick = {
                                            selectedKeyForAction = keyItem
                                            actionDialogType = "ROTATE"
                                        }
                                    ) {
                                        Icon(Icons.Default.Refresh, contentDescription = "Rotate Key", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }

                                    // Edit / Configure Settings
                                    IconButton(
                                        onClick = { keyToEdit = keyItem }
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = "Edit Config", tint = MaterialTheme.colorScheme.onSurfaceVariant)
                                    }

                                    // Delete Key
                                    IconButton(
                                        onClick = {
                                            selectedKeyForAction = keyItem
                                            actionDialogType = "DELETE"
                                        }
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = StatusRed)
                                    }
                                }
                            }
                        }
                    }
                }
            } else {
                // REST Documentation Specs Tab
                item {
                    SectionHeader(
                        title = "Dharma AI External REST API Gateway Specifications",
                        subtitle = "Standard endpoints for external Mobile, Web, and Bot clients."
                    )
                }

                item {
                    ApiDocCard(
                        method = "POST",
                        endpoint = "/api/v1/chat",
                        description = "Interactive Sanskrit & Dharma AI reasoning engine with scripture grounding.",
                        sampleBody = """
                            {
                              "query": "শ্রীমদ্ভগবদ্গীতা ২.৪৭ শ্লোকের তাৎপর্য কী?",
                              "temperature": 0.2
                            }
                        """.trimIndent(),
                        onTestClick = {
                            viewModel.updateApiTestEndpoint("/api/v1/chat")
                            viewModel.navigateTo(ScreenDestination.API_TESTING)
                        }
                    )
                }

                item {
                    ApiDocCard(
                        method = "POST",
                        endpoint = "/api/v1/knowledge/search",
                        description = "Search verified Hindu scripture canonical records (Gita, Vedas, Upanishads, Mantras, Pujas).",
                        sampleBody = """
                            {
                              "query": "Gayatri Mantra",
                              "limit": 5
                            }
                        """.trimIndent(),
                        onTestClick = {
                            viewModel.updateApiTestEndpoint("/api/v1/knowledge/search")
                            viewModel.navigateTo(ScreenDestination.API_TESTING)
                        }
                    )
                }

                item {
                    ApiDocCard(
                        method = "POST",
                        endpoint = "/api/v1/mantra/search",
                        description = "Dedicated Mantra & Stotra lookup with IAST transliteration and metric guidance.",
                        sampleBody = """
                            {
                              "query": "Mahamrityunjaya",
                              "include_transliteration": true
                            }
                        """.trimIndent(),
                        onTestClick = {
                            viewModel.updateApiTestEndpoint("/api/v1/mantra/search")
                            viewModel.navigateTo(ScreenDestination.API_TESTING)
                        }
                    )
                }

                item {
                    ApiDocCard(
                        method = "POST",
                        endpoint = "/api/v1/image/generate",
                        description = "Internal Sacred Image Generation Engine routed centrally through Dharma AI Unified Gateway.",
                        sampleBody = """
                            {
                              "prompt": "শ্রীকৃষ্ণের একটি দিব্য রূপ",
                              "aspect_ratio": "1:1",
                              "quality": "STANDARD",
                              "dharma_enhanced": true
                            }
                        """.trimIndent(),
                        onTestClick = {
                            viewModel.updateApiTestEndpoint("/api/v1/image/generate")
                            viewModel.navigateTo(ScreenDestination.API_TESTING)
                        }
                    )
                }

                item {
                    ApiDocCard(
                        method = "POST",
                        endpoint = "/api/v1/image/understand",
                        description = "Sacred Vision & Iconography analysis with scriptural symbolism and significance mapping.",
                        sampleBody = """
                            {
                              "image_file_path": "/data/user/0/com.example/files/sacred_images/krishna.jpg",
                              "question": "এই ছবির আধ্যাত্মিক তাৎপর্য কী?"
                            }
                        """.trimIndent(),
                        onTestClick = {
                            viewModel.updateApiTestEndpoint("/api/v1/image/understand")
                            viewModel.navigateTo(ScreenDestination.API_TESTING)
                        }
                    )
                }

                item {
                    ApiDocCard(
                        method = "POST",
                        endpoint = "/api/v1/voice",
                        description = "Sacred Voice Assistant, Sanskrit pronunciation, and real-time audio orchestration.",
                        sampleBody = """
                            {
                              "text": "নমস্কার! Dharma AI Voice Assistant",
                              "query": "নমস্কার"
                            }
                        """.trimIndent(),
                        onTestClick = {
                            viewModel.updateApiTestEndpoint("/api/v1/voice")
                            viewModel.navigateTo(ScreenDestination.API_TESTING)
                        }
                    )
                }

                item {
                    ApiDocCard(
                        method = "POST",
                        endpoint = "/api/v1/research",
                        description = "Deep scriptural research across Vedas, Upanishads, and verified Hindu philosophical traditions.",
                        sampleBody = """
                            {
                              "query": "Comparative analysis of Karma Yoga and Jnana Yoga"
                            }
                        """.trimIndent(),
                        onTestClick = {
                            viewModel.updateApiTestEndpoint("/api/v1/research")
                            viewModel.navigateTo(ScreenDestination.API_TESTING)
                        }
                    )
                }

                item {
                    ApiDocCard(
                        method = "POST",
                        endpoint = "/api/v1/verify",
                        description = "Cross-source canonical verification shield for mantras and scriptural claims.",
                        sampleBody = """
                            {
                              "query": "যদা যদা হি ধর্মস্য গ্লানির্ভবতি ভারত"
                            }
                        """.trimIndent(),
                        onTestClick = {
                            viewModel.updateApiTestEndpoint("/api/v1/verify")
                            viewModel.navigateTo(ScreenDestination.API_TESTING)
                        }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(32.dp))
            }
        }
    }

    // =========================================================================
    // 1. CREATE NEW API KEY DIALOG
    // =========================================================================
    if (showCreateDialog) {
        var apiName by remember { mutableStateOf("") }
        var appName by remember { mutableStateOf("") }
        var description by remember { mutableStateOf("") }
        var selectedScopeType by remember { mutableStateOf("ALL") } // ALL, CHAT, SCRIPTURE, CALENDAR, RESEARCH, CUSTOM
        var customPermissions by remember { mutableStateOf("chat,knowledge,mantra,scripture,puja,research,verify,status,calendar,festival") }
        var selectedExpiryOption by remember { mutableStateOf(30) } // 30, 90, 180, 365, 0 (Lifetime), -1 (Custom)
        var customExpiryDays by remember { mutableStateOf("45") }
        var rateLimit by remember { mutableStateOf("60") }
        var dailyQuota by remember { mutableStateOf("5000") }

        val calculatedDays = if (selectedExpiryOption >= 0) selectedExpiryOption else (customExpiryDays.toIntOrNull() ?: 30)

        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Key, contentDescription = null, tint = SaffronPrimary)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Create New Dharma AI API Key", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = apiName,
                        onValueChange = { apiName = it },
                        label = { Text("API Name *") },
                        placeholder = { Text("e.g. Dharma Mobile App Live API") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = appName,
                        onValueChange = { appName = it },
                        label = { Text("Client Application / Service *") },
                        placeholder = { Text("e.g. Sanatan Portal, Android Client") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("Description (Optional)") },
                        placeholder = { Text("e.g. Primary external mobile integration") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Expiry Selector Chips (1M, 3M, 6M, 1Y, Custom, Lifetime)
                    Text("API Validity / Expiry *", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = VedicGold)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        val expiryPresets = listOf(
                            30 to "1 Month",
                            90 to "3 Months",
                            180 to "6 Months",
                            365 to "1 Year",
                            -1 to "Custom Days",
                            0 to "Lifetime"
                        )
                        items(expiryPresets) { (days, label) ->
                            FilterChip(
                                selected = selectedExpiryOption == days,
                                onClick = { selectedExpiryOption = days },
                                label = { Text(label, fontSize = 11.sp, fontWeight = if (selectedExpiryOption == days) FontWeight.Bold else FontWeight.Normal) }
                            )
                        }
                    }

                    if (selectedExpiryOption == -1) {
                        OutlinedTextField(
                            value = customExpiryDays,
                            onValueChange = { customExpiryDays = it },
                            label = { Text("Custom Expiry in Days") },
                            placeholder = { Text("e.g. 45") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    // Scope / Permission Presets
                    Text("Access Scope & Permissions", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = VedicGold)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        val scopePresets = listOf(
                            "ALL" to "All Access",
                            "CHAT" to "Chat & AI",
                            "SCRIPTURE" to "Scriptures & Mantras",
                            "CALENDAR" to "Panchang & Festivals",
                            "RESEARCH" to "Research & Verification"
                        )
                        items(scopePresets) { (code, label) ->
                            FilterChip(
                                selected = selectedScopeType == code,
                                onClick = {
                                    selectedScopeType = code
                                    customPermissions = when (code) {
                                        "CHAT" -> "chat,status"
                                        "SCRIPTURE" -> "knowledge,mantra,scripture,status"
                                        "CALENDAR" -> "calendar,festival,puja,status"
                                        "RESEARCH" -> "research,verify,status"
                                        else -> "chat,knowledge,mantra,scripture,puja,research,verify,status,calendar,festival"
                                    }
                                },
                                label = { Text(label, fontSize = 11.sp) }
                            )
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = rateLimit,
                            onValueChange = { rateLimit = it },
                            label = { Text("Req / Min") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = dailyQuota,
                            onValueChange = { dailyQuota = it },
                            label = { Text("Daily Quota") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (apiName.isNotBlank() && appName.isNotBlank()) {
                            viewModel.createDharmaApiKey(
                                name = apiName,
                                appName = appName,
                                description = description,
                                permissions = customPermissions,
                                expiresInDays = calculatedDays,
                                rateLimitPerMin = rateLimit.toIntOrNull() ?: 60,
                                dailyLimit = dailyQuota.toIntOrNull() ?: 5000
                            )
                            Toast.makeText(context, "Secure API Key generated and saved to database!", Toast.LENGTH_LONG).show()
                            showCreateDialog = false
                        } else {
                            Toast.makeText(context, "Please provide API Name and Application Name", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
                ) {
                    Text("Generate & Save API Key", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) {
                    Text("Cancel")
                }
            }
        )
    }

    // =========================================================================
    // 2. EXTEND API EXPIRY DIALOG (মেয়াদ বৃদ্ধি)
    // =========================================================================
    keyToExtend?.let { key ->
        var additionalDays by remember { mutableStateOf(30) } // default +1 Month (30 days)
        var customAddDays by remember { mutableStateOf("60") }
        var isCustom by remember { mutableStateOf(false) }

        val now = System.currentTimeMillis()
        val baseTime = if (key.expiresAt > now) key.expiresAt else now
        val effectiveDays = if (isCustom) (customAddDays.toIntOrNull() ?: 30) else additionalDays
        val previewNewExpiry = baseTime + (effectiveDays.toLong() * 24 * 60 * 60 * 1000L)

        AlertDialog(
            onDismissRequest = { keyToExtend = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.HourglassBottom, contentDescription = null, tint = VedicGold)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Extend API Validity: ${key.name}", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        text = "Current Status: " + if (key.expiresAt > 0 && now > key.expiresAt) "EXPIRED" else key.status,
                        fontWeight = FontWeight.Bold,
                        color = if (key.expiresAt > 0 && now > key.expiresAt) StatusRed else StatusGreen
                    )
                    Text(
                        text = "Current Expiry: ${if (key.expiresAt > 0) dateFormat.format(Date(key.expiresAt)) else "Lifetime"}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Select Extension Duration (মেয়াদ বৃদ্ধি):", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = VedicGold)

                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        val extensionPresets = listOf(
                            30 to "+1 Month",
                            90 to "+3 Months",
                            180 to "+6 Months",
                            365 to "+1 Year"
                        )
                        items(extensionPresets) { (days, label) ->
                            FilterChip(
                                selected = !isCustom && additionalDays == days,
                                onClick = {
                                    isCustom = false
                                    additionalDays = days
                                },
                                label = { Text(label, fontSize = 11.sp, fontWeight = if (!isCustom && additionalDays == days) FontWeight.Bold else FontWeight.Normal) }
                            )
                        }
                    }

                    FilterChip(
                        selected = isCustom,
                        onClick = { isCustom = true },
                        label = { Text("Custom Days...", fontSize = 11.sp) }
                    )

                    if (isCustom) {
                        OutlinedTextField(
                            value = customAddDays,
                            onValueChange = { customAddDays = it },
                            label = { Text("Number of additional days") },
                            placeholder = { Text("e.g. 60") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }

                    Surface(
                        color = CosmicNavyElevated,
                        shape = RoundedCornerShape(8.dp),
                        border = BorderStroke(1.dp, SaffronPrimary.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("New Expiration Date Preview:", style = MaterialTheme.typography.labelSmall, color = SaffronPrimary)
                            Text(
                                text = dateFormat.format(Date(previewNewExpiry)),
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = VedicGold
                            )
                            Text("Backend gateway will immediately allow requests until this date.", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.extendApiKeyExpiry(key, effectiveDays)
                        Toast.makeText(context, "API validity extended by $effectiveDays days!", Toast.LENGTH_LONG).show()
                        keyToExtend = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
                ) {
                    Text("Confirm & Extend Validity", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { keyToExtend = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // =========================================================================
    // 3. VIEW CONFIGURATION & CURL DIALOG
    // =========================================================================
    keyToConfig?.let { key ->
        val curlCommand = """
curl -X POST "${key.endpoint}" \
  -H "Authorization: Bearer ${key.apiKey}" \
  -H "Content-Type: application/json" \
  -d '{"query": "গায়ত্রী মন্ত্রের অর্থ কী?"}'
        """.trimIndent()

        val jsonConfig = """
{
  "api_name": "${key.name}",
  "client_app": "${key.appName}",
  "endpoint": "${key.endpoint}",
  "authorization": "Bearer ${key.apiKey}",
  "rate_limit_per_min": ${key.rateLimitPerMin},
  "daily_limit": ${key.dailyLimit},
  "granted_permissions": "${key.permissions}"
}
        """.trimIndent()

        AlertDialog(
            onDismissRequest = { keyToConfig = null },
            title = {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Code, contentDescription = null, tint = VedicGold)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("API Configuration & cURL", fontWeight = FontWeight.Bold)
                }
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("External App Integration cURL Command:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = SaffronPrimary)
                    CodeBlockViewer(code = curlCommand, language = "cURL")

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                clipboardManager.setText(AnnotatedString(curlCommand))
                                Toast.makeText(context, "cURL command copied to clipboard!", Toast.LENGTH_SHORT).show()
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = SpiritualTeal),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Copy cURL", fontSize = 12.sp)
                        }

                        Button(
                            onClick = {
                                clipboardManager.setText(AnnotatedString(jsonConfig))
                                Toast.makeText(context, "JSON Configuration copied!", Toast.LENGTH_SHORT).show()
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = CosmicNavyElevated),
                            modifier = Modifier.weight(1f)
                        ) {
                            Icon(Icons.Default.Description, contentDescription = null, tint = VedicGold, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Copy JSON", color = VedicGold, fontSize = 12.sp)
                        }
                    }
                }
            },
            confirmButton = {
                TextButton(onClick = { keyToConfig = null }) {
                    Text("Close")
                }
            }
        )
    }

    // =========================================================================
    // 4. EDIT / CONFIGURE API KEY DIALOG
    // =========================================================================
    keyToEdit?.let { editing ->
        var keyName by remember(editing) { mutableStateOf(editing.name) }
        var appName by remember(editing) { mutableStateOf(editing.appName) }
        var description by remember(editing) { mutableStateOf(editing.description) }
        var endpoint by remember(editing) { mutableStateOf(editing.endpoint) }
        var permissions by remember(editing) { mutableStateOf(editing.permissions) }
        var rateLimit by remember(editing) { mutableStateOf(editing.rateLimitPerMin.toString()) }
        var dailyLimit by remember(editing) { mutableStateOf(editing.dailyLimit.toString()) }

        AlertDialog(
            onDismissRequest = { keyToEdit = null },
            title = {
                Text("Configure API: ${editing.name}", fontWeight = FontWeight.Bold)
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = keyName,
                        onValueChange = { keyName = it },
                        label = { Text("API Identifier Name") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = appName,
                        onValueChange = { appName = it },
                        label = { Text("Application / Client") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = description,
                        onValueChange = { description = it },
                        label = { Text("Description") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = endpoint,
                        onValueChange = { endpoint = it },
                        label = { Text("Endpoint URL") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = permissions,
                        onValueChange = { permissions = it },
                        label = { Text("Granted Permissions") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = rateLimit,
                            onValueChange = { rateLimit = it },
                            label = { Text("Req / Min") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = dailyLimit,
                            onValueChange = { dailyLimit = it },
                            label = { Text("Daily Quota") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (keyName.isNotBlank() && appName.isNotBlank()) {
                            viewModel.saveOperationalApiKey(
                                id = editing.id,
                                name = keyName,
                                appName = appName,
                                description = description,
                                apiKey = editing.apiKey,
                                provider = editing.provider,
                                endpoint = endpoint,
                                model = editing.model,
                                status = editing.status,
                                permissions = permissions,
                                dailyLimit = dailyLimit.toIntOrNull() ?: 5000,
                                rateLimitPerMin = rateLimit.toIntOrNull() ?: 60,
                                expiresAt = editing.expiresAt
                            )
                            Toast.makeText(context, "API Configuration updated!", Toast.LENGTH_SHORT).show()
                            keyToEdit = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
                ) {
                    Text("Save Config", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { keyToEdit = null }) {
                    Text("Cancel")
                }
            }
        )
    }

    // =========================================================================
    // 5. ROTATE / DELETE CONFIRMATION DIALOGS
    // =========================================================================
    selectedKeyForAction?.let { key ->
        if (actionDialogType == "ROTATE") {
            AlertDialog(
                onDismissRequest = { actionDialogType = null },
                title = { Text("Rotate API Key Token", fontWeight = FontWeight.Bold) },
                text = {
                    Text("A new secure token will be generated for '${key.name}'. The previous token will immediately stop working.")
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.rotateApiKey(key)
                            Toast.makeText(context, "API Key rotated successfully!", Toast.LENGTH_SHORT).show()
                            actionDialogType = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
                    ) {
                        Text("Confirm Rotate", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { actionDialogType = null }) { Text("Cancel") }
                }
            )
        } else if (actionDialogType == "DELETE") {
            AlertDialog(
                onDismissRequest = { actionDialogType = null },
                title = { Text("Revoke & Delete API Key", color = StatusRed, fontWeight = FontWeight.Bold) },
                text = {
                    Text("This will permanently remove '${key.name}' from Room database. External applications using this key will immediately fail with 401 Unauthorized.")
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.deleteApiKey(key)
                            Toast.makeText(context, "API Key deleted from database.", Toast.LENGTH_SHORT).show()
                            actionDialogType = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = StatusRed)
                    ) {
                        Text("Permanent Delete", color = Color.White)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { actionDialogType = null }) { Text("Cancel") }
                }
            )
        }
    }
}

@Composable
private fun ApiDocCard(
    method: String,
    endpoint: String,
    description: String,
    sampleBody: String,
    onTestClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(14.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StatusPill(
                        text = method,
                        color = if (method == "POST") SaffronPrimary else StatusGreen
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = endpoint,
                        style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Monospace),
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Button(
                    onClick = onTestClick,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary.copy(alpha = 0.2f))
                ) {
                    Text("Try in Console →", color = SaffronPrimary, style = MaterialTheme.typography.labelSmall)
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(10.dp))
            CodeBlockViewer(code = sampleBody, language = "JSON Payload")
        }
    }
}
