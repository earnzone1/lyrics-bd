package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.horizontalScroll
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ExternalAppEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.ScreenDestination
import com.example.ui.viewmodel.VedaNovaViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExternalAppsMonitorScreen(viewModel: VedaNovaViewModel) {
    val externalApps by viewModel.allExternalApps.collectAsStateWithLifecycle()
    val selectedApp by viewModel.selectedAppForDetail.collectAsStateWithLifecycle()

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("ALL") } // ALL, ACTIVE, SUSPENDED
    var showRegisterDialog by remember { mutableStateOf(false) }
    var showEditScopesDialog by remember { mutableStateOf<ExternalAppEntity?>(null) }
    var showRateLimitDialog by remember { mutableStateOf<ExternalAppEntity?>(null) }
    var showRotateKeyDialog by remember { mutableStateOf<ExternalAppEntity?>(null) }

    val filteredApps = remember(externalApps, searchQuery, selectedFilter) {
        externalApps.filter { app ->
            val appName = app.appName.orEmpty()
            val appId = app.appId.orEmpty()
            val devName = app.developerName.orEmpty()
            val status = app.status.orEmpty()

            val matchesQuery = searchQuery.isBlank() ||
                    appName.contains(searchQuery, ignoreCase = true) ||
                    appId.contains(searchQuery, ignoreCase = true) ||
                    devName.contains(searchQuery, ignoreCase = true)

            val matchesFilter = when (selectedFilter) {
                "ACTIVE" -> status.equals("ACTIVE", ignoreCase = true)
                "SUSPENDED" -> status.equals("SUSPENDED", ignoreCase = true)
                else -> true
            }
            matchesQuery && matchesFilter
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .testTag("external_apps_monitor_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Sub-Navigation Tabs for External App Subsystems
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    FilledTonalButton(
                        onClick = { viewModel.navigateTo(ScreenDestination.EXTERNAL_APPS_MONITOR) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = SaffronPrimary,
                            contentColor = Color.White
                        ),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Apps, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Apps", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = { viewModel.navigateTo(ScreenDestination.CAPABILITY_APPROVAL) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.VerifiedUser, contentDescription = null, modifier = Modifier.size(14.dp), tint = VedicGold)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Capabilities", fontSize = 11.sp)
                    }

                    OutlinedButton(
                        onClick = { viewModel.navigateTo(ScreenDestination.DAILY_DATA_MONITOR) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(14.dp), tint = SpiritualTeal)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Daily Data", fontSize = 11.sp)
                    }

                    OutlinedButton(
                        onClick = { viewModel.navigateTo(ScreenDestination.EXTERNAL_APP_SIMULATOR) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Science, contentDescription = null, modifier = Modifier.size(14.dp), tint = SaffronPrimary)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Sandbox", fontSize = 11.sp)
                    }
                }
            }
        }

        // Executive Header Card with Register App Action
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "📱", fontSize = 20.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "External Apps & Gateway Monitor",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            "Central Access Control, Scopes, Quotas & Telemetry",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                        )
                    }

                    Button(
                        onClick = { showRegisterDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("register_app_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Register App", modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Register App", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Executive Metric Summary Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val activeCount = externalApps.count { it.status.equals("ACTIVE", ignoreCase = true) }
                val totalCallsToday = externalApps.sumOf { it.requestsToday }
                val totalQuota = externalApps.sumOf { it.dailyQuota.toLong() }

                AppMetricCard(
                    title = "Registered Apps",
                    value = "${externalApps.size}",
                    subtitle = "$activeCount Active in Production",
                    icon = Icons.Default.Apps,
                    color = SaffronPrimary,
                    modifier = Modifier.weight(1f)
                )
                AppMetricCard(
                    title = "Daily Calls",
                    value = "$totalCallsToday",
                    subtitle = "of $totalQuota quota",
                    icon = Icons.Default.DataUsage,
                    color = SpiritualTeal,
                    modifier = Modifier.weight(1f)
                )
                AppMetricCard(
                    title = "Security",
                    value = if (externalApps.isNotEmpty()) "${externalApps.count { it.status.equals("ACTIVE", ignoreCase = true) }} Active" else "Enforced",
                    subtitle = "RBAC & Scopes Enforced",
                    icon = Icons.Default.Security,
                    color = VedicGold,
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // Search & Filter Controls
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier.fillMaxWidth().testTag("search_apps_input"),
                        placeholder = { Text("Search by App ID, Name, or Developer...", fontSize = 12.sp) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", modifier = Modifier.size(18.dp)) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChip(
                            selected = selectedFilter == "ALL",
                            onClick = { selectedFilter = "ALL" },
                            label = { Text("All (${externalApps.size})", fontSize = 11.sp) },
                            shape = RoundedCornerShape(6.dp)
                        )
                        FilterChip(
                            selected = selectedFilter == "ACTIVE",
                            onClick = { selectedFilter = "ACTIVE" },
                            label = { Text("Active (${externalApps.count { it.status.equals("ACTIVE", ignoreCase = true) }})", fontSize = 11.sp) },
                            shape = RoundedCornerShape(6.dp)
                        )
                        FilterChip(
                            selected = selectedFilter == "SUSPENDED",
                            onClick = { selectedFilter = "SUSPENDED" },
                            label = { Text("Suspended (${externalApps.count { it.status.equals("SUSPENDED", ignoreCase = true) }})", fontSize = 11.sp) },
                            shape = RoundedCornerShape(6.dp)
                        )
                    }
                }
            }
        }

        // Apps List or Empty State
        if (filteredApps.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            Icons.Default.SearchOff,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = if (searchQuery.isNotBlank()) "No external apps matching '$searchQuery'" else "No external apps found",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            items(filteredApps, key = { it.id }) { app ->
                ExternalAppCard(
                    app = app,
                    onInspect = { viewModel.selectAppForDetail(app) },
                    onToggleStatus = {
                        val nextStatus = if (app.status.equals("ACTIVE", ignoreCase = true)) "SUSPENDED" else "ACTIVE"
                        viewModel.updateAppStatus(app, nextStatus)
                    },
                    onEditScopes = { showEditScopesDialog = app },
                    onEditRateLimit = { showRateLimitDialog = app },
                    onRotateKey = { showRotateKeyDialog = app }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Modal: App Detail Inspector Sheet
    selectedApp?.let { app ->
        AppDetailDialog(
            app = app,
            onDismiss = { viewModel.selectAppForDetail(null) },
            onToggleStatus = {
                val nextStatus = if (app.status.equals("ACTIVE", ignoreCase = true)) "SUSPENDED" else "ACTIVE"
                viewModel.updateAppStatus(app, nextStatus)
            }
        )
    }

    // Modal: Register New External App
    if (showRegisterDialog) {
        RegisterExternalAppDialog(
            onDismiss = { showRegisterDialog = false },
            onRegister = { name, dev, email, scopes, caps, rateLimit, quota ->
                viewModel.registerExternalApp(name, dev, email, scopes, caps, rateLimit, quota) {
                    showRegisterDialog = false
                }
            }
        )
    }

    // Modal: Edit Scopes & Capabilities
    showEditScopesDialog?.let { app ->
        EditScopesDialog(
            app = app,
            onDismiss = { showEditScopesDialog = null },
            onSave = { scopes, caps ->
                viewModel.updateAppScopesAndCapabilities(app, scopes, caps)
                showEditScopesDialog = null
            }
        )
    }

    // Modal: Edit Rate Limits
    showRateLimitDialog?.let { app ->
        EditRateLimitDialog(
            app = app,
            onDismiss = { showRateLimitDialog = null },
            onSave = { rate, quota ->
                viewModel.updateAppRateLimit(app, rate, quota)
                showRateLimitDialog = null
            }
        )
    }

    // Modal: Rotate API Key Confirmation
    showRotateKeyDialog?.let { app ->
        AlertDialog(
            onDismissRequest = { showRotateKeyDialog = null },
            title = { Text("Rotate API Key for ${app.appName}?", fontWeight = FontWeight.Bold) },
            text = {
                Text("This will immediately invalidate the current credentials. The external application must update its authorization header to continue calling VedaNova AI Gateway.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.rotateAppApiKey(app)
                        showRotateKeyDialog = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
                ) {
                    Text("Rotate Key")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRotateKeyDialog = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun AppMetricCard(
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(26.dp)
                        .clip(CircleShape)
                        .background(color.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(14.dp))
                }
                Spacer(modifier = Modifier.width(6.dp))
                Text(title, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold), maxLines = 1)
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(value, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = color))
            Text(subtitle, style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant), maxLines = 1)
        }
    }
}

@Composable
fun ExternalAppCard(
    app: ExternalAppEntity,
    onInspect: () -> Unit,
    onToggleStatus: () -> Unit,
    onEditScopes: () -> Unit,
    onEditRateLimit: () -> Unit,
    onRotateKey: () -> Unit
) {
    val isActive = app.status.equals("ACTIVE", ignoreCase = true)
    val statusColor = if (isActive) Color(0xFF2E7D32) else Color(0xFFC62828)
    val scrollState = rememberScrollState()

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            app.appName.ifBlank { "Untitled App" },
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = statusColor.copy(alpha = 0.15f)
                        ) {
                            Text(
                                app.status.uppercase(),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = statusColor,
                                    fontSize = 10.sp
                                )
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        "ID: ${app.appId} • Dev: ${app.developerName} (${app.contactEmail})",
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                }

                IconButton(onClick = onInspect, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Inspect App", modifier = Modifier.size(18.dp))
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Credentials & Quota Row
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(8.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("API Key Credential", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant))
                        Text(app.maskedKey.ifBlank { "••••••••" }, style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold, fontSize = 11.sp))
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Rate Limit / Quota", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant))
                        Text("${app.rateLimitPerMin} req/min • ${app.requestsToday}/${app.dailyQuota} today", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold, fontSize = 11.sp))
                    }
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Granted Scopes (Horizontal Scroll to prevent measure issues)
            Text("Granted Scopes:", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 11.sp))
            val scopesList = remember(app.allowedScopes) {
                app.allowedScopes.orEmpty().split(",").map { it.trim() }.filter { it.isNotBlank() }
            }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .horizontalScroll(scrollState)
                    .padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                scopesList.forEach { scope ->
                    Surface(
                        shape = RoundedCornerShape(4.dp),
                        color = SaffronPrimary.copy(alpha = 0.12f)
                    ) {
                        Text(
                            scope,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = SaffronPrimary, fontSize = 10.sp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(2.dp))
            Text("Active Capabilities:", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = SpiritualTeal, fontSize = 11.sp))
            Text(
                app.activeCapabilities.orEmpty().replace(",", " • ").ifBlank { "None" },
                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant),
                maxLines = 1
            )

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outline)
            Spacer(modifier = Modifier.height(8.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                    OutlinedButton(
                        onClick = onEditScopes,
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("Scopes", fontSize = 11.sp)
                    }

                    OutlinedButton(
                        onClick = onEditRateLimit,
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.Speed, contentDescription = null, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("Limits", fontSize = 11.sp)
                    }

                    OutlinedButton(
                        onClick = onRotateKey,
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(12.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("Rotate Key", fontSize = 11.sp)
                    }
                }

                Button(
                    onClick = onToggleStatus,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isActive) Color(0xFFC62828) else Color(0xFF2E7D32)
                    ),
                    shape = RoundedCornerShape(6.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                ) {
                    Text(if (isActive) "Suspend" else "Activate", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun AppDetailDialog(
    app: ExternalAppEntity,
    onDismiss: () -> Unit,
    onToggleStatus: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(app.appName, fontWeight = FontWeight.Bold)
                Text("App ID: ${app.appId}", style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Developer & Contact", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                Text("${app.developerName} • ${app.contactEmail}", style = MaterialTheme.typography.bodyMedium)

                HorizontalDivider()

                Text("Raw API Key (Authorized)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        app.apiKey,
                        modifier = Modifier.padding(8.dp),
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace)
                    )
                }

                HorizontalDivider()

                Text("Granted Scopes", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                Text(app.allowedScopes, style = MaterialTheme.typography.bodyMedium)

                Text("Active Capabilities", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                Text(app.activeCapabilities, style = MaterialTheme.typography.bodyMedium)

                HorizontalDivider()

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Total Requests Served:", style = MaterialTheme.typography.bodySmall)
                    Text("${app.totalRequests}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Rate Limit (per min):", style = MaterialTheme.typography.bodySmall)
                    Text("${app.rateLimitPerMin}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Daily Quota:", style = MaterialTheme.typography.bodySmall)
                    Text("${app.dailyQuota}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onToggleStatus()
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (app.status.equals("ACTIVE", ignoreCase = true)) Color(0xFFC62828) else Color(0xFF2E7D32)
                )
            ) {
                Text(if (app.status.equals("ACTIVE", ignoreCase = true)) "Suspend App" else "Activate App")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

@Composable
fun RegisterExternalAppDialog(
    onDismiss: () -> Unit,
    onRegister: (name: String, dev: String, email: String, scopes: String, caps: String, rate: Int, quota: Int) -> Unit
) {
    var appName by remember { mutableStateOf("") }
    var developerName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var scopes by remember { mutableStateOf("CHAT, CALENDAR, FESTIVAL, MANTRA") }
    var capabilities by remember { mutableStateOf("AI_CHAT, DAILY_DATE, BANGLA_DATE, UPCOMING_FESTIVAL, MANTRA_SEARCH") }
    var rateLimit by remember { mutableStateOf("60") }
    var dailyQuota by remember { mutableStateOf("10000") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Register External Application", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = appName,
                    onValueChange = { appName = it },
                    label = { Text("Application Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = developerName,
                    onValueChange = { developerName = it },
                    label = { Text("Developer / Organization Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Contact Email") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = scopes,
                    onValueChange = { scopes = it },
                    label = { Text("Allowed Scopes (comma separated)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = capabilities,
                    onValueChange = { capabilities = it },
                    label = { Text("Initial Capabilities") },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = rateLimit,
                        onValueChange = { rateLimit = it },
                        label = { Text("Rate Limit/Min") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = dailyQuota,
                        onValueChange = { dailyQuota = it },
                        label = { Text("Daily Quota") },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (appName.isNotBlank() && developerName.isNotBlank()) {
                        val rate = rateLimit.toIntOrNull() ?: 60
                        val quota = dailyQuota.toIntOrNull() ?: 10000
                        onRegister(appName, developerName, email, scopes, capabilities, rate, quota)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
            ) {
                Text("Register App")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun EditScopesDialog(
    app: ExternalAppEntity,
    onDismiss: () -> Unit,
    onSave: (scopes: String, capabilities: String) -> Unit
) {
    var scopes by remember { mutableStateOf(app.allowedScopes) }
    var capabilities by remember { mutableStateOf(app.activeCapabilities) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Scopes: ${app.appName}", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = scopes,
                    onValueChange = { scopes = it },
                    label = { Text("Allowed API Scopes") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = capabilities,
                    onValueChange = { capabilities = it },
                    label = { Text("Active Capabilities") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(scopes, capabilities) },
                colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
            ) {
                Text("Save Changes")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun EditRateLimitDialog(
    app: ExternalAppEntity,
    onDismiss: () -> Unit,
    onSave: (rateLimit: Int, quota: Int) -> Unit
) {
    var rateLimit by remember { mutableStateOf(app.rateLimitPerMin.toString()) }
    var dailyQuota by remember { mutableStateOf(app.dailyQuota.toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Configure Limits: ${app.appName}", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = rateLimit,
                    onValueChange = { rateLimit = it },
                    label = { Text("Requests per Minute") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = dailyQuota,
                    onValueChange = { dailyQuota = it },
                    label = { Text("Daily Quota (Requests/Day)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val rate = rateLimit.toIntOrNull() ?: app.rateLimitPerMin
                    val quota = dailyQuota.toIntOrNull() ?: app.dailyQuota
                    onSave(rate, quota)
                },
                colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
            ) {
                Text("Save Limits")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
