package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "knowledge_items")
data class KnowledgeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val knowledgeCode: String = "", // e.g. KB-001, CONV-001, MANTRA-001
    val title: String,
    val question: String = "", // User Question / Trigger question (e.g. "ভগবদ্গীতা কী?", "তুমি কেমন আছো?")
    val answer: String = "", // Canonical taught answer text
    val category: String, // GENERAL_CONVERSATION, GENERAL_DHARMA, DEITY, MANTRA, SCRIPTURE, VEDA, UPANISHAD, PUJA, FESTIVAL, SANSKRIT, PHILOSOPHY
    val subcategory: String = "",
    val language: String = "BENGALI", // BENGALI, SANSKRIT, ENGLISH, BILINGUAL
    val sanskritText: String = "",
    val transliteration: String = "",
    val banglaMeaning: String = "",
    val englishMeaning: String = "",
    val explanation: String = "",
    val scripture: String = "",
    val chapter: String = "",
    val verse: String = "",
    val reference: String = "",
    val source: String = "ADMIN_TAUGHT", // ADMIN_TAUGHT, SCRIPTURE, BOOK, WEBSITE, TRADITIONAL, ADMIN_VERIFIED_REFERENCE
    val sourceType: String = "Shruti", // Shruti, Smriti, Purana, Itihasa, Tantra, Stotra, Traditional
    val verificationStatus: String = "PUBLISHED", // DRAFT, PENDING, CANDIDATE, APPROVED, PUBLISHED, REJECTED, ARCHIVED
    val confidenceScore: Float = 0.99f,
    val tags: String = "",
    val version: Int = 1, // Knowledge versioning (v1, v2, v3)
    val usageCount: Long = 0, // Number of times used in user queries
    val successCount: Long = 0, // Successful matches / positive feedback
    val lastUsedDate: Long = 0,
    val createdBy: String = "Admin",
    val updatedBy: String = "Admin",
    val createdDate: Long = System.currentTimeMillis(),
    val updatedDate: Long = System.currentTimeMillis()
)

@Entity(tableName = "unknown_knowledge_queue")
data class UnknownKnowledgeEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val userQuestion: String,
    val aiResponse: String = "এই বিষয়টি সম্পর্কে আমার যাচাই করা জ্ঞানে পর্যাপ্ত তথ্য নেই। আপনি চাইলে আমাকে তথ্যটি শেখাতে পারেন।",
    val whyUnknown: String = "No verified scripture or published knowledge record matched query",
    val searchResultStatus: String = "EXHAUSTED_NO_MATCH", // EXHAUSTED_NO_MATCH, LOW_CONFIDENCE, AMBIGUOUS
    val suggestedCategory: String = "GENERAL_DHARMA",
    val frequency: Int = 1,
    val status: String = "PENDING", // PENDING, CANDIDATE_CREATED, RESOLVED, DISMISSED
    val createdAt: Long = System.currentTimeMillis(),
    val resolvedAt: Long? = null,
    val resolvedKnowledgeId: Long? = null
)

@Entity(tableName = "knowledge_versions")
data class KnowledgeVersionEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val knowledgeId: Long,
    val versionNumber: Int,
    val title: String,
    val question: String,
    val answer: String,
    val category: String,
    val source: String,
    val reference: String,
    val changedBy: String = "Admin",
    val changeReason: String = "Knowledge Teaching / Correction",
    val diffSummary: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "knowledge_usage_logs")
data class KnowledgeUsageLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val knowledgeId: Long,
    val userQuery: String,
    val matchedStrategy: String = "EXACT", // EXACT, PHONETIC, SEMANTIC, KEYWORD
    val confidence: Float = 0.99f,
    val feedbackScore: Int = 0, // 0 = Neutral, 1 = Helpful, -1 = Correction Requested
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "api_keys")
data class ApiKeyEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val name: String,
    val appName: String,
    val description: String = "",
    val apiKey: String,
    val maskedKey: String,
    val provider: String = "Dharma AI Gateway", // Dharma AI Gateway, Google Gemini, OpenAI, Anthropic, Groq, Custom REST API
    val endpoint: String = "https://ais-dev-v2q3z47ktmramt3bwyb577-234096854893.asia-southeast1.run.app/api/v1/chat",
    val model: String = "dharma-ai-v1",
    val version: String = "v1", // v1, v2, v3
    val status: String = "Active", // Active, Suspended, Expired, Revoked, Error
    val allowedDomains: String = "*",
    val allowedApplications: String = "All Clients",
    val permissions: String = "chat,knowledge,mantra,scripture,puja,research,verify,status,calendar,festival",
    val rateLimitPerMin: Int = 60,
    val dailyLimit: Int = 5000,
    val monthlyLimit: Int = 100000,
    val requestCount: Long = 0,
    val errorCount: Long = 0,
    val lastUsed: Long = 0,
    val lastResponseTimeMs: Long = 0,
    val lastErrorMessage: String? = null,
    val lastSuccessTimestamp: Long = 0,
    val configJson: String = "{}",
    val expiresAt: Long = 0, // 0 = Never
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "api_logs")
data class ApiLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val endpoint: String,
    val method: String = "POST",
    val statusCode: Int = 200,
    val responseTimeMs: Long = 120,
    val apiKeyName: String = "Default App Key",
    val clientIdentifier: String = "VedaNova Mobile",
    val requestPayloadSummary: String = "",
    val responseStatusText: String = "OK",
    val errorMessage: String? = null,
    val tokensUsed: Int = 145,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "issue_records")
data class IssueEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val issueCode: String,
    val title: String,
    val description: String,
    val userQuery: String = "",
    val aiResponse: String = "",
    val expectedResponse: String = "",
    val actualResponse: String = "",
    val severity: String = "Medium", // Critical, High, Medium, Low
    val category: String = "AI Wrong Answer", // AI Wrong Answer, Unknown Knowledge, Wrong Intent, Ambiguous Query, Incorrect Source, Verification Failure, API Error, Database Error, Performance Problem, Translation Problem, Knowledge Conflict, Security Warning
    val status: String = "Open", // Open, Investigating, Fixed, Verified, Closed
    val detectedDate: Long = System.currentTimeMillis(),
    val assignedAdmin: String = "Unassigned",
    val resolution: String = "",
    val notes: String = ""
)

@Entity(tableName = "user_reports")
data class ReportEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val reportCode: String,
    val reportType: String, // Wrong Answer, Missing Knowledge, Incorrect Scripture, Incorrect Translation, Technical Problem, Other
    val title: String,
    val description: String,
    val userQuery: String = "",
    val aiResponse: String = "",
    val scriptureRef: String = "",
    val status: String = "Pending", // Pending, In Review, Resolved, Dismissed
    val priority: String = "Medium", // High, Medium, Low
    val submittedBy: String = "App User",
    val createdAt: Long = System.currentTimeMillis(),
    val resolutionNotes: String = ""
)

@Entity(tableName = "audit_logs")
data class AuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val adminUsername: String,
    val adminRole: String,
    val action: String,
    val targetType: String, // API, KNOWLEDGE, ISSUE, SETTING, DATABASE, SECURITY, USER
    val targetId: String = "",
    val details: String,
    val ipAddress: String = "127.0.0.1",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "system_logs")
data class SystemLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val category: String, // API, AI_ORCHESTRATOR, KNOWLEDGE_ENGINE, AUTH, DATABASE, SECURITY, RESEARCH
    val level: String = "INFO", // INFO, WARN, ERROR, DEBUG
    val message: String,
    val metadata: String = "",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "admin_users")
data class AdminUserEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val username: String,
    val fullName: String,
    val role: String, // Super Admin, Admin, Knowledge Manager, Reviewer, Support, Developer
    val email: String,
    val lastLogin: Long = System.currentTimeMillis(),
    val isActive: Boolean = true,
    val permissions: String = "ALL"
)

@Entity(tableName = "system_settings")
data class SystemSettingEntity(
    @PrimaryKey val key: String,
    val value: String,
    val category: String = "General",
    val description: String = "",
    val updatedAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "backups")
data class BackupEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val backupName: String,
    val backupType: String = "Full Snapshot",
    val recordCount: Int = 0,
    val sizeKb: Int = 0,
    val status: String = "Verified",
    val checksum: String = "",
    val createdAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "capability_proposals")
data class CapabilityProposalEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val capabilityCode: String,
    val name: String,
    val bengaliName: String,
    val category: String, // Calendar, Puja, Mantra, Scripture, Location, Custom
    val description: String,
    val proposedByApp: String,
    val triggerQuery: String,
    val detectedNeeds: String, // e.g. "Location + Calendar + Puja Timing"
    val inputSchemaJson: String,
    val outputSchemaJson: String,
    val safetyRating: String = "Safe - Composed Read-Only",
    val status: String = "AI_PROPOSED", // AI_PROPOSED, ACTIVE, REJECTED, DISABLED
    val createdAt: Long = System.currentTimeMillis(),
    val reviewedAt: Long? = null,
    val reviewedByAdmin: String? = null,
    val reviewNotes: String = ""
)

@Entity(tableName = "daily_job_logs")
data class DailyJobLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val jobName: String = "Dynamic Daily Calendar & Festival Resolution",
    val region: String = "BANGLADESH_DHAKA",
    val gregorianDate: String,
    val bengaliDate: String,
    val tithi: String,
    val festivalToday: String,
    val updatedRecords: Int,
    val failedRecords: Int = 0,
    val status: String = "SUCCESS", // SUCCESS, WARNING, FAILED
    val calendarVersion: String = "v2026.08-surya-siddhanta-drik",
    val dataSource: String = "Verified Astronomical Ephemeris & Canonical Almanac",
    val verificationStatus: String = "VERIFIED",
    val executionDurationMs: Long = 45,
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "external_apps")
data class ExternalAppEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val appId: String, // e.g. APP-PUJA-CAL-809
    val appName: String,
    val developerName: String,
    val contactEmail: String,
    val apiKey: String,
    val maskedKey: String,
    val status: String = "ACTIVE", // ACTIVE, SUSPENDED, RATE_LIMITED, DISABLED
    val apiVersion: String = "v1.0",
    val allowedScopes: String = "CHAT,CALENDAR,FESTIVAL,PUJA,MANTRA,SCRIPTURE,STATUS",
    val activeCapabilities: String = "DAILY_DATE,BANGLA_DATE,FESTIVAL_CALENDAR,UPCOMING_FESTIVAL,PUJA_INFORMATION,MANTRA_SEARCH,SCRIPTURE_SEARCH,AI_CHAT",
    val rateLimitPerMin: Int = 120,
    val dailyQuota: Int = 10000,
    val requestsToday: Long = 0,
    val requestsThisMonth: Long = 0,
    val totalRequests: Long = 0,
    val errorCount: Long = 0,
    val avgLatencyMs: Long = 85,
    val lastActiveTimestamp: Long = System.currentTimeMillis(),
    val registeredAt: Long = System.currentTimeMillis()
)

@Entity(tableName = "crash_reports")
data class CrashReportEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val crashId: String, // e.g. "CRASH-20260826-A1B2"
    val screen: String,
    val navigationRoute: String,
    val timestamp: Long = System.currentTimeMillis(),
    val exceptionType: String,
    val errorMessage: String,
    val stackTrace: String,
    val lastAction: String = "User Navigation / Interaction",
    val previousRoute: String = "DASHBOARD",
    val currentRoute: String = "DASHBOARD",
    val userRole: String = "Admin",
    val appVersion: String = "v5.1.0-prod"
)

@Entity(tableName = "function_activity_logs")
data class FunctionActivityLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val functionId: String,
    val functionName: String,
    val section: String,
    val previousScreen: String,
    val currentScreen: String,
    val adminUser: String = "Admin",
    val timestamp: Long = System.currentTimeMillis()
)

@Entity(tableName = "development_tasks")
data class DevelopmentTaskEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val taskCode: String = "", // e.g. TASK-20260827-01
    val title: String,
    val instruction: String,
    val category: String = "FEATURE_CREATION", // FEATURE_CREATION, UI_CHANGE, LOGO_UPDATE, FUNCTION_ADDITION, SETTINGS_UPDATE, KNOWLEDGE_ADDITION
    val targetLocation: String = "Home / Settings",
    val requiredComponents: String = "UI, Database, Logic",
    val proposedChanges: String = "",
    val attachedImageUri: String? = null,
    val status: String = "WAITING_FOR_APPROVAL", // ANALYZING, PLANNING, IMPLEMENTING, WAITING_FOR_APPROVAL, APPROVED, TESTING, COMPLETED, FAILED, REJECTED
    val currentStep: String = "Waiting for Admin Approval", // Analyzing -> Planning -> Implementing -> Testing -> Completed
    val impactAssessment: String = "Safe - Non-destructive verified operation",
    val executionLogs: String = "",
    val approvedBy: String? = null,
    val approvedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null
)

@Entity(tableName = "generated_images")
data class GeneratedImageEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val imageCode: String = "",
    val prompt: String,
    val enhancedDharmaPrompt: String = "",
    val aspectRatio: String = "1:1",
    val imageUri: String = "",
    val localFilePath: String = "",
    val provider: String = "Google Gemini Image",
    val modelName: String = "gemini-2.5-flash-image",
    val status: String = "SUCCESS", // IDLE, GENERATING, SUCCESS, FAILED, NOT_CONFIGURED
    val errorMessage: String? = null,
    val width: Int = 1024,
    val height: Int = 1024,
    val isSavedToGallery: Boolean = false,
    val isFavorite: Boolean = false,
    val sourceContext: String = "PUBLIC_CHAT",
    val createdAt: Long = System.currentTimeMillis()
)



