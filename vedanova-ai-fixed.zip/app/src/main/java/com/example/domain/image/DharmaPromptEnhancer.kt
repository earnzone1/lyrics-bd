package com.example.domain.image

import java.util.Locale

object DharmaPromptEnhancer {

    /**
     * Translates and enriches spiritual prompts into respectful, high-quality
     * artistic visual descriptions suitable for real image generation models.
     * Note: Never invents fake mantras or scriptures; focuses purely on visual aesthetics.
     */
    fun enhancePrompt(userPrompt: String): String {
        val trimmed = userPrompt.trim()
        val lower = trimmed.lowercase(Locale.ROOT)

        // Base visual style tokens for dignified sacred and devotional art
        val spiritualStyle = "Masterpiece sacred art, divine celestial golden hour lighting, authentic traditional iconography, majestic atmosphere, high resolution, intricate devotional aesthetic"

        val specificVisual = when {
            lower.contains("কৃষ্ণ") || lower.contains("krishna") || lower.contains("শ্যাম") -> {
                "Divine depiction of Sri Krishna with sacred peacock feather, gentle serene smile, playing bansuri flute, bathed in warm ethereal glow, Vrindavan nature background with blooming lotuses"
            }
            lower.contains("শিব") || lower.contains("shiva") || lower.contains("মহাদেব") || lower.contains("mahadev") -> {
                "Majestic depiction of Lord Shiva in deep peaceful meditation on Mount Kailash, crescent moon in matted hair, holy Ganga stream, sacred trishula and damru nearby, serene Himalayan mountain snowscape"
            }
            lower.contains("দুর্গা") || lower.contains("durga") || lower.contains("দেবী") -> {
                "Radiant depiction of Goddess Maa Durga on majestic lion, divine golden weapons, gentle yet powerful benevolent expression, traditional glowing aura, celestial sacred illumination"
            }
            lower.contains("রাম") || lower.contains("rama") || lower.contains("সীতা") || lower.contains("sita") -> {
                "Serene noble portrait of Lord Sri Rama with sacred bow, calm righteous posture, traditional royal Vedic attire, graceful golden sunlight, sacred forest surroundings"
            }
            lower.contains("গণেশ") || lower.contains("ganesha") || lower.contains("গণপতি") -> {
                "Auspicious portrait of Lord Ganesha holding sacred modaka and lotus, gentle eyes of wisdom, illuminated with divine radiance, glowing oil lamps in sacred temple sanctum"
            }
            lower.contains("হনুমান") || lower.contains("hanuman") || lower.contains("বজরংবলী") -> {
                "Devotional depiction of Sri Hanuman in deep reverence and devotion to Sri Rama, noble posture, golden glow of spiritual strength, sacred Himalayan background"
            }
            lower.contains("মন্দির") || lower.contains("temple") -> {
                "Ancient Vedic architectural stone temple at sunset, intricately carved shikhara towers, sacred courtyard with glowing brass ghee lamps, spiritual peaceful sanctuary"
            }
            lower.contains("গঙ্গা") || lower.contains("ganga") || lower.contains("আরতি") || lower.contains("aarti") -> {
                "Sacred Ganga Aarti at ancient river ghats, glowing brass fire lamps reflecting on holy river waters, gentle evening twilight, devotional atmosphere"
            }
            lower.contains("প্রকৃতি") || lower.contains("nature") || lower.contains("হিমালয়") -> {
                "Breathtaking serene Himalayan valley, crystal clear holy stream flowing through alpine meadows, soft morning mist, peaceful spiritual solitude"
            }
            lower.contains("পূজা") || lower.contains("যজ্ঞ") || lower.contains("হবন") || lower.contains("yajna") -> {
                "Traditional sacred Vedic yajna fire altar, holy ghee offerings, pure dancing flames, sacred sandalwood logs, quiet meditative spiritual ambiance"
            }
            else -> {
                trimmed
            }
        }

        return if (specificVisual == trimmed) {
            "$trimmed, $spiritualStyle"
        } else {
            "$specificVisual, $spiritualStyle, based on user request: \"$trimmed\""
        }
    }
}
