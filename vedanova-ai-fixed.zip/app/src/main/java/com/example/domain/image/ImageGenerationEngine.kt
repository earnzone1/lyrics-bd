package com.example.domain.image

import android.content.Context
import com.example.data.dao.AuditLogDao
import com.example.data.dao.GeneratedImageDao
import com.example.data.model.AuditLogEntity
import com.example.data.model.GeneratedImageEntity
import com.example.domain.diagnostic.CrashReportingManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.withContext
import java.util.Locale

class ImageGenerationEngine(
    private val generatedImageDao: GeneratedImageDao,
    private val auditLogDao: AuditLogDao
) {
    private val providers: MutableList<ImageGenerationProvider> = mutableListOf(
        GeminiImageProvider()
    )

    private var activeProviderIndex = 0

    val activeProvider: ImageGenerationProvider
        get() = providers.getOrElse(activeProviderIndex) { providers.first() }

    private val _engineState = MutableStateFlow(ImageGenerationStatus.IDLE)
    val engineState = _engineState.asStateFlow()

    private val _lastResult = MutableStateFlow<ImageGenerationResult?>(null)
    val lastResult = _lastResult.asStateFlow()

    fun getAllImages(): Flow<List<GeneratedImageEntity>> = generatedImageDao.getAllImages()
    fun getRecentImages(limit: Int = 10): Flow<List<GeneratedImageEntity>> = generatedImageDao.getRecentImages(limit)
    fun getTotalCount(): Flow<Int> = generatedImageDao.getTotalCount()
    fun getSuccessfulCount(): Flow<Int> = generatedImageDao.getSuccessfulCount()
    fun getFailedCount(): Flow<Int> = generatedImageDao.getFailedCount()

    fun isConfigured(): Boolean = activeProvider.isConfigured()

    fun registerProvider(provider: ImageGenerationProvider) {
        if (providers.none { it.providerId == provider.providerId }) {
            providers.add(provider)
        }
    }

    suspend fun generateImage(
        request: ImageGenerationRequest,
        context: Context
    ): ImageGenerationResult = withContext(Dispatchers.IO) {
        _engineState.value = ImageGenerationStatus.GENERATING

        val provider = activeProvider
        val result = provider.generateImage(request, context)

        val entity = GeneratedImageEntity(
            imageCode = result.imageCode.ifBlank { "IMG-${System.currentTimeMillis() % 1000000}" },
            prompt = request.prompt,
            enhancedDharmaPrompt = result.enhancedPrompt,
            aspectRatio = request.aspectRatio.ratioStr,
            imageUri = result.imageUri ?: "",
            localFilePath = result.localFilePath ?: "",
            provider = provider.providerName,
            modelName = provider.defaultModel,
            status = result.status.name,
            errorMessage = result.errorMessage,
            width = request.aspectRatio.width,
            height = request.aspectRatio.height,
            sourceContext = request.requestedBy,
            createdAt = result.generatedAt
        )

        try {
            val insertedId = generatedImageDao.insertImage(entity)
            auditLogDao.insertAuditLog(
                AuditLogEntity(
                    adminUsername = request.requestedBy,
                    adminRole = "SYSTEM_OR_USER",
                    action = "IMAGE_GENERATION_${result.status.name}",
                    targetType = "IMAGE",
                    targetId = entity.imageCode,
                    details = "Prompt: \"${request.prompt}\" | Status: ${result.status.name} | Error: ${result.errorMessage ?: "None"}"
                )
            )

            val finalResult = result.copy(imageId = insertedId)
            _lastResult.value = finalResult
            _engineState.value = result.status
            finalResult
        } catch (e: Exception) {
            CrashReportingManager.recordException(
                screen = "IMAGE_STUDIO",
                throwable = e,
                action = "ImageGenerationEngine.generateImage.persistence"
            )
            _lastResult.value = result
            _engineState.value = result.status
            result
        }
    }

    suspend fun understandImage(
        imageFilePath: String,
        userQuestion: String,
        context: Context
    ): ImageUnderstandingResult = withContext(Dispatchers.IO) {
        val provider = activeProvider
        provider.understandImage(imageFilePath, userQuestion, context)
    }

    suspend fun saveToGallery(
        imageEntity: GeneratedImageEntity,
        context: Context
    ): Boolean = withContext(Dispatchers.IO) {
        if (imageEntity.localFilePath.isBlank()) return@withContext false
        val success = ImageStorageManager.saveToPublicGallery(
            context = context,
            sourceFilePath = imageEntity.localFilePath,
            title = imageEntity.prompt
        )
        if (success) {
            generatedImageDao.updateImage(imageEntity.copy(isSavedToGallery = true))
        }
        success
    }

    suspend fun deleteImage(
        imageEntity: GeneratedImageEntity
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            if (imageEntity.localFilePath.isNotBlank()) {
                ImageStorageManager.deleteLocalFile(imageEntity.localFilePath)
            }
            generatedImageDao.deleteImage(imageEntity)
            auditLogDao.insertAuditLog(
                AuditLogEntity(
                    adminUsername = "Admin/User",
                    adminRole = "USER",
                    action = "IMAGE_DELETED",
                    targetType = "IMAGE",
                    targetId = imageEntity.imageCode,
                    details = "Deleted generated image with prompt: ${imageEntity.prompt}"
                )
            )
            true
        } catch (e: Exception) {
            CrashReportingManager.recordException(
                screen = "IMAGE_STUDIO",
                throwable = e,
                action = "ImageGenerationEngine.deleteImage"
            )
            false
        }
    }

    /**
     * Detects whether a chat query is an image generation intent
     */
    fun isImageGenerationIntent(query: String): Boolean {
        val norm = query.lowercase(Locale.ROOT).trim()
        val imageKeywords = listOf(
            "ছবি তৈরি করো", "ছবি বানাও", "ছবি আঁকো", "চিত্র তৈরি করো", "একটি ফটো বানাও",
            "ছবি জেনারেট করো", "ছবি দেখাও", "একটি ছবি বানাও", "একটি ছবি তৈরি করো",
            "image বানাও", "photo বানাও", "picture বানাও",
            "generate image", "create image", "draw an image", "paint an image", "create a photo of",
            "generate picture", "draw a picture", "make a photo of"
        )
        if (imageKeywords.any { norm.contains(it) }) {
            return true
        }

        // Check patterns like "...এর ছবি", "...এর চিত্র", "শ্রীকৃষ্ণের ছবি"
        if ((norm.contains("ছবি") || norm.contains("চিত্র") || norm.contains("photo") || norm.contains("image")) &&
            (norm.contains("বানাও") || norm.contains("করো") || norm.contains("দেখা") || norm.contains("আঁকো") || norm.contains("make") || norm.contains("create") || norm.contains("generate"))
        ) {
            return true
        }

        return false
    }

    /**
     * Cleans up the image query to extract pure prompt
     */
    fun extractPromptFromQuery(query: String): String {
        var clean = query.trim()
        val removePhrases = listOf(
            "একটি ছবি তৈরি করো", "একটি ছবি বানাও", "ছবি তৈরি করো", "ছবি বানাও",
            "ছবি আঁকো", "চিত্র তৈরি করো", "একটি ফটো বানাও", "ছবি জেনারেট করো",
            "please generate an image of", "generate an image of", "create an image of",
            "draw an image of", "generate image", "create image", "draw image",
            "দয়া করে", "অনুগ্রহ করে", "আমাকে", "একটি", "একটা"
        )
        for (phrase in removePhrases) {
            clean = clean.replace(phrase, "", ignoreCase = true).trim()
        }
        return if (clean.isBlank()) query else clean
    }
}
