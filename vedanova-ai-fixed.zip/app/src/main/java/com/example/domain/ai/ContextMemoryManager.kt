package com.example.domain.ai

import java.util.Locale
import java.util.UUID

data class ConversationTurn(
    val id: String = UUID.randomUUID().toString(),
    val userQuery: String,
    val aiResponse: String,
    val intentDetected: String,
    val resolvedSubject: String?,
    val timestamp: Long = System.currentTimeMillis()
)

data class ConversationContextState(
    val sessionId: String = UUID.randomUUID().toString(),
    val activeSubject: String? = null,
    val activeDeity: String? = null,
    val activeDeityKey: String? = null, // "SHIVA", "KRISHNA", "DURGA", "GANESHA", "SARASWATI", "LAKSHMI", "SURYA", "HANUMAN"
    val activeScripture: String? = null,
    val activeMantra: String? = null,
    val activeMantraSanskrit: String? = null,
    val activeMantraMeaning: String? = null,
    val activeMantraSource: String? = null,
    val activeChapter: String? = null,
    val lastDetectedLanguage: String = "Bengali (বাংলা)",
    val threadTurnCount: Int = 0,
    val contextSummary: String = "Fresh Context",
    val recentTurns: List<ConversationTurn> = emptyList(),
    val isAwaitingMantraDisambiguation: Boolean = false
)

data class MultiIntentAnalysis(
    val isGreeting: Boolean = false,
    val isCreatorInquiry: Boolean = false,
    val isIdentityInquiry: Boolean = false,
    val isDeityInquiry: Boolean = false,
    val isMantraRequest: Boolean = false,
    val isMeaningRequest: Boolean = false,
    val isSourceRequest: Boolean = false,
    val isChantingMethodRequest: Boolean = false,
    val isAnotherMantraRequest: Boolean = false,
    val isMantraClarificationAnswer: Boolean = false,
    val isBroadMantraInquiry: Boolean = false,
    val detectedDeity: String? = null,
    val detectedScripture: String? = null,
    val detectedMantra: String? = null,
    val primaryIntent: String = "GENERAL_DHARMA",
    val secondaryIntents: List<String> = emptyList()
)

object ContextMemoryManager {

    // In-memory Session Cache for Multi-Turn API & UI conversations (SessionId -> State)
    private val sessionStore = mutableMapOf<String, ConversationContextState>()

    fun getOrCreateSession(sessionId: String): ConversationContextState {
        return sessionStore.getOrPut(sessionId) {
            ConversationContextState(sessionId = sessionId)
        }
    }

    fun updateSession(sessionId: String, updatedState: ConversationContextState) {
        sessionStore[sessionId] = updatedState
    }

    fun clearSession(sessionId: String) {
        sessionStore.remove(sessionId)
    }

    fun analyzeMultiIntent(query: String, previousState: ConversationContextState): MultiIntentAnalysis {
        val q = query.trim().lowercase(Locale.ROOT)

        val isCreator = q.contains("কে বানিয়েছে") || q.contains("কে তৈরি করেছে") || q.contains("কে বানিয়েছে") ||
                q.contains("কে বানাইছে") || q.contains("creator কে") || q.contains("নির্মাতা কে") ||
                q.contains("প্রস্তুতকারক") || q.contains("আবিষ্কারক") || q.contains("বানিয়েছে কে") ||
                q.contains("বানিয়েছে কে") || q.contains("তৈরি করেছে কে") ||
                q.contains("who created you") || q.contains("who made you") || q.contains("who is your creator") ||
                q.contains("who built you") || q.contains("who developed you") || q.contains("your creator") ||
                q.contains("who created dharma ai") || q.contains("creator of dharma ai") ||
                q.contains("মহামতি মিলন চন্দ্র") || q.contains("মিলন চন্দ্র") || q.contains("milon chandra")

        val isIdentity = !isCreator && (
                q.contains("তুমি কে") || q.contains("তোমার নাম কি") || q.contains("তোমার নাম কী") ||
                q.contains("তোমার পরিচয়") || q.contains("who are you") || q.contains("what is your name") ||
                q == "who are you?" || q == "who are you" || q.startsWith("tell me about yourself")
                )

        val isGreeting = !isCreator && (
                q.startsWith("নমস্কার") || q.startsWith("প্রণাম") || q.startsWith("কেমন আছো") ||
                q.startsWith("কেমন আছেন") || q == "hello" || q == "hi" || q == "namaste" ||
                q.startsWith("শুভ সকাল") || q.startsWith("শুভ সন্ধ্যা") || q.startsWith("শুভ রাত্রি") ||
                q == "ধন্যবাদ" || q == "thanks" || q == "thank you" || q.startsWith("ভালো থেকো")
                )

        val hasPronoun = q.contains("তার") || q.contains("তাঁর") || q.contains("উহার") ||
                q.contains("এর") || q.contains("ওর") || q.contains("এটার") || q.contains("ওটার") ||
                q.contains("এইটা") || q.contains("ওইটা") || q.contains("সেটার") || q.contains("সেটির") ||
                q.contains("এখানে") || q.contains("সেখানে") || q.contains("একইটা") || q.contains("অন্যটা") ||
                q.contains("আগেরটা") || q.contains("পরেরটা") || q.contains("আরেকটা") || q.contains("আরেকটি") ||
                q.contains("মন্ত্রটার") || q.contains("মন্ত্রটির") || q.contains("শ্লোকটার") || q.contains("শ্লোকটির") ||
                q.contains("মানে কী") || q.contains("মানে কি") || q.contains("কার?") || q.contains("কার") ||
                q.contains("কোথা থেকে") || q.contains("his ") || q.contains("her ") || q.contains("its ") ||
                q.contains("this ") || q.contains("that ") || q.contains("another ")

        val isMantra = q.contains("মন্ত্র") || q.contains("স্তোত্র") || q.contains("শ্লোক") ||
                q.contains("mantra") || q.contains("stotra") || q.contains("verse") ||
                q.contains("জপ") || q.contains("প্রণাম মন্ত্র") || q.contains("তারক")

        val isMeaning = q.contains("অর্থ") || q.contains("অনুবাদ") || q.contains("ভাবার্থ") ||
                q.contains("ব্যাখ্যা") || q.contains("মানে কী") || q.contains("মানে কি") ||
                q.contains("মানে") || q.contains("meaning") || q.contains("translate") ||
                q.contains("explain") || q.contains("significance")

        val isSource = q.contains("কোথায় পাওয়া যায়") || q.contains("কোথায় পাওয়া যায়") ||
                q.contains("কোথা থেকে এসেছে") || q.contains("কোথা থেকে") ||
                q.contains("উৎস") || q.contains("কোন শাস্ত্রে") || q.contains("কোন্ গ্রন্থে") ||
                q.contains("source") || q.contains("scripture") || q.contains("which book") ||
                q.contains("reference") || q.contains("origin") || q.contains("কোথায় আছে")

        val isDeityIdentity = q.contains("এটা কার") || q.contains("এটি কার") || q.contains("কার মন্ত্র") ||
                q.contains("কোন দেবতার") || q.contains("কার শ্লোক") || q.contains("who is this for") ||
                q.contains("which deity")

        val isChanting = q.contains("কীভাবে জপ") || q.contains("কিভাবে জপ") ||
                q.contains("জপের নিয়ম") || q.contains("জপের নিয়ম") || q.contains("how to chant") || q.contains("procedure")

        val isAnother = q.contains("আরেকটা") || q.contains("আরেকটি") || q.contains("অন্য একটি") ||
                q.contains("অন্যান্য") || q.contains("another") || q.contains("one more") ||
                q.contains("more mantras") || q.contains("আরেকটা দাও") || q.contains("আরেকটি দাও") ||
                q.contains("অন্যটা দাও") || q.contains("আরেকটা শ্লোক") || q.contains("আরেকটি শ্লোক")

        val isMore = q.contains("আরও বলো") || q.contains("আরো বলো") || q.contains("আরও বলুন") ||
                q.contains("আরও জানতে চাই") || q.contains("আরো জানতে চাই") || q.contains("tell me more") ||
                q.contains("more details") || q.contains("বিস্তারিত বলো")

        val isTiming = q.contains("কখন করতে হয়") || q.contains("কখন করা হয়") || q.contains("কখন হয়") ||
                q.contains("কখন দেব") || q.contains("কখন জ্বালানো হয়") || q.contains("সময় কী") ||
                q.contains("when to perform") || q.contains("timing")

        // Check if query is answering a broad mantra clarification (e.g. user just typed "শিব" or "shiva")
        val isMantraClarificationAnswer = previousState.isAwaitingMantraDisambiguation && (
                q.contains("শিব") || q.contains("shiva") || q.contains("কৃষ্ণ") || q.contains("krishna") ||
                        q.contains("দুর্গা") || q.contains("durga") || q.contains("গণেশ") || q.contains("ganesha") ||
                        q.contains("সরস্বতী") || q.contains("saraswati") || q.contains("লক্ষ্মী") || q.contains("lakshmi") ||
                        q.contains("রাম") || q.contains("rama") || q.contains("সূর্য") || q.contains("surya")
                )

        val isBroadMantraInquiry = (q == "আমাকে একটি মন্ত্র দাও" || q == "একটি মন্ত্র দাও" ||
                q == "একটি মন্ত্র বলো" || q == "give me a mantra" || q == "tell me a mantra" ||
                q == "মন্ত্র দাও" || q == "mantra please" || q == "মন্ত্র") && !hasPronoun && previousState.activeDeity == null

        // Detect Deity (explicit switch takes highest priority)
        val detectedDeity = when {
            q.contains("শিব") || q.contains("shiva") || q.contains("মহাদেব") || q.contains("ভোলানাথ") || q.contains("রুদ্র") -> "Lord Shiva (মহাদেব শিব)"
            q.contains("কৃষ্ণ") || q.contains("krishna") || q.contains("গোবিন্দ") -> "Lord Krishna (শ্রীকৃষ্ণ)"
            q.contains("নারায়ণ") || q.contains("বিষ্ণু") || q.contains("vishnu") || q.contains("narayana") -> "Lord Vishnu (শ্রীবিষ্ণু / নারায়ণ)"
            q.contains("দুর্গা") || q.contains("durga") || q.contains("চণ্ডী") || q.contains("মহিষাসুরমর্দিনী") -> "Maa Durga (মা দুর্গা)"
            q.contains("কালী") || q.contains("kali") || q.contains("শ্যামা") -> "Maa Kali (মা কালী)"
            q.contains("গণেশ") || q.contains("ganesha") || q.contains("সিদ্ধিদাতা") || q.contains("গণপতি") || q.contains("ganapati") -> "Lord Ganesha (শ্রীগণেশ)"
            q.contains("সরস্বতী") || q.contains("saraswati") || q.contains("বাগদেবী") -> "Maa Saraswati (মা সরস্বতী)"
            q.contains("লক্ষ্মী") || q.contains("lakshmi") || q.contains("মहालक्ष्मी") || q.contains("কমলা") -> "Maa Lakshmi (মা লক্ষ্মী)"
            q.contains("রাম") || q.contains("rama") || q.contains("শ্রীরাম") || q.contains("রঘুপতি") -> "Lord Rama (শ্রীরামচন্দ্র)"
            q.contains("গায়ত্রী") || q.contains("gayatri") || q.contains("সবিতা") || q.contains("সূর্য") || q.contains("surya") -> "Surya / Gayatri Devata (সূর্যদেব / গায়ত্রী)"
            q.contains("হনুমান") || q.contains("hanuman") || q.contains("বজরংবলী") -> "Lord Hanuman (শ্রীহনুমানজী)"
            q.contains("তুলসী") || q.contains("tulasi") || q.contains("tulsi") -> "Devi Tulasi (দেবী তুলসী / তুলসী দেবী)"
            q.contains("গঙ্গা") || q.contains("ganga") || q.contains("ভাগীরথী") -> "Maa Ganga (মা গঙ্গা / গঙ্গা দেবী)"
            q.contains("কার্তিকেয়") || q.contains("kartikeya") || q.contains("কার্তিক") || q.contains("মুরুগান") -> "Lord Kartikeya (দেবসেনাপতি কার্তিকেয়)"
            q.contains("পার্বতী") || q.contains("parvati") || q.contains("উমা") || q.contains("গিরিজা") -> "Maa Parvati (দেবী পার্বতী)"
            q.contains("লক্ষ্মী-নারায়ণ") || q.contains("লক্ষ্মী নারায়ণ") || q.contains("lakshmi narayana") -> "Lord Lakshmi-Narayana (যুগলরূপ শ্রীশ্রীলক্ষ্মী-নারায়ণ)"
            hasPronoun -> previousState.activeDeity
            else -> null
        }

        // Detect Scripture (explicit switch takes priority)
        val detectedScripture = when {
            q.contains("গীতা") || q.contains("gita") -> "Bhagavad Gita (শ্রীমদ্ভগবদ্গীতা)"
            q.contains("উপনিষদ") || q.contains("upanishad") -> "Mukhya Upanishads (উপনিষদ)"
            q.contains("ঋগ্বেদ") || q.contains("বেদ") || q.contains("veda") -> "Vedas (বেদ সংহিতা)"
            q.contains("চণ্ডী") || q.contains("দেবী মাহাত্ম্য") -> "Devi Mahatmya (শ্রীশ্রীচণ্ডী)"
            q.contains("ভাগবত") || q.contains("ভাগবত পুরাণ") || q.contains("bhagavata") -> "Srimad Bhagavata Purana (শ্রীমদ্ভাগবত পুরাণ)"
            q.contains("মহাভারত") || q.contains("mahabharata") -> "Mahabharata (মহাভারত)"
            q.contains("পুরাণ") || q.contains("purana") -> "Puranas (পুরাণ)"
            q.contains("রামায়ণ") || q.contains("ramayana") -> "Ramayana (রামায়ণ)"
            hasPronoun -> previousState.activeScripture
            else -> null
        }

        // Detect Mantra
        val detectedMantra = when {
            q.contains("মহামৃত্যুঞ্জয়") || q.contains("mrityunjaya") || q.contains("ত্র্যম্বক") -> "Maha Mrityunjaya Mantra (মহামৃত্যুঞ্জয় মন্ত্র)"
            q.contains("গায়ত্রী") || q.contains("gayatri") -> "Gayatri Mantra (গায়ত্রী মন্ত্র)"
            q.contains("হরে কৃষ্ণ") || q.contains("মহামন্ত্র") -> "Hare Krishna Mahamantra (হরে কৃষ্ণ মহামন্ত্র)"
            q.contains("ওঁ নমঃ শিবায়") || q.contains("শিব পঞ্চাক্ষর") || q.contains("নমঃ শিবায়") || q.contains("নমঃ শিবায়") -> "Shiva Panchakshari Mantra (ওঁ নমঃ শিবায়)"
            q.contains("ওঁ গং গণপতয়ে") || q.contains("গণেশ মন্ত্র") || q.contains("গণপতে") -> "Ganesha Beej Mantra (ওঁ গং গণপতয়ে নমঃ)"
            q.contains("ওঁ নমো নারায়ণায়") || q.contains("নারায়ণ মন্ত্র") || q.contains("বিষ্ণু মন্ত্র") -> "Vishnu Ashtakshari Mantra (ওঁ নমো নারায়ণায়)"
            q.contains("ওঁ দুং দুর্গায়ৈ") || q.contains("দুর্গা বীজ") -> "Durga Beej Mantra (ওঁ দুং দুর্গায়ৈ নমঃ)"
            q.contains("ওঁ ঐং সরস্বত্যৈ") || q.contains("সরস্বতী বীজ") -> "Saraswati Beej Mantra (ওঁ ঐং সরস্বত্যৈ নমঃ)"
            q.contains("ওঁ শ্রীং মহালক্ষ্ম্যৈ") || q.contains("লক্ষ্মী বীজ") -> "Lakshmi Beej Mantra (ওঁ শ্রীং মহালক্ষ্ম্যৈ নমঃ)"
            q.contains("ওঁ সূর্যায় নমঃ") || q.contains("সূর্য প্রণাম") -> "Surya Pranam Mantra (ওঁ সূর্যায় নমঃ)"
            q.contains("শ্রী রাম জয় রাম") || q.contains("তারক মন্ত্র") -> "Rama Taraka Mantra (শ্রী রাম জয় রাম জয় জয় রাম)"
            q.contains("সর্বমঙ্গল") -> "Sarvamangala Mangalye (মা দুর্গা প্রণাম মন্ত্র)"
            q.contains("শান্তিপাঠ") || q.contains("shanti") -> "Shanti Patha (শান্তিপাঠ)"
            q.contains("স্নান মন্ত্র") || q.contains("গঙ্গে চ যমুনে") -> "Snana Mantra (গঙ্গে চ যমুনে চৈব - স্নানের মন্ত্র)"
            q.contains("তুলসী মন্ত্র") || q.contains("তুলসী পূজা") || q.contains("তুলসী প্রণাম") || q.contains("তুলসী অর্ঘ্য") -> "Tulasi Puja Mantra (তুলসী পূজার মন্ত্র)"
            q.contains("কালী মন্ত্র") || q.contains("কালিকায়ৈ") -> "Kali Beej Mantra (ওঁ ক্রীং কালিকায়ৈ নমঃ)"
            q.contains("গীতা ধ্যান") || q.contains("গীতা পাঠ") -> "Gita Dhyanam (গীতা ধ্যানম্ - প্রার্থ শ্লোক)"
            hasPronoun && previousState.activeMantra != null -> previousState.activeMantra
            else -> null
        }

        val secondaryList = mutableListOf<String>()
        if (isCreator) secondaryList.add("CREATOR_IDENTITY")
        if (isIdentity) secondaryList.add("AI_IDENTITY")
        if (isMantra) secondaryList.add("MANTRA_TEXT")
        if (isMeaning) secondaryList.add("MEANING")
        if (isSource) secondaryList.add("CANONICAL_SOURCE")
        if (isDeityIdentity) secondaryList.add("DEITY_IDENTITY")
        if (isChanting) secondaryList.add("CHANTING_PROCEDURE")
        if (isAnother) secondaryList.add("ANOTHER_MANTRA")

        val primaryIntent = when {
            isCreator -> "CREATOR_IDENTITY"
            isIdentity -> "AI_IDENTITY"
            isGreeting -> "GREETING"
            isBroadMantraInquiry -> "INTERACTIVE_MANTRA_CLARIFICATION"
            isMantraClarificationAnswer -> "MANTRA_SELECTION"
            isDeityIdentity -> "DEITY_IDENTITY_QUERY"
            isAnother && (detectedScripture?.contains("Gita", ignoreCase = true) == true || previousState.activeScripture?.contains("Gita", ignoreCase = true) == true) -> "ANOTHER_GITA_SHLOKA"
            isAnother -> "ANOTHER_MANTRA_REQUEST"
            isMeaning && isSource && isMantra -> "MULTI_INTENT_MANTRA_DECOMPOSITION"
            isMeaning && isSource -> "MULTI_INTENT_SOURCE_AND_MEANING"
            isMeaning -> "MANTRA_MEANING_QUERY"
            isSource -> "SCRIPTURE_SOURCE_QUERY"
            isChanting -> "CHANTING_PROCEDURE_QUERY"
            isMantra -> "MANTRA_REQUEST"
            detectedDeity != null && hasPronoun -> "DEITY_FOLLOW_UP"
            detectedDeity != null -> "DEITY_INQUIRY"
            else -> "GENERAL_DHARMA"
        }

        return MultiIntentAnalysis(
            isGreeting = isGreeting,
            isCreatorInquiry = isCreator,
            isIdentityInquiry = isIdentity,
            isDeityInquiry = detectedDeity != null,
            isMantraRequest = isMantra,
            isMeaningRequest = isMeaning,
            isSourceRequest = isSource,
            isChantingMethodRequest = isChanting,
            isAnotherMantraRequest = isAnother,
            isMantraClarificationAnswer = isMantraClarificationAnswer,
            isBroadMantraInquiry = isBroadMantraInquiry,
            detectedDeity = detectedDeity,
            detectedScripture = detectedScripture,
            detectedMantra = detectedMantra,
            primaryIntent = primaryIntent,
            secondaryIntents = secondaryList
        )
    }

    fun extractContextEntities(query: String, previousState: ConversationContextState): ConversationContextState {
        val analysis = analyzeMultiIntent(query, previousState)

        // If user explicitly switched deity, do not carry over previous deity's specific mantra
        val isExplicitDeitySwitch = analysis.detectedDeity != null &&
                previousState.activeDeity != null &&
                analysis.detectedDeity != previousState.activeDeity

        val resolvedDeity = analysis.detectedDeity ?: previousState.activeDeity
        val resolvedScripture = analysis.detectedScripture ?: previousState.activeScripture
        val resolvedMantra = if (isExplicitDeitySwitch) {
            analysis.detectedMantra
        } else {
            analysis.detectedMantra ?: previousState.activeMantra
        }

        val deityKey = when {
            resolvedDeity?.contains("Shiva", ignoreCase = true) == true || resolvedDeity?.contains("শিব") == true -> "SHIVA"
            resolvedDeity?.contains("Krishna", ignoreCase = true) == true || resolvedDeity?.contains("কৃষ্ণ") == true -> "KRISHNA"
            resolvedDeity?.contains("Vishnu", ignoreCase = true) == true || resolvedDeity?.contains("বিষ্ণু") == true || resolvedDeity?.contains("নারায়ণ") == true -> "VISHNU"
            resolvedDeity?.contains("Durga", ignoreCase = true) == true || resolvedDeity?.contains("দুর্গা") == true -> "DURGA"
            resolvedDeity?.contains("Ganesha", ignoreCase = true) == true || resolvedDeity?.contains("গণেশ") == true -> "GANESHA"
            resolvedDeity?.contains("Saraswati", ignoreCase = true) == true || resolvedDeity?.contains("সরস্বতী") == true -> "SARASWATI"
            resolvedDeity?.contains("Lakshmi", ignoreCase = true) == true || resolvedDeity?.contains("লক্ষ্মী") == true -> "LAKSHMI"
            resolvedDeity?.contains("Rama", ignoreCase = true) == true || resolvedDeity?.contains("রাম") == true -> "RAMA"
            resolvedDeity?.contains("Surya", ignoreCase = true) == true || resolvedDeity?.contains("Gayatri", ignoreCase = true) == true || resolvedDeity?.contains("সূর্য") == true -> "SURYA"
            else -> previousState.activeDeityKey
        }

        val resolvedSubject = resolvedMantra ?: resolvedDeity ?: resolvedScripture ?: previousState.activeSubject

        val summaryParts = listOfNotNull(
            resolvedDeity?.let { "Deity: $it" },
            resolvedScripture?.let { "Scripture: $it" },
            resolvedMantra?.let { "Mantra/Verse: $it" }
        )
        val summary = if (summaryParts.isNotEmpty()) summaryParts.joinToString(" | ") else "General Context"

        return previousState.copy(
            activeSubject = resolvedSubject,
            activeDeity = resolvedDeity,
            activeDeityKey = deityKey,
            activeScripture = resolvedScripture,
            activeMantra = resolvedMantra,
            threadTurnCount = previousState.threadTurnCount + 1,
            contextSummary = summary,
            isAwaitingMantraDisambiguation = analysis.isBroadMantraInquiry
        )
    }

    fun resolveMultiTurnQuery(
        query: String,
        history: List<Pair<String, String>>,
        contextState: ConversationContextState
    ): String {
        val trimmed = query.trim()
        val lower = trimmed.lowercase(Locale.ROOT)
        val analysis = analyzeMultiIntent(query, contextState)

        // Case 1: Anaphora resolution for deity ("তার একটি মন্ত্র বলো" / "তাঁর মন্ত্র" / "এবার দুর্গারটা দাও")
        if (lower.contains("এবার দুর্গার") || lower.contains("দুর্গারটা")) {
            return "মা দুর্গার প্রামাণিক বীজ ও প্রণাম মন্ত্র"
        }
        if (lower.contains("এবার শিবের") || lower.contains("শিবেরটা")) {
            return "ভগবান শিবের প্রামাণিক পঞ্চাক্ষর মন্ত্র"
        }
        if (lower.contains("এবার গণেশের") || lower.contains("গণেশেরটা")) {
            return "ভগবান শ্রীগণেশের প্রামাণিক বীজ মন্ত্র"
        }
        if (lower.contains("এবার বিষ্ণুর") || lower.contains("বিষ্ণুরটা")) {
            return "ভগবান শ্রীবিষ্ণুর প্রামাণিক অষ্টাক্ষর মন্ত্র"
        }
        if ((lower.contains("তার ") || lower.contains("তাঁর ") || lower.startsWith("তার") || lower.startsWith("তাঁর")) &&
            (lower.contains("মন্ত্র") || lower.contains("শ্লোক") || lower.contains("স্তোত্র") || lower.contains("প্রণাম"))
        ) {
            val deityName = contextState.activeDeity ?: "Lord Shiva (মহাদেব শিব)"
            return "$deityName এর প্রামাণিক মন্ত্র ও স্তোত্র"
        }

        // Case 2: Meaning follow up ("এর অর্থ কী?" / "এর মানে কী?" / "এর বাংলা অর্থ কী?" / "মানে কী?")
        if ((lower.contains("এর অর্থ") || lower.contains("এর মানে") || lower.contains("এই মন্ত্রের অর্থ") || lower.contains("এটার অর্থ") ||
                lower.contains("মন্ত্রটার অর্থ") || lower.contains("মন্ত্রটির অর্থ") || lower.contains("শ্লোকের অর্থ") ||
                lower.contains("বাংলা অর্থ") || lower.contains("its meaning") || lower == "মানে কী?" || lower == "মানে কি?" ||
                lower == "এর অর্থ কি?" || lower == "এর অর্থ কী?" || lower == "অর্থ কী?" || lower == "অর্থ কি?")
        ) {
            val target = contextState.activeMantra ?: contextState.activeSubject ?: "সর্বশেষ শ্লোক বা মন্ত্র"
            return "$target এর শাস্ত্রীয় সংস্কৃত অর্থ, বাংলা অনুবাদ ও ভাবার্থ"
        }

        // Case 3: Deity identity follow up ("এটা কার?" / "এটি কার মন্ত্র?")
        if (lower.contains("এটা কার") || lower.contains("এটি কার") || lower.contains("কার মন্ত্র") || lower == "এটা কার?") {
            val target = contextState.activeMantra ?: contextState.activeSubject ?: "মন্ত্র"
            return "$target কোন পরমেশ্বর বা দেবতার উদ্দেশ্যে নিবেদিত এবং তাঁর পরিচয়"
        }

        // Case 4: Source follow up ("এটা কোথা থেকে এসেছে?" / "কোথায় পাওয়া যায়?" / "কোন শাস্ত্রে আছে?")
        if ((lower.contains("কোথা থেকে এসেছে") || lower.contains("কোথায় পাওয়া যায়") || lower.contains("কোথায় পাওয়া যায়") ||
                lower.contains("উৎস") || lower.contains("কোন শাস্ত্রে") || lower.contains("কোথায় আছে") || lower.contains("where is it found"))
        ) {
            val target = contextState.activeMantra ?: contextState.activeSubject ?: "মন্ত্র বা শ্লোক"
            return "$target এর প্রামাণিক শাস্ত্রীয় গ্রন্থসূত্র ও বৈদিক প্রসঙ্গ"
        }

        // Case 5: Another mantra or verse follow up ("আরেকটা দাও" / "আরেকটি মন্ত্র বলো" / "আরেকটা শ্লোক দাও")
        if (analysis.isAnotherMantraRequest) {
            if (contextState.activeScripture?.contains("Gita", ignoreCase = true) == true || lower.contains("শ্লোক")) {
                return "শ্রীমদ্ভগবদ্গীতার আরেকটি প্রামাণিক শ্লোক ও বঙ্গানুবাদ"
            }
            if (contextState.activeDeity != null) {
                return "${contextState.activeDeity} এর আরেকটি প্রামাণিক বৈদিক বা পৌরাণিক মন্ত্র"
            }
            return "আরেকটি প্রামাণিক শাস্ত্রীয় বৈদিক মন্ত্র ও অর্থ"
        }

        // Case 6: Answering disambiguation prompt with just a deity name (e.g. "শিব" / "কৃষ্ণ")
        if (contextState.isAwaitingMantraDisambiguation && analysis.detectedDeity != null) {
            return "${analysis.detectedDeity} এর প্রামাণিক প্রণাম ও ধ্যান মন্ত্র"
        }

        // Case 7: Compound multi-intent (e.g. "গায়ত্রী মন্ত্রটা লিখে অর্থ বলো আর কোথায় পাওয়া যায়")
        if (analysis.primaryIntent == "MULTI_INTENT_MANTRA_DECOMPOSITION" || analysis.primaryIntent == "MULTI_INTENT_SOURCE_AND_MEANING") {
            val targetSubject = analysis.detectedMantra ?: contextState.activeMantra ?: analysis.detectedDeity ?: "গায়ত্রী মন্ত্র"
            return "$targetSubject - মূল সংস্কৃত শ্লোক, বাংলা অর্থ, শাস্ত্রীয় উৎস ও আধ্যাত্মিক তাৎপর্য"
        }

        return trimmed
    }
}
