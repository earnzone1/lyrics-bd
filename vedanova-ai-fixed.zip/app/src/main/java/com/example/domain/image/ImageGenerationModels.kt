package com.example.domain.image

enum class ImageGenerationStatus {
    IDLE,
    GENERATING,
    SUCCESS,
    FAILED,
    NOT_CONFIGURED
}

enum class ImageAspectRatio(
    val ratioStr: String,
    val displayName: String,
    val width: Int,
    val height: Int
) {
    SQUARE("1:1", "Square (1:1)", 1024, 1024),
    PORTRAIT("3:4", "Portrait (3:4)", 768, 1024),
    PORTRAIT_STORY("9:16", "Story / Tall (9:16)", 576, 1024),
    LANDSCAPE("16:9", "Landscape (16:9)", 1024, 576),
    LANDSCAPE_PHOTO("4:3", "Landscape (4:3)", 1024, 768)
}

enum class ImageQuality(val displayName: String) {
    STANDARD("Standard (1K)"),
    HIGH("High Definition (2K)")
}

data class ImageGenerationRequest(
    val prompt: String,
    val aspectRatio: ImageAspectRatio = ImageAspectRatio.SQUARE,
    val quality: ImageQuality = ImageQuality.STANDARD,
    val isDharmaEnhanced: Boolean = true,
    val referenceImageUri: String? = null,
    val editInstruction: String? = null,
    val requestedBy: String = "User"
)

data class ImageGenerationResult(
    val status: ImageGenerationStatus,
    val imageId: Long = 0,
    val imageCode: String = "",
    val imageUri: String? = null,
    val localFilePath: String? = null,
    val rawPrompt: String = "",
    val enhancedPrompt: String = "",
    val aspectRatio: String = "1:1",
    val providerName: String = "",
    val modelName: String = "",
    val errorMessage: String? = null,
    val generatedAt: Long = System.currentTimeMillis()
)

data class ImageUnderstandingResult(
    val isSuccess: Boolean,
    val analysisText: String,
    val detectedElements: List<String> = emptyList(),
    val spiritualSignificance: String = "",
    val errorMessage: String? = null
)
