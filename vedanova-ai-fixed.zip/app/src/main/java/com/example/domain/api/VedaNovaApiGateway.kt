package com.example.domain.api

import android.content.Context
import com.example.data.dao.ApiKeyDao
import com.example.data.dao.ApiLogDao
import com.example.data.dao.CapabilityProposalDao
import com.example.data.dao.KnowledgeDao
import com.example.data.dao.SystemSettingDao
import com.example.data.model.ApiKeyEntity
import com.example.data.model.ApiLogEntity
import com.example.data.model.KnowledgeEntity
import com.example.domain.ai.*
import com.example.domain.image.ImageAspectRatio
import com.example.domain.image.ImageGenerationEngine
import com.example.domain.image.ImageGenerationRequest
import com.example.domain.image.ImageQuality
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.UUID

data class ApiGatewayRequest(
    val endpoint: String,
    val method: String = "POST",
    val apiKey: String,
    val headers: Map<String, String> = emptyMap(),
    val body: String = "",
    val queryParams: Map<String, String> = emptyMap()
)

data class ApiGatewayResponse(
    val statusCode: Int,
    val statusText: String,
    val responseTimeMs: Long,
    val responseHeaders: Map<String, String>,
    val jsonBody: String,
    val clientApp: String,
    val tokensUsed: Int,
    val requestId: String = UUID.randomUUID().toString()
)

enum class ApiScope(val code: String, val description: String) {
    CHAT("CHAT", "Access to /api/v1/chat endpoint"),
    RESEARCH("RESEARCH", "Access to /api/v1/research endpoint"),
    KNOWLEDGE_READ("KNOWLEDGE_READ", "Access to /api/v1/knowledge/search endpoint"),
    MANTRA_READ("MANTRA_READ", "Access to /api/v1/mantra/search endpoint"),
    SCRIPTURE_READ("SCRIPTURE_READ", "Access to /api/v1/scripture/search endpoint"),
    VERIFY("VERIFY", "Access to /api/v1/verify endpoint"),
    STATUS("STATUS", "Access to /api/v1/status endpoint"),
    CALENDAR("CALENDAR", "Access to /api/v1/daily/today and dynamic calendar endpoints"),
    FESTIVAL("FESTIVAL", "Access to /api/v1/daily/festivals/upcoming and festival countdown"),
    PUJA("PUJA", "Access to /api/v1/puja/info and ritual procedure endpoints"),
    IMAGE_GENERATION("IMAGE_GENERATION", "Access to /api/v1/image/generate endpoint"),
    VISION("VISION", "Access to /api/v1/image/understand and sacred vision endpoints"),
    VOICE("VOICE", "Access to /api/v1/voice/synthesize and real-time audio endpoints")
}

class VedaNovaApiGateway(
    private val apiKeyDao: ApiKeyDao,
    private val apiLogDao: ApiLogDao,
    private val knowledgeDao: KnowledgeDao,
    private val aiOrchestrator: AiOrchestrator,
    private val capabilityProposalDao: CapabilityProposalDao? = null,
    private val imageGenerationEngine: ImageGenerationEngine? = null,
    private val systemSettingDao: SystemSettingDao? = null,
    private val context: Context? = null
) {
    // In-memory rate limiting tracker (Key ID -> Window timestamp -> count)
    private val minuteRateLimitMap = mutableMapOf<Long, Pair<Long, Int>>()

    private suspend fun isCapabilityAdminEnabled(capabilityKey: String): Boolean {
        if (systemSettingDao == null) return true
        val setting = systemSettingDao.getSetting("capability_${capabilityKey.lowercase()}_enabled")
            ?: systemSettingDao.getSetting("setting_capability_${capabilityKey.lowercase()}")
        return setting?.value?.toBooleanStrictOrNull() ?: true
    }

    suspend fun executeRequest(request: ApiGatewayRequest): ApiGatewayResponse = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        val requestId = "req_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}"
        val cleanEndpoint = request.endpoint.trim().lowercase()

        // 0. Check Emergency Controls
        val emergency = EmergencyControlsManager.controlsState.value
        if (emergency.isGlobalAiPaused || emergency.isApiPaused) {
            val elapsed = System.currentTimeMillis() - startTime
            val pauseMsg = emergency.emergencyNotice ?: "VedaNova AI service is temporarily paused under emergency control protocol."
            val errorResponse = ApiGatewayResponse(
                statusCode = 503,
                statusText = "Service Unavailable",
                responseTimeMs = elapsed,
                responseHeaders = mapOf(
                    "Content-Type" to "application/json",
                    "X-VedaNova-Request-ID" to requestId,
                    "X-Error-Code" to "SERVICE_UNAVAILABLE",
                    "Retry-After" to "120"
                ),
                jsonBody = buildErrorJson(
                    code = 503,
                    status = "SERVICE_UNAVAILABLE",
                    message = pauseMsg,
                    requestId = requestId
                ),
                clientApp = "All External Clients",
                tokensUsed = 0,
                requestId = requestId
            )
            logApiCall(request, errorResponse, "SERVICE_UNAVAILABLE (Emergency Pause)", null)
            return@withContext errorResponse
        }

        // 1. Authenticate API Key
        val cleanKey = request.apiKey.trim().removePrefix("Bearer ").trim()
        val keyRecord: ApiKeyEntity? = if (cleanKey.isNotBlank()) {
            apiKeyDao.getApiKeyByValue(cleanKey)
        } else null

        if (keyRecord == null) {
            val elapsed = System.currentTimeMillis() - startTime
            val errorResponse = ApiGatewayResponse(
                statusCode = 401,
                statusText = "Unauthorized",
                responseTimeMs = elapsed,
                responseHeaders = mapOf(
                    "Content-Type" to "application/json",
                    "X-VedaNova-Version" to "v1.0",
                    "X-VedaNova-Request-ID" to requestId,
                    "X-Error-Code" to "INVALID_API_KEY"
                ),
                jsonBody = buildErrorJson(
                    code = 401,
                    status = "INVALID_API_KEY",
                    message = "Invalid or missing VedaNova API Key. Please provide a valid 'Authorization: Bearer vn_live_...' header.",
                    requestId = requestId
                ),
                clientApp = "Unknown Client",
                tokensUsed = 0,
                requestId = requestId
            )
            logApiCall(request, errorResponse, "INVALID_API_KEY", null)
            return@withContext errorResponse
        }

        // 2. Expiration Date Verification
        if (keyRecord.expiresAt > 0 && System.currentTimeMillis() > keyRecord.expiresAt) {
            val elapsed = System.currentTimeMillis() - startTime
            val sdf = SimpleDateFormat("dd MMM yyyy HH:mm:ss z", Locale.ENGLISH)
            val expiryDateStr = sdf.format(Date(keyRecord.expiresAt))
            val errorResponse = ApiGatewayResponse(
                statusCode = 403,
                statusText = "Forbidden",
                responseTimeMs = elapsed,
                responseHeaders = mapOf(
                    "Content-Type" to "application/json",
                    "X-Dharma-Request-ID" to requestId,
                    "X-Error-Code" to "API_KEY_EXPIRED"
                ),
                jsonBody = buildErrorJson(
                    code = 403,
                    status = "API_KEY_EXPIRED",
                    message = "This Dharma AI API Key expired on $expiryDateStr. Please contact administrator to extend key validity.",
                    requestId = requestId
                ),
                clientApp = keyRecord.appName,
                tokensUsed = 0,
                requestId = requestId
            )
            apiKeyDao.incrementErrorCount(keyRecord.id)
            logApiCall(request, errorResponse, "API_KEY_EXPIRED", keyRecord)
            return@withContext errorResponse
        }

        // 3. Key Status Check (ACTIVE, SUSPENDED, REVOKED, EXPIRED)
        val statusUpper = keyRecord.status.uppercase()
        if (statusUpper != "ACTIVE") {
            val elapsed = System.currentTimeMillis() - startTime
            val errorCode = when (statusUpper) {
                "SUSPENDED" -> "API_KEY_SUSPENDED"
                "REVOKED" -> "API_KEY_REVOKED"
                "EXPIRED" -> "API_KEY_EXPIRED"
                else -> "PERMISSION_DENIED"
            }
            val errorResponse = ApiGatewayResponse(
                statusCode = 403,
                statusText = "Forbidden",
                responseTimeMs = elapsed,
                responseHeaders = mapOf(
                    "Content-Type" to "application/json",
                    "X-Dharma-Request-ID" to requestId,
                    "X-Error-Code" to errorCode
                ),
                jsonBody = buildErrorJson(
                    code = 403,
                    status = errorCode,
                    message = "This Dharma AI API Key is currently ${keyRecord.status}. Access is restricted. Please contact your administrator.",
                    requestId = requestId
                ),
                clientApp = keyRecord.appName,
                tokensUsed = 0,
                requestId = requestId
            )
            apiKeyDao.incrementErrorCount(keyRecord.id)
            logApiCall(request, errorResponse, "$errorCode (${keyRecord.status})", keyRecord)
            return@withContext errorResponse
        }

        // 4. Granular Scope Authorization Check
        val requiredScope = determineRequiredScope(cleanEndpoint)
        if (requiredScope != null && !hasRequiredScope(keyRecord.permissions, requiredScope)) {
            val elapsed = System.currentTimeMillis() - startTime
            val errorResponse = ApiGatewayResponse(
                statusCode = 403,
                statusText = "Forbidden",
                responseTimeMs = elapsed,
                responseHeaders = mapOf(
                    "Content-Type" to "application/json",
                    "X-VedaNova-Request-ID" to requestId,
                    "X-Error-Code" to "INSUFFICIENT_SCOPE"
                ),
                jsonBody = buildErrorJson(
                    code = 403,
                    status = "INSUFFICIENT_SCOPE",
                    message = "API key '${keyRecord.name}' lacks required scope '${requiredScope.code}' for endpoint '$cleanEndpoint'. Granted scopes: [${keyRecord.permissions}]",
                    requestId = requestId
                ),
                clientApp = keyRecord.appName,
                tokensUsed = 0,
                requestId = requestId
            )
            logApiCall(request, errorResponse, "INSUFFICIENT_SCOPE (${requiredScope.code})", keyRecord)
            return@withContext errorResponse
        }

        // 5. Multi-tier Rate Limiting Check
        val currentMinuteWindow = System.currentTimeMillis() / 60000
        val minuteLimit = keyRecord.rateLimitPerMin.coerceAtLeast(1)
        val currentTrack = minuteRateLimitMap[keyRecord.id]

        val currentCount = if (currentTrack != null && currentTrack.first == currentMinuteWindow) {
            currentTrack.second + 1
        } else {
            1
        }
        minuteRateLimitMap[keyRecord.id] = currentMinuteWindow to currentCount

        if (currentCount > minuteLimit) {
            val elapsed = System.currentTimeMillis() - startTime
            val errorResponse = ApiGatewayResponse(
                statusCode = 429,
                statusText = "Too Many Requests",
                responseTimeMs = elapsed,
                responseHeaders = mapOf(
                    "Content-Type" to "application/json",
                    "X-VedaNova-Request-ID" to requestId,
                    "Retry-After" to "60",
                    "X-RateLimit-Limit" to "$minuteLimit",
                    "X-RateLimit-Remaining" to "0",
                    "X-Error-Code" to "RATE_LIMIT_EXCEEDED"
                ),
                jsonBody = buildErrorJson(
                    code = 429,
                    status = "RATE_LIMIT_EXCEEDED",
                    message = "Rate limit of $minuteLimit requests per minute exceeded for application '${keyRecord.appName}'. Please retry after 60 seconds.",
                    requestId = requestId
                ),
                clientApp = keyRecord.appName,
                tokensUsed = 0,
                requestId = requestId
            )
            logApiCall(request, errorResponse, "RATE_LIMIT_EXCEEDED", keyRecord)
            return@withContext errorResponse
        }

        // 6. Route Endpoint Execution
        var statusCode = 200
        var statusText = "OK"
        var jsonResult = ""
        var tokens = 0

        try {
            when {
                // Dynamic Capability Discovery
                cleanEndpoint.contains("/api/v1/capabilities") -> {
                    val capabilities = ExternalAppCapabilityEngine.getCapabilitiesForScopes(keyRecord.permissions)
                    val capsJson = capabilities.joinToString(",\n") { cap ->
                        """
                        {
                          "code": "${cap.code}",
                          "name_en": "${escapeJsonString(cap.nameEn)}",
                          "name_bn": "${escapeJsonString(cap.nameBn)}",
                          "category": "${cap.category}",
                          "description": "${escapeJsonString(cap.description)}",
                          "required_scope": "${cap.requiredScope}",
                          "endpoint": "${cap.endpoint}",
                          "safety_rating": "${cap.safetyRating}",
                          "sample_input": ${cap.sampleInputJson},
                          "sample_output": ${cap.sampleOutputJson}
                        }
                        """.trimIndent()
                    }
                    val dataJson = """
                        {
                          "client_application": "${escapeJsonString(keyRecord.appName)}",
                          "granted_scopes": "${keyRecord.permissions}",
                          "capabilities_count": ${capabilities.size},
                          "capabilities": [
                            $capsJson
                          ]
                        }
                    """.trimIndent()
                    jsonResult = buildSuccessJson(dataJson, requestId)
                    tokens = 30
                }

                // Dynamic Daily Resolution
                cleanEndpoint.contains("/api/v1/daily/today") -> {
                    val regionParam = extractParamFromBodyOrQuery(request.body, request.queryParams, "region") ?: "BANGLADESH_DHAKA"
                    val region = try {
                        CalendarRegion.valueOf(regionParam.uppercase())
                    } catch (e: Exception) {
                        CalendarRegion.BANGLADESH_DHAKA
                    }
                    val daily = DailyDataEngine.resolveDailyData(region = region)

                    val todayFestsJson = daily.todayFestivals.joinToString(",") { fest ->
                        """
                        {
                          "name_en": "${escapeJsonString(fest.nameEn)}",
                          "name_bn": "${escapeJsonString(fest.nameBn)}",
                          "category": "${fest.category}",
                          "deity": "${escapeJsonString(fest.primaryDeity)}",
                          "description_bn": "${escapeJsonString(fest.descriptionBn)}"
                        }
                        """.trimIndent()
                    }

                    val dataJson = """
                        {
                          "region": {
                            "code": "${daily.region.code}",
                            "display_name": "${escapeJsonString(daily.region.displayName)}"
                          },
                          "gregorian_date": "${daily.gregorianDateFormatted}",
                          "bengali_date": {
                            "day": "${daily.bengaliDate.dayBangla}",
                            "month": "${daily.bengaliDate.monthBangla}",
                            "year": "${daily.bengaliDate.yearBangla}",
                            "day_of_week": "${daily.bengaliDate.dayOfWeekBangla}",
                            "paksha": "${daily.bengaliDate.paksha}",
                            "tithi": "${daily.bengaliDate.fullTithiTitle}",
                            "nakshatra": "${daily.bengaliDate.nakshatra}"
                          },
                          "sun_timings": {
                            "sunrise": "${daily.bengaliDate.sunriseTime}",
                            "sunset": "${daily.bengaliDate.sunsetTime}",
                            "brahma_muhurta": "${daily.bengaliDate.brahmaMuhurta}",
                            "rahu_kala": "${daily.bengaliDate.rahuKala}",
                            "abhijit_muhurta": "${daily.bengaliDate.abhijitMuhurta}"
                          },
                          "today_festivals": [$todayFestsJson],
                          "spiritual_feed": {
                            "daily_mantra_devata": "${escapeJsonString(daily.spiritualFeed.dailyMantraDevata)}",
                            "daily_mantra_sanskrit": "${escapeJsonString(daily.spiritualFeed.dailyMantraSanskrit)}",
                            "daily_mantra_transliteration": "${escapeJsonString(daily.spiritualFeed.dailyMantraTransliteration)}",
                            "daily_mantra_bn": "${escapeJsonString(daily.spiritualFeed.dailyMantraBn)}",
                            "daily_gita_chapter_verse": "${escapeJsonString(daily.spiritualFeed.dailyGitaChapterVerse)}",
                            "daily_gita_sanskrit": "${escapeJsonString(daily.spiritualFeed.dailyGitaSanskrit)}",
                            "daily_gita_transliteration": "${escapeJsonString(daily.spiritualFeed.dailyGitaTransliteration)}",
                            "daily_gita_bn": "${escapeJsonString(daily.spiritualFeed.dailyGitaBn)}"
                          }
                        }
                    """.trimIndent()
                    jsonResult = buildSuccessJson(dataJson, requestId)
                    tokens = 60
                }

                // Dynamic Festival List with Live Countdowns
                cleanEndpoint.contains("/api/v1/daily/festivals/upcoming") -> {
                    val daily = DailyDataEngine.resolveDailyData()
                    val festsJson = daily.upcomingFestivals.joinToString(",\n") { fest ->
                        val ritualsJson = fest.rituals.joinToString(",") { "\"${escapeJsonString(it)}\"" }
                        val scripturesJson = fest.scriptures.joinToString(",") { "\"${escapeJsonString(it)}\"" }
                        """
                        {
                          "id": "${fest.id}",
                          "name_en": "${escapeJsonString(fest.nameEn)}",
                          "name_bn": "${escapeJsonString(fest.nameBn)}",
                          "category": "${fest.category}",
                          "target_date": "${fest.targetGregorianDate}",
                          "days_remaining": ${fest.daysRemaining},
                          "hours_remaining": ${fest.hoursRemaining},
                          "primary_deity": "${escapeJsonString(fest.primaryDeity)}",
                          "description_bn": "${escapeJsonString(fest.descriptionBn)}",
                          "description_en": "${escapeJsonString(fest.descriptionEn)}",
                          "rituals": [$ritualsJson],
                          "scriptures": [$scripturesJson]
                        }
                        """.trimIndent()
                    }
                    val dataJson = """
                        {
                          "total_upcoming": ${daily.upcomingFestivals.size},
                          "festivals": [
                            $festsJson
                          ]
                        }
                    """.trimIndent()
                    jsonResult = buildSuccessJson(dataJson, requestId)
                    tokens = 95
                }

                // Dynamic Puja Info
                cleanEndpoint.contains("/api/v1/puja/info") -> {
                    val query = extractQueryFromBody(request.body)
                    val items = knowledgeDao.findMatchingPublishedKnowledge(query).filter {
                        it.category.equals("Puja", ignoreCase = true) || it.category.equals("Festivals", ignoreCase = true) || it.category.equals("Vrata", ignoreCase = true)
                    }
                    val itemsJson = items.joinToString(",\n") { formatKnowledgeJson(it) }
                    val dataJson = """
                        {
                          "search_puja": "${escapeJsonString(query)}",
                          "results_count": ${items.size},
                          "procedures": [
                            $itemsJson
                          ]
                        }
                    """.trimIndent()
                    jsonResult = buildSuccessJson(dataJson, requestId)
                    tokens = 45 + items.size * 20
                }

                cleanEndpoint.contains("/api/v1/status") -> {
                    val count = knowledgeDao.getKnowledgeCountDirect()
                    val dataJson = """
                        {
                          "platform": "VedaNova AI Central Brain Platform (Phase 7 Production)",
                          "version": "${keyRecord.version}",
                          "status": "OPERATIONAL",
                          "environment": "Production Cloud",
                          "knowledge_nodes": $count,
                          "ai_brain": "Operational (Multi-Intent + Session Memory + Anti-Fabrication + Research Engine)",
                          "client_application": "${escapeJsonString(keyRecord.appName)}",
                          "rate_limit_per_min": ${keyRecord.rateLimitPerMin},
                          "rate_limit_remaining": ${(minuteLimit - currentCount).coerceAtLeast(0)},
                          "emergency_status": {
                            "is_global_ai_paused": ${emergency.isGlobalAiPaused},
                            "is_api_paused": ${emergency.isApiPaused},
                            "is_research_paused": ${emergency.isResearchPaused}
                          }
                        }
                    """.trimIndent()
                    jsonResult = buildSuccessJson(dataJson, requestId)
                    tokens = 35
                }

                cleanEndpoint.contains("/api/v1/chat") -> {
                    val query = extractQueryFromBody(request.body)
                    val sessionId = extractParamFromBodyOrQuery(request.body, request.queryParams, "session_id")
                        ?: extractParamFromBodyOrQuery(request.body, request.queryParams, "sessionId")
                        ?: "default_session"

                    // Retrieve existing conversation state
                    val sessionContext = ContextMemoryManager.getOrCreateSession(sessionId)

                    // Trigger AI capability analysis for dynamic proposal detection
                    capabilityProposalDao?.let { dao ->
                        ExternalAppCapabilityEngine.analyzeAndProposeCapabilities(query, keyRecord.appName, dao)
                    }

                    val result = aiOrchestrator.processConversationTurn(
                        query = query,
                        history = sessionContext.recentTurns.map { "USER" to it.userQuery }
                    )

                    // Update session context state with the result
                    val updatedState = result.diagnosticInfo.contextState.copy(
                        sessionId = sessionId,
                        recentTurns = sessionContext.recentTurns + ConversationTurn(
                            userQuery = query,
                            aiResponse = result.answer,
                            intentDetected = result.diagnosticInfo.intentDetected,
                            resolvedSubject = result.diagnosticInfo.contextState.activeSubject
                        )
                    )
                    ContextMemoryManager.updateSession(sessionId, updatedState)

                    val sanitizedAnswer = escapeJsonString(result.answer)
                    val sanitizedSummary = escapeJsonString(result.diagnosticInfo.diagnosticSummary)
                    val refListJson = result.references.joinToString(",") { "\"${escapeJsonString(it)}\"" }
                    val clarificationJson = result.clarificationOptions.joinToString(",") { "\"${escapeJsonString(it)}\"" }

                    val dataJson = """
                        {
                          "model": "vedanova-central-brain-v1",
                          "session_id": "$sessionId",
                          "query": "${escapeJsonString(query)}",
                          "answer": "$sanitizedAnswer",
                          "sanskrit_verse": ${result.sanskritVerse?.let { "\"${escapeJsonString(it)}\"" } ?: "null"},
                          "transliteration": ${result.transliteration?.let { "\"${escapeJsonString(it)}\"" } ?: "null"},
                          "scripture_references": [$refListJson],
                          "is_canonical_verified": ${result.isVerifiedSource},
                          "is_clarification_prompt": ${result.isClarificationPrompt},
                          "clarification_options": [$clarificationJson],
                          "conversation_context": {
                            "active_subject": ${updatedState.activeSubject?.let { "\"${escapeJsonString(it)}\"" } ?: "null"},
                            "active_deity": ${updatedState.activeDeity?.let { "\"${escapeJsonString(it)}\"" } ?: "null"},
                            "active_mantra": ${updatedState.activeMantra?.let { "\"${escapeJsonString(it)}\"" } ?: "null"},
                            "active_scripture": ${updatedState.activeScripture?.let { "\"${escapeJsonString(it)}\"" } ?: "null"},
                            "turn_count": ${updatedState.threadTurnCount}
                          },
                          "diagnostics": {
                            "language_detected": "${result.diagnosticInfo.languageDetected}",
                            "intent_detected": "${result.diagnosticInfo.intentDetected}",
                            "confidence_score": ${result.diagnosticInfo.confidenceScore},
                            "verification_status": "${result.diagnosticInfo.verificationStatus}",
                            "diagnostic_summary": "$sanitizedSummary"
                          }
                        }
                    """.trimIndent()
                    jsonResult = buildSuccessJson(dataJson, requestId)
                    tokens = 120 + (query.length / 4)
                }

                cleanEndpoint.contains("/api/v1/knowledge/search") -> {
                    val query = extractQueryFromBody(request.body)
                    val items = knowledgeDao.findMatchingPublishedKnowledge(query)
                    val itemsJson = items.joinToString(",\n") { formatKnowledgeJson(it) }
                    val dataJson = """
                        {
                          "query": "${escapeJsonString(query)}",
                          "match_count": ${items.size},
                          "items": [
                            $itemsJson
                          ]
                        }
                    """.trimIndent()
                    jsonResult = buildSuccessJson(dataJson, requestId)
                    tokens = 50 + items.size * 25
                }

                cleanEndpoint.contains("/api/v1/mantra/search") -> {
                    val query = extractQueryFromBody(request.body)
                    val items = knowledgeDao.findMatchingPublishedKnowledge(query).filter { 
                        it.category.equals("Mantras", ignoreCase = true) || it.category.equals("Stotras", ignoreCase = true) 
                    }
                    val itemsJson = items.joinToString(",\n") { formatKnowledgeJson(it) }
                    val dataJson = """
                        {
                          "search_type": "MANTRA_AND_STOTRA",
                          "query": "${escapeJsonString(query)}",
                          "total_found": ${items.size},
                          "mantras": [
                            $itemsJson
                          ]
                        }
                    """.trimIndent()
                    jsonResult = buildSuccessJson(dataJson, requestId)
                    tokens = 45 + items.size * 25
                }

                cleanEndpoint.contains("/api/v1/scripture/search") -> {
                    val query = extractQueryFromBody(request.body)
                    val items = knowledgeDao.findMatchingPublishedKnowledge(query).filter { 
                        it.category in listOf("Bhagavad Gita", "Upanishads", "Vedas", "Puranas", "Philosophy") 
                    }
                    val itemsJson = items.joinToString(",\n") { formatKnowledgeJson(it) }
                    val dataJson = """
                        {
                          "search_type": "CANONICAL_SCRIPTURE",
                          "query": "${escapeJsonString(query)}",
                          "total_verses": ${items.size},
                          "scriptures": [
                            $itemsJson
                          ]
                        }
                    """.trimIndent()
                    jsonResult = buildSuccessJson(dataJson, requestId)
                    tokens = 50 + items.size * 25
                }

                cleanEndpoint.contains("/api/v1/research") -> {
                    val query = extractQueryFromBody(request.body)
                    val web = com.example.domain.research.WebResearchProvider.performWebResearch(query)
                    val yt = com.example.domain.research.YouTubeResearchProvider.performYouTubeResearch(query, web.queryId)
                    val cross = com.example.domain.research.CrossSourceVerificationEngine.performCrossVerification(query, web.sources, yt.supportingEvidenceSources)
                    
                    val webSourcesJson = web.sources.joinToString(",\n") { src ->
                        """
                        {
                          "id": "${src.sourceId}",
                          "title": "${escapeJsonString(src.title)}",
                          "domain": "${src.domain}",
                          "source_tier": "${src.sourceTier}",
                          "author": "${escapeJsonString(src.author)}",
                          "authority_score": ${src.authorityScore},
                          "verification_status": "${src.verificationStatus}",
                          "url": "${src.url}"
                        }
                        """.trimIndent()
                    }

                    val ytVideosJson = yt.videos.joinToString(",\n") { v ->
                        """
                        {
                          "video_id": "${v.videoId}",
                          "title": "${escapeJsonString(v.title)}",
                          "channel": "${escapeJsonString(v.channel)}",
                          "url": "${v.url}",
                          "relevance": ${v.relevanceScore}
                        }
                        """.trimIndent()
                    }

                    val dataJson = """
                        {
                          "research_topic": "${escapeJsonString(query)}",
                          "query_id": "${web.queryId}",
                          "canonical_scripture_found": ${web.canonicalScriptureFound},
                          "primary_scripture": ${web.primaryScripture?.let { "\"${escapeJsonString(it)}\"" } ?: "null"},
                          "primary_reference": ${web.primaryReference?.let { "\"${escapeJsonString(it)}\"" } ?: "null"},
                          "sanskrit_text": ${web.primarySanskritText?.let { "\"${escapeJsonString(it)}\"" } ?: "null"},
                          "bengali_meaning": ${web.primaryBengaliMeaning?.let { "\"${escapeJsonString(it)}\"" } ?: "null"},
                          "sources_count": ${web.sources.size},
                          "web_sources": [
                            $webSourcesJson
                          ],
                          "youtube_evidence": [
                            $ytVideosJson
                          ],
                          "cross_verification": {
                            "consensus": "${escapeJsonString(cross.consensusConclusion)}",
                            "confidence": ${cross.overallConfidence},
                            "tier1_count": ${cross.verifiedTier1Count},
                            "tier2_count": ${cross.verifiedTier2Count},
                            "has_conflict": ${cross.hasConflict},
                            "is_multi_tradition": ${cross.isMultiTraditionTopic}
                          }
                        }
                    """.trimIndent()
                    jsonResult = buildSuccessJson(dataJson, requestId)
                    tokens = 220
                }

                cleanEndpoint.contains("/api/v1/verify") -> {
                    val query = extractQueryFromBody(request.body)
                    val web = com.example.domain.research.WebResearchProvider.performWebResearch(query)
                    val yt = com.example.domain.research.YouTubeResearchProvider.performYouTubeResearch(query, web.queryId)
                    val shield = com.example.domain.research.MantraVerificationShield.verifyMantra(query, web.sources, yt.supportingEvidenceSources)
                    val cross = com.example.domain.research.CrossSourceVerificationEngine.performCrossVerification(query, web.sources, yt.supportingEvidenceSources)

                    val dataJson = """
                        {
                          "assertion_query": "${escapeJsonString(query)}",
                          "verified": ${shield.isVerified},
                          "confidence": ${shield.verifiedMantra?.confidenceScore ?: cross.overallConfidence},
                          "canonical_source_tier": "${shield.verifiedMantra?.sourceTier ?: if (cross.verifiedTier1Count > 0) "TIER 1" else "TIER 3"}",
                          "scripture_citation": "${escapeJsonString(shield.verifiedMantra?.sourceScripture ?: web.primaryReference ?: "Unverified")}",
                          "sanskrit_canonical_text": ${shield.verifiedMantra?.sanskritDevanagari?.let { "\"${escapeJsonString(it)}\"" } ?: "null"},
                          "tradition": "${escapeJsonString(shield.verifiedMantra?.tradition ?: "Sanatan Canonical")}",
                          "verification_notes": "${escapeJsonString(shield.verifiedMantra?.verificationNotes ?: shield.refusalMessage ?: cross.consensusConclusion)}"
                        }
                    """.trimIndent()
                    jsonResult = buildSuccessJson(dataJson, requestId)
                    tokens = 90
                }

                // =========================================================================
                // Central Dharma AI Internal Image Generation Capability Router
                // =========================================================================
                cleanEndpoint.contains("/api/v1/image/generate") -> {
                    val isImageEnabled = isCapabilityAdminEnabled("image_generation")
                    if (!isImageEnabled) {
                        statusCode = 403
                        statusText = "Forbidden"
                        jsonResult = buildErrorJson(
                            code = 403,
                            status = "CAPABILITY_DISABLED",
                            message = "Image Generation capability is currently disabled by Admin in Dharma AI Central Gateway.",
                            requestId = requestId
                        )
                    } else if (imageGenerationEngine == null) {
                        statusCode = 503
                        statusText = "Service Unavailable"
                        jsonResult = buildErrorJson(
                            code = 503,
                            status = "SERVICE_UNAVAILABLE",
                            message = "Image Generation Engine is not initialized on this gateway instance.",
                            requestId = requestId
                        )
                    } else {
                        val prompt = extractParamFromBodyOrQuery(request.body, request.queryParams, "prompt") ?: "শ্রীকৃষ্ণের একটি দিব্য রূপ"
                        val ratioStr = extractParamFromBodyOrQuery(request.body, request.queryParams, "aspect_ratio")
                            ?: extractParamFromBodyOrQuery(request.body, request.queryParams, "aspectRatio")
                            ?: "1:1"
                        val qualityStr = extractParamFromBodyOrQuery(request.body, request.queryParams, "quality") ?: "STANDARD"
                        val dharmaEnhancedStr = extractParamFromBodyOrQuery(request.body, request.queryParams, "dharma_enhanced")
                            ?: extractParamFromBodyOrQuery(request.body, request.queryParams, "isDharmaEnhanced")
                            ?: "true"

                        val aspectRatio = when (ratioStr.uppercase()) {
                            "9:16", "PORTRAIT", "VERTICAL" -> ImageAspectRatio.PORTRAIT
                            "16:9", "LANDSCAPE", "HORIZONTAL" -> ImageAspectRatio.LANDSCAPE
                            "4:3" -> ImageAspectRatio.FOUR_THREE
                            "3:4" -> ImageAspectRatio.THREE_FOUR
                            else -> ImageAspectRatio.SQUARE
                        }

                        val quality = try {
                            ImageQuality.valueOf(qualityStr.uppercase())
                        } catch (e: Exception) {
                            ImageQuality.STANDARD
                        }

                        val dharmaEnhanced = dharmaEnhancedStr.toBooleanStrictOrNull() ?: true

                        val imgRequest = ImageGenerationRequest(
                            prompt = prompt,
                            aspectRatio = aspectRatio,
                            quality = quality,
                            isDharmaEnhanced = dharmaEnhanced,
                            requestedBy = "API Client: ${keyRecord.appName}"
                        )

                        val appContext = context ?: android.app.ActivityThread.currentApplication()
                        val imgResult = imageGenerationEngine.generateImage(imgRequest, appContext)

                        val dataJson = """
                            {
                              "gateway": "Dharma AI Central Gateway v1",
                              "client_application": "${escapeJsonString(keyRecord.appName)}",
                              "image_code": "${imgResult.imageCode}",
                              "image_uri": "${escapeJsonString(imgResult.imageUri ?: "")}",
                              "local_file_path": "${escapeJsonString(imgResult.localFilePath ?: "")}",
                              "original_prompt": "${escapeJsonString(prompt)}",
                              "enhanced_dharma_prompt": "${escapeJsonString(imgResult.enhancedPrompt)}",
                              "aspect_ratio": "${imgResult.aspectRatio}",
                              "status": "${imgResult.status.name}",
                              "provider": "Dharma AI Internal Generator",
                              "generated_at": ${imgResult.generatedAt},
                              "latency_ms": ${imgResult.latencyMs}
                            }
                        """.trimIndent()
                        jsonResult = buildSuccessJson(dataJson, requestId)
                        tokens = 150
                    }
                }

                // =========================================================================
                // Central Dharma AI Sacred Vision & Image Understanding Router
                // =========================================================================
                cleanEndpoint.contains("/api/v1/image/understand") || cleanEndpoint.contains("/api/v1/vision") -> {
                    val isVisionEnabled = isCapabilityAdminEnabled("vision")
                    if (!isVisionEnabled) {
                        statusCode = 403
                        statusText = "Forbidden"
                        jsonResult = buildErrorJson(
                            code = 403,
                            status = "CAPABILITY_DISABLED",
                            message = "Vision & Sacred Image Analysis capability is currently disabled by Admin in Dharma AI Central Gateway.",
                            requestId = requestId
                        )
                    } else if (imageGenerationEngine == null) {
                        statusCode = 503
                        statusText = "Service Unavailable"
                        jsonResult = buildErrorJson(
                            code = 503,
                            status = "SERVICE_UNAVAILABLE",
                            message = "Vision & Image Analysis Engine is not initialized on this gateway instance.",
                            requestId = requestId
                        )
                    } else {
                        val filePath = extractParamFromBodyOrQuery(request.body, request.queryParams, "image_file_path")
                            ?: extractParamFromBodyOrQuery(request.body, request.queryParams, "image_path")
                            ?: extractParamFromBodyOrQuery(request.body, request.queryParams, "imageUri")
                            ?: ""
                        val question = extractParamFromBodyOrQuery(request.body, request.queryParams, "question")
                            ?: extractParamFromBodyOrQuery(request.body, request.queryParams, "query")
                            ?: "এই ছবির আধ্যাত্মিক তাৎপর্য ও শাস্ত্রীয় প্রতীক ব্যাখ্যা করুন।"

                        val appContext = context ?: android.app.ActivityThread.currentApplication()
                        val visionResult = imageGenerationEngine.understandImage(filePath, question, appContext)

                        val elementsJson = visionResult.detectedElements.joinToString(",") { "\"${escapeJsonString(it)}\"" }
                        val scripturesJson = visionResult.associatedScriptures.joinToString(",") { "\"${escapeJsonString(it)}\"" }

                        val dataJson = """
                            {
                              "gateway": "Dharma AI Central Gateway v1",
                              "client_application": "${escapeJsonString(keyRecord.appName)}",
                              "image_file_path": "${escapeJsonString(filePath)}",
                              "user_question": "${escapeJsonString(question)}",
                              "analysis": "${escapeJsonString(visionResult.analysis)}",
                              "detected_elements": [$elementsJson],
                              "spiritual_significance": "${escapeJsonString(visionResult.spiritualSignificance)}",
                              "associated_scriptures": [$scripturesJson],
                              "confidence_score": ${visionResult.confidenceScore}
                            }
                        """.trimIndent()
                        jsonResult = buildSuccessJson(dataJson, requestId)
                        tokens = 110
                    }
                }

                // =========================================================================
                // Central Dharma AI Voice Router
                // =========================================================================
                cleanEndpoint.contains("/api/v1/voice") -> {
                    val isVoiceEnabled = isCapabilityAdminEnabled("voice")
                    if (!isVoiceEnabled) {
                        statusCode = 403
                        statusText = "Forbidden"
                        jsonResult = buildErrorJson(
                            code = 403,
                            status = "CAPABILITY_DISABLED",
                            message = "Voice capability is currently disabled by Admin in Dharma AI Central Gateway.",
                            requestId = requestId
                        )
                    } else {
                        val text = extractParamFromBodyOrQuery(request.body, request.queryParams, "text")
                            ?: extractParamFromBodyOrQuery(request.body, request.queryParams, "query")
                            ?: "নমস্কার! Dharma AI Voice Assistant"
                        val dataJson = """
                            {
                              "gateway": "Dharma AI Central Gateway v1",
                              "service": "Dharma Voice Synthesis & Recognition",
                              "text": "${escapeJsonString(text)}",
                              "audio_format": "PCM_16BIT_24KHZ",
                              "status": "READY",
                              "voice_profile": "Sanatan Sacred Guide (Bengali & Sanskrit)"
                            }
                        """.trimIndent()
                        jsonResult = buildSuccessJson(dataJson, requestId)
                        tokens = 70
                    }
                }

                else -> {
                    statusCode = 404
                    statusText = "Not Found"
                    jsonResult = buildErrorJson(
                        code = 404,
                        status = "NOT_FOUND",
                        message = "Endpoint '${request.endpoint}' not recognized in Dharma AI Central Gateway v1. Supported endpoints: /api/v1/capabilities, /api/v1/image/generate, /api/v1/image/understand, /api/v1/voice, /api/v1/daily/today, /api/v1/daily/festivals/upcoming, /api/v1/puja/info, /api/v1/chat, /api/v1/research, /api/v1/knowledge/search, /api/v1/mantra/search, /api/v1/scripture/search, /api/v1/verify, /api/v1/status",
                        requestId = requestId
                    )
                }
            }
        } catch (e: Exception) {
            statusCode = 500
            statusText = "Internal Server Error"
            jsonResult = buildErrorJson(
                code = 500,
                status = "AI_SERVICE_ERROR",
                message = "An internal processing exception occurred: ${escapeJsonString(e.message ?: "Unknown error")}",
                requestId = requestId
            )
        }

        val elapsed = System.currentTimeMillis() - startTime
        val gatewayResponse = ApiGatewayResponse(
            statusCode = statusCode,
            statusText = statusText,
            responseTimeMs = elapsed,
            responseHeaders = mapOf(
                "Content-Type" to "application/json",
                "X-VedaNova-Latency" to "${elapsed}ms",
                "X-VedaNova-Request-ID" to requestId,
                "X-VedaNova-Client" to keyRecord.appName,
                "X-RateLimit-Limit" to "$minuteLimit",
                "X-RateLimit-Remaining" to "${(minuteLimit - currentCount).coerceAtLeast(0)}"
            ),
            jsonBody = jsonResult,
            clientApp = keyRecord.appName,
            tokensUsed = tokens,
            requestId = requestId
        )

        // Increment stats & logs
        apiKeyDao.incrementRequestCount(keyRecord.id, System.currentTimeMillis())
        if (statusCode >= 400) {
            apiKeyDao.incrementErrorCount(keyRecord.id)
        }
        logApiCall(request, gatewayResponse, if (statusCode >= 400) statusText else null, keyRecord)

        gatewayResponse
    }

    private fun determineRequiredScope(endpoint: String): ApiScope? {
        return when {
            endpoint.contains("/api/v1/capabilities") -> null // Available to all authenticated keys
            endpoint.contains("/api/v1/daily/today") -> ApiScope.CALENDAR
            endpoint.contains("/api/v1/daily/festivals") -> ApiScope.FESTIVAL
            endpoint.contains("/api/v1/puja/info") -> ApiScope.PUJA
            endpoint.contains("/api/v1/chat") -> ApiScope.CHAT
            endpoint.contains("/api/v1/research") -> ApiScope.RESEARCH
            endpoint.contains("/api/v1/knowledge/search") -> ApiScope.KNOWLEDGE_READ
            endpoint.contains("/api/v1/mantra/search") -> ApiScope.MANTRA_READ
            endpoint.contains("/api/v1/scripture/search") -> ApiScope.SCRIPTURE_READ
            endpoint.contains("/api/v1/verify") -> ApiScope.VERIFY
            endpoint.contains("/api/v1/status") -> ApiScope.STATUS
            endpoint.contains("/api/v1/image/generate") -> ApiScope.IMAGE_GENERATION
            endpoint.contains("/api/v1/image/understand") || endpoint.contains("/api/v1/vision") -> ApiScope.VISION
            endpoint.contains("/api/v1/voice") -> ApiScope.VOICE
            else -> null
        }
    }

    private fun hasRequiredScope(grantedPermissions: String, requiredScope: ApiScope): Boolean {
        val granted = grantedPermissions.split(",").map { it.trim().uppercase() }
        if (granted.contains("ALL") || granted.contains("*")) return true

        return when (requiredScope) {
            ApiScope.CHAT -> granted.contains("CHAT")
            ApiScope.RESEARCH -> granted.contains("RESEARCH")
            ApiScope.KNOWLEDGE_READ -> granted.contains("KNOWLEDGE_READ") || granted.contains("KNOWLEDGE")
            ApiScope.MANTRA_READ -> granted.contains("MANTRA_READ") || granted.contains("MANTRA")
            ApiScope.SCRIPTURE_READ -> granted.contains("SCRIPTURE_READ") || granted.contains("SCRIPTURE")
            ApiScope.VERIFY -> granted.contains("VERIFY")
            ApiScope.STATUS -> granted.contains("STATUS")
            ApiScope.CALENDAR -> granted.contains("CALENDAR") || granted.contains("KNOWLEDGE")
            ApiScope.FESTIVAL -> granted.contains("FESTIVAL") || granted.contains("CALENDAR")
            ApiScope.PUJA -> granted.contains("PUJA") || granted.contains("KNOWLEDGE")
            ApiScope.IMAGE_GENERATION -> granted.contains("IMAGE_GENERATION") || granted.contains("IMAGE") || granted.contains("VISION")
            ApiScope.VISION -> granted.contains("VISION") || granted.contains("IMAGE_GENERATION") || granted.contains("IMAGE")
            ApiScope.VOICE -> granted.contains("VOICE") || granted.contains("CHAT")
        }
    }

    private suspend fun logApiCall(
        request: ApiGatewayRequest,
        response: ApiGatewayResponse,
        errorMessage: String?,
        keyRecord: ApiKeyEntity?
    ) {
        apiLogDao.insertLog(
            ApiLogEntity(
                endpoint = request.endpoint,
                method = request.method,
                statusCode = response.statusCode,
                responseTimeMs = response.responseTimeMs,
                apiKeyName = keyRecord?.name ?: "Anonymous/Invalid",
                clientIdentifier = keyRecord?.appName ?: "External Client",
                requestPayloadSummary = request.body.take(120),
                responseStatusText = response.statusText,
                errorMessage = errorMessage,
                tokensUsed = response.tokensUsed,
                timestamp = System.currentTimeMillis()
            )
        )
    }

    private fun buildSuccessJson(dataContent: String, requestId: String): String {
        return """
            {
              "success": true,
              "requestId": "$requestId",
              "timestamp": ${System.currentTimeMillis()},
              "data": $dataContent
            }
        """.trimIndent()
    }

    private fun buildErrorJson(code: Int, status: String, message: String, requestId: String): String {
        return """
            {
              "success": false,
              "requestId": "$requestId",
              "timestamp": ${System.currentTimeMillis()},
              "error": {
                "code": $code,
                "status": "$status",
                "message": "${escapeJsonString(message)}"
              }
            }
        """.trimIndent()
    }

    private fun formatKnowledgeJson(it: KnowledgeEntity): String {
        return """
            {
              "id": ${it.id},
              "title": "${escapeJsonString(it.title)}",
              "category": "${escapeJsonString(it.category)}",
              "sanskrit": "${escapeJsonString(it.sanskritText)}",
              "transliteration": "${escapeJsonString(it.transliteration)}",
              "bangla_meaning": "${escapeJsonString(it.banglaMeaning)}",
              "english_meaning": "${escapeJsonString(it.englishMeaning)}",
              "scripture_reference": "${escapeJsonString(it.reference)}",
              "source_authority": "${escapeJsonString(it.sourceType)}",
              "confidence_score": ${it.confidenceScore}
            }
        """.trimIndent()
    }

    private fun extractQueryFromBody(body: String): String {
        if (body.isBlank()) return ""
        val patterns = listOf(
            Regex("\"query\"\\s*:\\s*\"([^\"]+)\""),
            Regex("\"search\"\\s*:\\s*\"([^\"]+)\""),
            Regex("\"message\"\\s*:\\s*\"([^\"]+)\""),
            Regex("\"q\"\\s*:\\s*\"([^\"]+)\""),
            Regex("\"claim\"\\s*:\\s*\"([^\"]+)\""),
            Regex("\"puja_name\"\\s*:\\s*\"([^\"]+)\"")
        )
        for (p in patterns) {
            val match = p.find(body)
            if (match != null) return match.groupValues[1]
        }
        return body.trim().removeSurrounding("\"")
    }

    private fun extractParamFromBodyOrQuery(body: String, queryParams: Map<String, String>, paramName: String): String? {
        if (queryParams.containsKey(paramName)) return queryParams[paramName]
        val stringPattern = Regex("\"$paramName\"\\s*:\\s*\"([^\"]+)\"")
        val stringMatch = stringPattern.find(body)
        if (stringMatch != null) return stringMatch.groupValues[1]

        val rawPattern = Regex("\"$paramName\"\\s*:\\s*([a-zA-Z0-9_.-]+)")
        val rawMatch = rawPattern.find(body)
        return rawMatch?.groupValues?.get(1)
    }

    private fun escapeJsonString(str: String): String {
        return str
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\b", "\\b")
            .replace("\n", "\\n")
            .replace("\r", "\\r")
            .replace("\t", "\\t")
    }
}
