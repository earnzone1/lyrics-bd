package com.example.domain.image

import android.content.ContentValues
import android.content.Context
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import android.os.Environment
import android.provider.MediaStore
import androidx.core.content.FileProvider
import com.example.domain.diagnostic.CrashReportingManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.io.File
import java.io.FileOutputStream
import java.io.InputStream

object ImageStorageManager {

    private const val DIRECTORY_NAME = "generated_images"

    suspend fun saveImageBytesLocally(
        context: Context,
        imageBytes: ByteArray,
        filePrefix: String = "dharma_img"
    ): File? = withContext(Dispatchers.IO) {
        try {
            val dir = File(context.filesDir, DIRECTORY_NAME)
            if (!dir.exists()) {
                dir.mkdirs()
            }
            val fileName = "${filePrefix}_${System.currentTimeMillis()}.png"
            val file = File(dir, fileName)
            FileOutputStream(file).use { out ->
                out.write(imageBytes)
                out.flush()
            }
            file
        } catch (e: Exception) {
            CrashReportingManager.recordException(
                screen = "IMAGE_STORAGE",
                throwable = e,
                action = "ImageStorageManager.saveImageBytesLocally"
            )
            null
        }
    }

    suspend fun saveBitmapLocally(
        context: Context,
        bitmap: Bitmap,
        filePrefix: String = "dharma_img"
    ): File? = withContext(Dispatchers.IO) {
        try {
            val dir = File(context.filesDir, DIRECTORY_NAME)
            if (!dir.exists()) {
                dir.mkdirs()
            }
            val fileName = "${filePrefix}_${System.currentTimeMillis()}.png"
            val file = File(dir, fileName)
            FileOutputStream(file).use { out ->
                bitmap.compress(Bitmap.CompressFormat.PNG, 100, out)
                out.flush()
            }
            file
        } catch (e: Exception) {
            CrashReportingManager.recordException(
                screen = "IMAGE_STORAGE",
                throwable = e,
                action = "ImageStorageManager.saveBitmapLocally"
            )
            null
        }
    }

    suspend fun saveToPublicGallery(
        context: Context,
        sourceFilePath: String,
        title: String = "Dharma AI Image"
    ): Boolean = withContext(Dispatchers.IO) {
        try {
            val sourceFile = File(sourceFilePath)
            if (!sourceFile.exists()) return@withContext false

            val resolver = context.contentResolver
            val contentValues = ContentValues().apply {
                put(MediaStore.Images.Media.DISPLAY_NAME, "DharmaAI_${System.currentTimeMillis()}.png")
                put(MediaStore.Images.Media.MIME_TYPE, "image/png")
                put(MediaStore.Images.Media.TITLE, title)
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                    put(MediaStore.Images.Media.RELATIVE_PATH, Environment.DIRECTORY_PICTURES + "/DharmaAI")
                    put(MediaStore.Images.Media.IS_PENDING, 1)
                }
            }

            val uri = resolver.insert(MediaStore.Images.Media.EXTERNAL_CONTENT_URI, contentValues)
                ?: return@withContext false

            sourceFile.inputStream().use { input ->
                resolver.openOutputStream(uri)?.use { output ->
                    input.copyTo(output)
                    output.flush()
                }
            }

            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
                contentValues.clear()
                contentValues.put(MediaStore.Images.Media.IS_PENDING, 0)
                resolver.update(uri, contentValues, null, null)
            }
            true
        } catch (e: Exception) {
            CrashReportingManager.recordException(
                screen = "IMAGE_STORAGE",
                throwable = e,
                action = "ImageStorageManager.saveToPublicGallery"
            )
            false
        }
    }

    fun getShareIntent(context: Context, filePath: String, prompt: String): Intent? {
        return try {
            val file = File(filePath)
            if (!file.exists()) return null

            val authority = "${context.packageName}.fileprovider"
            val uri: Uri = FileProvider.getUriForFile(context, authority, file)

            val shareIntent = Intent(Intent.ACTION_SEND).apply {
                type = "image/png"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_TEXT, "🕉️ Dharma AI চিত্রণ:\n$prompt")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            Intent.createChooser(shareIntent, "চিত্র শেয়ার করুন")
        } catch (e: Exception) {
            CrashReportingManager.recordException(
                screen = "IMAGE_STORAGE",
                throwable = e,
                action = "ImageStorageManager.getShareIntent"
            )
            null
        }
    }

    suspend fun deleteLocalFile(filePath: String): Boolean = withContext(Dispatchers.IO) {
        try {
            val file = File(filePath)
            if (file.exists()) {
                file.delete()
            } else {
                true
            }
        } catch (e: Exception) {
            CrashReportingManager.recordException(
                screen = "IMAGE_STORAGE",
                throwable = e,
                action = "ImageStorageManager.deleteLocalFile"
            )
            false
        }
    }

    suspend fun decodeBitmapFromFile(filePath: String): Bitmap? = withContext(Dispatchers.IO) {
        try {
            val file = File(filePath)
            if (file.exists()) {
                BitmapFactory.decodeFile(file.absolutePath)
            } else {
                null
            }
        } catch (e: Exception) {
            null
        }
    }

    suspend fun readBytesFromUri(context: Context, uri: Uri): ByteArray? = withContext(Dispatchers.IO) {
        try {
            context.contentResolver.openInputStream(uri)?.use { it.readBytes() }
        } catch (e: Exception) {
            null
        }
    }
}
