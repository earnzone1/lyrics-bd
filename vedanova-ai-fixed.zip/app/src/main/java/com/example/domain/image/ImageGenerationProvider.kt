package com.example.domain.image

import android.content.Context

interface ImageGenerationProvider {
    val providerId: String
    val providerName: String
    val defaultModel: String

    fun isConfigured(): Boolean
    fun getConfigurationMessage(): String

    suspend fun generateImage(
        request: ImageGenerationRequest,
        context: Context
    ): ImageGenerationResult

    suspend fun editImage(
        baseImageFilePath: String,
        editPrompt: String,
        context: Context
    ): ImageGenerationResult

    suspend fun understandImage(
        imageFilePath: String,
        userQuestion: String,
        context: Context
    ): ImageUnderstandingResult

    fun getSupportedAspectRatios(): List<ImageAspectRatio>
    fun supportsImageEditing(): Boolean
    fun supportsVision(): Boolean
}
