package com.example

import com.example.data.model.AdminUserEntity
import com.example.data.model.KnowledgeEntity
import com.example.domain.ai.AiSelfDiagnosticEngine
import com.example.domain.ai.DiagnosticInfo
import org.junit.Assert.*
import org.junit.Test

class ExampleUnitTest {
  @Test
  fun addition_isCorrect() {
    assertEquals(4, 2 + 2)
  }

  @Test
  fun testSelfDiagnosticEngine_CleanCase() {
    val engine = AiSelfDiagnosticEngine()
    val mockDiag = DiagnosticInfo(
        languageDetected = "Bengali (বাংলা)",
        intentDetected = "MANTRA_INQUIRY",
        subIntent = "Recitation & Meaning",
        ambiguityScore = 0.1f,
        knowledgeMatchCount = 1,
        topKnowledgeSource = "Rigveda",
        scriptureReference = "Rigveda 3.62.10",
        verificationStatus = "VERIFIED_CANONICAL",
        confidenceScore = 0.98f,
        researchEngineUsed = false,
        responseTimeMs = 120,
        apiEndpointUsed = "/api/v1/chat",
        safetyPassed = true,
        conflictsDetected = false,
        diagnosticSummary = "Processed clean"
    )

    val matched = listOf(
        KnowledgeEntity(
            id = 1,
            title = "Gayatri Mantra",
            category = "Mantras",
            scripture = "Rigveda",
            reference = "3.62.10",
            sourceType = "Shruti",
            confidenceScore = 0.98f
        )
    )

    val report = engine.diagnoseInteraction(
        userQuery = "গায়ত্রী মন্ত্রের অর্থ কী?",
        aiResponse = "ॐ ভূর্ভুবঃ স্বঃ",
        diagnosticInfo = mockDiag,
        matchedEntities = matched
    )

    assertEquals(95, report.overallHealthScore)
    assertTrue(report.potentialErrorsOrHallucinations.contains("None detected. Clean verification pipeline execution."))
    assertTrue(report.sourceIntegrity.contains("Rigveda"))
  }

  @Test
  fun testSelfDiagnosticEngine_ZeroGrounding_PenalizesScore() {
    val engine = AiSelfDiagnosticEngine()
    val mockDiag = DiagnosticInfo(
        languageDetected = "English",
        intentDetected = "GENERAL_DHARMA",
        subIntent = "Spiritual Wisdom",
        ambiguityScore = 0.8f,
        knowledgeMatchCount = 0,
        topKnowledgeSource = "None",
        scriptureReference = "General Dharma Query",
        verificationStatus = "UNKNOWN_GROUNDING",
        confidenceScore = 0.45f,
        researchEngineUsed = true,
        responseTimeMs = 210,
        apiEndpointUsed = "/api/v1/chat",
        safetyPassed = true,
        conflictsDetected = false,
        diagnosticSummary = "No local matches"
    )

    val report = engine.diagnoseInteraction(
        userQuery = "unknown random query",
        aiResponse = "Namaste",
        diagnosticInfo = mockDiag,
        matchedEntities = emptyList()
    )

    assertEquals(75, report.overallHealthScore)
    assertTrue(report.potentialErrorsOrHallucinations.any { it.contains("Zero local canonical grounding nodes found") })
    assertTrue(report.recommendedFix.contains("Teach AI"))
  }

  @Test
  fun testApiScopes() {
    val scopes = com.example.domain.api.ApiScope.values()
    assertEquals(7, scopes.size)
    assertTrue(scopes.any { it.code == "CHAT" })
    assertTrue(scopes.any { it.code == "RESEARCH" })
    assertTrue(scopes.any { it.code == "KNOWLEDGE_READ" })
    assertTrue(scopes.any { it.code == "MANTRA_READ" })
    assertTrue(scopes.any { it.code == "SCRIPTURE_READ" })
    assertTrue(scopes.any { it.code == "VERIFY" })
    assertTrue(scopes.any { it.code == "STATUS" })
  }

  @Test
  fun testDailyDataEngine_Resolution() {
    val result = com.example.domain.ai.DailyDataEngine.resolveDailyData(
      com.example.domain.ai.CalendarRegion.BANGLADESH_DHAKA
    )
    assertNotNull(result)
    assertTrue(result.bengaliDate.yearBangla.contains("বঙ্গাব্দ"))
    assertTrue(result.bengaliDate.monthBangla.isNotBlank())
    assertTrue(result.bengaliDate.fullTithiTitle.isNotBlank())
    assertTrue(result.bengaliDate.sunriseTime.isNotBlank())
    assertTrue(result.bengaliDate.brahmaMuhurta.isNotBlank())
    assertTrue(result.upcomingFestivals.isNotEmpty())
    assertTrue(result.spiritualFeed.dailyGitaSanskrit.isNotBlank())
  }

  @Test
  fun testExternalAppCapabilityEngine_StandardDiscovery() {
    val caps = com.example.domain.ai.ExternalAppCapabilityEngine.getCapabilitiesForScopes("CALENDAR, FESTIVAL")
    assertTrue(caps.any { it.code == "DAILY_DATE" })
    assertTrue(caps.any { it.code == "BANGLA_DATE" })
    assertTrue(caps.any { it.code == "UPCOMING_FESTIVAL" })
  }

  @Test
  fun testExternalAppCapabilityEngine_AiProposal() {
    val proposal = com.example.domain.ai.ExternalAppCapabilityEngine.proposeCapabilityForQuery(
      query = "কালকে একাদশী পালনের সময়সূচী এবং ব্রতের নিয়ম কী কী?",
      appName = "DharmaGuide App"
    )
    assertNotNull(proposal)
    assertEquals("EKADASHI_MAHATMYA_OBSERVANCE", proposal?.capabilityCode)
    assertTrue(proposal?.inputSchemaJson?.contains("ekadashiName") == true)
    assertEquals("AI_PROPOSED", proposal?.status)
  }
}

