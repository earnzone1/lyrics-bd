package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.MenuBook
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.KnowledgeEntity
import com.example.data.model.KnowledgeVersionEntity
import com.example.data.model.UnknownKnowledgeEntity
import com.example.domain.ai.KnowledgeConflictResult
import com.example.domain.ai.KnowledgeMatchingEngine
import com.example.ui.theme.*
import com.example.ui.viewmodel.ScreenDestination
import com.example.ui.viewmodel.VedaNovaViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun TeachAiScreen(viewModel: VedaNovaViewModel) {
    val teachState by viewModel.teachAiState.collectAsState()
    val allUnknown by viewModel.allUnknownKnowledge.collectAsState()
    val pendingUnknownCount by viewModel.pendingUnknownCount.collectAsState()
    val candidates by viewModel.candidateKnowledge.collectAsState()
    val allVersions by viewModel.allKnowledgeVersions.collectAsState()
    val usageLogs by viewModel.allUsageLogs.collectAsState()

    var showConflictDialog by remember { mutableStateOf(false) }
    var showSuccessSnackbar by remember { mutableStateOf(false) }
    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(teachState.successMessage) {
        teachState.successMessage?.let {
            snackbarHostState.showSnackbar(it)
        }
    }

    LaunchedEffect(teachState.conflictResult) {
        if (teachState.conflictResult != null && teachState.conflictResult?.hasConflict == true) {
            showConflictDialog = true
        }
    }

    val categories = listOf(
        "GENERAL_CONVERSATION" to "সাধারণ কথোপকথন (Greetings & Intro)",
        "HINDU_DHARMA" to "হিন্দু ধর্মজ্ঞান (Core Sanatan Dharma)",
        "DEITY" to "দেবতাতত্ত্ব (Deities & Avatars)",
        "MANTRA" to "মন্ত্র ও স্তোত্র (Mantras & Stotrams)",
        "SCRIPTURE" to "শাস্ত্রজ্ঞান (Gita, Vedas, Upanishads)",
        "FESTIVAL" to "উৎসব ও ব্রত (Festivals & Vratas)",
        "PUJA" to "পূজাবিধি ও নিয়ম (Puja & Rituals)",
        "BENGALI_MEANINGS" to "বাংলা অর্থ ও ব্যাখ্যা (Meanings)",
        "SANSKRIT_INFO" to "সংস্কৃত ব্যাকরণ ও তত্ত্ব (Sanskrit)"
    )

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
            ) {
                Surface(
                    color = MaterialTheme.colorScheme.surface,
                    tonalElevation = 2.dp
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 16.dp, vertical = 12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(onClick = { viewModel.navigateTo(ScreenDestination.DASHBOARD) }) {
                                Icon(Icons.AutoMirrored.Filled.ArrowBack, contentDescription = "Back")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = "Teach AI (জ্ঞান শিক্ষক ও শিক্ষার্থী ব্যবস্থা)",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Badge(
                                        containerColor = SaffronPrimary,
                                        contentColor = Color.White
                                    ) {
                                        Text("Phase 5", style = MaterialTheme.typography.labelSmall)
                                    }
                                }
                                Text(
                                    text = "Human-Guided AI Learning • Conflict Shield • Version Snapshot",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Button(
                            onClick = { viewModel.clearTeachForm() },
                            colors = ButtonDefaults.outlinedButtonColors(),
                            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("নতুন ফর্ম", style = MaterialTheme.typography.labelMedium)
                        }
                    }
                }

                // Sub-tabs
                ScrollableTabRow(
                    selectedTabIndex = teachState.activeTeachTab,
                    edgePadding = 16.dp,
                    containerColor = MaterialTheme.colorScheme.surfaceVariant,
                    contentColor = MaterialTheme.colorScheme.onSurface
                ) {
                    Tab(
                        selected = teachState.activeTeachTab == 0,
                        onClick = { viewModel.setTeachTab(0) },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.School, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("জ্ঞান শেখান")
                            }
                        }
                    )
                    Tab(
                        selected = teachState.activeTeachTab == 1,
                        onClick = { viewModel.setTeachTab(1) },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.HelpOutline, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("অজ্ঞাত প্রশ্ন (${allUnknown.count { it.status == "PENDING" }})")
                            }
                        }
                    )
                    Tab(
                        selected = teachState.activeTeachTab == 2,
                        onClick = { viewModel.setTeachTab(2) },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.FactCheck, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Candidate অনুমোদন (${candidates.size})")
                            }
                        }
                    )
                    Tab(
                        selected = teachState.activeTeachTab == 3,
                        onClick = { viewModel.setTeachTab(3) },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("সংস্করণ ইতিহাস (${allVersions.size})")
                            }
                        }
                    )
                    Tab(
                        selected = teachState.activeTeachTab == 4,
                        onClick = { viewModel.setTeachTab(4) },
                        text = {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Insights, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("ব্যবহার ও ফিডব্যাক")
                            }
                        }
                    )
                }
            }
        }
    ) { padding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
        ) {
            when (teachState.activeTeachTab) {
                0 -> TeachNewKnowledgeTab(
                    state = teachState,
                    categories = categories,
                    onUpdateField = { q, a, t, c, s, r, sk, tr, ex, cand ->
                        viewModel.updateTeachField(
                            question = q,
                            answer = a,
                            title = t,
                            category = c,
                            source = s,
                            reference = r,
                            sanskrit = sk,
                            transliteration = tr,
                            explanation = ex,
                            saveAsCandidate = cand
                        )
                    },
                    onSubmit = { viewModel.checkConflictAndTeachKnowledge(overrideConflict = false) }
                )
                1 -> UnknownKnowledgeQueueTab(
                    unknownList = allUnknown,
                    onTeach = { item -> viewModel.prefillTeachFromUnknown(item) },
                    onIgnore = { item -> viewModel.ignoreUnknownQuery(item) }
                )
                2 -> CandidateApprovalTab(
                    candidates = candidates,
                    onApprove = { item -> viewModel.approveCandidateKnowledge(item) },
                    onReject = { item -> viewModel.rejectCandidateKnowledge(item) }
                )
                3 -> VersionHistoryTab(versions = allVersions)
                4 -> UsageFeedbackTab(usageLogs = usageLogs)
            }
        }
    }

    // Conflict Resolution Dialog
    if (showConflictDialog && teachState.conflictResult != null) {
        val conflict = teachState.conflictResult!!
        AlertDialog(
            onDismissRequest = { showConflictDialog = false },
            icon = { Icon(Icons.Default.Warning, contentDescription = null, tint = AmberAlert) },
            title = {
                Text("⚠️ Knowledge Conflict Detected", fontWeight = FontWeight.Bold)
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = conflict.conflictReason,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.SemiBold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Divider()
                    Text("অসঙ্গতি ও পার্থক্যের বিবরণ:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                    conflict.differences.forEach { diff ->
                        Surface(
                            color = MaterialTheme.colorScheme.surfaceVariant,
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = "• $diff",
                                style = MaterialTheme.typography.bodySmall,
                                modifier = Modifier.padding(8.dp)
                            )
                        }
                    }
                    Text(
                        text = "নিয়ম: Admin সিদ্ধান্ত না নেওয়া পর্যন্ত কোনো অসঙ্গতিপূর্ণ তথ্য production-এ সরাসরি প্রকাশ হবে না।",
                        style = MaterialTheme.typography.labelSmall,
                        color = SaffronPrimary
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        showConflictDialog = false
                        viewModel.checkConflictAndTeachKnowledge(overrideConflict = true)
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
                ) {
                    Text("নতুন সংস্করণ হিসেবে সংরক্ষণ করুন")
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showConflictDialog = false }) {
                    Text("বাতিল করুন")
                }
            }
        )
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun TeachNewKnowledgeTab(
    state: com.example.ui.viewmodel.TeachAiState,
    categories: List<Pair<String, String>>,
    onUpdateField: (
        question: String?,
        answer: String?,
        title: String?,
        category: String?,
        source: String?,
        reference: String?,
        sanskrit: String?,
        transliteration: String?,
        explanation: String?,
        saveAsCandidate: Boolean?
    ) -> Unit,
    onSubmit: () -> Unit
) {
    var expandedCategory by remember { mutableStateOf(false) }
    var showAdvancedFields by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Pre-filled Indicator from Unknown Queue
        if (state.selectedUnknownId != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SaffronPrimary.copy(alpha = 0.12f)),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, SaffronPrimary.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.HelpCenter, contentDescription = null, tint = SaffronPrimary)
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "Teaching from Unknown Query Queue (#${state.selectedUnknownId})",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = SaffronPrimary
                            )
                            Text(
                                text = "AI এই প্রশ্নের নির্ভরযোগ্য উত্তর জানে না। আপনি যে উত্তর প্রদান করবেন তা যাচাইকৃত ডাটাবেসে সেভ হবে।",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }

        // Error Banner
        if (state.errorMessage != null) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = MaterialTheme.colorScheme.error)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = state.errorMessage,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onErrorContainer
                        )
                    }
                }
            }
        }

        // Core Teaching Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.EditNote, contentDescription = null, tint = SaffronPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "১. প্রশ্ন ও নির্ভুল উত্তর (Core Q&A)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // Question
                    OutlinedTextField(
                        value = state.question,
                        onValueChange = { onUpdateField(it, null, null, null, null, null, null, null, null, null) },
                        label = { Text("প্রশ্ন (User Query / Trigger Question) *") },
                        placeholder = { Text("যেমন: হিন্দু ধর্ম কী? অথবা গায়ত্রী মন্ত্রের অর্থ কী?") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2,
                        shape = RoundedCornerShape(12.dp)
                    )

                    // Answer
                    OutlinedTextField(
                        value = state.answer,
                        onValueChange = { onUpdateField(null, it, null, null, null, null, null, null, null, null) },
                        label = { Text("সঠিক ও প্রামাণ্য উত্তর (Verified Canonical Answer) *") },
                        placeholder = { Text("এখানে প্রামাণ্য, সুস্পষ্ট ও নিরপেক্ষ ব্যাখ্যা লিখুন...") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 4,
                        shape = RoundedCornerShape(12.dp)
                    )

                    // Title
                    OutlinedTextField(
                        value = state.title,
                        onValueChange = { onUpdateField(null, null, it, null, null, null, null, null, null, null) },
                        label = { Text("শিরোনাম বা বিষয়বস্তু (Title / Topic Name)") },
                        placeholder = { Text("যেমন: গায়ত্রী মন্ত্র / হিন্দু ধর্মের পরিচয়") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            }
        }

        // Category & Authority Source
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Category, contentDescription = null, tint = SaffronPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "২. ক্যাটাগরি ও শাস্ত্রীয় উৎস (Taxonomy & Source)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }

                    // Category Dropdown
                    ExposedDropdownMenuBox(
                        expanded = expandedCategory,
                        onExpandedChange = { expandedCategory = !expandedCategory }
                    ) {
                        OutlinedTextField(
                            value = categories.find { it.first == state.category }?.second ?: state.category,
                            onValueChange = {},
                            readOnly = true,
                            label = { Text("ক্যাটাগরি নির্বাচন করুন *") },
                            trailingIcon = { ExposedDropdownMenuDefaults.TrailingIcon(expanded = expandedCategory) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .menuAnchor(),
                            shape = RoundedCornerShape(12.dp)
                        )
                        ExposedDropdownMenu(
                            expanded = expandedCategory,
                            onDismissRequest = { expandedCategory = false }
                        ) {
                            categories.forEach { (catKey, catLabel) ->
                                DropdownMenuItem(
                                    text = { Text(catLabel) },
                                    onClick = {
                                        onUpdateField(null, null, null, catKey, null, null, null, null, null, null)
                                        expandedCategory = false
                                    }
                                )
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        OutlinedTextField(
                            value = state.source,
                            onValueChange = { onUpdateField(null, null, null, null, it, null, null, null, null, null) },
                            label = { Text("উৎস (Source)") },
                            placeholder = { Text("বেদ / গীতা / পুরাণ") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        )
                        OutlinedTextField(
                            value = state.reference,
                            onValueChange = { onUpdateField(null, null, null, null, null, it, null, null, null, null) },
                            label = { Text("সূত্র / রেফারেন্স (Citation)") },
                            placeholder = { Text("ঋগ্বেদ ৩.৬২.১০") },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp)
                        )
                    }
                }
            }
        }

        // Advanced Fields (Sanskrit Shloka / Transliteration / Deep Explanation)
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { showAdvancedFields = !showAdvancedFields },
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.AutoMirrored.Filled.MenuBook, contentDescription = null, tint = SaffronPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "৩. ঐচ্ছিক সংস্কৃত শ্লোক ও বিশ্লেষণ (Advanced)",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Icon(
                            if (showAdvancedFields) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = null
                        )
                    }

                    AnimatedVisibility(visible = showAdvancedFields) {
                        Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            OutlinedTextField(
                                value = state.sanskritText,
                                onValueChange = { onUpdateField(null, null, null, null, null, null, it, null, null, null) },
                                label = { Text("মূল দেবনাগরী বা সংস্কৃত শ্লোক (Sanskrit Text)") },
                                placeholder = { Text("ॐ भूर्भुवः स्वः...") },
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 2,
                                shape = RoundedCornerShape(12.dp)
                            )
                            OutlinedTextField(
                                value = state.transliteration,
                                onValueChange = { onUpdateField(null, null, null, null, null, null, null, it, null, null) },
                                label = { Text("IAST / উচ্চারণ লিপ্যন্তর (Transliteration)") },
                                placeholder = { Text("oṃ bhūr bhuvaḥ svaḥ...") },
                                modifier = Modifier.fillMaxWidth(),
                                shape = RoundedCornerShape(12.dp)
                            )
                            OutlinedTextField(
                                value = state.explanation,
                                onValueChange = { onUpdateField(null, null, null, null, null, null, null, null, it, null) },
                                label = { Text("দার্শনিক তাৎপর্য ও মাহাত্ম্য (Detailed Philosophy)") },
                                modifier = Modifier.fillMaxWidth(),
                                minLines = 3,
                                shape = RoundedCornerShape(12.dp)
                            )
                        }
                    }
                }
            }
        }

        // Publishing Strategy & Actions
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "৪. প্রকাশনা ও সুরক্ষা নীতি (Publishing Policy)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SaffronPrimary
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Checkbox(
                            checked = state.saveAsCandidate,
                            onCheckedChange = { onUpdateField(null, null, null, null, null, null, null, null, null, it) }
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Save as Candidate (সরাসরি প্রকাশ না করে অনুমোদনের জন্য রাখুন)",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                text = "অনুমোদিত না হওয়া পর্যন্ত AI এই জ্ঞানটি public chat-এ ব্যবহার করবে না।",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(4.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Button(
                            onClick = onSubmit,
                            enabled = !state.isSaving && (state.question.isNotBlank() || state.title.isNotBlank()) && state.answer.isNotBlank(),
                            modifier = Modifier
                                .weight(1f)
                                .height(50.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            if (state.isSaving) {
                                CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.White)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("যাচাই হচ্ছে...")
                            } else {
                                Icon(
                                    if (state.saveAsCandidate) Icons.Default.BookmarkAdd else Icons.Default.Publish,
                                    contentDescription = null
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(if (state.saveAsCandidate) "Save as Candidate" else "যাচাই ও প্রকাশ করুন")
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun UnknownKnowledgeQueueTab(
    unknownList: List<UnknownKnowledgeEntity>,
    onTeach: (UnknownKnowledgeEntity) -> Unit,
    onIgnore: (UnknownKnowledgeEntity) -> Unit
) {
    if (unknownList.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.CheckCircle, contentDescription = null, tint = SaffronPrimary, modifier = Modifier.size(56.dp))
                Spacer(modifier = Modifier.height(12.dp))
                Text("কোনো অজ্ঞাত প্রশ্ন পেন্ডিং নেই!", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("AI সকল জিজ্ঞাসার যাচাইকৃত উত্তর প্রদান করতে সক্ষম হয়েছে।", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(Icons.Default.Queue, contentDescription = null, tint = SaffronPrimary)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "AI Unknown Knowledge Queue",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            text = "ইউজারদের যে সকল প্রশ্নের যাচাইকৃত তথ্য AI এর ডাটাবেসে নেই তা এখানে জমা হয়। এখান থেকে সরাসরি AI-কে শেখাতে পারবেন।",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        items(unknownList) { item ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(
                    1.dp,
                    if (item.status == "PENDING") SaffronPrimary.copy(alpha = 0.6f) else MaterialTheme.colorScheme.outline
                )
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(
                                color = if (item.status == "PENDING") AmberAlert.copy(alpha = 0.2f) else MaterialTheme.colorScheme.primaryContainer,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = item.status,
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (item.status == "PENDING") AmberAlert else MaterialTheme.colorScheme.primary
                                )
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Surface(
                                color = MaterialTheme.colorScheme.secondaryContainer,
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = "Frequency: ${item.frequency}x",
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                    style = MaterialTheme.typography.labelSmall
                                )
                            }
                        }

                        Text(
                            text = SimpleDateFormat("dd MMM, HH:mm", Locale.getDefault()).format(Date(item.createdAt)),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Text(
                        text = "❓ ${item.userQuestion}",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("🤖 AI Fallback Response:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = SaffronPrimary)
                            Text(item.aiResponse, style = MaterialTheme.typography.bodySmall)
                            Spacer(modifier = Modifier.height(4.dp))
                            Text("🔍 Why Unknown: ${item.whyUnknown}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        if (item.status == "PENDING") {
                            TextButton(onClick = { onIgnore(item) }) {
                                Text("Ignore", color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = { onTeach(item) },
                                colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
                            ) {
                                Icon(Icons.Default.School, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("AI-কে শেখান")
                            }
                        } else {
                            Text(
                                text = "✅ Resolved (KB #${item.resolvedKnowledgeId})",
                                style = MaterialTheme.typography.labelMedium,
                                color = EmeraldGreen,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun CandidateApprovalTab(
    candidates: List<KnowledgeEntity>,
    onApprove: (KnowledgeEntity) -> Unit,
    onReject: (KnowledgeEntity) -> Unit
) {
    if (candidates.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.Verified, contentDescription = null, tint = EmeraldGreen, modifier = Modifier.size(56.dp))
                Spacer(modifier = Modifier.height(12.dp))
                Text("কোনো Candidate অনুমোদনের জন্য অপেক্ষমাণ নেই", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                Text("সকল নলেজ রেকর্ড যাচাইকৃত অবস্থায় রয়েছে।", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.Gavel, contentDescription = null, tint = SaffronPrimary)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("Knowledge Candidate Approval Center", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Text("Lifecycle: Candidate -> Validation Check -> Review -> Approve & Publish (Version v1)", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        items(candidates) { candidate ->
            val validation = remember(candidate) { KnowledgeMatchingEngine.validateCandidate(candidate) }

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, if (validation.isValid) EmeraldGreen.copy(alpha = 0.5f) else AmberAlert)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Text(
                                text = "Code: ${candidate.knowledgeCode.ifBlank { "KB-${candidate.id}" }}",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold
                            )
                        }

                        Surface(
                            color = if (validation.isValid) EmeraldGreen.copy(alpha = 0.15f) else AmberAlert.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(6.dp)
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    if (validation.isValid) Icons.Default.CheckCircle else Icons.Default.Warning,
                                    contentDescription = null,
                                    tint = if (validation.isValid) EmeraldGreen else AmberAlert,
                                    modifier = Modifier.size(14.dp)
                                )
                                Spacer(modifier = Modifier.width(4.dp))
                                Text(
                                    text = if (validation.isValid) "Validation: Passed" else "Validation: Needs Review",
                                    style = MaterialTheme.typography.labelSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = if (validation.isValid) EmeraldGreen else AmberAlert
                                )
                            }
                        }
                    }

                    Text(
                        text = candidate.title.ifBlank { candidate.question },
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold
                    )

                    if (candidate.question.isNotBlank() && candidate.question != candidate.title) {
                        Text(
                            text = "❓ Question: ${candidate.question}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("📖 Answer:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = SaffronPrimary)
                            Text(candidate.answer.ifBlank { candidate.banglaMeaning }, style = MaterialTheme.typography.bodySmall)
                            if (candidate.source.isNotBlank() || candidate.reference.isNotBlank()) {
                                Spacer(modifier = Modifier.height(4.dp))
                                Text("🏛️ Source: ${candidate.source} (${candidate.reference})", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedButton(
                            onClick = { onReject(candidate) },
                            colors = ButtonDefaults.outlinedButtonColors(contentColor = MaterialTheme.colorScheme.error)
                        ) {
                            Text("Reject")
                        }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = { onApprove(candidate) },
                            colors = ButtonDefaults.buttonColors(containerColor = EmeraldGreen)
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Approve & Publish")
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun VersionHistoryTab(versions: List<KnowledgeVersionEntity>) {
    if (versions.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("কোনো সংস্করণ রেকর্ড পাওয়া যায়নি।", style = MaterialTheme.typography.bodyMedium)
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.HistoryEdu, contentDescription = null, tint = SaffronPrimary)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("Knowledge Version Control & Audit Trail", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Text("নিয়ম: পুরোনো knowledge কখনো মুছে ফেলা হয় না; প্রতি আপডেটে নতুন সংস্করণ (v1, v2) তৈরি হয়।", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        items(versions) { ver ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(14.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Badge(containerColor = SaffronPrimary, contentColor = Color.White) {
                                Text("v${ver.versionNumber}")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(ver.title, style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        }

                        Text(
                            text = SimpleDateFormat("dd MMM yyyy, HH:mm", Locale.getDefault()).format(Date(ver.timestamp)),
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Text("📝 Diff / Reason: ${ver.changeReason}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.SemiBold, color = SaffronPrimary)
                    Text("👤 Author / Modifier: ${ver.changedBy}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)

                    Surface(
                        color = MaterialTheme.colorScheme.surface,
                        shape = RoundedCornerShape(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = ver.answer.take(160) + if (ver.answer.length > 160) "..." else "",
                            style = MaterialTheme.typography.bodySmall,
                            modifier = Modifier.padding(8.dp)
                        )
                    }
                }
            }
        }
    }
}

@Composable
private fun UsageFeedbackTab(usageLogs: List<com.example.data.model.KnowledgeUsageLogEntity>) {
    if (usageLogs.isEmpty()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Text("কোনো ব্যবহারের লগ নেই।", style = MaterialTheme.typography.bodyMedium)
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                    Icon(Icons.Default.TrendingUp, contentDescription = null, tint = SaffronPrimary)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text("Knowledge Usage & Feedback Loop", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold)
                        Text("AI response-এ কোন জ্ঞানটি ম্যাচ করেছে, কনফিডেন্স স্কোর কত এবং ইউজারের ফিডব্যাক ট্র্যাকিং।", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        }

        items(usageLogs) { log ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "Query: \"${log.userQuery}\"",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Surface(color = MaterialTheme.colorScheme.primaryContainer, shape = RoundedCornerShape(4.dp)) {
                                Text(
                                    text = log.matchedStrategy,
                                    style = MaterialTheme.typography.labelSmall,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Confidence: ${(log.confidence * 100).toInt()}% • KB ID #${log.knowledgeId}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Surface(
                        color = if (log.feedbackScore >= 0) EmeraldGreen.copy(alpha = 0.15f) else MaterialTheme.colorScheme.errorContainer,
                        shape = RoundedCornerShape(6.dp)
                    ) {
                        Text(
                            text = if (log.feedbackScore >= 0) "👍 Positive" else "👎 Correction",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (log.feedbackScore >= 0) EmeraldGreen else MaterialTheme.colorScheme.error,
                            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                        )
                    }
                }
            }
        }
    }
}
