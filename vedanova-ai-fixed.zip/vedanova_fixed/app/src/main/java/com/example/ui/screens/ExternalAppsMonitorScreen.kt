package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.ExternalAppEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.VedaNovaViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExternalAppsMonitorScreen(viewModel: VedaNovaViewModel) {
    val externalApps by viewModel.allExternalApps.collectAsState()
    val selectedApp by viewModel.selectedAppForDetail.collectAsState()

    var searchQuery by remember { mutableStateOf("") }
    var selectedFilter by remember { mutableStateOf("ALL") } // ALL, ACTIVE, SUSPENDED
    var showRegisterDialog by remember { mutableStateOf(false) }
    var showEditScopesDialog by remember { mutableStateOf<ExternalAppEntity?>(null) }
    var showRateLimitDialog by remember { mutableStateOf<ExternalAppEntity?>(null) }
    var showRotateKeyDialog by remember { mutableStateOf<ExternalAppEntity?>(null) }

    val filteredApps = externalApps.filter { app ->
        val matchesQuery = app.appName.contains(searchQuery, ignoreCase = true) ||
                app.appId.contains(searchQuery, ignoreCase = true) ||
                app.developerName.contains(searchQuery, ignoreCase = true)
        val matchesFilter = when (selectedFilter) {
            "ACTIVE" -> app.status.equals("ACTIVE", ignoreCase = true)
            "SUSPENDED" -> app.status.equals("SUSPENDED", ignoreCase = true)
            else -> true
        }
        matchesQuery && matchesFilter
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            "External Apps Monitor & Control",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            "API-First Architecture — Central Monitoring, Security & Quota Control",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }
                },
                actions = {
                    Button(
                        onClick = { showRegisterDialog = true },
                        colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                        modifier = Modifier.padding(end = 8.dp).testTag("register_app_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = "Register App", modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Register App", fontWeight = FontWeight.Bold)
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Executive Summary Cards
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val activeCount = externalApps.count { it.status.equals("ACTIVE", ignoreCase = true) }
                    val totalCallsToday = externalApps.sumOf { it.requestsToday }
                    val totalQuota = externalApps.sumOf { it.dailyQuota.toLong() }

                    AppMetricCard(
                        title = "Registered Apps",
                        value = "${externalApps.size}",
                        subtitle = "$activeCount Active in Production",
                        icon = Icons.Default.Apps,
                        color = SaffronPrimary,
                        modifier = Modifier.weight(1f)
                    )
                    AppMetricCard(
                        title = "Daily Quota Usage",
                        value = "$totalCallsToday",
                        subtitle = "of $totalQuota Allocated Calls",
                        icon = Icons.Default.DataUsage,
                        color = SpiritualTeal,
                        modifier = Modifier.weight(1f)
                    )
                    AppMetricCard(
                        title = "Gateway Security",
                        value = "100% Enforced",
                        subtitle = "Granular Scopes & Isolation",
                        icon = Icons.Default.Security,
                        color = VedicGold,
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // 2. Search & Filter Bar
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier.weight(1f).testTag("search_apps_input"),
                        placeholder = { Text("Search by App ID, Name, or Developer...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    FilterChip(
                        selected = selectedFilter == "ALL",
                        onClick = { selectedFilter = "ALL" },
                        label = { Text("All (${externalApps.size})") }
                    )
                    FilterChip(
                        selected = selectedFilter == "ACTIVE",
                        onClick = { selectedFilter = "ACTIVE" },
                        label = { Text("Active") }
                    )
                    FilterChip(
                        selected = selectedFilter == "SUSPENDED",
                        onClick = { selectedFilter = "SUSPENDED" },
                        label = { Text("Suspended") }
                    )
                }
            }

            // 3. Apps List
            items(filteredApps) { app ->
                ExternalAppCard(
                    app = app,
                    onInspect = { viewModel.selectAppForDetail(app) },
                    onToggleStatus = {
                        val nextStatus = if (app.status.equals("ACTIVE", ignoreCase = true)) "SUSPENDED" else "ACTIVE"
                        viewModel.updateAppStatus(app, nextStatus)
                    },
                    onEditScopes = { showEditScopesDialog = app },
                    onEditRateLimit = { showRateLimitDialog = app },
                    onRotateKey = { showRotateKeyDialog = app }
                )
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // Modal: App Detail Inspector Sheet
    selectedApp?.let { app ->
        AppDetailDialog(
            app = app,
            onDismiss = { viewModel.selectAppForDetail(null) },
            onToggleStatus = {
                val nextStatus = if (app.status.equals("ACTIVE", ignoreCase = true)) "SUSPENDED" else "ACTIVE"
                viewModel.updateAppStatus(app, nextStatus)
            }
        )
    }

    // Modal: Register New External App
    if (showRegisterDialog) {
        RegisterExternalAppDialog(
            onDismiss = { showRegisterDialog = false },
            onRegister = { name, dev, email, scopes, caps, rateLimit, quota ->
                viewModel.registerExternalApp(name, dev, email, scopes, caps, rateLimit, quota) {
                    showRegisterDialog = false
                }
            }
        )
    }

    // Modal: Edit Scopes & Capabilities
    showEditScopesDialog?.let { app ->
        EditScopesDialog(
            app = app,
            onDismiss = { showEditScopesDialog = null },
            onSave = { scopes, caps ->
                viewModel.updateAppScopesAndCapabilities(app, scopes, caps)
                showEditScopesDialog = null
            }
        )
    }

    // Modal: Edit Rate Limits
    showRateLimitDialog?.let { app ->
        EditRateLimitDialog(
            app = app,
            onDismiss = { showRateLimitDialog = null },
            onSave = { rate, quota ->
                viewModel.updateAppRateLimit(app, rate, quota)
                showRateLimitDialog = null
            }
        )
    }

    // Modal: Rotate API Key Confirmation
    showRotateKeyDialog?.let { app ->
        AlertDialog(
            onDismissRequest = { showRotateKeyDialog = null },
            title = { Text("Rotate API Key for ${app.appName}?") },
            text = {
                Text("This will immediately invalidate the current credentials. The external application must update its authorization header to continue calling VedaNova AI Gateway.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.rotateAppApiKey(app)
                        showRotateKeyDialog = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
                ) {
                    Text("Rotate Key")
                }
            },
            dismissButton = {
                TextButton(onClick = { showRotateKeyDialog = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun AppMetricCard(
    title: String,
    value: String,
    subtitle: String,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(36.dp)
                        .clip(CircleShape)
                        .background(color.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(icon, contentDescription = null, tint = color, modifier = Modifier.size(20.dp))
                }
                Spacer(modifier = Modifier.width(8.dp))
                Text(title, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
            }
            Spacer(modifier = Modifier.height(10.dp))
            Text(value, style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold, color = color))
            Text(subtitle, style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
        }
    }
}

@Composable
fun ExternalAppCard(
    app: ExternalAppEntity,
    onInspect: () -> Unit,
    onToggleStatus: () -> Unit,
    onEditScopes: () -> Unit,
    onEditRateLimit: () -> Unit,
    onRotateKey: () -> Unit
) {
    val isActive = app.status.equals("ACTIVE", ignoreCase = true)
    val statusColor = if (isActive) Color(0xFF2E7D32) else Color(0xFFC62828)

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header Row
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            app.appName,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = statusColor.copy(alpha = 0.15f)
                        ) {
                            Text(
                                app.status.uppercase(),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = statusColor
                                )
                            )
                        }
                    }
                    Text(
                        "ID: ${app.appId} • Dev: ${app.developerName} (${app.contactEmail})",
                        style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )
                }

                IconButton(onClick = onInspect) {
                    Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = "Inspect App")
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // Credentials & Quota Row
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(10.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("API Key Credential", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                        Text(app.maskedKey, style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.SemiBold))
                    }
                    Column(horizontalAlignment = Alignment.End) {
                        Text("Rate Limit / Quota", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                        Text("${app.rateLimitPerMin} req/min • ${app.requestsToday}/${app.dailyQuota} today", style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold))
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Granted Scopes & Capabilities
            Text("Granted Scopes:", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
            Row(
                modifier = Modifier.fillMaxWidth().padding(vertical = 4.dp),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                app.allowedScopes.split(",").forEach { scope ->
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = SaffronPrimary.copy(alpha = 0.12f)
                    ) {
                        Text(
                            scope.trim(),
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = SaffronPrimary)
                        )
                    }
                }
            }

            Text("Active Capabilities:", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = SpiritualTeal))
            Text(
                app.activeCapabilities.replace(",", " • "),
                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant),
                maxLines = 1
            )

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(8.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedButton(
                        onClick = onEditScopes,
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Lock, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Scopes", fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = onEditRateLimit,
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Speed, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Limits", fontSize = 12.sp)
                    }

                    OutlinedButton(
                        onClick = onRotateKey,
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Rotate Key", fontSize = 12.sp)
                    }
                }

                Button(
                    onClick = onToggleStatus,
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isActive) Color(0xFFC62828) else Color(0xFF2E7D32)
                    ),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Text(if (isActive) "Suspend" else "Activate", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                }
            }
        }
    }
}

@Composable
fun AppDetailDialog(
    app: ExternalAppEntity,
    onDismiss: () -> Unit,
    onToggleStatus: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = {
            Column {
                Text(app.appName, fontWeight = FontWeight.Bold)
                Text("App ID: ${app.appId}", style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
            }
        },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Text("Developer & Contact", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                Text("${app.developerName} • ${app.contactEmail}", style = MaterialTheme.typography.bodyMedium)

                HorizontalDivider()

                Text("Raw API Key (Authorized)", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        app.apiKey,
                        modifier = Modifier.padding(8.dp),
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace)
                    )
                }

                HorizontalDivider()

                Text("Granted Scopes", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                Text(app.allowedScopes, style = MaterialTheme.typography.bodyMedium)

                Text("Active Capabilities", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.labelMedium)
                Text(app.activeCapabilities, style = MaterialTheme.typography.bodyMedium)

                HorizontalDivider()

                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Total Requests Served:", style = MaterialTheme.typography.bodySmall)
                    Text("${app.totalRequests}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Rate Limit (per min):", style = MaterialTheme.typography.bodySmall)
                    Text("${app.rateLimitPerMin}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                }
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                    Text("Daily Quota:", style = MaterialTheme.typography.bodySmall)
                    Text("${app.dailyQuota}", fontWeight = FontWeight.Bold, style = MaterialTheme.typography.bodySmall)
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    onToggleStatus()
                    onDismiss()
                },
                colors = ButtonDefaults.buttonColors(
                    containerColor = if (app.status.equals("ACTIVE", ignoreCase = true)) Color(0xFFC62828) else Color(0xFF2E7D32)
                )
            ) {
                Text(if (app.status.equals("ACTIVE", ignoreCase = true)) "Suspend App" else "Activate App")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Close")
            }
        }
    )
}

@Composable
fun RegisterExternalAppDialog(
    onDismiss: () -> Unit,
    onRegister: (name: String, dev: String, email: String, scopes: String, caps: String, rate: Int, quota: Int) -> Unit
) {
    var appName by remember { mutableStateOf("") }
    var developerName by remember { mutableStateOf("") }
    var email by remember { mutableStateOf("") }
    var scopes by remember { mutableStateOf("CHAT, CALENDAR, FESTIVAL, MANTRA") }
    var capabilities by remember { mutableStateOf("AI_CHAT, DAILY_DATE, BANGLA_DATE, UPCOMING_FESTIVAL, MANTRA_SEARCH") }
    var rateLimit by remember { mutableStateOf("60") }
    var dailyQuota by remember { mutableStateOf("10000") }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Register External Application", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = appName,
                    onValueChange = { appName = it },
                    label = { Text("Application Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = developerName,
                    onValueChange = { developerName = it },
                    label = { Text("Developer / Organization Name") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = email,
                    onValueChange = { email = it },
                    label = { Text("Contact Email") },
                    singleLine = true,
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = scopes,
                    onValueChange = { scopes = it },
                    label = { Text("Allowed Scopes (comma separated)") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = capabilities,
                    onValueChange = { capabilities = it },
                    label = { Text("Initial Capabilities") },
                    modifier = Modifier.fillMaxWidth()
                )
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = rateLimit,
                        onValueChange = { rateLimit = it },
                        label = { Text("Rate Limit/Min") },
                        modifier = Modifier.weight(1f)
                    )
                    OutlinedTextField(
                        value = dailyQuota,
                        onValueChange = { dailyQuota = it },
                        label = { Text("Daily Quota") },
                        modifier = Modifier.weight(1f)
                    )
                }
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    if (appName.isNotBlank() && developerName.isNotBlank()) {
                        val rate = rateLimit.toIntOrNull() ?: 60
                        val quota = dailyQuota.toIntOrNull() ?: 10000
                        onRegister(appName, developerName, email, scopes, capabilities, rate, quota)
                    }
                },
                colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
            ) {
                Text("Register App")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun EditScopesDialog(
    app: ExternalAppEntity,
    onDismiss: () -> Unit,
    onSave: (scopes: String, capabilities: String) -> Unit
) {
    var scopes by remember { mutableStateOf(app.allowedScopes) }
    var capabilities by remember { mutableStateOf(app.activeCapabilities) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Edit Scopes: ${app.appName}", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = scopes,
                    onValueChange = { scopes = it },
                    label = { Text("Allowed API Scopes") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = capabilities,
                    onValueChange = { capabilities = it },
                    label = { Text("Active Capabilities") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = { onSave(scopes, capabilities) },
                colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
            ) {
                Text("Save Changes")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}

@Composable
fun EditRateLimitDialog(
    app: ExternalAppEntity,
    onDismiss: () -> Unit,
    onSave: (rateLimit: Int, quota: Int) -> Unit
) {
    var rateLimit by remember { mutableStateOf(app.rateLimitPerMin.toString()) }
    var dailyQuota by remember { mutableStateOf(app.dailyQuota.toString()) }

    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Configure Limits: ${app.appName}", fontWeight = FontWeight.Bold) },
        text = {
            Column(
                modifier = Modifier.fillMaxWidth(),
                verticalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                OutlinedTextField(
                    value = rateLimit,
                    onValueChange = { rateLimit = it },
                    label = { Text("Requests per Minute") },
                    modifier = Modifier.fillMaxWidth()
                )
                OutlinedTextField(
                    value = dailyQuota,
                    onValueChange = { dailyQuota = it },
                    label = { Text("Daily Quota (Requests/Day)") },
                    modifier = Modifier.fillMaxWidth()
                )
            }
        },
        confirmButton = {
            Button(
                onClick = {
                    val rate = rateLimit.toIntOrNull() ?: app.rateLimitPerMin
                    val quota = dailyQuota.toIntOrNull() ?: app.dailyQuota
                    onSave(rate, quota)
                },
                colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
            ) {
                Text("Save Limits")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) {
                Text("Cancel")
            }
        }
    )
}
