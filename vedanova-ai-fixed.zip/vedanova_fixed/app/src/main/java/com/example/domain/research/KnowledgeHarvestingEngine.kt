package com.example.domain.research

import com.example.data.dao.KnowledgeCandidateDao
import com.example.data.dao.KnowledgeDao
import com.example.data.dao.ResearchActivityLogDao
import com.example.data.dao.ResearchCacheDao
import com.example.data.dao.ResearchIssueDao
import com.example.data.model.*
import java.util.UUID

data class DuplicateCheckResult(
    val isDuplicate: Boolean,
    val matchedKnowledgeId: Long?,
    val matchedTitle: String?,
    val matchType: String = "NONE" // NONE, EXACT_QUESTION, EXACT_SANSKRIT, EXACT_REFERENCE, HIGH_SIMILARITY
)

data class KnowledgeConflictResult(
    val hasConflict: Boolean,
    val existingKnowledgeId: Long?,
    val existingContent: String?,
    val newSourceContent: String?,
    val conflictDescription: String?
)

class KnowledgeHarvestingEngine(
    private val knowledgeDao: KnowledgeDao,
    private val knowledgeCandidateDao: KnowledgeCandidateDao,
    private val researchIssueDao: ResearchIssueDao,
    private val researchCacheDao: ResearchCacheDao,
    private val researchActivityLogDao: ResearchActivityLogDao
) {

    /**
     * Checks if new research content is a duplicate of any existing published knowledge
     */
    suspend fun checkForDuplicates(
        question: String,
        sanskritText: String = "",
        reference: String = ""
    ): DuplicateCheckResult {
        val existingItems = knowledgeDao.findMatchingPublishedKnowledge(question)
        val cleanQ = question.trim().lowercase()

        // 1. Exact or near match on question
        for (item in existingItems) {
            val itemQ = item.question.trim().lowercase()
            val itemTitle = item.title.trim().lowercase()
            if (itemQ.isNotEmpty() && (itemQ == cleanQ || cleanQ.contains(itemQ) || itemQ.contains(cleanQ))) {
                return DuplicateCheckResult(
                    isDuplicate = true,
                    matchedKnowledgeId = item.id,
                    matchedTitle = item.title,
                    matchType = "EXACT_QUESTION"
                )
            }
            if (itemTitle.isNotEmpty() && (itemTitle == cleanQ || cleanQ.contains(itemTitle))) {
                return DuplicateCheckResult(
                    isDuplicate = true,
                    matchedKnowledgeId = item.id,
                    matchedTitle = item.title,
                    matchType = "HIGH_SIMILARITY"
                )
            }
        }

        // 2. Exact match on Sanskrit text if present
        if (sanskritText.isNotBlank()) {
            val cleanSanskrit = sanskritText.replace("\\s+".toRegex(), "")
            for (item in existingItems) {
                val itemSanskrit = item.sanskritText.replace("\\s+".toRegex(), "")
                if (itemSanskrit.isNotEmpty() && (itemSanskrit == cleanSanskrit || cleanSanskrit.contains(itemSanskrit))) {
                    return DuplicateCheckResult(
                        isDuplicate = true,
                        matchedKnowledgeId = item.id,
                        matchedTitle = item.title,
                        matchType = "EXACT_SANSKRIT"
                    )
                }
            }
        }

        // 3. Exact match on Scripture Reference if present
        if (reference.isNotBlank() && reference.length > 5) {
            for (item in existingItems) {
                if (item.reference.isNotBlank() && item.reference.equals(reference, ignoreCase = true)) {
                    return DuplicateCheckResult(
                        isDuplicate = true,
                        matchedKnowledgeId = item.id,
                        matchedTitle = item.title,
                        matchType = "EXACT_REFERENCE"
                    )
                }
            }
        }

        return DuplicateCheckResult(isDuplicate = false, matchedKnowledgeId = null, matchedTitle = null)
    }

    /**
     * Checks if new research conflicts with existing canonical knowledge
     */
    suspend fun checkForConflicts(
        question: String,
        newScripture: String,
        newReference: String,
        newSanskrit: String
    ): KnowledgeConflictResult {
        val existingItems = knowledgeDao.findMatchingPublishedKnowledge(question)
        if (existingItems.isEmpty()) {
            return KnowledgeConflictResult(false, null, null, null, null)
        }

        val primary = existingItems.first()
        // If same topic but completely different scripture reference
        if (primary.reference.isNotBlank() && newReference.isNotBlank() && !primary.reference.equals(newReference, ignoreCase = true)) {
            return KnowledgeConflictResult(
                hasConflict = true,
                existingKnowledgeId = primary.id,
                existingContent = "Existing Reference: ${primary.reference} (${primary.scripture})",
                newSourceContent = "New Source Reference: $newReference ($newScripture)",
                conflictDescription = "The existing database attributes this topic to '${primary.reference}', but new research points to '$newReference'."
            )
        }

        return KnowledgeConflictResult(false, null, null, null, null)
    }

    /**
     * Creates a KnowledgeCandidateEntity with reviewStatus = PENDING_REVIEW
     */
    suspend fun createKnowledgeCandidate(
        title: String,
        question: String,
        answer: String,
        category: String,
        language: String = "BENGALI",
        sourceIds: String = "",
        scripture: String = "",
        chapter: String = "",
        verse: String = "",
        reference: String = "",
        sanskritText: String = "",
        transliteration: String = "",
        bengaliMeaning: String = "",
        englishMeaning: String = "",
        sourceTier: String = "TIER 1",
        confidence: Float = 0.95f,
        verificationStatus: String = "VERIFIED",
        conflictNotes: String = "",
        sampradayaNotes: String = ""
    ): KnowledgeCandidateEntity {
        // 1. Duplicate Check
        val dupCheck = checkForDuplicates(question, sanskritText, reference)

        val candidate = KnowledgeCandidateEntity(
            candidateId = "CAND-${System.currentTimeMillis() % 1000000}",
            title = title,
            question = question,
            answer = answer,
            category = category,
            language = language,
            sourceIds = sourceIds,
            scripture = scripture,
            chapter = chapter,
            verse = verse,
            reference = reference,
            sanskritText = sanskritText,
            transliteration = transliteration,
            bengaliMeaning = bengaliMeaning,
            englishMeaning = englishMeaning,
            sourceTier = sourceTier,
            confidence = confidence,
            verificationStatus = verificationStatus,
            reviewStatus = "PENDING_REVIEW",
            conflictNotes = conflictNotes,
            duplicateMatchId = dupCheck.matchedKnowledgeId,
            duplicateMatchTitle = dupCheck.matchedTitle ?: "",
            sampradayaNotes = sampradayaNotes,
            createdAt = System.currentTimeMillis()
        )

        knowledgeCandidateDao.insertCandidate(candidate)
        return candidate
    }

    /**
     * Reports an unknown or unverified question directly to Admin Research Issue Center
     */
    suspend fun createResearchIssueReport(
        userQuery: String,
        normalizedQuery: String,
        language: String,
        intent: String,
        reason: String,
        sourcesFound: Int,
        sourcesVerified: Int,
        conflictDetected: Boolean,
        confidence: Float
    ): ResearchIssueEntity {
        val report = ResearchIssueEntity(
            reportId = "REP-RES-${System.currentTimeMillis() % 1000000}",
            userQuery = userQuery,
            normalizedQuery = normalizedQuery,
            language = language,
            intent = intent,
            localKnowledgeResult = "NOT_FOUND",
            webSearchAttempted = true,
            youtubeSearchAttempted = true,
            sourcesFound = sourcesFound,
            sourcesVerified = sourcesVerified,
            conflictDetected = conflictDetected,
            reason = reason,
            confidence = confidence,
            status = if (conflictDetected) "VERIFICATION_REQUIRED" else if (sourcesFound == 0) "NO_RELIABLE_SOURCE" else "OPEN",
            suggestedAction = "Admin Canonical Verification & Teach AI",
            createdAt = System.currentTimeMillis()
        )

        researchIssueDao.insertIssue(report)
        return report
    }

    /**
     * Logs research activity for admin transparency and auditability
     */
    suspend fun logResearchActivity(
        userQuery: String,
        searchQueries: String,
        providersUsed: String,
        sourcesFound: Int,
        sourcesAccepted: Int,
        sourcesRejected: Int,
        verificationResult: String,
        confidence: Float,
        durationMs: Long,
        finalDecision: String
    ) {
        val log = ResearchActivityLogEntity(
            researchId = "RES-ACT-${System.currentTimeMillis() % 1000000}",
            userQuery = userQuery,
            searchQueries = searchQueries,
            providersUsed = providersUsed,
            sourcesFound = sourcesFound,
            sourcesAccepted = sourcesAccepted,
            sourcesRejected = sourcesRejected,
            verificationResult = verificationResult,
            confidence = confidence,
            durationMs = durationMs,
            finalDecision = finalDecision,
            timestamp = System.currentTimeMillis()
        )
        researchActivityLogDao.insertLog(log)
    }

    /**
     * Approves a candidate and publishes it to the main canonical KnowledgeEntity table
     */
    suspend fun approveAndPublishCandidate(candidateId: String, adminUser: String = "Admin"): KnowledgeEntity? {
        val candidate = knowledgeCandidateDao.getCandidateById(candidateId) ?: return null

        val newKnowledge = KnowledgeEntity(
            knowledgeCode = "KB-RES-${System.currentTimeMillis() % 100000}",
            title = candidate.title,
            question = candidate.question,
            answer = candidate.answer,
            category = candidate.category,
            language = candidate.language,
            sanskritText = candidate.sanskritText,
            transliteration = candidate.transliteration,
            banglaMeaning = candidate.bengaliMeaning,
            englishMeaning = candidate.englishMeaning,
            explanation = "গবেষণা যাচাই ও অ্যাডমিন অনুমোদনের মাধ্যমে প্রকাশিত canonical জ্ঞান।",
            scripture = candidate.scripture,
            chapter = candidate.chapter,
            verse = candidate.verse,
            reference = candidate.reference,
            source = "WEB_RESEARCH_ADMIN_APPROVED",
            sourceType = candidate.sourceTier,
            verificationStatus = "PUBLISHED",
            confidenceScore = candidate.confidence,
            tags = "${candidate.title}, ${candidate.category}, ${candidate.scripture}",
            version = 1,
            usageCount = 0,
            successCount = 0,
            createdBy = "Research Harvesting ($adminUser)",
            updatedBy = adminUser,
            createdDate = System.currentTimeMillis(),
            updatedDate = System.currentTimeMillis()
        )

        val insertedId = knowledgeDao.insertKnowledge(newKnowledge)
        knowledgeCandidateDao.updateCandidateStatus(candidateId, "APPROVED", adminUser, System.currentTimeMillis())

        return newKnowledge.copy(id = insertedId)
    }
}
