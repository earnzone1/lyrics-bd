package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.ApiKeyEntity
import com.example.ui.components.CodeBlockViewer
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.*
import com.example.ui.viewmodel.ScreenDestination
import com.example.ui.viewmodel.VedaNovaViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun ApiCenterScreen(viewModel: VedaNovaViewModel) {
    val apiKeys by viewModel.allApiKeys.collectAsStateWithLifecycle()
    var showCreateDialog by remember { mutableStateOf(false) }
    var selectedKeyForAction by remember { mutableStateOf<ApiKeyEntity?>(null) }
    var actionDialogType by remember { mutableStateOf<String?>(null) } // "ROTATE", "STATUS", "DELETE"
    var showDocsTab by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.VpnKey, contentDescription = null, tint = SaffronPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "API Management Center",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Button(
                            onClick = { showCreateDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Create API Key", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = "Provision, rotate, and secure external client API keys for mobile, web, and partner platforms. All keys are securely hashed and enforce rate limiting.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = !showDocsTab,
                            onClick = { showDocsTab = false },
                            label = { Text("Active API Keys (${apiKeys.size})") },
                            leadingIcon = { Icon(Icons.Default.Key, contentDescription = null, modifier = Modifier.size(14.dp)) }
                        )
                        FilterChip(
                            selected = showDocsTab,
                            onClick = { showDocsTab = true },
                            label = { Text("Interactive API Docs (OpenAPI)") },
                            leadingIcon = { Icon(Icons.Default.MenuBook, contentDescription = null, modifier = Modifier.size(14.dp)) }
                        )
                        AssistChip(
                            onClick = { viewModel.navigateTo(ScreenDestination.EXTERNAL_TEST_CLIENT) },
                            label = { Text("External Test Client", color = SaffronPrimary, fontWeight = FontWeight.Bold) },
                            leadingIcon = { Icon(Icons.Default.CloudQueue, contentDescription = null, tint = SaffronPrimary, modifier = Modifier.size(14.dp)) }
                        )
                    }
                }
            }
        }

        if (!showDocsTab) {
            // API Keys List
            items(apiKeys) { keyItem ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = keyItem.name,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Client: ${keyItem.appName} • Version: ${keyItem.version}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            StatusPill(
                                text = keyItem.status,
                                color = when (keyItem.status) {
                                    "Active" -> StatusGreen
                                    "Suspended" -> StatusYellow
                                    else -> StatusRed
                                }
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Masked API Key Display Box
                        Surface(
                            color = Color(0xFF0E0717),
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2E1B4E)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = keyItem.maskedKey,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.SemiBold
                                    ),
                                    color = VedicGold
                                )
                                Text(
                                    text = "HMAC SHA-256 Protected",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Stats & Rate Limits
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(text = "Total Requests", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(text = "${keyItem.requestCount}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = SaffronPrimary)
                            }
                            Column {
                                Text(text = "Error Rate", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(text = "${keyItem.errorCount}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = if (keyItem.errorCount > 0) StatusYellow else StatusGreen)
                            }
                            Column {
                                Text(text = "Rate Limit", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(text = "${keyItem.rateLimitPerMin} req/min", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                            }
                            Column {
                                Text(text = "Daily Limit", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(text = "${keyItem.dailyLimit}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = "Allowed Scopes: ${keyItem.permissions}",
                            style = MaterialTheme.typography.labelSmall,
                            color = SaffronLight
                        )

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                        Spacer(modifier = Modifier.height(10.dp))

                        // Action Buttons
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedButton(
                                onClick = {
                                    viewModel.updateApiTestKey(keyItem.apiKey)
                                    viewModel.navigateTo(ScreenDestination.API_TESTING)
                                },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.Terminal, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Test in Console", style = MaterialTheme.typography.labelSmall)
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            OutlinedButton(
                                onClick = {
                                    selectedKeyForAction = keyItem
                                    actionDialogType = "ROTATE"
                                },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(14.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Rotate Key", style = MaterialTheme.typography.labelSmall)
                            }

                            Spacer(modifier = Modifier.width(8.dp))

                            IconButton(
                                onClick = {
                                    selectedKeyForAction = keyItem
                                    actionDialogType = "STATUS"
                                }
                            ) {
                                Icon(
                                    imageVector = if (keyItem.status == "Active") Icons.Default.PauseCircle else Icons.Default.PlayCircle,
                                    contentDescription = "Toggle Status",
                                    tint = if (keyItem.status == "Active") StatusYellow else StatusGreen
                                )
                            }

                            IconButton(
                                onClick = {
                                    selectedKeyForAction = keyItem
                                    actionDialogType = "DELETE"
                                }
                            ) {
                                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = StatusRed)
                            }
                        }
                    }
                }
            }
        } else {
            // Interactive OpenAPI Documentation (Requirement #5 & #6)
            item {
                SectionHeader(
                    title = "VedaNova Core REST API Specification (v1)",
                    subtitle = "Production endpoints for mobile, web, and external applications"
                )
            }

            item {
                ApiDocCard(
                    method = "POST",
                    endpoint = "/api/v1/chat",
                    description = "Interactive Sanskrit & Dharma AI reasoning engine with scripture grounding.",
                    sampleBody = """
                        {
                          "query": "শ্রীমদ্ভগবদ্গীতা ২.৪৭ শ্লোকের তাৎপর্য কী?",
                          "temperature": 0.2
                        }
                    """.trimIndent(),
                    onTestClick = {
                        viewModel.updateApiTestEndpoint("/api/v1/chat")
                        viewModel.navigateTo(ScreenDestination.API_TESTING)
                    }
                )
            }

            item {
                ApiDocCard(
                    method = "POST",
                    endpoint = "/api/v1/knowledge/search",
                    description = "Search verified Hindu scripture canonical records (Gita, Vedas, Upanishads, Mantras, Pujas).",
                    sampleBody = """
                        {
                          "query": "Gayatri Mantra",
                          "limit": 5
                        }
                    """.trimIndent(),
                    onTestClick = {
                        viewModel.updateApiTestEndpoint("/api/v1/knowledge/search")
                        viewModel.navigateTo(ScreenDestination.API_TESTING)
                    }
                )
            }

            item {
                ApiDocCard(
                    method = "POST",
                    endpoint = "/api/v1/mantra/search",
                    description = "Dedicated Mantra & Stotra lookup with IAST transliteration and audio metric guidance.",
                    sampleBody = """
                        {
                          "query": "Mahamrityunjaya",
                          "include_transliteration": true
                        }
                    """.trimIndent(),
                    onTestClick = {
                        viewModel.updateApiTestEndpoint("/api/v1/mantra/search")
                        viewModel.navigateTo(ScreenDestination.API_TESTING)
                    }
                )
            }

            item {
                ApiDocCard(
                    method = "POST",
                    endpoint = "/api/v1/scripture/search",
                    description = "Precise scripture chapter & verse retrieval with classical Sanskrit commentaries.",
                    sampleBody = """
                        {
                          "query": "Isha Upanishad 1",
                          "scripture": "Upanishads"
                        }
                    """.trimIndent(),
                    onTestClick = {
                        viewModel.updateApiTestEndpoint("/api/v1/scripture/search")
                        viewModel.navigateTo(ScreenDestination.API_TESTING)
                    }
                )
            }

            item {
                ApiDocCard(
                    method = "POST",
                    endpoint = "/api/v1/research",
                    description = "Scholarly comparative hermeneutical synthesis with multi-scripture citation matrix.",
                    sampleBody = """
                        {
                          "query": "Karma Yoga in Gita vs Jnana in Upanishads"
                        }
                    """.trimIndent(),
                    onTestClick = {
                        viewModel.updateApiTestEndpoint("/api/v1/research")
                        viewModel.navigateTo(ScreenDestination.API_TESTING)
                    }
                )
            }

            item {
                ApiDocCard(
                    method = "POST",
                    endpoint = "/api/v1/verify",
                    description = "Fact-check and canonical authority verification for any Hindu scripture assertion.",
                    sampleBody = """
                        {
                          "query": "যদা যদা হি ধর্মস্য গ্লানির্ভবতি ভারত"
                        }
                    """.trimIndent(),
                    onTestClick = {
                        viewModel.updateApiTestEndpoint("/api/v1/verify")
                        viewModel.navigateTo(ScreenDestination.API_TESTING)
                    }
                )
            }

            item {
                ApiDocCard(
                    method = "GET",
                    endpoint = "/api/v1/status",
                    description = "Live gateway health status, rate limits, and connected knowledge node counters.",
                    sampleBody = "(No request body needed)",
                    onTestClick = {
                        viewModel.updateApiTestEndpoint("/api/v1/status")
                        viewModel.navigateTo(ScreenDestination.API_TESTING)
                    }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Create API Key Dialog
    if (showCreateDialog) {
        var keyName by remember { mutableStateOf("") }
        var appName by remember { mutableStateOf("") }
        var version by remember { mutableStateOf("v1") }
        var rateLimit by remember { mutableStateOf("60") }
        var dailyLimit by remember { mutableStateOf("5000") }
        var monthlyLimit by remember { mutableStateOf("100000") }
        var permissions by remember { mutableStateOf("chat,knowledge,mantra,scripture,puja,research,verify,status") }

        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("Create New VedaNova API Key", fontWeight = FontWeight.Bold) },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    OutlinedTextField(
                        value = keyName,
                        onValueChange = { keyName = it },
                        label = { Text("Key Identifier / Description") },
                        placeholder = { Text("e.g. Dharma Mobile App Client") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = appName,
                        onValueChange = { appName = it },
                        label = { Text("Client Application Name") },
                        placeholder = { Text("e.g. Sanatan Portal") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = version,
                            onValueChange = { version = it },
                            label = { Text("API Version") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = rateLimit,
                            onValueChange = { rateLimit = it },
                            label = { Text("Req / Min") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                    OutlinedTextField(
                        value = dailyLimit,
                        onValueChange = { dailyLimit = it },
                        label = { Text("Daily Request Quota") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = permissions,
                        onValueChange = { permissions = it },
                        label = { Text("Allowed Scope Permissions") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (keyName.isNotBlank() && appName.isNotBlank()) {
                            viewModel.createApiKey(
                                name = keyName,
                                appName = appName,
                                version = version,
                                rateLimit = rateLimit.toIntOrNull() ?: 60,
                                dailyLimit = dailyLimit.toIntOrNull() ?: 5000,
                                monthlyLimit = monthlyLimit.toIntOrNull() ?: 100000,
                                permissions = permissions
                            )
                            showCreateDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
                ) {
                    Text("Generate Key", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Action Confirmation Dialogs
    selectedKeyForAction?.let { key ->
        when (actionDialogType) {
            "ROTATE" -> {
                AlertDialog(
                    onDismissRequest = { actionDialogType = null },
                    title = { Text("Rotate API Key") },
                    text = {
                        Text("Are you sure you want to regenerate the API key for '${key.name}'? The previous key will be immediately invalidated.")
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                viewModel.rotateApiKey(key)
                                actionDialogType = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
                        ) {
                            Text("Confirm Rotation", color = Color.Black)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { actionDialogType = null }) { Text("Cancel") }
                    }
                )
            }
            "STATUS" -> {
                val nextStatus = if (key.status == "Active") "Suspended" else "Active"
                AlertDialog(
                    onDismissRequest = { actionDialogType = null },
                    title = { Text("Change API Status") },
                    text = {
                        Text("Set status of '${key.name}' to $nextStatus?")
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                viewModel.updateApiKeyStatus(key, nextStatus)
                                actionDialogType = null
                            }
                        ) {
                            Text("Set $nextStatus")
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { actionDialogType = null }) { Text("Cancel") }
                    }
                )
            }
            "DELETE" -> {
                AlertDialog(
                    onDismissRequest = { actionDialogType = null },
                    title = { Text("Revoke & Delete API Key", color = StatusRed) },
                    text = {
                        Text("This action is permanent and cannot be undone. External applications using this key will immediately fail with 401 Unauthorized.")
                    },
                    confirmButton = {
                        Button(
                            onClick = {
                                viewModel.deleteApiKey(key)
                                actionDialogType = null
                            },
                            colors = ButtonDefaults.buttonColors(containerColor = StatusRed)
                        ) {
                            Text("Permanent Delete", color = Color.White)
                        }
                    },
                    dismissButton = {
                        TextButton(onClick = { actionDialogType = null }) { Text("Cancel") }
                    }
                )
            }
        }
    }
}

@Composable
private fun ApiDocCard(
    method: String,
    endpoint: String,
    description: String,
    sampleBody: String,
    onTestClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StatusPill(
                        text = method,
                        color = if (method == "POST") SaffronPrimary else StatusGreen
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = endpoint,
                        style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Monospace),
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Button(
                    onClick = onTestClick,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary.copy(alpha = 0.2f))
                ) {
                    Text("Try in Console →", color = SaffronPrimary, style = MaterialTheme.typography.labelSmall)
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(10.dp))
            CodeBlockViewer(code = sampleBody, language = "JSON Payload")
        }
    }
}
