package com.example.domain.auth

import com.example.data.dao.AdminUserDao
import com.example.data.dao.AuditLogDao
import com.example.data.model.AdminUserEntity
import com.example.data.model.AuditLogEntity
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class AdminSession(
    val currentUser: AdminUserEntity,
    val isAuthenticated: Boolean = true,
    val loginTime: Long = System.currentTimeMillis()
)

class AdminAuthManager(
    private val adminUserDao: AdminUserDao,
    private val auditLogDao: AuditLogDao
) {
    private val defaultSuperAdmin = AdminUserEntity(
        id = 1,
        username = "superadmin",
        fullName = "Acharya Vidyadhar (Lead Architect)",
        role = "Super Admin",
        email = "mray75779@gmail.com",
        permissions = "ALL"
    )

    private val _currentSession = MutableStateFlow(AdminSession(currentUser = defaultSuperAdmin))
    val currentSession: StateFlow<AdminSession> = _currentSession.asStateFlow()

    suspend fun switchUser(user: AdminUserEntity) {
        _currentSession.value = AdminSession(currentUser = user)
        auditLogDao.insertAuditLog(
            AuditLogEntity(
                adminUsername = user.username,
                adminRole = user.role,
                action = "Admin Session Switched",
                targetType = "AUTH",
                targetId = user.username,
                details = "Active admin switched to ${user.fullName} (${user.role})."
            )
        )
    }

    fun hasPermission(permissionKey: String): Boolean {
        val user = _currentSession.value.currentUser
        if (user.role == "Super Admin") return true
        return when (permissionKey) {
            "KNOWLEDGE_EDIT", "KNOWLEDGE_CREATE", "TEACH_AI" -> 
                user.role in listOf("Super Admin", "Admin", "Knowledge Manager")
            "KNOWLEDGE_APPROVE", "KNOWLEDGE_VERIFY" -> 
                user.role in listOf("Super Admin", "Admin", "Knowledge Manager", "Reviewer")
            "API_MANAGE", "API_CREATE", "API_ROTATE" -> 
                user.role in listOf("Super Admin", "Admin", "Developer")
            "API_TEST" -> 
                user.role in listOf("Super Admin", "Admin", "Developer", "Reviewer")
            "ISSUES_MANAGE", "REPORTS_MANAGE" -> 
                user.role in listOf("Super Admin", "Admin", "Support", "Knowledge Manager", "Developer")
            "DATABASE_MANAGE", "BACKUP_MANAGE", "SECURITY_SETTINGS" -> 
                user.role in listOf("Super Admin", "Admin")
            "LOGS_VIEW", "AUDIT_VIEW", "ANALYTICS_VIEW" -> 
                true
            else -> false
        }
    }

    suspend fun recordAudit(action: String, targetType: String, targetId: String, details: String) {
        val user = _currentSession.value.currentUser
        auditLogDao.insertAuditLog(
            AuditLogEntity(
                adminUsername = user.username,
                adminRole = user.role,
                action = action,
                targetType = targetType,
                targetId = targetId,
                details = details
            )
        )
    }
}
