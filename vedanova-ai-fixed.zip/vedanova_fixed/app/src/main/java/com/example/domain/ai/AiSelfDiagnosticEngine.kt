package com.example.domain.ai

import com.example.data.model.KnowledgeEntity

class AiSelfDiagnosticEngine {
    fun diagnoseInteraction(
        userQuery: String,
        aiResponse: String,
        diagnosticInfo: DiagnosticInfo,
        matchedEntities: List<KnowledgeEntity>
    ): SelfDiagnosticReport {
        val queryLower = userQuery.lowercase()
        val potentialErrors = mutableListOf<String>()
        var healthScore = 95

        // Check query clarity
        val interpretation = if (diagnosticInfo.ambiguityScore > 0.5f) {
            "Query contains minimal contextual parameters (${diagnosticInfo.languageDetected}). Interpretation relies heavily on probabilistic intent heuristics."
        } else {
            "Clear, unambiguous domain inquiry targeting ${diagnosticInfo.intentDetected} (${diagnosticInfo.subIntent})."
        }

        // Check knowledge retrieval status
        val retrievalStatus = if (diagnosticInfo.knowledgeMatchCount > 0) {
            "Matched ${diagnosticInfo.knowledgeMatchCount} verified scripture node(s) in Room database. Top source: ${diagnosticInfo.topKnowledgeSource}."
        } else {
            healthScore -= 20
            potentialErrors.add("Zero local canonical grounding nodes found. Synthesized via fallback/LLM inference.")
            "No direct canonical match. Synthesized under strict safety guardrails."
        }

        // Check source integrity
        val sourceIntegrity = if (matchedEntities.isNotEmpty()) {
            val top = matchedEntities.first()
            "Validated against ${top.sourceType} authority: ${top.scripture} [${top.reference}]. Confidence ${(top.confidenceScore * 100).toInt()}%."
        } else {
            "External model inference with standard Vedic system instructions."
        }

        // Conflict check
        if (diagnosticInfo.conflictsDetected) {
            healthScore -= 10
            potentialErrors.add("Multi-tradition hermeneutical variance detected across Shruti vs Smriti sources.")
        }

        // Check Sanskrit diacritics integrity
        if (aiResponse.contains("ॐ") || aiResponse.contains("॥")) {
            // Good Vedic formatting
        }

        val verificationAnalysis = "Verification Tier: ${diagnosticInfo.verificationStatus}. Latency: ${diagnosticInfo.responseTimeMs}ms. Safety Guardrails: Passed."

        val recommendedFix = when {
            diagnosticInfo.knowledgeMatchCount == 0 ->
                "Action Recommended: Create a new verified Knowledge item under '${diagnosticInfo.intentDetected}' via 'Teach AI' or 'Knowledge Center' with canonical Sanskrit shloka and Bengali/English translation."
            diagnosticInfo.ambiguityScore > 0.5f ->
                "Action Recommended: Prompt user with disambiguation chips (e.g. Gita chapter, Vedic Samhita, or Puja Paddhati)."
            diagnosticInfo.conflictsDetected ->
                "Action Recommended: Add multi-sampradaya notes (e.g. Advaita, Vishishtadvaita, Gaudiya) to clarify scriptural commentaries."
            else ->
                "No critical remediation required. Shloka references, translation accuracy, and metadata are intact."
        }

        return SelfDiagnosticReport(
            queryInterpretation = interpretation,
            detectedIntent = "${diagnosticInfo.intentDetected} (${diagnosticInfo.subIntent})",
            knowledgeRetrievalStatus = retrievalStatus,
            sourceIntegrity = sourceIntegrity,
            verificationAnalysis = verificationAnalysis,
            potentialErrorsOrHallucinations = potentialErrors.ifEmpty { listOf("None detected. Clean verification pipeline execution.") },
            recommendedFix = recommendedFix,
            overallHealthScore = healthScore.coerceIn(0, 100)
        )
    }
}
