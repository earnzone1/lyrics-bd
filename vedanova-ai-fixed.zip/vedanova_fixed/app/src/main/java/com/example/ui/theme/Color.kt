package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// High Density Theme Tokens (Primary bg #fdf8f5, text #1d1b16)
val HighDensityBgLight = Color(0xFFFDF8F5)
val HighDensitySurfaceLight = Color(0xFFFFFFFF)
val HighDensitySurfaceVariantLight = Color(0xFFF7F1EB)
val HighDensityTextPrimary = Color(0xFF1D1B16)
val HighDensityTextSecondary = Color(0xFF5E574D)
val HighDensityTextMuted = Color(0xFF8B8275)
val HighDensityBorderLight = Color(0xFFE8DFD3)
val HighDensityBorderSubtle = Color(0xFFF0E8DD)

// Saffron & Warm Ember Palette
val SaffronPrimary = Color(0xFFE65100)
val SaffronDark = Color(0xFFBF360C)
val SaffronLight = Color(0xFFFF8A50)
val SaffronContainer = Color(0xFFFFF0E5)
val OnSaffronContainer = Color(0xFF7A2000)

val VedicGold = Color(0xFFD97706)
val VedicGoldDark = Color(0xFFB45309)
val VedicGoldContainer = Color(0xFFFEF3C7)
val OnVedicGoldContainer = Color(0xFF78350F)

// High Density Dark Theme Tokens
val HighDensityBgDark = Color(0xFF151310)
val HighDensitySurfaceDark = Color(0xFF1E1A16)
val HighDensitySurfaceVariantDark = Color(0xFF2B251F)
val HighDensityBorderDark = Color(0xFF3E362E)
val TextPrimaryDark = Color(0xFFF6EFE9)
val TextSecondaryDark = Color(0xFFBDB3A6)
val TextMutedDark = Color(0xFF887D70)

// Legacy compatibility aliases
val CosmicNavy = HighDensityBgDark
val CosmicNavySurface = HighDensitySurfaceDark
val CosmicNavyElevated = HighDensitySurfaceVariantDark
val CosmicCardBorder = HighDensityBorderDark
val SacredSand = HighDensityBgLight
val SacredSandDark = HighDensityBgDark
val SacredCream = HighDensitySurfaceVariantLight
val TextPrimaryLight = HighDensityTextPrimary
val TextSecondaryLight = HighDensityTextSecondary

// Status & Metric Indicators
val StatusGreen = Color(0xFF16A34A)
val EmeraldGreen = Color(0xFF16A34A)
val StatusYellow = Color(0xFFD97706)
val AmberAlert = Color(0xFFD97706)
val StatusRed = Color(0xFFDC2626)
val StatusBlue = Color(0xFF2563EB)
val StatusPurple = Color(0xFF7C3AED)
val StatusTeal = Color(0xFF0D9488)
val SpiritualTeal = Color(0xFF0D9488)

