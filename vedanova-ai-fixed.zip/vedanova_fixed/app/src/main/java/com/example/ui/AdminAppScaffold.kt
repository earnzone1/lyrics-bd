package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.StatusPill
import com.example.ui.screens.*
import com.example.ui.theme.SaffronPrimary
import com.example.ui.theme.SpiritualTeal
import com.example.ui.theme.VedicGold
import com.example.ui.viewmodel.ScreenDestination
import com.example.ui.viewmodel.VedaNovaViewModel
import kotlinx.coroutines.launch

data class NavItem(
    val destination: ScreenDestination,
    val icon: ImageVector,
    val section: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminAppScaffold(viewModel: VedaNovaViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val session by viewModel.currentSession.collectAsStateWithLifecycle()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()

    // Handle back button
    BackHandler(enabled = currentScreen != ScreenDestination.DASHBOARD) {
        viewModel.navigateTo(ScreenDestination.DASHBOARD)
    }

    val navItems = listOf(
        // Core
        NavItem(ScreenDestination.DASHBOARD, Icons.Default.Dashboard, "Core"),
        NavItem(ScreenDestination.FUNCTION_MAP, Icons.Default.AccountTree, "Core"),
        NavItem(ScreenDestination.SETTINGS, Icons.Default.Tune, "Core"),

        // Phase 4: AI External App Function Engine
        NavItem(ScreenDestination.EXTERNAL_APPS_MONITOR, Icons.Default.Apps, "External App Engine"),
        NavItem(ScreenDestination.CAPABILITY_APPROVAL, Icons.Default.VerifiedUser, "External App Engine"),
        NavItem(ScreenDestination.DAILY_DATA_MONITOR, Icons.Default.CalendarMonth, "External App Engine"),
        NavItem(ScreenDestination.EXTERNAL_APP_SIMULATOR, Icons.Default.DeveloperMode, "External App Engine"),

        // AI & Testing
        NavItem(ScreenDestination.AI_TESTING_LAB, Icons.Default.Science, "AI & Testing"),

        // API Platform
        NavItem(ScreenDestination.API_CENTER, Icons.Default.Key, "API Platform"),
        NavItem(ScreenDestination.API_TESTING, Icons.Default.Terminal, "API Platform"),
        NavItem(ScreenDestination.EXTERNAL_TEST_CLIENT, Icons.Default.CloudQueue, "API Platform"),

        // Knowledge System
        NavItem(ScreenDestination.RESEARCH_CENTER, Icons.Default.TravelExplore, "Knowledge System"),
        NavItem(ScreenDestination.KNOWLEDGE_CENTER, Icons.Default.AutoStories, "Knowledge System"),
        NavItem(ScreenDestination.TEACH_AI, Icons.Default.School, "Knowledge System"),

        // Monitoring & Quality
        NavItem(ScreenDestination.PROBLEM_CENTER, Icons.Default.ReportProblem, "Monitoring & Quality"),
        NavItem(ScreenDestination.CRASH_REPORTS, Icons.Default.BugReport, "Monitoring & Quality"),
        NavItem(ScreenDestination.REPORTS, Icons.Default.Feedback, "Monitoring & Quality"),
        NavItem(ScreenDestination.ANALYTICS, Icons.Default.Analytics, "Monitoring & Quality"),
        NavItem(ScreenDestination.LOGS, Icons.Default.ListAlt, "Monitoring & Quality"),

        // Security & Governance
        NavItem(ScreenDestination.AUDIT_LOGS, Icons.Default.Security, "Security & Governance"),
        NavItem(ScreenDestination.SECURITY, Icons.Default.Shield, "Security & Governance"),
        NavItem(ScreenDestination.USERS, Icons.Default.AdminPanelSettings, "Security & Governance"),

        // Infrastructure
        NavItem(ScreenDestination.DATABASE_CENTER, Icons.Default.Storage, "Infrastructure"),
        NavItem(ScreenDestination.SYSTEM_HEALTH, Icons.Default.MonitorHeart, "Infrastructure"),

        // Public App Mode
        NavItem(ScreenDestination.PUBLIC_APP, Icons.Default.PhoneAndroid, "Public Client Mode")
    )

    val navSections = navItems.groupBy { it.section }

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = MaterialTheme.colorScheme.surface,
                modifier = Modifier.width(300.dp)
            ) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 12.dp, vertical = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Drawer Header
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(text = "🕉️", fontSize = 22.sp)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "VedaNova AI",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Hindu Dharma & Spirituality AI Platform",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                StatusPill(
                                    text = "${session.currentUser.role}: @${session.currentUser.username}",
                                    color = SaffronPrimary
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                        Spacer(modifier = Modifier.height(4.dp))
                    }

                    // Section-wise Navigation Items
                    navSections.forEach { (sectionTitle, items) ->
                        item {
                            Text(
                                text = sectionTitle.uppercase(),
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = VedicGold,
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                            )
                        }

                        items(items) { item ->
                            val isSelected = currentScreen == item.destination
                            NavigationDrawerItem(
                                icon = {
                                    Icon(
                                        imageVector = item.icon,
                                        contentDescription = null,
                                        tint = if (isSelected) MaterialTheme.colorScheme.onPrimary else SaffronPrimary
                                    )
                                },
                                label = {
                                    Text(
                                        text = item.destination.title,
                                        style = MaterialTheme.typography.bodyMedium,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                    )
                                },
                                selected = isSelected,
                                onClick = {
                                    viewModel.navigateTo(item.destination)
                                    coroutineScope.launch { drawerState.close() }
                                },
                                shape = RoundedCornerShape(8.dp),
                                colors = NavigationDrawerItemDefaults.colors(
                                    selectedContainerColor = SaffronPrimary,
                                    selectedTextColor = MaterialTheme.colorScheme.onPrimary,
                                    unselectedTextColor = MaterialTheme.colorScheme.onSurface
                                ),
                                modifier = Modifier.padding(vertical = 2.dp)
                            )
                        }
                    }

                    item {
                        Spacer(modifier = Modifier.height(24.dp))
                    }
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = currentScreen.title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "VedaNova AI Core • ${session.currentUser.role}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = { coroutineScope.launch { drawerState.open() } }) {
                            Icon(Icons.Default.Menu, contentDescription = "Open Navigation Menu", tint = SaffronPrimary)
                        }
                    },
                    actions = {
                        // Switcher button between Admin Dashboard and Public Dharma App
                        if (currentScreen == ScreenDestination.PUBLIC_APP) {
                            FilledTonalButton(
                                onClick = { viewModel.navigateTo(ScreenDestination.DASHBOARD) },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.Dashboard, contentDescription = null, tint = SaffronPrimary, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Admin Center", color = SaffronPrimary, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            }
                        } else {
                            FilledTonalButton(
                                onClick = { viewModel.navigateTo(ScreenDestination.PUBLIC_APP) },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = SaffronPrimary, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Dharma App", color = SaffronPrimary, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            }
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            },
            containerColor = MaterialTheme.colorScheme.background
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                when (currentScreen) {
                    ScreenDestination.DASHBOARD -> DashboardScreen(viewModel)
                    ScreenDestination.EXTERNAL_APPS_MONITOR -> ExternalAppsMonitorScreen(viewModel)
                    ScreenDestination.CAPABILITY_APPROVAL -> CapabilityApprovalScreen(viewModel)
                    ScreenDestination.DAILY_DATA_MONITOR -> DailyDataEngineScreen(viewModel)
                    ScreenDestination.EXTERNAL_APP_SIMULATOR -> ExternalAppSimulatorScreen(viewModel)
                    ScreenDestination.AI_TESTING_LAB -> AiTestingLabScreen(viewModel)
                    ScreenDestination.API_CENTER -> ApiCenterScreen(viewModel)
                    ScreenDestination.API_TESTING -> ApiTestingScreen(viewModel)
                    ScreenDestination.EXTERNAL_TEST_CLIENT -> ExternalTestClientScreen(viewModel)
                    ScreenDestination.KNOWLEDGE_CENTER -> KnowledgeCenterScreen(viewModel)
                    ScreenDestination.RESEARCH_CENTER -> ResearchCenterScreen(viewModel)
                    ScreenDestination.TEACH_AI -> TeachAiScreen(viewModel)
                    ScreenDestination.PROBLEM_CENTER -> ProblemCenterScreen(viewModel)
                    ScreenDestination.REPORTS -> ReportCenterScreen(viewModel)
                    ScreenDestination.DATABASE_CENTER, ScreenDestination.BACKUPS -> DatabaseCenterScreen(viewModel)
                    ScreenDestination.USERS -> UsersCenterScreen(viewModel)
                    ScreenDestination.ANALYTICS -> AnalyticsScreen(viewModel)
                    ScreenDestination.LOGS -> LogsScreen(viewModel)
                    ScreenDestination.AUDIT_LOGS -> AuditLogScreen(viewModel)
                    ScreenDestination.SYSTEM_HEALTH -> SystemHealthScreen(viewModel)
                    ScreenDestination.SECURITY -> SecurityCenterScreen(viewModel)
                    ScreenDestination.SETTINGS -> SettingsScreen(viewModel)
                    ScreenDestination.FUNCTION_MAP -> AdminFunctionMapScreen(viewModel)
                    ScreenDestination.CRASH_REPORTS -> CrashDiagnosticCenterScreen(viewModel)
                    ScreenDestination.PUBLIC_APP -> PublicAppScreen(viewModel)
                }
            }
        }
    }
}
