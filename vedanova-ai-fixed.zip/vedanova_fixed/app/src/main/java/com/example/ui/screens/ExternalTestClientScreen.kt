package com.example.ui.screens

import androidx.compose.animation.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForward
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.viewmodel.VedaNovaViewModel

@Composable
fun ExternalTestClientScreen(
    viewModel: VedaNovaViewModel,
    modifier: Modifier = Modifier
) {
    val state by viewModel.externalClientState.collectAsState()
    val activeKeys by viewModel.allApiKeys.collectAsState()
    val clipboardManager = LocalClipboardManager.current
    var expandedResultIndex by remember { mutableStateOf<Int?>(null) }
    var showKeySelector by remember { mutableStateOf(false) }

    val presetUrls = listOf(
        "https://ais-dev-v2q3z47ktmramt3bwyb577-234096854893.asia-southeast1.run.app",
        "https://api.vedanova.ai",
        "https://in-app-gateway.local"
    )

    LazyColumn(
        modifier = modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Header Banner
        item {
            Card(
                colors = CardDefaults.cardColors(
                    containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f)
                ),
                shape = RoundedCornerShape(16.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = MaterialTheme.colorScheme.primary,
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    Icons.Default.CloudQueue,
                                    contentDescription = "Cloud API",
                                    tint = MaterialTheme.colorScheme.onPrimary
                                )
                            }
                        }
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                "External Android App — Test Client",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                "Testing remote HTTPS connection, Granular Scopes, Rate Limiting & E2E Handshake",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // 2. Connection Settings (Base URL & API Key)
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Text(
                        "1. Cloud Connection Configuration",
                        style = MaterialTheme.typography.labelLarge,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.primary
                    )

                    // Target Base URL
                    OutlinedTextField(
                        value = state.baseUrl,
                        onValueChange = { viewModel.setExternalBaseUrl(it) },
                        label = { Text("Cloud API Base URL (HTTPS)") },
                        leadingIcon = { Icon(Icons.Default.Link, contentDescription = null) },
                        singleLine = true,
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Preset Chips
                    Row(
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        presetUrls.forEach { url ->
                            val label = when {
                                url.contains("run.app") -> "Cloud Run (HTTPS)"
                                url.contains("api.vedanova") -> "Production URL"
                                else -> "Local Gateway"
                            }
                            FilterChip(
                                selected = state.baseUrl == url,
                                onClick = { viewModel.setExternalBaseUrl(url) },
                                label = { Text(label, fontSize = 11.sp) },
                                leadingIcon = {
                                    if (state.baseUrl == url) {
                                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                                    }
                                }
                            )
                        }
                    }

                    // API Key Selector & Input
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        OutlinedTextField(
                            value = state.apiKey,
                            onValueChange = { viewModel.setExternalApiKey(it) },
                            label = { Text("Client API Key (Bearer)") },
                            leadingIcon = { Icon(Icons.Default.Key, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier.weight(1f)
                        )

                        FilledTonalButton(
                            onClick = { showKeySelector = !showKeySelector },
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Icon(Icons.Default.List, contentDescription = null)
                            Spacer(Modifier.width(4.dp))
                            Text("Pick Key")
                        }
                    }

                    if (showKeySelector) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                                Text("Select Active API Key:", style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                                activeKeys.forEach { key ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .clip(RoundedCornerShape(8.dp))
                                            .background(
                                                if (state.apiKey == key.apiKey) MaterialTheme.colorScheme.primaryContainer else Color.Transparent
                                            )
                                            .clickable {
                                                viewModel.setExternalApiKey(key.apiKey)
                                                showKeySelector = false
                                            }
                                            .padding(horizontal = 8.dp, vertical = 6.dp),
                                        horizontalArrangement = Arrangement.SpaceBetween,
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Column {
                                            Text(key.name, fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                                            Text("${key.appName} • ${key.permissions}", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        }
                                        AssistChip(
                                            onClick = {
                                                viewModel.setExternalApiKey(key.apiKey)
                                                showKeySelector = false
                                            },
                                            label = { Text(key.status, fontSize = 10.sp) }
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }

        // 3. Tab Bar (Automated Suite vs Manual Playground)
        item {
            TabRow(
                selectedTabIndex = state.activeTab,
                containerColor = MaterialTheme.colorScheme.surface,
                modifier = Modifier.clip(RoundedCornerShape(12.dp))
            ) {
                Tab(
                    selected = state.activeTab == 0,
                    onClick = { viewModel.setExternalActiveTab(0) },
                    text = { Text("12-Point Automated Suite", fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.FactCheck, contentDescription = null) }
                )
                Tab(
                    selected = state.activeTab == 1,
                    onClick = { viewModel.setExternalActiveTab(1) },
                    text = { Text("Manual HTTP Playground", fontWeight = FontWeight.Bold) },
                    icon = { Icon(Icons.Default.Terminal, contentDescription = null) }
                )
            }
        }

        // TAB 0: 12-Point Automated Test Suite
        if (state.activeTab == 0) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    "E2E Integration Test Suite",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold
                                )
                                Text(
                                    "12 test vectors validating Authentication, AI Brain, Scopes & Rate Limiting",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        // Run Full Test Suite Button
                        Button(
                            onClick = { viewModel.runExternalFullTestSuite() },
                            enabled = !state.isRunningSuite,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            if (state.isRunningSuite) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    strokeWidth = 2.dp
                                )
                                Spacer(Modifier.width(8.dp))
                                Text("Running Tests (${(state.suiteProgress * 100).toInt()}%)...")
                            } else {
                                Icon(Icons.Default.PlayArrow, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text("Run Full 12-Point Test Suite")
                            }
                        }

                        if (state.isRunningSuite) {
                            LinearProgressIndicator(
                                progress = { state.suiteProgress },
                                modifier = Modifier.fillMaxWidth().height(6.dp).clip(RoundedCornerShape(3.dp))
                            )
                        }

                        // Summary Metric Chips if results exist
                        if (state.testResults.isNotEmpty()) {
                            val total = state.testResults.size
                            val passed = state.testResults.count { it.isSuccess }
                            val failed = total - passed
                            val avgLatency = state.testResults.map { it.latencyMs }.average().toLong()

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Total Tests", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text("$total / 28", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    }
                                }
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = Color(0xFF1B5E20).copy(alpha = 0.15f)),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Passed", fontSize = 11.sp, color = Color(0xFF2E7D32))
                                        Text("$passed", fontWeight = FontWeight.Bold, fontSize = 15.sp, color = Color(0xFF2E7D32))
                                    }
                                }
                                Card(
                                    colors = CardDefaults.cardColors(
                                        containerColor = if (failed > 0) MaterialTheme.colorScheme.errorContainer else MaterialTheme.colorScheme.surfaceVariant
                                    ),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Failed", fontSize = 11.sp)
                                        Text("$failed", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    }
                                }
                                Card(
                                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                    modifier = Modifier.weight(1f)
                                ) {
                                    Column(modifier = Modifier.padding(8.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                                        Text("Avg Latency", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                        Text("${avgLatency}ms", fontWeight = FontWeight.Bold, fontSize = 15.sp)
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Results List
            items(state.testResults) { result ->
                val index = state.testResults.indexOf(result)
                val isExpanded = expandedResultIndex == index

                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { expandedResultIndex = if (isExpanded) null else index },
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(10.dp),
                                modifier = Modifier.weight(1f)
                            ) {
                                Surface(
                                    shape = CircleShape,
                                    color = if (result.isSuccess) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error,
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Icon(
                                            if (result.isSuccess) Icons.Default.Check else Icons.Default.Close,
                                            contentDescription = null,
                                            tint = Color.White,
                                            modifier = Modifier.size(16.dp)
                                        )
                                    }
                                }
                                Column {
                                    Text(result.testName, fontWeight = FontWeight.Bold, fontSize = 13.sp)
                                    Text(
                                        "${result.method} ${result.endpoint} • ${result.latencyMs}ms",
                                        fontSize = 11.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                Surface(
                                    shape = RoundedCornerShape(6.dp),
                                    color = if (result.isSuccess) Color(0xFF1B5E20).copy(alpha = 0.15f) else MaterialTheme.colorScheme.errorContainer
                                ) {
                                    Text(
                                        "${result.httpStatusCode}",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                        color = if (result.isSuccess) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error
                                    )
                                }
                                Icon(
                                    if (isExpanded) Icons.Default.KeyboardArrowUp else Icons.Default.KeyboardArrowDown,
                                    contentDescription = "Expand",
                                    tint = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        AnimatedVisibility(visible = isExpanded) {
                            Column(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(top = 10.dp),
                                verticalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Divider()
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        "Request ID: ${result.requestId ?: "N/A"}",
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        color = MaterialTheme.colorScheme.primary
                                    )
                                    TextButton(
                                        onClick = { clipboardManager.setText(AnnotatedString(result.responseBody)) },
                                        contentPadding = PaddingValues(0.dp)
                                    ) {
                                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("Copy JSON", fontSize = 11.sp)
                                    }
                                }

                                Surface(
                                    shape = RoundedCornerShape(8.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = result.responseBody.take(600) + if (result.responseBody.length > 600) "..." else "",
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        modifier = Modifier.padding(10.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        // TAB 1: Manual HTTP Playground
        if (state.activeTab == 1) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier.padding(16.dp),
                        verticalArrangement = Arrangement.spacedBy(14.dp)
                    ) {
                        Text(
                            "Manual Request Playground",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )

                        // Endpoint Selector
                        val endpoints = listOf(
                            "/api/v1/chat",
                            "/api/v1/research",
                            "/api/v1/knowledge/search",
                            "/api/v1/mantra/search",
                            "/api/v1/scripture/search",
                            "/api/v1/verify",
                            "/api/v1/status"
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (state.playgroundMethod == "POST") MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.secondaryContainer
                            ) {
                                Text(
                                    state.playgroundMethod,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 12.sp,
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                )
                            }
                            Text(
                                state.playgroundEndpoint,
                                fontWeight = FontWeight.SemiBold,
                                fontSize = 13.sp,
                                fontFamily = FontFamily.Monospace,
                                modifier = Modifier.weight(1f)
                            )
                        }

                        // Endpoint Quick-Select Chips
                        ScrollableTabRow(
                            selectedTabIndex = endpoints.indexOf(state.playgroundEndpoint).coerceAtLeast(0),
                            edgePadding = 0.dp,
                            containerColor = Color.Transparent
                        ) {
                            endpoints.forEach { ep ->
                                Tab(
                                    selected = state.playgroundEndpoint == ep,
                                    onClick = { viewModel.setExternalPlaygroundEndpoint(ep) },
                                    text = { Text(ep.removePrefix("/api/v1/"), fontSize = 11.sp) }
                                )
                            }
                        }

                        // Request Body
                        if (state.playgroundMethod == "POST") {
                            OutlinedTextField(
                                value = state.playgroundBody,
                                onValueChange = { viewModel.setExternalPlaygroundBody(it) },
                                label = { Text("Request Body (JSON)") },
                                minLines = 4,
                                maxLines = 8,
                                textStyle = androidx.compose.ui.text.TextStyle(
                                    fontFamily = FontFamily.Monospace,
                                    fontSize = 12.sp
                                ),
                                modifier = Modifier.fillMaxWidth()
                            )
                        }

                        // Send Button
                        Button(
                            onClick = { viewModel.executeExternalPlaygroundRequest() },
                            enabled = !state.isPlaygroundLoading,
                            shape = RoundedCornerShape(12.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            if (state.isPlaygroundLoading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(18.dp),
                                    color = MaterialTheme.colorScheme.onPrimary,
                                    strokeWidth = 2.dp
                                )
                                Spacer(Modifier.width(8.dp))
                                Text("Executing HTTPS Call...")
                            } else {
                                Icon(Icons.AutoMirrored.Filled.ArrowForward, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text("Send HTTPS Request")
                            }
                        }

                        // Response Display
                        state.playgroundResponse?.let { resp ->
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Divider()
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp), verticalAlignment = Alignment.CenterVertically) {
                                        Surface(
                                            shape = RoundedCornerShape(6.dp),
                                            color = if (resp.statusCode in 200..299) Color(0xFF1B5E20).copy(alpha = 0.15f) else MaterialTheme.colorScheme.errorContainer
                                        ) {
                                            Text(
                                                "${resp.statusCode} ${resp.statusText}",
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 12.sp,
                                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                                color = if (resp.statusCode in 200..299) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error
                                            )
                                        }
                                        Text(
                                            "${resp.responseTimeMs} ms",
                                            fontSize = 12.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }

                                    TextButton(
                                        onClick = { clipboardManager.setText(AnnotatedString(resp.jsonBody)) }
                                    ) {
                                        Icon(Icons.Default.ContentCopy, contentDescription = null, modifier = Modifier.size(14.dp))
                                        Spacer(Modifier.width(4.dp))
                                        Text("Copy", fontSize = 11.sp)
                                    }
                                }

                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.6f),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = resp.jsonBody,
                                        fontSize = 11.sp,
                                        fontFamily = FontFamily.Monospace,
                                        modifier = Modifier.padding(12.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
