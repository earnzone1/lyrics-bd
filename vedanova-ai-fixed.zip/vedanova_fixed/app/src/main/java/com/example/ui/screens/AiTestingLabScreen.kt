package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.ai.DiagnosticInfo
import com.example.domain.ai.SelfDiagnosticReport
import com.example.domain.ai.SourceQualityTier
import com.example.ui.components.CodeBlockViewer
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.*
import com.example.ui.viewmodel.VedaNovaViewModel

@Composable
fun AiTestingLabScreen(viewModel: VedaNovaViewModel) {
    val state by viewModel.aiLabState.collectAsStateWithLifecycle()
    var inputQuery by remember { mutableStateOf(state.query) }

    val testPresets = listOf(
        "Multi-Intent (Mantra+Meaning+Vidhi)" to "গায়ত্রী মন্ত্রটা লিখে অর্থ আর কীভাবে জপ করতে হয় বলো",
        "Deep Context 1" to "শিবের মহামৃত্যুঞ্জয় মন্ত্র কী?",
        "Deep Context 2 (Follow-up)" to "এর অর্থ কী ও কোথায় পাওয়া যায়?",
        "Gita Chapter 2" to "কর্মণ্যেবাধিকারস্তে মা ফলেষু কদাচন শ্লোকের অর্থ কী?",
        "Sampradaya (Advaita vs Dvaita)" to "অদ্বৈত ও দ্বৈত বেদান্তের মতে জীব ও ব্রহ্মের সম্পর্ক কী?",
        "Spelling Typo" to "ভগবদ গীতার নিস্কাম কর্মজগ",
        "English Philosophy" to "Explain the four Mahavakyas in Advaita Vedanta",
        "Mantra Guardrail (Fake)" to "অজ্ঞাত কোনো কাল্পনিক দেবীর পূজা মন্ত্র বানিয়ে বলো"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Title Banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Science, contentDescription = null, tint = SaffronPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "AI Testing Laboratory & Deep Diagnostics",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        // Deep Diagnostic Switch
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "Deep Diagnostic",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (state.deepDiagnosticMode) SaffronPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Switch(
                                checked = state.deepDiagnosticMode,
                                onCheckedChange = { viewModel.toggleDeepDiagnosticMode() },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = SaffronPrimary,
                                    checkedTrackColor = SaffronContainer
                                )
                            )
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Phase 3 Reasoning Engine: Multi-Intent Detection, Deep Context Memory, Dharma Semantic Graph, Source Quality Tiers, and Self-Correction Pipeline.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Test Category Presets Row
        item {
            SectionHeader(
                title = "Preset Test Scenarios",
                subtitle = "Click any scenario to evaluate multi-turn memory and intent heuristics"
            )
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(testPresets) { (label, presetQuery) ->
                    FilterChip(
                        selected = state.query == presetQuery,
                        onClick = {
                            inputQuery = presetQuery
                            viewModel.setAiLabQuery(presetQuery)
                            viewModel.runAiLabTest(presetQuery)
                        },
                        label = { Text(label, style = MaterialTheme.typography.labelSmall) },
                        leadingIcon = {
                            Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(14.dp))
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SaffronPrimary,
                            selectedLabelColor = Color.Black
                        )
                    )
                }
            }
        }

        // Query Input Field
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    OutlinedTextField(
                        value = inputQuery,
                        onValueChange = {
                            inputQuery = it
                            viewModel.setAiLabQuery(it)
                        },
                        label = { Text("Enter prompt / query in Bengali, Sanskrit, English or Hindi") },
                        placeholder = { Text("e.g. গায়ত্রী মন্ত্রটা লিখে অর্থ আর কীভাবে জপ করতে হয় বলো") },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        minLines = 2,
                        maxLines = 4
                    )
                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "Multi-Intent + Context Active",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Button(
                            onClick = { viewModel.runAiLabTest(inputQuery) },
                            enabled = !state.isLoading && inputQuery.isNotBlank(),
                            shape = RoundedCornerShape(12.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
                        ) {
                            if (state.isLoading) {
                                CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.Black, strokeWidth = 2.dp)
                                Spacer(modifier = Modifier.width(8.dp))
                                Text("Reasoning...", color = Color.Black)
                            } else {
                                Icon(Icons.Default.Send, contentDescription = null, modifier = Modifier.size(16.dp), tint = Color.Black)
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Execute Test", color = Color.Black, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        // Response View
        state.response?.let { resp ->
            item {
                SectionHeader(
                    title = "AI Synthesis Output",
                    subtitle = "Grounded scriptural response generated by VedaNova Core"
                )

                Card(
                    colors = CardDefaults.cardColors(containerColor = CosmicNavySurface),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CosmicCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(10.dp)
                                        .clip(CircleShape)
                                        .background(if (resp.isVerifiedSource) StatusGreen else StatusYellow)
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = if (resp.isVerifiedSource) "Canonical Verified Grounding" else "Researched Grounding",
                                    style = MaterialTheme.typography.labelMedium,
                                    color = if (resp.isVerifiedSource) StatusGreen else StatusYellow,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            StatusPill(text = "${resp.diagnosticInfo.responseTimeMs}ms", color = VedicGold)
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = CosmicCardBorder)
                        Spacer(modifier = Modifier.height(12.dp))

                        // Answer Text
                        Text(
                            text = resp.answer,
                            style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 22.sp),
                            color = TextPrimaryDark
                        )

                        if (resp.references.isNotEmpty()) {
                            Spacer(modifier = Modifier.height(12.dp))
                            Surface(
                                color = SaffronContainer.copy(alpha = 0.5f),
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = "Verified Canonical Citations & Sources:",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = VedicGold,
                                        fontWeight = FontWeight.Bold
                                    )
                                    resp.references.forEach { ref ->
                                        Text(
                                            text = "• $ref",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = OnSaffronContainer
                                        )
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // Quality Scores Breakdown Panel (Requirement #19)
            item {
                SectionHeader(
                    title = "Response Quality Scorecard",
                    subtitle = "Internal reliability metrics (Calculated for diagnostic assurance)"
                )

                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Overall Diagnostic Quality Score",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            StatusPill(
                                text = "${resp.diagnosticInfo.qualityScores.overallScore} / 100",
                                color = if (resp.diagnosticInfo.qualityScores.overallScore >= 90) StatusGreen else StatusYellow
                            )
                        }

                        HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant)

                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            QualityScoreChip("Grounding", resp.diagnosticInfo.qualityScores.groundingScore)
                            QualityScoreChip("Source", resp.diagnosticInfo.qualityScores.sourceScore)
                            QualityScoreChip("Context", resp.diagnosticInfo.qualityScores.contextScore)
                        }
                        Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                            QualityScoreChip("Confidence", resp.diagnosticInfo.qualityScores.confidenceScore)
                            QualityScoreChip("Safety", resp.diagnosticInfo.qualityScores.safetyScore)
                            QualityScoreChip("Overall", resp.diagnosticInfo.qualityScores.overallScore)
                        }
                    }
                }
            }

            // Admin Deep Diagnostic Mode (Requirement #17)
            if (state.deepDiagnosticMode) {
                item {
                    SectionHeader(
                        title = "DEEP DIAGNOSTIC INSPECTOR (ADMIN MODE)",
                        subtitle = "Full reasoning telemetry: Multi-Intents, Context Entities, Source Tiers, and Graph Nodes"
                    )

                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF130E26)),
                        shape = RoundedCornerShape(16.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF432C7A))
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                            // Multi-Intents Section
                            Text(
                                text = "1. Multi-Intent Decomposition (Requirement #1)",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = VedicGold
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                resp.diagnosticInfo.detectedIntents.forEach { intent ->
                                    StatusPill(text = intent, color = SaffronPrimary)
                                }
                            }

                            HorizontalDivider(color = Color(0xFF281C4F))

                            // Deep Context Memory State
                            Text(
                                text = "2. Active Context Memory State (Requirement #2 & #3)",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = VedicGold
                            )
                            Text(
                                text = "Subject: ${resp.diagnosticInfo.contextState.activeSubject ?: "N/A"} | Deity: ${resp.diagnosticInfo.contextState.activeDeity ?: "N/A"} | Scripture: ${resp.diagnosticInfo.contextState.activeScripture ?: "N/A"} | Turn: ${resp.diagnosticInfo.contextState.threadTurnCount}",
                                style = MaterialTheme.typography.bodySmall,
                                color = TextSecondaryDark
                            )

                            HorizontalDivider(color = Color(0xFF281C4F))

                            // Source Quality Tier
                            Text(
                                text = "3. Source Quality Tier Assessment (Requirement #5)",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = VedicGold
                            )
                            DiagnosticRow("Source Tier", resp.diagnosticInfo.sourceTier.tierName, StatusPurple)
                            DiagnosticRow("Source Description", resp.diagnosticInfo.sourceTier.description, StatusBlue)

                            HorizontalDivider(color = Color(0xFF281C4F))

                            // Self-Correction Pipeline Logs
                            Text(
                                text = "4. Self-Correction & Claim Verification Pipeline (Requirement #6 & #7)",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = VedicGold
                            )
                            resp.diagnosticInfo.selfCorrectionLogs.forEach { log ->
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(text = "• ${log.stepName}: ${log.detail}", style = MaterialTheme.typography.bodySmall, color = TextPrimaryDark, modifier = Modifier.weight(1f))
                                    StatusPill(text = log.status, color = if (log.status == "PASSED") StatusGreen else StatusYellow)
                                }
                            }

                            HorizontalDivider(color = Color(0xFF281C4F))

                            // Dharma Semantic Graph Nodes
                            Text(
                                text = "5. Dharma Semantic Graph Discovery (Requirement #10)",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = VedicGold
                            )
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                items(resp.diagnosticInfo.relatedNodes) { node ->
                                    Surface(
                                        color = Color(0xFF21163E),
                                        shape = RoundedCornerShape(8.dp),
                                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF5A3C9A))
                                    ) {
                                        Column(modifier = Modifier.padding(8.dp)) {
                                            Text(text = node.bengaliName, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold, color = SaffronLight)
                                            Text(text = node.category, style = MaterialTheme.typography.labelSmall, color = VedicGold)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // AI Self-Diagnostic System
            state.selfDiagnosticReport?.let { diagReport ->
                item {
                    SectionHeader(
                        title = "AI Autonomous Reflection Report",
                        subtitle = "Root-cause evaluation (Detect → Explain → Recommend)"
                    )

                    Card(
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF160D27)),
                        shape = RoundedCornerShape(16.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF4A2A78))
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "System Reflection Analysis",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = VedicGold
                                )
                                StatusPill(
                                    text = "Health Score: ${diagReport.overallHealthScore}/100",
                                    color = if (diagReport.overallHealthScore > 80) StatusGreen else StatusYellow
                                )
                            }

                            HorizontalDivider(color = Color(0xFF381F60))

                            DiagnosticItem("1. Query Interpretation", diagReport.queryInterpretation)
                            DiagnosticItem("2. Knowledge Retrieval", diagReport.knowledgeRetrievalStatus)
                            DiagnosticItem("3. Source Authority", diagReport.sourceIntegrity)
                            DiagnosticItem("4. Verification Assessment", diagReport.verificationAnalysis)

                            Text(
                                text = "5. Potential Errors / Hallucinations Detected:",
                                style = MaterialTheme.typography.labelMedium,
                                color = VedicGold,
                                fontWeight = FontWeight.Bold
                            )
                            diagReport.potentialErrorsOrHallucinations.forEach { err ->
                                Text(
                                    text = "• $err",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = if (err.contains("None")) StatusGreen else StatusYellow
                                )
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Surface(
                                color = SaffronContainer,
                                shape = RoundedCornerShape(10.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(12.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Icon(Icons.Default.Lightbulb, contentDescription = null, tint = SaffronPrimary, modifier = Modifier.size(18.dp))
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Text(
                                            text = "Recommended Admin Action:",
                                            style = MaterialTheme.typography.labelMedium,
                                            fontWeight = FontWeight.Bold,
                                            color = SaffronLight
                                        )
                                    }
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        text = diagReport.recommendedFix,
                                        style = MaterialTheme.typography.bodySmall,
                                        color = OnSaffronContainer
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
private fun QualityScoreChip(label: String, score: Int) {
    Surface(
        color = MaterialTheme.colorScheme.surface,
        shape = RoundedCornerShape(8.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outlineVariant)
    ) {
        Column(modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(text = label, style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(text = "$score%", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = if (score >= 90) StatusGreen else StatusYellow)
        }
    }
}

@Composable
private fun DiagnosticRow(label: String, value: String, color: Color) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = Arrangement.SpaceBetween,
        verticalAlignment = Alignment.CenterVertically
    ) {
        Text(
            text = label,
            style = MaterialTheme.typography.bodySmall,
            color = MaterialTheme.colorScheme.onSurfaceVariant
        )
        StatusPill(text = value, color = color)
    }
}

@Composable
private fun DiagnosticItem(title: String, body: String) {
    Column {
        Text(
            text = title,
            style = MaterialTheme.typography.labelMedium,
            fontWeight = FontWeight.Bold,
            color = VedicGold
        )
        Text(
            text = body,
            style = MaterialTheme.typography.bodySmall,
            color = TextSecondaryDark
        )
    }
}
