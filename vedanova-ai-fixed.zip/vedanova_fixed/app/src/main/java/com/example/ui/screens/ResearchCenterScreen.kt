package com.example.ui.screens

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.KnowledgeCandidateEntity
import com.example.data.model.ResearchActivityLogEntity
import com.example.data.model.ResearchIssueEntity
import com.example.domain.research.CrossSourceVerificationReport
import com.example.domain.research.MantraVerificationShieldResult
import com.example.domain.research.TopicScanResult
import com.example.domain.research.WebResearchResult
import com.example.domain.research.YouTubeResearchResult
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.SaffronPrimary
import com.example.ui.theme.StatusGreen
import com.example.ui.theme.StatusRed
import com.example.ui.theme.StatusYellow
import com.example.ui.theme.VedicGold
import com.example.ui.viewmodel.ResearchLabState
import com.example.ui.viewmodel.VedaNovaViewModel

@Composable
fun ResearchCenterScreen(viewModel: VedaNovaViewModel) {
    val labState by viewModel.researchLabState.collectAsState()
    val pendingCandidates by viewModel.pendingCandidates.collectAsState()
    val pendingCandidatesCount by viewModel.pendingCandidatesCount.collectAsState()
    val openIssues by viewModel.openResearchIssues.collectAsState()
    val openIssuesCount by viewModel.openResearchIssuesCount.collectAsState()
    val recentActivityLogs by viewModel.recentResearchActivityLogs.collectAsState()

    val tabs = listOf(
        "🔬 Web & Video Lab",
        "🛡️ Mantra Shield",
        "🧭 Discovery Engine",
        "📜 Candidates ($pendingCandidatesCount)",
        "⚠️ Issues ($openIssuesCount)",
        "📋 Activity Log"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            SectionHeader(
                title = "Web Research & Knowledge Harvesting Engine",
                subtitle = "Phase 6 — Multi-Tier Source Verification, Mantra Shield & Canonical Knowledge Ingestion"
            )
        }

        // Top Navigation Tabs
        item {
            ScrollableTabRow(
                selectedTabIndex = labState.activeTab,
                containerColor = MaterialTheme.colorScheme.surface,
                contentColor = SaffronPrimary,
                edgePadding = 0.dp
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = labState.activeTab == index,
                        onClick = { viewModel.setResearchTab(index) },
                        text = {
                            Text(
                                text = title,
                                fontWeight = if (labState.activeTab == index) FontWeight.Bold else FontWeight.Normal,
                                color = if (labState.activeTab == index) SaffronPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    )
                }
            }
        }

        when (labState.activeTab) {
            0 -> {
                // TAB 0: Web & YouTube Research Engine
                item {
                    WebResearchLabTab(
                        labState = labState,
                        onQueryChange = { viewModel.updateResearchQuery(it) },
                        onExecuteSearch = { viewModel.executeResearchLabSearch() }
                    )
                }
            }
            1 -> {
                // TAB 1: Mantra Verification Shield
                item {
                    MantraShieldTab(
                        labState = labState,
                        onQueryChange = { viewModel.updateResearchQuery(it) },
                        onVerifyMantra = { viewModel.executeMantraShieldVerification() }
                    )
                }
            }
            2 -> {
                // TAB 2: Dharma Topic Discovery Engine
                item {
                    DiscoveryEngineTab(
                        labState = labState,
                        onToggleCategory = { viewModel.toggleDiscoveryCategory(it) },
                        onRunDiscovery = { viewModel.runTopicDiscoveryScan() }
                    )
                }
            }
            3 -> {
                // TAB 3: Knowledge Candidates Approval Center
                item {
                    CandidateApprovalsTab(
                        candidates = pendingCandidates,
                        onApprove = { viewModel.approveResearchCandidate(it) },
                        onReject = { viewModel.rejectResearchCandidate(it) }
                    )
                }
            }
            4 -> {
                // TAB 4: Research Issue Review Center
                item {
                    ResearchIssuesTab(
                        issues = openIssues,
                        onResolve = { id, status, notes -> viewModel.resolveResearchIssue(id, status, notes) }
                    )
                }
            }
            5 -> {
                // TAB 5: Research Activity Log
                item {
                    ResearchActivityLogsTab(logs = recentActivityLogs)
                }
            }
        }
    }
}

@Composable
fun WebResearchLabTab(
    labState: ResearchLabState,
    onQueryChange: (String) -> Unit,
    onExecuteSearch: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "🔍 Deep Dharma Scholarly Web & Audio/Video Search",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = VedicGold
                )
                Text(
                    text = "VedaNova systematically searches Tier 1 canonical scriptures, Tier 2 academic commentaries, and authoritative video archives with zero fabrication.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = labState.query,
                    onValueChange = onQueryChange,
                    label = { Text("Enter Dharma Topic, Verse or Mantra") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp),
                    trailingIcon = {
                        if (labState.isLoading) {
                            CircularProgressIndicator(modifier = Modifier.size(24.dp), strokeWidth = 2.dp, color = SaffronPrimary)
                        } else {
                            IconButton(onClick = onExecuteSearch) {
                                Icon(Icons.Default.Search, contentDescription = "Search", tint = SaffronPrimary)
                            }
                        }
                    }
                )

                // Quick Preset Chips
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    listOf(
                        "গায়ত্রী মহামন্ত্র",
                        "মহামৃত্যুঞ্জয় মন্ত্র",
                        "গীতার কর্মযোগ",
                        "ভাগবতের চতুষশ্লোকী"
                    ).forEach { preset ->
                        AssistChip(
                            onClick = {
                                onQueryChange(preset)
                                onExecuteSearch()
                            },
                            label = { Text(preset, fontSize = 11.sp) }
                        )
                    }
                }

                Button(
                    onClick = onExecuteSearch,
                    enabled = !labState.isLoading && labState.query.isNotBlank(),
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.ManageSearch, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Execute Multi-Source Research & Cross-Verification", fontWeight = FontWeight.Bold)
                }
            }
        }

        // Results Section
        val web = labState.webResult
        if (web != null) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, SaffronPrimary.copy(alpha = 0.5f))
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "📜 Verified Canonical Result",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = SaffronPrimary
                        )
                        StatusPill(
                            text = if (web.canonicalScriptureFound) "TIER 1 CANONICAL" else "RESEARCH GROUNDED",
                            color = if (web.canonicalScriptureFound) StatusGreen else VedicGold
                        )
                    }

                    if (web.primaryScripture != null) {
                        Text(
                            text = "উৎস শাস্ত্র: ${web.primaryScripture} • ${web.primaryReference ?: ""}",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = VedicGold
                        )
                    }

                    if (!web.primarySanskritText.isNullOrBlank()) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, SaffronPrimary.copy(alpha = 0.4f))
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Text(
                                    text = web.primarySanskritText,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = SaffronPrimary
                                )
                            }
                        }
                    }

                    if (!web.primaryBengaliMeaning.isNullOrBlank()) {
                        Text(
                            text = "অনুবাদ ও তাৎপর্য:\n${web.primaryBengaliMeaning}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }

        // Cross-Source Verification Report Card
        val cross = labState.crossVerificationReport
        if (cross != null) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Text(
                        text = "⚖️ Cross-Source Verification Consensus",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = VedicGold
                    )
                    Text(
                        text = cross.consensusConclusion,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        StatusPill(text = "Confidence: ${(cross.overallConfidence * 100).toInt()}%", color = StatusGreen)
                        StatusPill(text = "Tier 1: ${cross.verifiedTier1Count}", color = SaffronPrimary)
                        StatusPill(text = "Tier 2: ${cross.verifiedTier2Count}", color = VedicGold)
                        if (cross.hasConflict) {
                            StatusPill(text = "Conflict Noted", color = StatusYellow)
                        }
                    }
                }
            }
        }

        // Authoritative Web Sources
        val sources = labState.webResult?.sources
        if (!sources.isNullOrEmpty()) {
            Text(
                text = "📚 Evaluated Sources (${sources.size})",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            sources.forEach { src ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = src.title,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = SaffronPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            StatusPill(text = src.sourceTier, color = if (src.sourceTier == "TIER 1") StatusGreen else VedicGold)
                        }
                        Text(
                            text = "${src.domain} • ${src.author} (${src.publicationDate})",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = src.excerpt,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f)
                        )
                    }
                }
            }
        }

        // YouTube Video Evidence
        val videos = labState.youtubeResult?.videos
        if (!videos.isNullOrEmpty()) {
            Text(
                text = "🎥 Supporting Audio/Video Evidence (${videos.size})",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )
            videos.forEach { v ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Icon(Icons.Default.PlayCircle, contentDescription = null, tint = StatusRed, modifier = Modifier.size(36.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(text = v.title, style = MaterialTheme.typography.labelMedium, fontWeight = FontWeight.Bold)
                            Text(text = "${v.channel} • ${v.language}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        }
                        StatusPill(text = "${(v.relevanceScore * 100).toInt()}% Match", color = VedicGold)
                    }
                }
            }
        }
    }
}

@Composable
fun MantraShieldTab(
    labState: ResearchLabState,
    onQueryChange: (String) -> Unit,
    onVerifyMantra: () -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(text = "🛡️", fontSize = 24.sp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Mantra Verification Shield & Anti-Fabrication Engine",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SaffronPrimary
                    )
                }
                Text(
                    text = "Rigorous verification against the 10 Principal Upanishads, 4 Vedas, and Canonical Samhitas. Fabricated Sanskrit or unverified chants will be strictly blocked.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = labState.query,
                    onValueChange = onQueryChange,
                    label = { Text("Enter Mantra / Stotra for Authenticity Check") },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(10.dp)
                )

                Button(
                    onClick = onVerifyMantra,
                    enabled = !labState.isLoading && labState.query.isNotBlank(),
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    Icon(Icons.Default.Security, contentDescription = null)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Verify Mantra Canonical Authenticity", fontWeight = FontWeight.Bold)
                }
            }
        }

        val shield = labState.mantraShieldResult
        if (shield != null) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, if (shield.isVerified) StatusGreen else StatusYellow)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (shield.isVerified) "✅ Canonical Mantra Verified" else "⚠️ Unverified / Disputed Mantra",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = if (shield.isVerified) StatusGreen else StatusYellow
                        )
                        StatusPill(
                            text = if (shield.isVerified) "VERIFIED AUTHENTIC" else "ADMIN REVIEW REQUIRED",
                            color = if (shield.isVerified) StatusGreen else StatusRed
                        )
                    }

                    val mantra = shield.verifiedMantra
                    if (mantra != null) {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                            shape = RoundedCornerShape(8.dp),
                            border = BorderStroke(1.dp, SaffronPrimary.copy(alpha = 0.5f))
                        ) {
                            Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                                Text(
                                    text = mantra.sanskritDevanagari,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = SaffronPrimary
                                )
                                Text(
                                    text = mantra.iastTransliteration,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = VedicGold
                                )
                            }
                        }

                        Text(
                            text = "📜 উৎস শাস্ত্র: ${mantra.sourceScripture} (${mantra.chapter}, ${mantra.verse})",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "🏛️ ঐতিহ্য: ${mantra.tradition} • দেবতা: ${mantra.deity}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Text(
                            text = "অনুবাদ:\n${mantra.bengaliWordMeaning}",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "শাস্ত্রীয় নোট: ${mantra.verificationNotes}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (shield.refusalMessage != null) {
                        Text(
                            text = shield.refusalMessage,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun DiscoveryEngineTab(
    labState: ResearchLabState,
    onToggleCategory: (String) -> Unit,
    onRunDiscovery: () -> Unit
) {
    val availableCategories = listOf(
        "Vedic Mantras",
        "Upanishadic Mantras",
        "Gita Verses",
        "Shiva Mantras",
        "Vaishnava Philosophy",
        "Durga Saptashati",
        "Surya Upasana",
        "Advaita Philosophy"
    )

    Column(verticalArrangement = Arrangement.spacedBy(14.dp)) {
        Card(
            modifier = Modifier.fillMaxWidth(),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                Text(
                    text = "🧭 Automated Dharma Topic Discovery Scanner",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = VedicGold
                )
                Text(
                    text = "Select Dharma categories to scan. The discovery engine will perform scholarly web research, check against existing database nodes, avoid duplicate creation, and stage high-confidence candidates for admin review.",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Text(
                    text = "Target Categories for Ingestion:",
                    style = MaterialTheme.typography.labelMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )

                // Multi-select Category Chips
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    availableCategories.take(4).forEach { cat ->
                        val selected = labState.discoveryCategories.contains(cat)
                        FilterChip(
                            selected = selected,
                            onClick = { onToggleCategory(cat) },
                            label = { Text(cat, fontSize = 11.sp) }
                        )
                    }
                }
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    availableCategories.drop(4).forEach { cat ->
                        val selected = labState.discoveryCategories.contains(cat)
                        FilterChip(
                            selected = selected,
                            onClick = { onToggleCategory(cat) },
                            label = { Text(cat, fontSize = 11.sp) }
                        )
                    }
                }

                Button(
                    onClick = onRunDiscovery,
                    enabled = !labState.isScanningDiscovery,
                    modifier = Modifier.fillMaxWidth(),
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                    shape = RoundedCornerShape(8.dp)
                ) {
                    if (labState.isScanningDiscovery) {
                        CircularProgressIndicator(modifier = Modifier.size(20.dp), strokeWidth = 2.dp, color = Color.White)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Scanning Canonical Databases & Harvesting...")
                    } else {
                        Icon(Icons.Default.TravelExplore, contentDescription = null)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("Run Dharma Knowledge Discovery Scan", fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Scan Results
        if (labState.discoveryResults.isNotEmpty()) {
            Text(
                text = "📊 Scan Harvest Summary",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onSurface
            )

            labState.discoveryResults.forEach { result ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(8.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "🏷️ ${result.category}",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = SaffronPrimary
                            )
                            StatusPill(text = "Generated: ${result.candidateCountGenerated}", color = StatusGreen)
                        }
                        Text(
                            text = "Candidates Staged: ${result.candidateCountGenerated} • Existing Skipped: ${result.duplicatesSkipped}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "Scan Duration: ${result.durationMs}ms",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}

@Composable
fun CandidateApprovalsTab(
    candidates: List<KnowledgeCandidateEntity>,
    onApprove: (String) -> Unit,
    onReject: (String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (candidates.isEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.Verified, contentDescription = null, tint = StatusGreen, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("No Pending Knowledge Candidates", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("All researched knowledge has been approved and published.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        } else {
            candidates.forEach { c ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, SaffronPrimary.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = c.title,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = SaffronPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            StatusPill(text = c.sourceTier, color = VedicGold)
                        }

                        Text(
                            text = "উৎস: ${c.scripture} (${c.reference}) • ভাষা: ${c.language}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        if (c.sanskritText.isNotBlank()) {
                            Card(
                                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                                shape = RoundedCornerShape(6.dp)
                            ) {
                                Text(
                                    text = c.sanskritText,
                                    modifier = Modifier.padding(8.dp),
                                    style = MaterialTheme.typography.bodySmall,
                                    color = VedicGold,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                        }

                        Text(
                            text = c.answer,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            OutlinedButton(
                                onClick = { onReject(c.candidateId) },
                                shape = RoundedCornerShape(6.dp),
                                colors = ButtonDefaults.outlinedButtonColors(contentColor = StatusRed)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Reject")
                            }
                            Spacer(modifier = Modifier.width(8.dp))
                            Button(
                                onClick = { onApprove(c.candidateId) },
                                shape = RoundedCornerShape(6.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = StatusGreen)
                            ) {
                                Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("Approve & Publish", fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ResearchIssuesTab(
    issues: List<ResearchIssueEntity>,
    onResolve: (String, String, String) -> Unit
) {
    Column(verticalArrangement = Arrangement.spacedBy(12.dp)) {
        if (issues.isEmpty()) {
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Column(horizontalAlignment = Alignment.CenterHorizontally) {
                        Icon(Icons.Default.CheckCircle, contentDescription = null, tint = StatusGreen, modifier = Modifier.size(48.dp))
                        Spacer(modifier = Modifier.height(8.dp))
                        Text("Zero Open Research Issues", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold)
                        Text("All ambiguous queries and disputed citations have been cleared.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    }
                }
            }
        } else {
            issues.forEach { issue ->
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(10.dp),
                    border = BorderStroke(1.dp, StatusYellow.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = issue.userQuery,
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = SaffronPrimary,
                                modifier = Modifier.weight(1f)
                            )
                            StatusPill(text = issue.status, color = StatusYellow)
                        }

                        Text(
                            text = "Reason: ${issue.reason}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Text(
                            text = "Sources Found: ${issue.sourcesFound} • Verified: ${issue.sourcesVerified} • Conflict: ${issue.conflictDetected}",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Button(
                                onClick = { onResolve(issue.reportId, "RESOLVED", "Manually verified by Admin") },
                                shape = RoundedCornerShape(6.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
                            ) {
                                Text("Mark Resolved", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ResearchActivityLogsTab(logs: List<ResearchActivityLogEntity>) {
    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
        logs.forEach { log ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(8.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(4.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Text(
                            text = log.userQuery,
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = SaffronPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        StatusPill(
                            text = log.verificationResult,
                            color = if (log.verificationResult == "VERIFIED") StatusGreen else StatusYellow
                        )
                    }
                    Text(
                        text = "Providers: ${log.providersUsed} • Latency: ${log.durationMs}ms • Decision: ${log.finalDecision}",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }
    }
}
