package com.example.domain.research

import com.example.data.model.ResearchSourceEntity

data class SourceComparisonItem(
    val sourceName: String,
    val tier: String,
    val claimText: String,
    val scriptureCitation: String,
    val authorityRating: Float,
    val status: String
)

data class CrossSourceVerificationReport(
    val query: String,
    val sourcesComparedCount: Int,
    val hasConflict: Boolean,
    val conflictDescription: String?,
    val isMultiTraditionTopic: Boolean,
    val traditionNotes: String?,
    val overallConfidence: Float,
    val consensusConclusion: String,
    val comparisons: List<SourceComparisonItem>,
    val verifiedTier1Count: Int,
    val verifiedTier2Count: Int,
    val supportingTierCount: Int
)

object CrossSourceVerificationEngine {

    fun performCrossVerification(
        query: String,
        webSources: List<ResearchSourceEntity>,
        youtubeSources: List<ResearchSourceEntity> = emptyList()
    ): CrossSourceVerificationReport {
        val q = query.lowercase()
        val allSources = webSources + youtubeSources

        var hasConflict = false
        var conflictDesc: String? = null
        var isMultiTradition = false
        var traditionNotes: String? = null

        // Check for multi-tradition inquiries
        if (q.contains("অদ্বৈত") || q.contains("দ্বৈত") || q.contains("বিশিষ্টাদ্বৈত") ||
            q.contains("advaita") || q.contains("dvaita") || q.contains("মায়া") || q.contains("ভক্তি ও জ্ঞান")) {
            isMultiTradition = true
            traditionNotes = "এই দার্শনিক বিষয়ে সনাতন ধর্মের বিভিন্ন প্রধান সম্প্রদায় ও আচার্য ঐতিহ্যে (অদ্বৈত বেদান্ত, বিশিষ্টাদ্বৈত বেদান্ত ও দ্বৈত বেদান্ত) ভিন্ন ভিন্ন গভীর প্রামাণ্য ব্যাখ্যা রয়েছে।"
        } else if (q.contains("শিব") && q.contains("বিষ্ণু") && (q.contains("শ্রেষ্ঠ") || q.contains("পার্থক্য"))) {
            isMultiTradition = true
            traditionNotes = "শৈব ও বৈষ্ণব ঐতিহ্যে পরম সত্যের প্রকাশ ভিন্ন রূপ ও লীলায় অনুধাবন করা হয়। তবে বেদান্ত সিদ্ধান্ত অনুযায়ী শিব ও বিষ্ণু একই পরমব্রহ্মের দুই প্রকাশ।"
        }

        // Check for conflicting claims simulation / detection
        if (q.contains("বিতর্ক") || q.contains("দ্বন্দ্ব") || q.contains("conflict") || q.contains("ভুল পাঠ")) {
            hasConflict = true
            conflictDesc = "বিভিন্ন টীকা ও আঞ্চলিক পাণ্ডুলিপির মধ্যে পাঠান্তর বা অধ্যায় বিন্যাসে বৈসাদৃশ্য সনাক্ত হয়েছে।"
        }

        val comparisons = allSources.map { src ->
            SourceComparisonItem(
                sourceName = "${src.title} (${src.domain})",
                tier = src.sourceTier,
                claimText = src.excerpt.take(120),
                scriptureCitation = src.author + " / " + src.publicationDate,
                authorityRating = src.authorityScore,
                status = src.verificationStatus
            )
        }

        val tier1Count = allSources.count { it.sourceTier == "TIER 1" }
        val tier2Count = allSources.count { it.sourceTier == "TIER 2" }
        val supportingCount = allSources.count { it.sourceTier in listOf("TIER 3", "TIER 4", "TIER 5", "TIER 6") }

        val confidence = when {
            hasConflict -> 0.65f
            tier1Count > 0 && tier2Count > 0 -> 0.98f
            tier1Count > 0 -> 0.95f
            tier2Count > 0 -> 0.90f
            supportingCount > 0 -> 0.82f
            else -> 0.40f
        }

        val consensus = when {
            hasConflict -> "একাধিক উৎসের পাঠে মতভেদ রয়েছে। অ্যাডমিন নিশ্চিতকরণ প্রয়োজন।"
            tier1Count > 0 -> "বেদ ও প্রামাণিক শাস্ত্রীয় উৎস দ্বারা পাঠটি সম্পূর্ণভাবে সুনিশ্চিত।"
            tier2Count > 0 -> "প্রামাণ্য আচার্যভাষ্য ও ঐতিহ্যবাহী টীকা দ্বারা সমর্থিত।"
            else -> "উপলব্ধ সাধারণ সূত্র থেকে প্রাথমিক মিল পাওয়া গেছে, তবে সরাসরি শ্রুতি রেফারেন্স প্রয়োজন।"
        }

        return CrossSourceVerificationReport(
            query = query,
            sourcesComparedCount = allSources.size,
            hasConflict = hasConflict,
            conflictDescription = conflictDesc,
            isMultiTraditionTopic = isMultiTradition,
            traditionNotes = traditionNotes,
            overallConfidence = confidence,
            consensusConclusion = consensus,
            comparisons = comparisons,
            verifiedTier1Count = tier1Count,
            verifiedTier2Count = tier2Count,
            supportingTierCount = supportingCount
        )
    }
}
