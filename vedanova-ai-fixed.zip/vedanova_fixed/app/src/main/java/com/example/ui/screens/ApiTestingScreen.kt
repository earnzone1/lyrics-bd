package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.CodeBlockViewer
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.*
import com.example.ui.viewmodel.VedaNovaViewModel

@Composable
fun ApiTestingScreen(viewModel: VedaNovaViewModel) {
    val state by viewModel.apiTestState.collectAsStateWithLifecycle()
    val apiKeys by viewModel.allApiKeys.collectAsStateWithLifecycle()

    val availableEndpoints = listOf(
        "/api/v1/chat",
        "/api/v1/research",
        "/api/v1/knowledge/search",
        "/api/v1/mantra/search",
        "/api/v1/scripture/search",
        "/api/v1/verify",
        "/api/v1/status"
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Terminal, contentDescription = null, tint = VedicGold)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "API Testing Console",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Real-time Gateway client console for developers & testers. Send raw HTTP JSON payloads with authentication validation, rate limiting checks, and latency measurement.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Endpoint Selector Chips
        item {
            SectionHeader(title = "Target REST Endpoint")
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(availableEndpoints) { ep ->
                    FilterChip(
                        selected = state.selectedEndpoint == ep,
                        onClick = { viewModel.updateApiTestEndpoint(ep) },
                        label = { Text(ep, fontFamily = FontFamily.Monospace, fontSize = 12.sp) },
                        leadingIcon = {
                            Text(
                                text = if (ep.contains("status")) "GET" else "POST",
                                style = MaterialTheme.typography.labelSmall,
                                fontWeight = FontWeight.Bold,
                                color = if (ep.contains("status")) StatusGreen else SaffronPrimary
                            )
                        },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = CosmicNavyElevated,
                            selectedLabelColor = VedicGold
                        )
                    )
                }
            }
        }

        // Authentication & Key Selection
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
                    Text(
                        text = "Authentication Key (Bearer Token)",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )

                    // Key Preset Chips
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        items(apiKeys) { k ->
                            FilterChip(
                                selected = state.customBearerKey == k.apiKey,
                                onClick = { viewModel.updateApiTestKey(k.apiKey) },
                                label = { Text("${k.name} (${k.status})") },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = SaffronPrimary,
                                    selectedLabelColor = Color.Black
                                )
                            )
                        }
                    }

                    OutlinedTextField(
                        value = state.customBearerKey,
                        onValueChange = { viewModel.updateApiTestKey(it) },
                        label = { Text("Bearer Key / Header Token") },
                        modifier = Modifier.fillMaxWidth(),
                        singleLine = true,
                        shape = RoundedCornerShape(10.dp)
                    )
                }
            }
        }

        // Request Body Editor
        if (state.selectedMethod == "POST") {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Request JSON Payload",
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "application/json",
                                style = MaterialTheme.typography.labelSmall,
                                color = VedicGold,
                                fontFamily = FontFamily.Monospace
                            )
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedTextField(
                            value = state.requestBody,
                            onValueChange = { viewModel.updateApiTestBody(it) },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 4,
                            maxLines = 8,
                            shape = RoundedCornerShape(10.dp),
                            textStyle = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace)
                        )
                    }
                }
            }
        }

        // Send Button
        item {
            Button(
                onClick = { viewModel.sendApiTestRequest() },
                enabled = !state.isLoading,
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(50.dp)
            ) {
                if (state.isLoading) {
                    CircularProgressIndicator(modifier = Modifier.size(20.dp), color = Color.Black, strokeWidth = 2.dp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text("Executing Gateway Dispatch...", color = Color.Black, fontWeight = FontWeight.Bold)
                } else {
                    Icon(Icons.Default.Send, contentDescription = null, tint = Color.Black)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = "Send Request (${state.selectedMethod} ${state.selectedEndpoint})",
                        color = Color.Black,
                        fontWeight = FontWeight.Bold
                    )
                }
            }
        }

        // Live Gateway Response View
        state.response?.let { resp ->
            item {
                SectionHeader(
                    title = "Live Gateway Response",
                    subtitle = "Real-time response returned by VedaNova API Engine"
                )

                Card(
                    colors = CardDefaults.cardColors(containerColor = CosmicNavySurface),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CosmicCardBorder),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                StatusPill(
                                    text = "${resp.statusCode} ${resp.statusText}",
                                    color = if (resp.statusCode in 200..299) StatusGreen else StatusRed
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "Latency: ${resp.responseTimeMs}ms",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = VedicGold
                                )
                            }
                            StatusPill(text = resp.clientApp, color = StatusPurple)
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = CosmicCardBorder)
                        Spacer(modifier = Modifier.height(12.dp))

                        // Response Headers
                        Text(
                            text = "Response Headers:",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        resp.responseHeaders.forEach { (k, v) ->
                            Text(
                                text = "$k: $v",
                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                                color = TextSecondaryDark
                            )
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        Text(
                            text = "JSON Body:",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = VedicGold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        CodeBlockViewer(code = resp.jsonBody, language = "json")
                    }
                }
            }
        }

        // Request History
        if (state.requestHistory.isNotEmpty()) {
            item {
                SectionHeader(
                    title = "Console Request History",
                    subtitle = "Previous requests in this testing session"
                )
            }

            items(state.requestHistory) { (req, res) ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                StatusPill(
                                    text = req.method,
                                    color = if (req.method == "POST") SaffronPrimary else StatusGreen
                                )
                                Spacer(modifier = Modifier.width(6.dp))
                                Text(
                                    text = req.endpoint,
                                    style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace),
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "Status: ${res.statusCode} • Latency: ${res.responseTimeMs}ms • Client: ${res.clientApp}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}
