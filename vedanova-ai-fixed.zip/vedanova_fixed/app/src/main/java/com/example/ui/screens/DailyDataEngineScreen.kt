package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.DailyJobLogEntity
import com.example.domain.ai.CalendarRegion
import com.example.ui.theme.*
import com.example.ui.viewmodel.VedaNovaViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DailyDataEngineScreen(viewModel: VedaNovaViewModel) {
    val selectedRegion by viewModel.selectedDailyRegion.collectAsState()
    val dailyData by viewModel.dailyData.collectAsState()
    val isJobRunning by viewModel.isDailyJobRunning.collectAsState()
    val jobMessage by viewModel.dailyJobMessage.collectAsState()
    val jobLogs by viewModel.recentDailyJobLogs.collectAsState()

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            "Dynamic Daily Data & Festival Engine",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            "Real-time Surya Siddhanta & Drik Ephemeris Resolution for External Apps",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }
                },
                actions = {
                    Button(
                        onClick = { viewModel.triggerDailyDataUpdateJob(selectedRegion) },
                        enabled = !isJobRunning,
                        colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                        modifier = Modifier.padding(end = 8.dp).testTag("trigger_daily_job_button")
                    ) {
                        if (isJobRunning) {
                            CircularProgressIndicator(modifier = Modifier.size(16.dp), color = Color.White, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Calculating...")
                        } else {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("Run Daily Job", fontWeight = FontWeight.Bold)
                        }
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // Status Notification
            jobMessage?.let { msg ->
                item {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = SpiritualTeal.copy(alpha = 0.15f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, SpiritualTeal),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(modifier = Modifier.padding(12.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Info, contentDescription = null, tint = SpiritualTeal)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(msg, style = MaterialTheme.typography.bodyMedium.copy(color = SpiritualTeal, fontWeight = FontWeight.SemiBold))
                        }
                    }
                }
            }

            // 1. Region Selector Tab Bar
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Text(
                            "Select Astronomical Calendar Region:",
                            style = MaterialTheme.typography.labelLarge.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            CalendarRegion.values().forEach { region ->
                                val isSelected = region == selectedRegion
                                FilterChip(
                                    selected = isSelected,
                                    onClick = { viewModel.selectDailyRegion(region) },
                                    label = {
                                        Text(
                                            region.displayName,
                                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                        )
                                    },
                                    leadingIcon = if (isSelected) {
                                        { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                    } else null
                                )
                            }
                        }
                    }
                }
            }

            // 2. Primary Date & Panchang Display
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(20.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 3.dp)
                ) {
                    Column(modifier = Modifier.padding(20.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    dailyData.gregorianDateFormatted,
                                    style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    "Region: ${dailyData.region.displayName} (${dailyData.region.standardConvention})",
                                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            }

                            Surface(
                                shape = RoundedCornerShape(12.dp),
                                color = SaffronPrimary.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    "LIVE EPHEMERIS",
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = SaffronPrimary)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(16.dp))

                        // Bengali Calendar Highlight
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(16.dp)
                        ) {
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text("বঙ্গাব্দ ও পঞ্জিকা", style = MaterialTheme.typography.labelSmall.copy(color = SaffronPrimary, fontWeight = FontWeight.Bold))
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        "${dailyData.bengaliDate.dayBangla} ${dailyData.bengaliDate.monthBangla}, ${dailyData.bengaliDate.yearBangla}",
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        dailyData.bengaliDate.dayOfWeekBangla,
                                        style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    )
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                modifier = Modifier.weight(1f)
                            ) {
                                Column(modifier = Modifier.padding(14.dp)) {
                                    Text("তিথি ও নক্ষত্র", style = MaterialTheme.typography.labelSmall.copy(color = SpiritualTeal, fontWeight = FontWeight.Bold))
                                    Spacer(modifier = Modifier.height(4.dp))
                                    Text(
                                        dailyData.bengaliDate.fullTithiTitle,
                                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                                    )
                                    Text(
                                        dailyData.bengaliDate.nakshatra,
                                        style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(16.dp))

                        // Solar & Lunar Timings Grid
                        Text("Solar & Muhurta Coordinates", style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold))
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            TimingChip(label = "Sunrise", value = dailyData.bengaliDate.sunriseTime, modifier = Modifier.weight(1f))
                            TimingChip(label = "Sunset", value = dailyData.bengaliDate.sunsetTime, modifier = Modifier.weight(1f))
                            TimingChip(label = "Brahma Muhurta", value = dailyData.bengaliDate.brahmaMuhurta, modifier = Modifier.weight(1.3f))
                            TimingChip(label = "Abhijit", value = dailyData.bengaliDate.abhijitMuhurta, modifier = Modifier.weight(1.1f))
                        }
                    }
                }
            }

            // 3. Next Major Festival Countdown
            dailyData.nextMajorFestival?.let { nextFest ->
                item {
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = VedicGold.copy(alpha = 0.12f)),
                        border = androidx.compose.foundation.BorderStroke(1.dp, VedicGold.copy(alpha = 0.5f))
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(Icons.Default.Celebration, contentDescription = null, tint = SaffronPrimary, modifier = Modifier.size(20.dp))
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text("আসন্ন প্রধান উৎসব", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = SaffronPrimary))
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(nextFest.nameBn, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                                Text(
                                    "তারিখ: ${nextFest.targetGregorianDate} • ${nextFest.descriptionBn}",
                                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            }

                            Column(horizontalAlignment = Alignment.End) {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = SaffronPrimary
                                ) {
                                    Column(
                                        modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                                        horizontalAlignment = Alignment.CenterHorizontally
                                    ) {
                                        Text("${nextFest.daysRemaining}", style = MaterialTheme.typography.headlineSmall.copy(fontWeight = FontWeight.Bold, color = Color.White))
                                        Text("দিন বাকি", style = MaterialTheme.typography.labelSmall.copy(color = Color.White))
                                    }
                                }
                            }
                        }
                    }
                }
            }

            // 4. Daily Spiritual Feed Preview
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.MenuBook, contentDescription = null, tint = SpiritualTeal)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Daily Spiritual Feed (Supplied to External Apps)", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                        }
                        Spacer(modifier = Modifier.height(12.dp))

                        // Daily Gita Verse
                        Text("শ্রীমদ্ভগবদ্গীতা শ্লোক (${dailyData.spiritualFeed.dailyGitaChapterVerse}):", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = SaffronPrimary))
                        Text(
                            dailyData.spiritualFeed.dailyGitaSanskrit,
                            style = MaterialTheme.typography.bodyMedium.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold)
                        )
                        Text(
                            dailyData.spiritualFeed.dailyGitaBn,
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Daily Dharma Thought
                        Text("আজকের আধ্যাত্মিক সুবচন:", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = SpiritualTeal))
                        Text(
                            "\"${dailyData.spiritualFeed.dailyDharmaQuoteBn}\"",
                            style = MaterialTheme.typography.bodyMedium.copy(fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
                        )
                        Text("— ${dailyData.spiritualFeed.quoteSource}", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                    }
                }
            }

            // 5. Daily Job Logs Table
            item {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Text("Daily Job Execution Audit Logs", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                    Text("Historical tracking of ephemeris reconciliation runs", style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                }
            }

            items(jobLogs) { log ->
                JobLogCard(log = log)
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
fun TimingChip(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(8.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
    ) {
        Column(modifier = Modifier.padding(6.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant))
            Text(value, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, fontSize = 11.sp))
        }
    }
}

@Composable
fun JobLogCard(log: DailyJobLogEntity) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
    ) {
        Row(
            modifier = Modifier.padding(12.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(log.jobName, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                Text(
                    "Region: ${log.region} • Date: ${log.gregorianDate} • ${log.bengaliDate}",
                    style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
                Text(
                    "Updated: ${log.updatedRecords} records in ${log.executionDurationMs}ms • Status: ${log.status}",
                    style = MaterialTheme.typography.labelSmall.copy(color = if (log.status == "SUCCESS") Color(0xFF2E7D32) else Color(0xFFC62828), fontWeight = FontWeight.Bold)
                )
            }

            Surface(
                shape = RoundedCornerShape(6.dp),
                color = Color(0xFF2E7D32).copy(alpha = 0.15f)
            ) {
                Text(
                    log.verificationStatus,
                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32))
                )
            }
        }
    }
}
