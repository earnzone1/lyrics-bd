package com.example.ui.components

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.window.DialogProperties
import com.example.domain.voice.LiveVoiceState
import com.example.ui.theme.*
import com.example.ui.viewmodel.VedaNovaViewModel

@Composable
fun LiveVoiceCallOverlay(
    viewModel: VedaNovaViewModel,
    onDismiss: () -> Unit
) {
    val voiceState by viewModel.liveVoiceState.collectAsState()
    val transcript by viewModel.liveVoiceTranscript.collectAsState()
    val amplitude by viewModel.liveVoiceAmplitude.collectAsState()
    val voiceError by viewModel.liveVoiceError.collectAsState()
    val settings by viewModel.liveVoiceSettings.collectAsState()

    // Smooth pulse animation for visualizer
    val infiniteTransition = rememberInfiniteTransition(label = "pulse")
    val pulseScale by infiniteTransition.animateFloat(
        initialValue = 1.0f,
        targetValue = 1.15f,
        animationSpec = infiniteRepeatable(
            animation = tween(900, easing = FastOutSlowInEasing),
            repeatMode = RepeatMode.Reverse
        ),
        label = "pulseScale"
    )

    val animatedAmplitude by animateFloatAsState(
        targetValue = amplitude.coerceIn(0.1f, 1.0f),
        animationSpec = spring(stiffness = Spring.StiffnessLow),
        label = "amp"
    )

    Dialog(
        onDismissRequest = {
            viewModel.endLiveVoiceCall()
            onDismiss()
        },
        properties = DialogProperties(usePlatformDefaultWidth = false)
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(
                    Brush.verticalGradient(
                        colors = listOf(
                            Color(0xFF0D081E),
                            Color(0xFF1B0B33),
                            Color(0xFF090412)
                        )
                    )
                )
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(24.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.SpaceBetween
            ) {
                // 1. Header Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "🕉️", fontSize = 20.sp)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "VedaNova Live Voice AI",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = VedicGold
                            )
                        }
                        Text(
                            text = "Continuous Dharma Conversation Mode",
                            style = MaterialTheme.typography.labelSmall,
                            color = TextSecondaryDark
                        )
                    }

                    Surface(
                        color = when (voiceState) {
                            LiveVoiceState.SPEAKING -> SaffronPrimary.copy(alpha = 0.2f)
                            LiveVoiceState.LISTENING -> VedicGold.copy(alpha = 0.2f)
                            LiveVoiceState.THINKING -> Color(0xFF9C27B0).copy(alpha = 0.2f)
                            LiveVoiceState.MUTED -> Color.Red.copy(alpha = 0.2f)
                            else -> Color.DarkGray.copy(alpha = 0.3f)
                        },
                        shape = RoundedCornerShape(16.dp),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            when (voiceState) {
                                LiveVoiceState.SPEAKING -> SaffronPrimary
                                LiveVoiceState.LISTENING -> VedicGold
                                LiveVoiceState.THINKING -> Color(0xFFCE93D8)
                                LiveVoiceState.MUTED -> Color.Red
                                else -> Color.Gray
                            }
                        )
                    ) {
                        Text(
                            text = when (voiceState) {
                                LiveVoiceState.SPEAKING -> "🗣️ Speaking..."
                                LiveVoiceState.LISTENING -> "🎙️ Listening..."
                                LiveVoiceState.THINKING -> "🧠 Thinking..."
                                LiveVoiceState.MUTED -> "🔇 Muted"
                                LiveVoiceState.ERROR -> "⚠️ Error"
                                else -> "⏳ Ready"
                            },
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = Color.White
                        )
                    }
                }

                // 2. Central Animated Waveform & Mandala Aura
                Box(
                    contentAlignment = Alignment.Center,
                    modifier = Modifier
                        .size(240.dp)
                        .padding(16.dp)
                ) {
                    // Outer pulsating aura ring
                    Box(
                        modifier = Modifier
                            .size(200.dp * (if (voiceState == LiveVoiceState.LISTENING) (1f + animatedAmplitude * 0.4f) else pulseScale))
                            .clip(CircleShape)
                            .background(
                                Brush.radialGradient(
                                    colors = when (voiceState) {
                                        LiveVoiceState.SPEAKING -> listOf(SaffronPrimary.copy(alpha = 0.4f), Color.Transparent)
                                        LiveVoiceState.LISTENING -> listOf(VedicGold.copy(alpha = 0.5f), Color.Transparent)
                                        LiveVoiceState.THINKING -> listOf(Color(0xFF9C27B0).copy(alpha = 0.4f), Color.Transparent)
                                        else -> listOf(Color.Gray.copy(alpha = 0.2f), Color.Transparent)
                                    }
                                )
                            )
                    )

                    // Middle Ring
                    Box(
                        modifier = Modifier
                            .size(130.dp)
                            .clip(CircleShape)
                            .background(Color(0xFF1E1038))
                            .border(
                                2.dp,
                                when (voiceState) {
                                    LiveVoiceState.SPEAKING -> SaffronPrimary
                                    LiveVoiceState.LISTENING -> VedicGold
                                    LiveVoiceState.THINKING -> Color(0xFFBA68C8)
                                    else -> Color(0xFF4A3B69)
                                },
                                CircleShape
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = when (voiceState) {
                                LiveVoiceState.SPEAKING -> "🔊"
                                LiveVoiceState.LISTENING -> "🎙️"
                                LiveVoiceState.THINKING -> "🕉️"
                                LiveVoiceState.MUTED -> "🔇"
                                else -> "✨"
                            },
                            fontSize = 42.sp
                        )
                    }
                }

                // 3. Live Transcript & Live Response Card
                Surface(
                    color = Color(0xFF180E2B),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, CosmicCardBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .heightIn(min = 120.dp, max = 220.dp)
                ) {
                    Column(
                        modifier = Modifier
                            .padding(16.dp)
                            .fillMaxWidth(),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        if (voiceError != null) {
                            Icon(Icons.Default.ErrorOutline, contentDescription = null, tint = Color(0xFFFF5252), modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = voiceError ?: "",
                                style = MaterialTheme.typography.bodySmall,
                                color = Color(0xFFFF8A80),
                                textAlign = TextAlign.Center
                            )
                        } else {
                            Text(
                                text = if (transcript.isNotBlank()) transcript else "কথা বলুন... VedaNova AI শুনছে",
                                style = MaterialTheme.typography.bodyLarge,
                                fontWeight = FontWeight.Medium,
                                color = TextPrimaryDark,
                                textAlign = TextAlign.Center
                            )
                            if (voiceState == LiveVoiceState.SPEAKING) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "💡 কথা বললে AI নিজে থেকেই থেমে আপনার কথা শুনবে (Barge-in)",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = SaffronLight
                                )
                            }
                        }
                    }
                }

                // 4. Quick Language & Speed Pill Controls
                Row(
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    FilterChip(
                        selected = settings.language == "BENGALI",
                        onClick = { viewModel.updateLiveVoiceSettings(settings.copy(language = "BENGALI")) },
                        label = { Text("বাংলা (Bengali)") }
                    )
                    FilterChip(
                        selected = settings.language == "ENGLISH",
                        onClick = { viewModel.updateLiveVoiceSettings(settings.copy(language = "ENGLISH")) },
                        label = { Text("English") }
                    )
                    FilterChip(
                        selected = settings.language == "SANSKRIT",
                        onClick = { viewModel.updateLiveVoiceSettings(settings.copy(language = "SANSKRIT")) },
                        label = { Text("সংস্কৃত (Sanskrit)") }
                    )
                }

                // 5. Call Control Buttons
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    // Mute / Unmute
                    IconButton(
                        onClick = { viewModel.toggleVoiceMute() },
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(if (voiceState == LiveVoiceState.MUTED) Color.Red.copy(alpha = 0.3f) else Color(0xFF2B1C4B))
                            .border(1.dp, Color(0xFF533B88), CircleShape)
                    ) {
                        Icon(
                            imageVector = if (voiceState == LiveVoiceState.MUTED) Icons.Default.MicOff else Icons.Default.Mic,
                            contentDescription = "Mute Microphone",
                            tint = if (voiceState == LiveVoiceState.MUTED) Color.Red else Color.White
                        )
                    }

                    // Interruption / Tap to Speak Button
                    IconButton(
                        onClick = { viewModel.interruptVoiceAndListen() },
                        modifier = Modifier
                            .size(64.dp)
                            .clip(CircleShape)
                            .background(
                                if (voiceState == LiveVoiceState.LISTENING) SaffronPrimary else VedicGold
                            )
                    ) {
                        Icon(
                            imageVector = Icons.Default.Hearing,
                            contentDescription = "Speak Now / Interrupt",
                            tint = Color.Black,
                            modifier = Modifier.size(32.dp)
                        )
                    }

                    // End Call
                    IconButton(
                        onClick = {
                            viewModel.endLiveVoiceCall()
                            onDismiss()
                        },
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(Color(0xFFD32F2F))
                    ) {
                        Icon(
                            imageVector = Icons.Default.CallEnd,
                            contentDescription = "End Voice Call",
                            tint = Color.White
                        )
                    }
                }
            }
        }
    }
}
