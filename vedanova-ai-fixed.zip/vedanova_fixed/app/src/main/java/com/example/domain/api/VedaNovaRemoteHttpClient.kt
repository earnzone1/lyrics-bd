package com.example.domain.api

import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import java.util.concurrent.TimeUnit

data class RemoteTestResult(
    val testName: String,
    val endpoint: String,
    val method: String,
    val httpStatusCode: Int,
    val latencyMs: Long,
    val isSuccess: Boolean,
    val responseBody: String,
    val requestId: String?,
    val errorDescription: String? = null
)

class VedaNovaRemoteHttpClient(
    private val apiGateway: VedaNovaApiGateway? = null
) {
    private val okHttpClient = OkHttpClient.Builder()
        .connectTimeout(15, TimeUnit.SECONDS)
        .readTimeout(30, TimeUnit.SECONDS)
        .writeTimeout(15, TimeUnit.SECONDS)
        .build()

    suspend fun executeRemoteRequest(
        baseUrl: String,
        endpoint: String,
        method: String = "POST",
        apiKey: String,
        body: String = "",
        forceRemoteHttp: Boolean = false
    ): ApiGatewayResponse = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        val trimmedBase = baseUrl.trim().removeSuffix("/")
        val cleanEndpoint = if (endpoint.startsWith("/")) endpoint else "/$endpoint"
        val fullUrl = "$trimmedBase$cleanEndpoint"

        // If forceRemoteHttp is true or baseUrl is an actual remote URL (http:// or https://)
        val isRealRemote = forceRemoteHttp || (trimmedBase.startsWith("http://") || trimmedBase.startsWith("https://"))

        if (isRealRemote && !trimmedBase.contains("in-app-gateway.local")) {
            try {
                val mediaType = "application/json; charset=utf-8".toMediaType()
                val requestBuilder = Request.Builder()
                    .url(fullUrl)
                    .addHeader("Authorization", if (apiKey.startsWith("Bearer ")) apiKey else "Bearer $apiKey")
                    .addHeader("Accept", "application/json")
                    .addHeader("User-Agent", "VedaNova-External-Client/1.0")

                if (method.equals("POST", ignoreCase = true)) {
                    val requestBody = body.ifBlank { "{}" }.toRequestBody(mediaType)
                    requestBuilder.post(requestBody)
                } else {
                    requestBuilder.get()
                }

                val okHttpRequest = requestBuilder.build()
                val okHttpResponse = okHttpClient.newCall(okHttpRequest).execute()
                val elapsed = System.currentTimeMillis() - startTime
                val responseString = okHttpResponse.body?.string() ?: ""

                val responseHeaders = mutableMapOf<String, String>()
                for (name in okHttpResponse.headers.names()) {
                    responseHeaders[name] = okHttpResponse.header(name) ?: ""
                }

                val reqId = responseHeaders["X-VedaNova-Request-ID"] ?: "req_remote_${System.currentTimeMillis()}"

                return@withContext ApiGatewayResponse(
                    statusCode = okHttpResponse.code,
                    statusText = okHttpResponse.message.ifBlank { if (okHttpResponse.isSuccessful) "OK" else "Error" },
                    responseTimeMs = elapsed,
                    responseHeaders = responseHeaders,
                    jsonBody = responseString,
                    clientApp = "External Android App",
                    tokensUsed = 50,
                    requestId = reqId
                )
            } catch (e: Exception) {
                // If remote network connection fails (e.g. DNS or no remote server running on URL),
                // if we have local gateway fallback available, we fallback or return network error
                if (apiGateway != null) {
                    val directResp = apiGateway.executeRequest(
                        ApiGatewayRequest(
                            endpoint = cleanEndpoint,
                            method = method,
                            apiKey = apiKey,
                            body = body
                        )
                    )
                    return@withContext directResp
                }

                val elapsed = System.currentTimeMillis() - startTime
                val reqId = "err_net_${System.currentTimeMillis()}"
                return@withContext ApiGatewayResponse(
                    statusCode = 503,
                    statusText = "Network Failure",
                    responseTimeMs = elapsed,
                    responseHeaders = mapOf(
                        "Content-Type" to "application/json",
                        "X-Error-Code" to "NETWORK_TIMEOUT"
                    ),
                    jsonBody = """
                        {
                          "success": false,
                          "requestId": "$reqId",
                          "error": {
                            "code": 503,
                            "status": "SERVER_UNREACHABLE",
                            "message": "Failed to connect to VedaNova Cloud endpoint: ${e.localizedMessage ?: "Connection refused or timed out."}"
                          }
                        }
                    """.trimIndent(),
                    clientApp = "External Client",
                    tokensUsed = 0,
                    requestId = reqId
                )
            }
        } else {
            // Direct Gateway invocation
            if (apiGateway != null) {
                return@withContext apiGateway.executeRequest(
                    ApiGatewayRequest(
                        endpoint = cleanEndpoint,
                        method = method,
                        apiKey = apiKey,
                        body = body
                    )
                )
            } else {
                val elapsed = System.currentTimeMillis() - startTime
                return@withContext ApiGatewayResponse(
                    statusCode = 500,
                    statusText = "Gateway Uninitialized",
                    responseTimeMs = elapsed,
                    responseHeaders = mapOf("Content-Type" to "application/json"),
                    jsonBody = "{\"success\": false, \"error\": {\"code\": 500, \"message\": \"Gateway not initialized\"}}",
                    clientApp = "Unknown",
                    tokensUsed = 0
                )
            }
        }
    }
}
