package com.example.domain.ai

enum class SourceQualityTier(
    val tierName: String,
    val bengaliLabel: String,
    val baseWeight: Float, // 0.0 - 1.0
    val defaultConfidence: Float,
    val description: String
) {
    PRIMARY_SCRIPTURE(
        tierName = "PRIMARY_SCRIPTURE",
        bengaliLabel = "মৌলিক বৈদিক ও শাস্ত্রীয় উৎস",
        baseWeight = 1.0f,
        defaultConfidence = 0.99f,
        description = "Shruti, Mukhya Upanishads, Bhagavad Gita, Brahma Sutras, and Vedic Samhitas."
    ),
    TRADITIONAL_COMMENTARY(
        tierName = "TRADITIONAL_COMMENTARY",
        bengaliLabel = "প্রামাণিক আচার্য ভাষ্য",
        baseWeight = 0.95f,
        defaultConfidence = 0.95f,
        description = "Classical commentaries (Bhashyas) by Adi Shankaracharya, Ramanuja, Madhva, Abhinavagupta, etc."
    ),
    ACADEMIC_SOURCE(
        tierName = "ACADEMIC_SOURCE",
        bengaliLabel = "একাডেমিক ও গবেষণা সংস্থান",
        baseWeight = 0.88f,
        defaultConfidence = 0.88f,
        description = "Peer-reviewed Indological studies, Critical editions, Bharatiya Vidya Bhavan, Bhandarkar Oriental Research."
    ),
    REPUTABLE_INSTITUTION(
        tierName = "REPUTABLE_INSTITUTION",
        bengaliLabel = "মর্যাদাপূর্ণ আধ্যাত্মিক প্রতিষ্ঠান",
        baseWeight = 0.82f,
        defaultConfidence = 0.85f,
        description = "Gita Press Gorakhpur, Ramakrishna Mission / Belur Math, Chinmaya Mission, Arya Samaj publications."
    ),
    GENERAL_WEBSITE(
        tierName = "GENERAL_WEBSITE",
        bengaliLabel = "সাধারণ তথ্যকোষ ও ওয়েব সংস্থান",
        baseWeight = 0.50f,
        defaultConfidence = 0.55f,
        description = "General informational articles, online encyclopedias, and community compendiums."
    ),
    USER_GENERATED_CONTENT(
        tierName = "USER_GENERATED_CONTENT",
        bengaliLabel = "ব্যবহারকারী প্রদত্ত / অসত্যায়িত বিষয়বস্তু",
        baseWeight = 0.30f,
        defaultConfidence = 0.35f,
        description = "Social forums, unverified blog posts, and ungrounded submissions."
    )
}

data class EvaluatedSource(
    val title: String,
    val tier: SourceQualityTier,
    val citation: String,
    val reliabilityScore: Float, // 0.0 - 1.0
    val verifiedCanonically: Boolean,
    val remarks: String
)

object SourceQualityEngine {

    fun categorizeSource(sourceText: String, scripture: String): SourceQualityTier {
        val s = (sourceText + " " + scripture).lowercase()
        return when {
            s.contains("veda") || s.contains("বেদ") || s.contains("upanishad") || s.contains("উপনিষদ") ||
            s.contains("gita") || s.contains("গীতা") || s.contains("samhita") || s.contains("ব্রহ্মসূত্র") ||
            s.contains("brahma sutra") || s.contains("rigveda") || s.contains("yajurveda") ->
                SourceQualityTier.PRIMARY_SCRIPTURE

            s.contains("shankara") || s.contains("bhashya") || s.contains("ভাষ্য") || s.contains("ramanuja") ||
            s.contains("madhva") || s.contains("sridhara") || s.contains("sayana") || s.contains("abhinavagupta") ->
                SourceQualityTier.TRADITIONAL_COMMENTARY

            s.contains("critical edition") || s.contains("indology") || s.contains("bhandarkar") ||
            s.contains("academic") || s.contains("vidya bhavan") || s.contains("oxford") ->
                SourceQualityTier.ACADEMIC_SOURCE

            s.contains("gita press") || s.contains("গীতা প্রেস") || s.contains("belur math") || s.contains("বেলুড় মঠ") ||
            s.contains("ramakrishna") || s.contains("chinmaya") || s.contains("advaita ashrama") ->
                SourceQualityTier.REPUTABLE_INSTITUTION

            s.contains("wikipedia") || s.contains("blog") || s.contains("website") || s.contains("web") ->
                SourceQualityTier.GENERAL_WEBSITE

            else ->
                SourceQualityTier.TRADITIONAL_COMMENTARY
        }
    }

    fun evaluateSources(sources: List<Pair<String, String>>): List<EvaluatedSource> {
        return sources.map { (title, citation) ->
            val tier = categorizeSource(title, citation)
            EvaluatedSource(
                title = title,
                tier = tier,
                citation = citation,
                reliabilityScore = tier.defaultConfidence,
                verifiedCanonically = tier.baseWeight >= 0.85f,
                remarks = "Evaluated via Source Quality Engine (${tier.tierName})"
            )
        }
    }
}
