package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.domain.ai.CalendarRegion
import com.example.domain.ai.ExternalAppCapabilityEngine
import com.example.ui.theme.*
import com.example.ui.viewmodel.VedaNovaViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExternalAppSimulatorScreen(viewModel: VedaNovaViewModel) {
    val externalApps by viewModel.allExternalApps.collectAsState()
    val selectedAppId by viewModel.simulatorAppId.collectAsState()
    val selectedRegion by viewModel.simulatorRegion.collectAsState()
    val activeTab by viewModel.simulatorActiveTab.collectAsState()
    val chatQuery by viewModel.simulatorChatQuery.collectAsState()
    val chatMessages by viewModel.simulatorChatMessages.collectAsState()
    val isLoading by viewModel.simulatorIsLoading.collectAsState()
    val lastResponse by viewModel.simulatorLastResponse.collectAsState()
    val dailyData by viewModel.dailyData.collectAsState()

    val currentApp = externalApps.find { it.appId == selectedAppId } ?: externalApps.firstOrNull()
    var appMenuExpanded by remember { mutableStateOf(false) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            "External App Sandbox & Live Simulator",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            "Simulate how 3rd-party clients consume VedaNova AI & Dynamic Capabilities",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }
                }
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp)
        ) {
            // 1. App Switcher & Context Banner
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text("Simulated External Application:", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                        Box {
                            TextButton(
                                onClick = { appMenuExpanded = true },
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Text(
                                    currentApp?.let { "${it.appName} (${it.appId})" } ?: "Select App",
                                    style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = SaffronPrimary)
                                )
                                Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = SaffronPrimary)
                            }
                            DropdownMenu(
                                expanded = appMenuExpanded,
                                onDismissRequest = { appMenuExpanded = false }
                            ) {
                                externalApps.forEach { app ->
                                    DropdownMenuItem(
                                        text = {
                                            Column {
                                                Text(app.appName, fontWeight = FontWeight.Bold)
                                                Text("ID: ${app.appId} • Scopes: ${app.allowedScopes}", fontSize = 11.sp, color = Color.Gray)
                                            }
                                        },
                                        onClick = {
                                            viewModel.setSimulatorApp(app.appId)
                                            appMenuExpanded = false
                                        }
                                    )
                                }
                            }
                        }
                    }

                    Column(horizontalAlignment = Alignment.End) {
                        Text("Active Scopes", style = MaterialTheme.typography.labelSmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                        Text(
                            currentApp?.allowedScopes ?: "None",
                            style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold, color = SpiritualTeal)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 2. Navigation Tabs
            val tabs = listOf("Daily Feed", "Live Countdown", "Discovered Capabilities", "Simulated Chat", "Raw Gateway Inspector")
            ScrollableTabRow(
                selectedTabIndex = activeTab,
                edgePadding = 0.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = activeTab == index,
                        onClick = {
                            viewModel.setSimulatorActiveTab(index)
                            if (index == 0) {
                                viewModel.executeSimulatorRawRequest("/api/v1/daily/today", "GET")
                            } else if (index == 1) {
                                viewModel.executeSimulatorRawRequest("/api/v1/daily/festivals/upcoming", "GET")
                            } else if (index == 2) {
                                viewModel.executeSimulatorRawRequest("/api/v1/capabilities", "GET")
                            }
                        },
                        text = { Text(title, fontWeight = if (activeTab == index) FontWeight.Bold else FontWeight.Normal) }
                    )
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            // 3. Tab Contents
            when (activeTab) {
                0 -> SimulatorDailyFeedTab(dailyData = dailyData)
                1 -> SimulatorCountdownTab(dailyData = dailyData)
                2 -> SimulatorCapabilitiesTab(currentApp = currentApp)
                3 -> SimulatorChatTab(
                    chatMessages = chatMessages,
                    chatQuery = chatQuery,
                    isLoading = isLoading,
                    onQueryChange = { viewModel.setSimulatorChatQuery(it) },
                    onSend = { viewModel.sendSimulatorChatMessage() }
                )
                4 -> SimulatorRawInspectorTab(lastResponse = lastResponse, viewModel = viewModel)
            }
        }
    }
}

@Composable
fun SimulatorDailyFeedTab(dailyData: com.example.domain.ai.DailyDataResolution) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        "Resolved for: ${dailyData.region.displayName}",
                        style = MaterialTheme.typography.labelSmall.copy(color = SaffronPrimary, fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        "${dailyData.bengaliDate.dayBangla} ${dailyData.bengaliDate.monthBangla} ${dailyData.bengaliDate.yearBangla} (${dailyData.bengaliDate.dayOfWeekBangla})",
                        style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        "গ্রেগরিয়ান: ${dailyData.gregorianDateFormatted} • ${dailyData.bengaliDate.fullTithiTitle}",
                        style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(12.dp))

                    Text("Muhurta Timings:", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        TimingChip(label = "Sunrise", value = dailyData.bengaliDate.sunriseTime, modifier = Modifier.weight(1f))
                        TimingChip(label = "Sunset", value = dailyData.bengaliDate.sunsetTime, modifier = Modifier.weight(1f))
                        TimingChip(label = "Brahma Muhurta", value = dailyData.bengaliDate.brahmaMuhurta, modifier = Modifier.weight(1.3f))
                        TimingChip(label = "Rahu Kala", value = dailyData.bengaliDate.rahuKala, modifier = Modifier.weight(1.1f))
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text("Daily Gita Exegesis (${dailyData.spiritualFeed.dailyGitaChapterVerse}):", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = SaffronPrimary))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(dailyData.spiritualFeed.dailyGitaSanskrit, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif))
                    Text(dailyData.spiritualFeed.dailyGitaBn, style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                }
            }
        }
    }
}

@Composable
fun SimulatorCountdownTab(dailyData: com.example.domain.ai.DailyDataResolution) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        items(dailyData.upcomingFestivals) { fest ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(fest.nameBn, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold))
                        Text(
                            "${fest.nameEn} • ${fest.targetGregorianDate}",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                        Text(
                            "উপাস্য দেব/দেবী: ${fest.primaryDeity}",
                            style = MaterialTheme.typography.labelSmall.copy(color = SpiritualTeal, fontWeight = FontWeight.SemiBold)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = SaffronPrimary
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("${fest.daysRemaining}", style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold, color = Color.White))
                            Text("দিন বাকি", style = MaterialTheme.typography.labelSmall.copy(color = Color.White))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SimulatorCapabilitiesTab(currentApp: com.example.data.model.ExternalAppEntity?) {
    val scopes = currentApp?.allowedScopes ?: "ALL"
    val capabilities = ExternalAppCapabilityEngine.getCapabilitiesForScopes(scopes)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        item {
            Text(
                "Authorized Capabilities for Scopes: [${scopes}] (${capabilities.size} Active)",
                style = MaterialTheme.typography.labelMedium.copy(fontWeight = FontWeight.Bold)
            )
        }

        items(capabilities) { cap ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(cap.nameBn, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = SaffronPrimary.copy(alpha = 0.15f)
                        ) {
                            Text(
                                cap.code,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = SaffronPrimary)
                            )
                        }
                    }
                    Text(cap.nameEn, style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(cap.description, style = MaterialTheme.typography.bodySmall)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("Endpoint: ${cap.endpoint} • Scope: ${cap.requiredScope}", style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, color = SpiritualTeal))
                }
            }
        }
    }
}

@Composable
fun SimulatorChatTab(
    chatMessages: List<Pair<String, String>>,
    chatQuery: String,
    isLoading: Boolean,
    onQueryChange: (String) -> Unit,
    onSend: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        // Quick Scenario Presets
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            AssistChip(
                onClick = { onQueryChange("শিব কে?") },
                label = { Text("১. শিব কে?", fontSize = 11.sp) }
            )
            AssistChip(
                onClick = { onQueryChange("তার প্রণাম ও ধ্যান মন্ত্র বলো") },
                label = { Text("২. তার প্রণাম মন্ত্র (Pronoun)", fontSize = 11.sp) }
            )
            AssistChip(
                onClick = { onQueryChange("আমাকে একটি মন্ত্র দাও") },
                label = { Text("৩. Disambiguation Test", fontSize = 11.sp) }
            )
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(10.dp)
        ) {
            items(chatMessages) { (sender, msg) ->
                val isUser = sender == "USER"
                val isSystem = sender == "APP_SYSTEM"

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                ) {
                    Surface(
                        shape = RoundedCornerShape(12.dp),
                        color = when {
                            isUser -> SaffronPrimary
                            isSystem -> SpiritualTeal.copy(alpha = 0.15f)
                            else -> MaterialTheme.colorScheme.surfaceVariant
                        },
                        modifier = Modifier.widthIn(max = 300.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text(
                                if (isUser) "Simulated User" else if (isSystem) "System Event" else "VedaNova AI Central Brain",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (isUser) Color.White.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                msg,
                                style = MaterialTheme.typography.bodyMedium.copy(
                                    color = if (isUser) Color.White else MaterialTheme.colorScheme.onSurface
                                )
                            )
                        }
                    }
                }
            }

            if (isLoading) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(modifier = Modifier.size(16.dp), strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("VedaNova Central AI Brain Processing Context...", style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(8.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            OutlinedTextField(
                value = chatQuery,
                onValueChange = onQueryChange,
                modifier = Modifier.weight(1f).testTag("simulator_chat_input"),
                placeholder = { Text("Ask simulated app query (e.g. শিব কে? / তার মন্ত্র বলো)...") },
                singleLine = true,
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { onSend() })
            )
            IconButton(
                onClick = onSend,
                enabled = !isLoading && chatQuery.isNotBlank(),
                modifier = Modifier
                    .clip(CircleShape)
                    .background(if (!isLoading && chatQuery.isNotBlank()) SaffronPrimary else Color.Gray.copy(alpha = 0.3f))
                    .testTag("simulator_send_button")
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.White)
            }
        }
        Spacer(modifier = Modifier.height(8.dp))
    }
}

@Composable
fun SimulatorRawInspectorTab(
    lastResponse: com.example.domain.api.ApiGatewayResponse?,
    viewModel: VedaNovaViewModel? = null
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // HTTP Error & Edge Case Simulation Controls
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text("Gateway Edge-Case & Error Code Simulator:", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = SaffronPrimary))
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                viewModel?.executeSimulatorRawRequest("/api/v1/chat", "POST", "{\"query\":\"test\"}")
                            },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("Normal 200", fontSize = 11.sp)
                        }
                        OutlinedButton(
                            onClick = {
                                viewModel?.executeSimulatorRawRequest("/api/v1/unknown_endpoint", "GET")
                            },
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("Test 404", fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        if (lastResponse == null) {
            item {
                Box(
                    modifier = Modifier.fillMaxWidth().height(200.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No API Gateway response captured yet. Send a request or select a tab to inspect.", color = Color.Gray)
                }
            }
        } else {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("HTTP Status: ${lastResponse.statusCode} ${lastResponse.statusText}", fontWeight = FontWeight.Bold)
                    Text("Latency: ${lastResponse.responseTimeMs}ms", style = MaterialTheme.typography.bodySmall.copy(color = SpiritualTeal, fontWeight = FontWeight.Bold))
                }
            }

            item {
                Text("Response Headers:", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(10.dp)) {
                        lastResponse.responseHeaders.forEach { (k, v) ->
                            Text("$k: $v", style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace))
                        }
                    }
                }
            }

            item {
                Text("JSON Payload:", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = Color(0xFF1E1E1E),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        lastResponse.jsonBody,
                        modifier = Modifier.padding(10.dp),
                        style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFFE0E0E0), fontFamily = FontFamily.Monospace)
                    )
                }
            }
        }
    }
}
