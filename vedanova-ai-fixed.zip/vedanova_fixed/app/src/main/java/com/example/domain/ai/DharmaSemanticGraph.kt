package com.example.domain.ai

data class DharmaGraphNode(
    val id: String,
    val name: String,
    val bengaliName: String,
    val category: String, // "DEITY", "SCRIPTURE", "CONCEPT", "MANTRA", "TRADITION", "FESTIVAL"
    val description: String,
    val relatedNodeIds: List<String> = emptyList(),
    val primaryScriptures: List<String> = emptyList(),
    val canonicalVerses: List<String> = emptyList(),
    val keyPractices: List<String> = emptyList()
)

object DharmaSemanticGraph {

    private val nodes = listOf(
        DharmaGraphNode(
            id = "krishna",
            name = "Lord Krishna",
            bengaliName = "শ্রীকৃষ্ণ",
            category = "DEITY",
            description = "Supreme Personality of Godhead, speaker of the Bhagavad Gita, avatar of Vishnu.",
            relatedNodeIds = listOf("gita", "gita_ch2", "bhagavata", "vaishnavism", "mahamantra", "janmashtami"),
            primaryScriptures = listOf("Bhagavad Gita", "Srimad Bhagavatam (10th Canto)", "Mahabharata"),
            canonicalVerses = listOf("Gita 2.47", "Gita 4.7-8", "Gita 9.22", "Gita 18.66"),
            keyPractices = listOf("Namasmarana", "Bhakti Yoga", "Nishkama Karma", "Janmashtami Vrata")
        ),
        DharmaGraphNode(
            id = "gita",
            name = "Bhagavad Gita",
            bengaliName = "শ্রীমদ্ভগবদ্গীতা",
            category = "SCRIPTURE",
            description = "700-verse Hindu scripture that is part of the epic Mahabharata, spoken by Krishna to Arjuna.",
            relatedNodeIds = listOf("krishna", "gita_ch2", "nishkama_karma", "advaita", "vaishnavism", "moksha"),
            primaryScriptures = listOf("Mahabharata Bhishma Parva (Chapters 23–40)"),
            canonicalVerses = listOf("Chapter 2 (Sankhya)", "Chapter 9 (Raja Vidya)", "Chapter 18 (Moksha Sanyasa)"),
            keyPractices = listOf("Gita Swadhyaya (Daily Reading)", "Nishkama Karma Yoga", "Dhyana Yoga")
        ),
        DharmaGraphNode(
            id = "gita_ch2",
            name = "Gita Chapter 2 (Sankhya Yoga)",
            bengaliName = "গীতা ২য় অধ্যায় (সাংখ্য যোগ)",
            category = "CONCEPT",
            description = "Core philosophical foundation: immortality of the Atman, Sthitaprajna lakshana, and Nishkama Karma.",
            relatedNodeIds = listOf("gita", "krishna", "nishkama_karma", "atman"),
            primaryScriptures = listOf("Bhagavad Gita 2.11-72"),
            canonicalVerses = listOf("BG 2.20 (Na Jayate Mriyate)", "BG 2.47 (Karmanye Vadhikaraste)", "BG 2.56 (Sthitaprajna)"),
            keyPractices = listOf("Selfless Action", "Sense Mastery", "Atma Vichara")
        ),
        DharmaGraphNode(
            id = "shiva",
            name = "Lord Shiva",
            bengaliName = "মহাদেব শিব",
            category = "DEITY",
            description = "The Supreme Cosmic Transformer (Mahadeva), embodiment of asceticism, bliss, and supreme consciousness.",
            relatedNodeIds = listOf("mahamrityunjaya", "panchakshara", "shivaratri", "shaivism", "upanishads"),
            primaryScriptures = listOf("Shvetashvatara Upanishad", "Shiva Purana", "Rudram (Yajurveda)"),
            canonicalVerses = listOf("Rigveda 7.59.12 (Tryambakam)", "Yajurveda Shri Rudram"),
            keyPractices = listOf("Maha Shivaratri Vrata", "Maha Mrityunjaya Japa", "Bilva Patra Archana", "Dhyana")
        ),
        DharmaGraphNode(
            id = "mahamrityunjaya",
            name = "Maha Mrityunjaya Mantra",
            bengaliName = "মহামৃত্যুঞ্জয় মন্ত্র",
            category = "MANTRA",
            description = "Vedic life-nourishing mantra from the Rigveda dedicated to Tryambaka (Shiva) for health, spiritual liberation, and overcoming fear of death.",
            relatedNodeIds = listOf("shiva", "rigveda", "moksha", "shaivism"),
            primaryScriptures = listOf("Rigveda Mandala 7, Sukta 59, Rik 12", "Taittiriya Samhita"),
            canonicalVerses = listOf("ॐ त्र्यम्बकं यजामहे सुगन्धिं पुष्टिवर्धनम्। उर्वारुकमिव बन्धनान्मृत्यschemaोर्मुक्षीय मामृतात्॥"),
            keyPractices = listOf("Daily Japa (108 times)", "Rudra Abhisheka", "Pradosha Puja")
        ),
        DharmaGraphNode(
            id = "durga",
            name = "Maa Durga",
            bengaliName = "মা দুর্গা",
            category = "DEITY",
            description = "Supreme Primordial Energy (Mahashakti / Adishakti), protector of Dharma and slayer of Mahishasura.",
            relatedNodeIds = listOf("chandi", "navaratri", "shakta", "durgamantra"),
            primaryScriptures = listOf("Devi Mahatmya (Markandeya Purana)", "Devi Bhagavata Purana"),
            canonicalVerses = listOf("Sarva Mangala Mangalye", "Ya Devi Sarvabhuteshu"),
            keyPractices = listOf("Sharadiya & Vasanti Navaratri", "Chandi Patha", "Kumari Puja", "Pushpanjali")
        ),
        DharmaGraphNode(
            id = "chandi",
            name = "Devi Mahatmya (Sri Sri Chandi)",
            bengaliName = "দেবী মাহাত্ম্য (শ্রীশ্রীচণ্ডী)",
            category = "SCRIPTURE",
            description = "700-verse Shakta scripture detailing the exploits of Divine Mother against Mahishasura, Shumbha, and Nishumbha.",
            relatedNodeIds = listOf("durga", "shakta", "navaratri"),
            primaryScriptures = listOf("Markandeya Purana Chapters 81–93"),
            canonicalVerses = listOf("Argala Stotra", "Kilaka Stotra", "Devi Kavacha", "Aparajita Stotra"),
            keyPractices = listOf("Navaratri Chandi Patha", "Homa", "Arati")
        ),
        DharmaGraphNode(
            id = "gayatri",
            name = "Gayatri Mantra",
            bengaliName = "গায়ত্রী মন্ত্র",
            category = "MANTRA",
            description = "Supreme Vedic solar mantra addressing Savitr for spiritual illumination and wisdom.",
            relatedNodeIds = listOf("rigveda", "upanishads", "sandhyavandanam"),
            primaryScriptures = listOf("Rigveda 3.62.10", "Yajurveda", "Chandogya Upanishad"),
            canonicalVerses = listOf("ॐ भूर्भुवः स्वः तत्सवितुर्वरेण्यं भर्गो देवस्य धीमहि धियो यो नः प्रचोदयात्॥"),
            keyPractices = listOf("Sandhyavandanam (Tri-Sandhya)", "Daily Gayatri Japa", "Pranayama")
        ),
        DharmaGraphNode(
            id = "advaita",
            name = "Advaita Vedanta",
            bengaliName = "অদ্বৈত বেদান্ত",
            category = "TRADITION",
            description = "Non-dual school of Indian philosophy systematized by Adi Shankaracharya, affirming Atman is non-different from Brahman.",
            relatedNodeIds = listOf("upanishads", "gita", "brahman", "atman", "moksha"),
            primaryScriptures = listOf("Prasthanatrayi (Upanishads, Bhagavad Gita, Brahma Sutras)"),
            canonicalVerses = listOf("Tat Tvam Asi (Chandogya 6.8.7)", "Aham Brahmasmi (Brihadaranyaka 1.4.10)"),
            keyPractices = listOf("Shravana", "Manana", "Nididhyasana", "Viveka & Vairagya")
        ),
        DharmaGraphNode(
            id = "upanishads",
            name = "Mukhya Upanishads",
            bengaliName = "মুখ্য উপনিষদ",
            category = "SCRIPTURE",
            description = "The philosophical essence (Vedanta) of the Vedas containing timeless wisdom on Brahman, Atman, and Moksha.",
            relatedNodeIds = listOf("advaita", "gayatri", "brahman", "moksha"),
            primaryScriptures = listOf("Isha, Kena, Katha, Prashna, Mundaka, Mandukya, Taittiriya, Aitareya, Chandogya, Brihadaranyaka"),
            canonicalVerses = listOf("Isha 1 (Ishavasyam Idam Sarvam)", "Katha 1.3.14 (Uttishthata Jagrata)"),
            keyPractices = listOf("Swadhyaya", "Guru Seva", "Meditation on Om")
        )
    )

    fun findNode(keyword: String): DharmaGraphNode? {
        val clean = keyword.lowercase().trim()
        return nodes.firstOrNull { node ->
            node.id.equals(clean, ignoreCase = true) ||
            node.name.contains(clean, ignoreCase = true) ||
            node.bengaliName.contains(clean, ignoreCase = true) ||
            node.primaryScriptures.any { it.contains(clean, ignoreCase = true) }
        }
    }

    fun findRelatedNodes(query: String): List<DharmaGraphNode> {
        val clean = query.lowercase().trim()
        val matched = nodes.filter { node ->
            node.name.contains(clean, ignoreCase = true) ||
            node.bengaliName.contains(clean, ignoreCase = true) ||
            node.id.contains(clean, ignoreCase = true) ||
            clean.contains(node.id) ||
            clean.contains(node.bengaliName)
        }

        if (matched.isNotEmpty()) {
            val relatedIds = matched.flatMap { it.relatedNodeIds }.toSet()
            val related = nodes.filter { it.id in relatedIds }
            return (matched + related).distinctBy { it.id }.take(5)
        }

        return nodes.take(3)
    }

    fun getAllNodes(): List<DharmaGraphNode> = nodes
}
