package com.example.data.repository

import com.example.data.dao.*
import com.example.data.local.InitialKnowledgeData
import com.example.data.local.VedaNovaDatabase
import com.example.data.model.*
import com.example.domain.ai.AiOrchestrator
import com.example.domain.ai.AiSelfDiagnosticEngine
import com.example.domain.ai.OrchestratedResponse
import com.example.domain.ai.SelfDiagnosticReport
import com.example.domain.api.ApiGatewayRequest
import com.example.domain.api.ApiGatewayResponse
import com.example.domain.api.VedaNovaApiGateway
import com.example.domain.auth.AdminAuthManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.Flow
import kotlinx.coroutines.withContext

class VedaNovaRepository(
    private val database: VedaNovaDatabase
) {
    val knowledgeDao = database.knowledgeDao()
    val apiKeyDao = database.apiKeyDao()
    val apiLogDao = database.apiLogDao()
    val issueDao = database.issueDao()
    val reportDao = database.reportDao()
    val auditLogDao = database.auditLogDao()
    val systemLogDao = database.systemLogDao()
    val adminUserDao = database.adminUserDao()
    val systemSettingDao = database.systemSettingDao()
    val backupDao = database.backupDao()
    val capabilityProposalDao = database.capabilityProposalDao()
    val dailyJobLogDao = database.dailyJobLogDao()
    val externalAppDao = database.externalAppDao()
    val unknownKnowledgeDao = database.unknownKnowledgeDao()
    val knowledgeVersionDao = database.knowledgeVersionDao()
    val knowledgeUsageLogDao = database.knowledgeUsageLogDao()
    val crashReportDao = database.crashReportDao()
    val functionActivityLogDao = database.functionActivityLogDao()
    val researchSourceDao = database.researchSourceDao()
    val researchIssueDao = database.researchIssueDao()
    val knowledgeCandidateDao = database.knowledgeCandidateDao()
    val researchCacheDao = database.researchCacheDao()
    val researchActivityLogDao = database.researchActivityLogDao()

    val aiOrchestrator = AiOrchestrator(knowledgeDao)
    val harvestingEngine = com.example.domain.research.KnowledgeHarvestingEngine(
        knowledgeDao,
        knowledgeCandidateDao,
        researchIssueDao,
        researchCacheDao,
        researchActivityLogDao
    )
    val apiGateway = VedaNovaApiGateway(apiKeyDao, apiLogDao, knowledgeDao, aiOrchestrator, capabilityProposalDao)
    val adminAuthManager = AdminAuthManager(adminUserDao, auditLogDao)
    val selfDiagnosticEngine = AiSelfDiagnosticEngine()
    val remoteHttpClient = com.example.domain.api.VedaNovaRemoteHttpClient(apiGateway)

    // Flows
    val allKnowledge: Flow<List<KnowledgeEntity>> = knowledgeDao.getAllKnowledge()
    val publishedKnowledge: Flow<List<KnowledgeEntity>> = knowledgeDao.getPublishedKnowledge()
    val candidateKnowledge: Flow<List<KnowledgeEntity>> = knowledgeDao.getCandidateKnowledge()
    val allUnknownKnowledge: Flow<List<UnknownKnowledgeEntity>> = unknownKnowledgeDao.getAllUnknown()
    val pendingUnknownKnowledge: Flow<List<UnknownKnowledgeEntity>> = unknownKnowledgeDao.getPendingUnknown()
    val pendingUnknownCount: Flow<Int> = unknownKnowledgeDao.getPendingCount()
    val allKnowledgeVersions: Flow<List<KnowledgeVersionEntity>> = knowledgeVersionDao.getAllVersions()
    val allUsageLogs: Flow<List<KnowledgeUsageLogEntity>> = knowledgeUsageLogDao.getAllUsageLogs()
    val allApiKeys: Flow<List<ApiKeyEntity>> = apiKeyDao.getAllApiKeys()
    val activeApiKeys: Flow<List<ApiKeyEntity>> = apiKeyDao.getActiveApiKeys()
    val recentApiLogs: Flow<List<ApiLogEntity>> = apiLogDao.getRecentLogs()
    val allIssues: Flow<List<IssueEntity>> = issueDao.getAllIssues()
    val allReports: Flow<List<ReportEntity>> = reportDao.getAllReports()
    val recentAuditLogs: Flow<List<AuditLogEntity>> = auditLogDao.getRecentAuditLogs()
    val recentSystemLogs: Flow<List<SystemLogEntity>> = systemLogDao.getRecentSystemLogs()
    val allUsers: Flow<List<AdminUserEntity>> = adminUserDao.getAllUsers()
    val allSettings: Flow<List<SystemSettingEntity>> = systemSettingDao.getAllSettings()
    val allBackups: Flow<List<BackupEntity>> = backupDao.getAllBackups()
    val draftKnowledgeItems: Flow<List<KnowledgeEntity>> = knowledgeDao.getKnowledgeByStatus("Draft")
    val allExternalApps: Flow<List<ExternalAppEntity>> = externalAppDao.getAllApps()
    val allCapabilityProposals: Flow<List<CapabilityProposalEntity>> = capabilityProposalDao.getAllProposals()
    val recentDailyJobLogs: Flow<List<DailyJobLogEntity>> = dailyJobLogDao.getRecentJobLogs()
    val recentCrashReports: Flow<List<CrashReportEntity>> = crashReportDao.getRecentCrashReports()
    val totalCrashCount: Flow<Int> = crashReportDao.getCrashCount()
    val recentActivityLogs: Flow<List<FunctionActivityLogEntity>> = functionActivityLogDao.getRecentActivityLogs()

    // Phase 6 Research Flows
    val allResearchSources: Flow<List<ResearchSourceEntity>> = researchSourceDao.getAllSources()
    val allResearchIssues: Flow<List<ResearchIssueEntity>> = researchIssueDao.getAllIssues()
    val openResearchIssues: Flow<List<ResearchIssueEntity>> = researchIssueDao.getOpenIssues()
    val openResearchIssuesCount: Flow<Int> = researchIssueDao.getOpenIssuesCount()
    val allKnowledgeCandidates: Flow<List<KnowledgeCandidateEntity>> = knowledgeCandidateDao.getAllCandidates()
    val pendingCandidates: Flow<List<KnowledgeCandidateEntity>> = knowledgeCandidateDao.getPendingCandidates()
    val pendingCandidatesCount: Flow<Int> = knowledgeCandidateDao.getPendingCandidatesCount()
    val recentResearchActivityLogs: Flow<List<ResearchActivityLogEntity>> = researchActivityLogDao.getRecentActivityLogs()

    // Counts
    val knowledgeCount = knowledgeDao.getKnowledgeCount()
    val totalLogsCount = apiLogDao.getTotalLogsCount()
    val failedLogsCount = apiLogDao.getFailedLogsCount()
    val averageResponseTime = apiLogDao.getAverageResponseTime()
    val pendingIssuesCount = issueDao.getPendingIssuesCount()


    suspend fun processAiQuery(query: String, temp: Float = 0.2f): OrchestratedResponse {
        val response = aiOrchestrator.processQuery(query, temperature = temp)
        handleResponseKnowledgeSideEffects(query, response)
        return response
    }

    suspend fun processAiConversationTurn(
        query: String,
        history: List<Pair<String, String>> = emptyList(),
        temp: Float = 0.2f
    ): OrchestratedResponse {
        val response = aiOrchestrator.processConversationTurn(query = query, history = history, temperature = temp)
        handleResponseKnowledgeSideEffects(query, response)
        return response
    }

    private suspend fun handleResponseKnowledgeSideEffects(query: String, response: OrchestratedResponse) {
        // If query was matched to published knowledge, record usage log
        response.matchedKnowledgeEntity?.let { matched ->
            knowledgeDao.incrementUsage(matched.id)
            knowledgeUsageLogDao.insertUsageLog(
                KnowledgeUsageLogEntity(
                    knowledgeId = matched.id,
                    userQuery = query,
                    matchedStrategy = response.matchStrategy,
                    confidence = response.diagnosticInfo.confidenceScore
                )
            )
        }

        // If unknown query flow triggered, record in Unknown Knowledge Queue & Research Issue Center
        if (response.isUnknownQuery) {
            recordUnknownQuery(
                userQuestion = query,
                aiResponse = response.answer,
                whyUnknown = response.diagnosticInfo.diagnosticSummary,
                searchResultStatus = "EXHAUSTED_NO_MATCH",
                suggestedCategory = response.diagnosticInfo.intentDetected
            )

            if (response.researchUsed) {
                harvestingEngine.createResearchIssueReport(
                    userQuery = query,
                    normalizedQuery = query.trim().lowercase(),
                    language = response.diagnosticInfo.languageDetected,
                    intent = response.diagnosticInfo.intentDetected,
                    reason = response.diagnosticInfo.diagnosticSummary,
                    sourcesFound = response.webSources.size,
                    sourcesVerified = response.webSources.count { it.verificationStatus == "VERIFIED" },
                    conflictDetected = response.conflictAnalysis != null,
                    confidence = response.diagnosticInfo.confidenceScore
                )
                harvestingEngine.logResearchActivity(
                    userQuery = query,
                    searchQueries = query,
                    providersUsed = "WebResearchProvider, YouTubeResearchProvider",
                    sourcesFound = response.webSources.size,
                    sourcesAccepted = 0,
                    sourcesRejected = response.webSources.size,
                    verificationResult = "UNVERIFIED",
                    confidence = response.diagnosticInfo.confidenceScore,
                    durationMs = response.diagnosticInfo.responseTimeMs,
                    finalDecision = "REPORTED_TO_ADMIN_ISSUES"
                )
            }
        }

        // If Phase 6 Research was used and verified, create Knowledge Candidate & Log
        if (response.researchUsed && !response.isUnknownQuery && response.webSources.isNotEmpty()) {
            val topSrc = response.webSources.first()
            val candidate = harvestingEngine.createKnowledgeCandidate(
                title = query.take(60),
                question = query,
                answer = response.answer,
                category = response.diagnosticInfo.intentDetected,
                language = response.diagnosticInfo.languageDetected,
                sourceIds = response.webSources.joinToString(", ") { it.sourceId },
                scripture = topSrc.title,
                reference = topSrc.publicationDate,
                sanskritText = response.sanskritVerse ?: "",
                transliteration = response.transliteration ?: "",
                bengaliMeaning = topSrc.excerpt,
                englishMeaning = topSrc.excerpt,
                sourceTier = topSrc.sourceTier,
                confidence = response.diagnosticInfo.confidenceScore,
                verificationStatus = "VERIFIED",
                conflictNotes = if (response.conflictAnalysis != null) "Multi-tradition perspectives noted" else "Consensus Verified",
                sampradayaNotes = response.conflictAnalysis?.coreDifference ?: "Sanatan Canonical Tradition"
            )

            // Save sources
            response.webSources.forEach { src ->
                researchSourceDao.insertSource(src)
            }

            harvestingEngine.logResearchActivity(
                userQuery = query,
                searchQueries = query,
                providersUsed = "WebResearchProvider, YouTubeResearchProvider",
                sourcesFound = response.webSources.size,
                sourcesAccepted = response.webSources.count { it.verificationStatus == "VERIFIED" },
                sourcesRejected = 0,
                verificationResult = "VERIFIED",
                confidence = response.diagnosticInfo.confidenceScore,
                durationMs = response.diagnosticInfo.responseTimeMs,
                finalDecision = "CANDIDATE_HARVESTED_${candidate.candidateId}"
            )
        }

        // If AI generated a candidate from standard reasoning
        response.knowledgeCandidate?.let { candidate ->
            insertDraftCandidate(candidate)
        }
    }

    suspend fun recordUnknownQuery(
        userQuestion: String,
        aiResponse: String,
        whyUnknown: String,
        searchResultStatus: String,
        suggestedCategory: String
    ): Long {
        val cleanQ = userQuestion.trim()
        val existing = unknownKnowledgeDao.findByQuestion(cleanQ)
        return if (existing != null) {
            val updated = existing.copy(
                frequency = existing.frequency + 1,
                aiResponse = aiResponse,
                whyUnknown = whyUnknown
            )
            unknownKnowledgeDao.updateUnknown(updated)
            existing.id
        } else {
            val entity = UnknownKnowledgeEntity(
                userQuestion = cleanQ,
                aiResponse = aiResponse,
                whyUnknown = whyUnknown,
                searchResultStatus = searchResultStatus,
                suggestedCategory = suggestedCategory
            )
            val id = unknownKnowledgeDao.insertUnknown(entity)
            adminAuthManager.recordAudit("Unknown Query Queued", "KNOWLEDGE_UNKNOWN", id.toString(), "Queued unknown query for teacher review: ${cleanQ.take(50)}")
            id
        }
    }

    suspend fun teachFromUnknownQuery(
        unknownId: Long,
        question: String,
        answer: String,
        category: String,
        source: String,
        reference: String,
        saveAsCandidate: Boolean
    ): Long {
        val status = if (saveAsCandidate) "CANDIDATE" else "PUBLISHED"
        val code = "KB-" + (1000..9999).random()
        val knowledge = KnowledgeEntity(
            knowledgeCode = code,
            title = question.take(60),
            question = question,
            answer = answer,
            category = category,
            language = "BENGALI",
            banglaMeaning = answer,
            source = source.ifBlank { "ADMIN_TAUGHT" },
            reference = reference.ifBlank { "Admin Verified Reference" },
            verificationStatus = status,
            confidenceScore = 1.0f,
            version = 1,
            createdBy = "Admin (from Unknown Queue)",
            updatedBy = "Admin"
        )
        val knowledgeId = knowledgeDao.insertKnowledge(knowledge)

        // Create version 1 record
        knowledgeVersionDao.insertVersion(
            KnowledgeVersionEntity(
                knowledgeId = knowledgeId,
                versionNumber = 1,
                title = knowledge.title,
                question = knowledge.question,
                answer = knowledge.answer,
                category = knowledge.category,
                source = knowledge.source,
                reference = knowledge.reference,
                changedBy = "Admin",
                changeReason = "Taught from Unknown Query Queue",
                diffSummary = "Initial authoritative entry v1."
            )
        )

        // Resolve unknown queue entry
        val unknown = unknownKnowledgeDao.getById(unknownId)
        if (unknown != null) {
            unknownKnowledgeDao.updateUnknown(
                unknown.copy(
                    status = if (saveAsCandidate) "CANDIDATE_CREATED" else "RESOLVED",
                    resolvedAt = System.currentTimeMillis(),
                    resolvedKnowledgeId = knowledgeId
                )
            )
        }

        adminAuthManager.recordAudit(
            action = if (saveAsCandidate) "Candidate Created from Unknown" else "Published Taught Knowledge",
            targetType = "KNOWLEDGE",
            targetId = knowledgeId.toString(),
            details = "Admin taught response for: ${question.take(40)} (Status: $status)"
        )
        return knowledgeId
    }

    suspend fun publishCandidate(item: KnowledgeEntity) {
        val currentVersion = item.version
        val newVersionNumber = currentVersion + 1
        val published = item.copy(
            verificationStatus = "PUBLISHED",
            confidenceScore = 1.0f,
            version = newVersionNumber,
            updatedBy = "Admin (Approved & Published)",
            updatedDate = System.currentTimeMillis()
        )
        knowledgeDao.updateKnowledge(published)

        // Create version record
        knowledgeVersionDao.insertVersion(
            KnowledgeVersionEntity(
                knowledgeId = item.id,
                versionNumber = newVersionNumber,
                title = published.title,
                question = published.question,
                answer = published.answer,
                category = published.category,
                source = published.source,
                reference = published.reference,
                changedBy = "Admin",
                changeReason = "Approved and published to production AI retrieval",
                diffSummary = "Promoted candidate to canonical published version v$newVersionNumber."
            )
        )

        adminAuthManager.recordAudit("Approved Knowledge Candidate", "KNOWLEDGE", item.id.toString(), "Promoted candidate to canonical published knowledge v$newVersionNumber: ${item.title}")
    }

    suspend fun insertDraftCandidate(candidate: KnowledgeEntity): Long {
        val id = knowledgeDao.insertKnowledge(candidate)
        adminAuthManager.recordAudit("AI Draft Candidate", "KNOWLEDGE", id.toString(), "AI suggested new candidate for review: ${candidate.title}")
        return id
    }

    suspend fun approveDraftKnowledge(item: KnowledgeEntity) = publishCandidate(item)

    suspend fun rejectDraftKnowledge(item: KnowledgeEntity) {
        val rejected = item.copy(
            verificationStatus = "Rejected",
            updatedBy = "Admin (Rejected)",
            updatedDate = System.currentTimeMillis()
        )
        knowledgeDao.updateKnowledge(rejected)
        adminAuthManager.recordAudit("Rejected Knowledge Candidate", "KNOWLEDGE", item.id.toString(), "Rejected draft candidate: ${item.title}")
    }

    suspend fun executeGatewayRequest(request: ApiGatewayRequest): ApiGatewayResponse {
        return apiGateway.executeRequest(request)
    }

    suspend fun runSelfDiagnostics(query: String, response: String, orchestrated: OrchestratedResponse): SelfDiagnosticReport {
        val matches = knowledgeDao.findMatchingPublishedKnowledge(query)
        return selfDiagnosticEngine.diagnoseInteraction(query, response, orchestrated.diagnosticInfo, matches)
    }

    // Knowledge Operations
    suspend fun insertKnowledge(item: KnowledgeEntity): Long {
        val id = knowledgeDao.insertKnowledge(item)
        adminAuthManager.recordAudit("Created Knowledge", "KNOWLEDGE", id.toString(), "Added knowledge item: ${item.title}")
        return id
    }

    suspend fun updateKnowledge(item: KnowledgeEntity) {
        knowledgeDao.updateKnowledge(item)
        adminAuthManager.recordAudit("Updated Knowledge", "KNOWLEDGE", item.id.toString(), "Modified knowledge: ${item.title} (Status: ${item.verificationStatus})")
    }

    suspend fun deleteKnowledge(item: KnowledgeEntity) {
        knowledgeDao.deleteKnowledge(item)
        adminAuthManager.recordAudit("Deleted Knowledge", "KNOWLEDGE", item.id.toString(), "Removed knowledge item: ${item.title}")
    }

    // API Key Operations
    suspend fun createApiKey(
        name: String,
        appName: String,
        version: String,
        rateLimit: Int,
        dailyLimit: Int,
        monthlyLimit: Int,
        permissions: String,
        expiresInDays: Int = 0 // 0 = No Expiry
    ): Long {
        val randomHex = (1..6).map { ('a'..'f').random() }.joinToString("") + (1000..9999).random()
        val key = "vn_live_${randomHex}"
        val masked = "vn_live_••••••••${key.takeLast(4)}"
        val expiryTimestamp = if (expiresInDays > 0) {
            System.currentTimeMillis() + (expiresInDays.toLong() * 24 * 60 * 60 * 1000L)
        } else 0L

        val entity = ApiKeyEntity(
            name = name,
            appName = appName,
            apiKey = key,
            maskedKey = masked,
            version = version,
            status = "Active",
            permissions = permissions,
            rateLimitPerMin = rateLimit,
            dailyLimit = dailyLimit,
            monthlyLimit = monthlyLimit,
            expiresAt = expiryTimestamp,
            createdAt = System.currentTimeMillis()
        )
        val id = apiKeyDao.insertApiKey(entity)
        adminAuthManager.recordAudit("Created API Key", "API", id.toString(), "Created key: $name for $appName (Expires: ${if (expiresInDays > 0) "$expiresInDays days" else "Never"})")
        return id
    }

    suspend fun extendApiKeyExpiry(key: ApiKeyEntity, additionalDays: Int) {
        val baseTime = if (key.expiresAt > System.currentTimeMillis()) key.expiresAt else System.currentTimeMillis()
        val newExpiry = baseTime + (additionalDays.toLong() * 24 * 60 * 60 * 1000L)
        val updated = key.copy(
            expiresAt = newExpiry,
            status = if (key.status.equals("EXPIRED", ignoreCase = true)) "Active" else key.status
        )
        apiKeyDao.updateApiKey(updated)
        adminAuthManager.recordAudit("EXTEND_API_KEY", "API", key.id.toString(), "Extended validity of '${key.name}' by $additionalDays days.")
    }

    suspend fun rotateApiKey(key: ApiKeyEntity) {
        val randomHex = (1..6).map { ('a'..'f').random() }.joinToString("") + (1000..9999).random()
        val newKey = "vn_live_${randomHex}"
        val masked = "vn_live_••••••••${newKey.takeLast(4)}"
        val updated = key.copy(apiKey = newKey, maskedKey = masked)
        apiKeyDao.updateApiKey(updated)
        adminAuthManager.recordAudit("Rotated API Key", "API", key.id.toString(), "Rotated key for ${key.name}")
    }

    suspend fun updateApiKeyStatus(key: ApiKeyEntity, newStatus: String) {
        val updated = key.copy(status = newStatus)
        apiKeyDao.updateApiKey(updated)
        adminAuthManager.recordAudit("Updated API Status", "API", key.id.toString(), "Changed status of ${key.name} to $newStatus")
    }

    suspend fun deleteApiKey(key: ApiKeyEntity) {
        apiKeyDao.deleteApiKey(key)
        adminAuthManager.recordAudit("Deleted API Key", "API", key.id.toString(), "Deleted key: ${key.name}")
    }

    // Issue operations
    suspend fun insertIssue(issue: IssueEntity): Long {
        val id = issueDao.insertIssue(issue)
        adminAuthManager.recordAudit("Created Issue", "ISSUE", issue.issueCode, "Logged issue: ${issue.title}")
        return id
    }

    suspend fun updateIssue(issue: IssueEntity) {
        issueDao.updateIssue(issue)
        adminAuthManager.recordAudit("Updated Issue", "ISSUE", issue.issueCode, "Updated issue status: ${issue.status}")
    }

    suspend fun submitUserFeedback(feedbackText: String, messageSnippet: String): Long {
        val randomCode = "ISS-FB-" + (1000..9999).random()
        val issue = IssueEntity(
            issueCode = randomCode,
            title = "User Reported Feedback / Correction Request",
            category = "AI Wrong Answer",
            severity = "Medium",
            status = "Open",
            description = "User Feedback: $feedbackText\n\nAI Response Snippet: $messageSnippet",
            userQuery = feedbackText,
            aiResponse = messageSnippet,
            assignedAdmin = "Unassigned (Pending Review)"
        )
        val id = issueDao.insertIssue(issue)
        adminAuthManager.recordAudit("User Feedback Filed", "ISSUE", randomCode, "Feedback submitted for review: ${feedbackText.take(40)}")
        return id
    }

    suspend fun createResearchTaskFromGap(gap: com.example.domain.ai.KnowledgeGapItem): Long {
        val randomCode = "GAP-RES-" + (1000..9999).random()
        val draftCandidate = KnowledgeEntity(
            title = gap.topic,
            category = gap.category,
            subcategory = "Knowledge Gap Research Task",
            language = "Bengali (বাংলা)",
            sanskritText = "",
            transliteration = "",
            banglaMeaning = "গবেষণা টাস্ক: ${gap.bengaliTopic}। ${gap.reason}",
            englishMeaning = "Research Task for: ${gap.topic}",
            explanation = "Action Plan: ${gap.suggestedAction}\nCoverage: ${gap.currentCoverage}\nDemand Level: ${gap.demandLevel}",
            scripture = "Pending Canonical Research",
            chapter = "",
            verse = "",
            reference = "Admin Created Gap Task",
            source = "VedaNova Autonomous Gap Detection",
            sourceType = "Academic",
            verificationStatus = "Draft",
            confidenceScore = 0.75f,
            tags = "${gap.category}, Gap Research, Continuous Improvement",
            createdBy = "Admin (from Knowledge Gap Engine)",
            updatedBy = "Pending Research"
        )
        val id = knowledgeDao.insertKnowledge(draftCandidate)
        adminAuthManager.recordAudit("Created Research Task", "KNOWLEDGE_GAP", gap.id, "Created draft research task for gap: ${gap.topic}")
        return id
    }

    // Report operations
    suspend fun insertReport(report: ReportEntity): Long {
        val id = reportDao.insertReport(report)
        adminAuthManager.recordAudit("Submitted Report", "REPORT", report.reportCode, "New report: ${report.title}")
        return id
    }

    suspend fun updateReport(report: ReportEntity) {
        reportDao.updateReport(report)
        adminAuthManager.recordAudit("Updated Report", "REPORT", report.reportCode, "Report status set to: ${report.status}")
    }

    // Backup operations
    suspend fun createBackup(name: String, type: String) = withContext(Dispatchers.IO) {
        val backupEntity = BackupEntity(
            backupName = name.ifBlank { "VedaNova_Snapshot_${System.currentTimeMillis()}" },
            backupType = type,
            recordCount = 150,
            sizeKb = 520,
            status = "Verified",
            checksum = "sha256_${System.currentTimeMillis()}"
        )
        backupDao.insertBackup(backupEntity)
        adminAuthManager.recordAudit("Created Backup", "BACKUP", backupEntity.backupName, "Database snapshot created successfully.")
    }

    suspend fun restoreDefaultSeedData() = withContext(Dispatchers.IO) {
        knowledgeDao.insertAllKnowledge(InitialKnowledgeData.initialKnowledge)
        adminAuthManager.recordAudit("Restored Seed Data", "DATABASE", "SEED", "Repopulated verified core knowledge items.")
    }

    suspend fun updateSetting(key: String, value: String) {
        val existing = systemSettingDao.getSetting(key)
        if (existing != null) {
            systemSettingDao.insertSetting(existing.copy(value = value, updatedAt = System.currentTimeMillis()))
            adminAuthManager.recordAudit("Updated Setting", "SETTING", key, "Changed $key to '$value'")
        }
    }

    // Phase 4: External Apps & Capability Proposal Operations
    suspend fun approveCapabilityProposal(proposal: CapabilityProposalEntity, notes: String = "Approved by Admin") {
        val approved = proposal.copy(
            status = "ACTIVE",
            reviewedAt = System.currentTimeMillis(),
            reviewedByAdmin = "superadmin",
            reviewNotes = notes
        )
        capabilityProposalDao.updateProposal(approved)
        adminAuthManager.recordAudit("APPROVE_CAPABILITY", "CAPABILITY", proposal.capabilityCode, "Approved dynamic capability proposal '${proposal.name}' for integration.")
    }

    suspend fun rejectCapabilityProposal(proposal: CapabilityProposalEntity, notes: String = "Rejected by Admin") {
        val rejected = proposal.copy(
            status = "REJECTED",
            reviewedAt = System.currentTimeMillis(),
            reviewedByAdmin = "superadmin",
            reviewNotes = notes
        )
        capabilityProposalDao.updateProposal(rejected)
        adminAuthManager.recordAudit("REJECT_CAPABILITY", "CAPABILITY", proposal.capabilityCode, "Rejected capability proposal '${proposal.name}': $notes")
    }

    suspend fun disableCapabilityProposal(proposal: CapabilityProposalEntity) {
        val disabled = proposal.copy(
            status = "DISABLED",
            reviewedAt = System.currentTimeMillis()
        )
        capabilityProposalDao.updateProposal(disabled)
        adminAuthManager.recordAudit("DISABLE_CAPABILITY", "CAPABILITY", proposal.capabilityCode, "Disabled capability '${proposal.name}'.")
    }

    suspend fun updateAppStatus(app: ExternalAppEntity, newStatus: String) {
        val updated = app.copy(status = newStatus)
        externalAppDao.updateApp(updated)
        adminAuthManager.recordAudit(
            if (newStatus == "ACTIVE") "ENABLE_APP" else "SUSPEND_APP",
            "EXTERNAL_APP",
            app.appId,
            "Changed application '${app.appName}' status to $newStatus"
        )
    }

    suspend fun updateAppScopesAndCapabilities(app: ExternalAppEntity, scopes: String, capabilities: String) {
        val updated = app.copy(allowedScopes = scopes, activeCapabilities = capabilities)
        externalAppDao.updateApp(updated)
        adminAuthManager.recordAudit("CHANGE_SCOPE", "EXTERNAL_APP", app.appId, "Updated scopes to [$scopes] and capabilities to [$capabilities] for ${app.appName}")
    }

    suspend fun updateAppRateLimit(app: ExternalAppEntity, rateLimitPerMin: Int, dailyQuota: Int) {
        val updated = app.copy(rateLimitPerMin = rateLimitPerMin, dailyQuota = dailyQuota)
        externalAppDao.updateApp(updated)
        adminAuthManager.recordAudit("CHANGE_RATE_LIMIT", "EXTERNAL_APP", app.appId, "Updated rate limits for ${app.appName}: $rateLimitPerMin req/min, $dailyQuota req/day")
    }

    suspend fun rotateAppApiKey(app: ExternalAppEntity) {
        val randomHex = (1..6).map { ('a'..'f').random() }.joinToString("") + (1000..9999).random()
        val newKey = "vn_live_app_${app.appId.lowercase().replace("-", "_")}_${randomHex}"
        val masked = "vn_live_app_••••••••${newKey.takeLast(4)}"
        val updated = app.copy(apiKey = newKey, maskedKey = masked)
        externalAppDao.updateApp(updated)
        adminAuthManager.recordAudit("ROTATE_KEY", "EXTERNAL_APP", app.appId, "Rotated API credentials for app '${app.appName}'")
    }

    suspend fun registerExternalApp(
        appName: String,
        developerName: String,
        email: String,
        scopes: String,
        capabilities: String,
        rateLimit: Int,
        dailyQuota: Int
    ): Long {
        val randomNum = (100..999).random()
        val appId = "APP-${appName.take(6).uppercase().replace(" ", "")}-$randomNum"
        val randomHex = (1..6).map { ('a'..'f').random() }.joinToString("") + (1000..9999).random()
        val key = "vn_live_app_${appId.lowercase().replace("-", "_")}_${randomHex}"
        val masked = "vn_live_app_••••••••${key.takeLast(4)}"

        val app = ExternalAppEntity(
            appId = appId,
            appName = appName,
            developerName = developerName,
            contactEmail = email,
            apiKey = key,
            maskedKey = masked,
            status = "ACTIVE",
            apiVersion = "v1.0",
            allowedScopes = scopes,
            activeCapabilities = capabilities,
            rateLimitPerMin = rateLimit,
            dailyQuota = dailyQuota,
            registeredAt = System.currentTimeMillis(),
            lastActiveTimestamp = System.currentTimeMillis()
        )
        val id = externalAppDao.insertApp(app)
        adminAuthManager.recordAudit("REGISTER_APP", "EXTERNAL_APP", appId, "Registered new external developer app '$appName' by $developerName")
        return id
    }

    suspend fun runDailyUpdateJob(region: com.example.domain.ai.CalendarRegion = com.example.domain.ai.CalendarRegion.BANGLADESH_DHAKA): DailyJobLogEntity = withContext(Dispatchers.IO) {
        val start = System.currentTimeMillis()
        val daily = com.example.domain.ai.DailyDataEngine.resolveDailyData(region = region)
        val duration = System.currentTimeMillis() - start

        val log = DailyJobLogEntity(
            jobName = "Dynamic Daily Calendar & Festival Resolution",
            region = region.code,
            gregorianDate = daily.gregorianDateFormatted,
            bengaliDate = "${daily.bengaliDate.dayBangla} ${daily.bengaliDate.monthBangla} ${daily.bengaliDate.yearBangla} (${daily.bengaliDate.dayOfWeekBangla})",
            tithi = daily.bengaliDate.fullTithiTitle,
            festivalToday = daily.todayFestivals.firstOrNull()?.nameBn ?: "নিত্য পূজা ও শাস্ত্রীয় বিধি",
            updatedRecords = 34 + daily.upcomingFestivals.size,
            failedRecords = 0,
            status = "SUCCESS",
            calendarVersion = "v2026.08-surya-siddhanta-drik",
            dataSource = "Verified Astronomical Ephemeris & Canonical Almanac (${daily.region.displayName})",
            verificationStatus = "VERIFIED",
            executionDurationMs = duration.coerceAtLeast(15),
            timestamp = System.currentTimeMillis()
        )
        dailyJobLogDao.insertJobLog(log)
        adminAuthManager.recordAudit("DAILY_UPDATE_JOB", "CALENDAR", region.code, "Executed daily dynamic calendar & festival recalculation job for ${region.displayName}.")
        log
    }

    suspend fun insertCrashReport(crash: CrashReportEntity) = withContext(Dispatchers.IO) {
        crashReportDao.insertCrashReport(crash)
    }

    suspend fun clearAllCrashReports() = withContext(Dispatchers.IO) {
        crashReportDao.deleteAllCrashReports()
        adminAuthManager.recordAudit("CLEAR_CRASH_LOGS", "DIAGNOSTICS", "ALL", "Cleared all recorded crash reports.")
    }

    suspend fun logFunctionActivity(
        functionId: String,
        functionName: String,
        section: String,
        previousScreen: String,
        currentScreen: String,
        adminUser: String = "Super Admin"
    ) = withContext(Dispatchers.IO) {
        val log = FunctionActivityLogEntity(
            functionId = functionId,
            functionName = functionName,
            section = section,
            previousScreen = previousScreen,
            currentScreen = currentScreen,
            adminUser = adminUser,
            timestamp = System.currentTimeMillis()
        )
        functionActivityLogDao.insertActivityLog(log)
    }

    suspend fun clearAllActivityLogs() = withContext(Dispatchers.IO) {
        functionActivityLogDao.deleteAllLogs()
        adminAuthManager.recordAudit("CLEAR_ACTIVITY_LOGS", "DIAGNOSTICS", "ALL", "Cleared all function activity logs.")
    }

    // ==========================================
    // Phase 6: Web Research & Knowledge Harvesting
    // ==========================================

    suspend fun approveKnowledgeCandidate(candidateId: String, adminUser: String = "Super Admin"): KnowledgeEntity? = withContext(Dispatchers.IO) {
        val published = harvestingEngine.approveAndPublishCandidate(candidateId, adminUser)
        if (published != null) {
            adminAuthManager.recordAudit(
                "APPROVE_KNOWLEDGE_CANDIDATE",
                "RESEARCH_CANDIDATE",
                candidateId,
                "Approved candidate '$candidateId' and published to Canonical Knowledge Base (${published.title})."
            )
        }
        published
    }

    suspend fun rejectKnowledgeCandidate(candidateId: String, rejectionReason: String, adminUser: String = "Super Admin") = withContext(Dispatchers.IO) {
        knowledgeCandidateDao.updateCandidateStatus(candidateId, "REJECTED", adminUser, System.currentTimeMillis())
        adminAuthManager.recordAudit(
            "REJECT_KNOWLEDGE_CANDIDATE",
            "RESEARCH_CANDIDATE",
            candidateId,
            "Rejected candidate '$candidateId'. Reason: $rejectionReason"
        )
    }

    suspend fun resolveResearchIssue(reportId: String, status: String, notes: String, adminUser: String = "Super Admin") = withContext(Dispatchers.IO) {
        researchIssueDao.updateIssueStatus(reportId = reportId, newStatus = status, resolvedAt = System.currentTimeMillis(), adminUser = adminUser)
        adminAuthManager.recordAudit(
            "RESOLVE_RESEARCH_ISSUE",
            "RESEARCH_ISSUE",
            reportId,
            "Updated research issue '$reportId' to status '$status'. Notes: $notes"
        )
    }

    suspend fun executeManualWebResearch(query: String): com.example.domain.research.WebResearchResult = withContext(Dispatchers.IO) {
        val result = com.example.domain.research.WebResearchProvider.performWebResearch(query)
        result.sources.forEach { src ->
            researchSourceDao.insertSource(src)
        }
        adminAuthManager.recordAudit(
            "MANUAL_WEB_RESEARCH",
            "RESEARCH_ENGINE",
            result.queryId,
            "Executed deep scholarly web research for query: '$query'. Found ${result.sources.size} authoritative sources."
        )
        result
    }

    suspend fun executeManualMantraVerification(query: String): com.example.domain.research.MantraVerificationShieldResult = withContext(Dispatchers.IO) {
        val web = com.example.domain.research.WebResearchProvider.performWebResearch(query)
        val yt = com.example.domain.research.YouTubeResearchProvider.performYouTubeResearch(query, web.queryId)
        val result = com.example.domain.research.MantraVerificationShield.verifyMantra(query, web.sources, yt.supportingEvidenceSources)
        adminAuthManager.recordAudit(
            "MANTRA_VERIFICATION_SHIELD",
            "MANTRA_SHIELD",
            query.take(30),
            "Executed Mantra Verification Shield for '$query'. Result: ${if (result.isVerified) "VERIFIED" else "REJECTED_UNVERIFIED"}."
        )
        result
    }

    suspend fun runTopicDiscoveryScan(
        categories: List<String>,
        config: com.example.domain.research.DiscoveryConfiguration = com.example.domain.research.DiscoveryConfiguration()
    ): List<com.example.domain.research.TopicScanResult> = withContext(Dispatchers.IO) {
        val results = com.example.domain.research.DharmaKnowledgeDiscoveryEngine.runTopicDiscoveryScan(
            harvestingEngine = harvestingEngine,
            categories = categories,
            config = config
        )
        val totalGenerated = results.sumOf { it.candidateCountGenerated }
        adminAuthManager.recordAudit(
            "TOPIC_DISCOVERY_SCAN",
            "DISCOVERY_ENGINE",
            categories.joinToString(","),
            "Ran Dharma Knowledge Discovery Scan across ${categories.size} categories. Generated $totalGenerated candidates."
        )
        results
    }
}

