package com.example.ui.theme

import androidx.compose.foundation.isSystemInDarkTheme
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.darkColorScheme
import androidx.compose.material3.lightColorScheme
import androidx.compose.runtime.Composable
import androidx.compose.ui.graphics.Color

private val DarkColorScheme = darkColorScheme(
    primary = SaffronLight,
    onPrimary = Color.Black,
    primaryContainer = Color(0xFF3B1B04),
    onPrimaryContainer = Color(0xFFFFDBC9),
    secondary = VedicGold,
    onSecondary = Color.Black,
    secondaryContainer = Color(0xFF382300),
    onSecondaryContainer = Color(0xFFFFE088),
    tertiary = StatusTeal,
    background = HighDensityBgDark,
    onBackground = TextPrimaryDark,
    surface = HighDensitySurfaceDark,
    onSurface = TextPrimaryDark,
    surfaceVariant = HighDensitySurfaceVariantDark,
    onSurfaceVariant = TextSecondaryDark,
    outline = HighDensityBorderDark,
    outlineVariant = Color(0xFF332B24)
)

private val LightColorScheme = lightColorScheme(
    primary = SaffronPrimary,
    onPrimary = Color.White,
    primaryContainer = SaffronContainer,
    onPrimaryContainer = OnSaffronContainer,
    secondary = VedicGoldDark,
    onSecondary = Color.White,
    secondaryContainer = VedicGoldContainer,
    onSecondaryContainer = OnVedicGoldContainer,
    tertiary = StatusTeal,
    background = HighDensityBgLight,
    onBackground = HighDensityTextPrimary,
    surface = HighDensitySurfaceLight,
    onSurface = HighDensityTextPrimary,
    surfaceVariant = HighDensitySurfaceVariantLight,
    onSurfaceVariant = HighDensityTextSecondary,
    outline = HighDensityBorderLight,
    outlineVariant = HighDensityBorderSubtle
)

@Composable
fun VedaNovaTheme(
    darkTheme: Boolean = false, // High Density Theme (warm crisp #fdf8f5 palette)
    content: @Composable () -> Unit
) {
    val colorScheme = if (darkTheme) DarkColorScheme else LightColorScheme

    MaterialTheme(
        colorScheme = colorScheme,
        typography = Typography,
        content = content
    )
}
