package com.example.domain.ai

import com.example.data.model.KnowledgeEntity

enum class MatchStrategy(val label: String, val weight: Float) {
    EXACT("Exact Question / Title Match", 1.0f),
    PHONETIC("Phonetic & Normalization Match", 0.95f),
    SEMANTIC("Semantic & Scriptural Keyword Match", 0.85f),
    RELATED("Related Category & Context Match", 0.70f),
    NONE("No Match (AI Unknown)", 0.0f)
}

data class KnowledgeMatchResult(
    val knowledge: KnowledgeEntity?,
    val strategy: MatchStrategy,
    val confidence: Float,
    val matchedField: String = "",
    val isKnown: Boolean = knowledge != null
)

data class KnowledgeConflictResult(
    val hasConflict: Boolean,
    val conflictingItem: KnowledgeEntity? = null,
    val conflictReason: String = "",
    val differences: List<String> = emptyList(),
    val severity: String = "LOW" // LOW, MEDIUM, HIGH, CRITICAL
)

data class KnowledgeValidationResult(
    val isValid: Boolean,
    val errors: List<String> = emptyList(),
    val warnings: List<String> = emptyList()
)

object KnowledgeMatchingEngine {

    /**
     * Executes the strict Multi-Stage Knowledge Retrieval Hierarchy:
     * 1. Exact Match (Cleaned query vs canonical question/title)
     * 2. Phonetic & Normalization Match (Bangla transliterations & variants)
     * 3. Semantic & Keyword Match (Token overlap, Jaccard, Scripture refs)
     * 4. Related Context Fallback
     */
    fun findBestMatch(query: String, publishedKnowledge: List<KnowledgeEntity>): KnowledgeMatchResult {
        val cleanQuery = normalizeText(query)
        if (cleanQuery.isBlank() || publishedKnowledge.isEmpty()) {
            return KnowledgeMatchResult(null, MatchStrategy.NONE, 0f)
        }

        // 1. Exact Match on question or title
        for (item in publishedKnowledge) {
            val itemQuestion = normalizeText(item.question)
            val itemTitle = normalizeText(item.title)
            if (cleanQuery == itemQuestion || cleanQuery == itemTitle) {
                return KnowledgeMatchResult(item, MatchStrategy.EXACT, 1.0f, "question/title")
            }
        }

        // 2. Phonetic & Normalization Match
        for (item in publishedKnowledge) {
            val normQuestion = normalizePhonetics(item.question)
            val normTitle = normalizePhonetics(item.title)
            val queryPhonetic = normalizePhonetics(cleanQuery)

            if (queryPhonetic == normQuestion || queryPhonetic == normTitle ||
                (normQuestion.isNotBlank() && queryPhonetic.contains(normQuestion)) ||
                (normQuestion.isNotBlank() && normQuestion.contains(queryPhonetic))
            ) {
                return KnowledgeMatchResult(item, MatchStrategy.PHONETIC, 0.95f, "phonetic_question")
            }
        }

        // 3. Semantic & Keyword Search
        var topScore = 0f
        var topItem: KnowledgeEntity? = null
        var matchedTag = ""

        val queryTokens = tokenize(cleanQuery)
        for (item in publishedKnowledge) {
            val corpus = listOf(
                item.title,
                item.question,
                item.answer,
                item.banglaMeaning,
                item.englishMeaning,
                item.tags,
                item.scripture,
                item.sanskritText
            ).joinToString(" ").lowercase()

            val score = calculateTokenScore(queryTokens, corpus)
            if (score > topScore) {
                topScore = score
                topItem = item
                matchedTag = "semantic_corpus"
            }
        }

        if (topScore >= 0.45f && topItem != null) {
            return KnowledgeMatchResult(topItem, MatchStrategy.SEMANTIC, (topScore.coerceIn(0.5f, 0.94f)), matchedTag)
        }

        // 4. No verified match found -> Trigger AI Unknown Flow
        return KnowledgeMatchResult(null, MatchStrategy.NONE, 0.0f)
    }

    /**
     * Checks if newly taught knowledge conflicts with existing verified knowledge.
     */
    fun detectConflict(
        newTitle: String,
        newQuestion: String,
        newAnswer: String,
        newCategory: String,
        existingList: List<KnowledgeEntity>
    ): KnowledgeConflictResult {
        val normNewQ = normalizeText(newQuestion)
        val normNewT = normalizeText(newTitle)
        val normNewAns = normalizeText(newAnswer)

        for (existing in existingList) {
            val normExQ = normalizeText(existing.question)
            val normExT = normalizeText(existing.title)
            val normExAns = normalizeText(existing.answer.ifBlank { existing.banglaMeaning })

            val isQuestionMatch = (normNewQ.isNotBlank() && normExQ.isNotBlank() && (normNewQ == normExQ || normNewQ.contains(normExQ) || normExQ.contains(normNewQ)))
            val isTitleMatch = (normNewT.isNotBlank() && normExT.isNotBlank() && (normNewT == normExT))

            if (isQuestionMatch || isTitleMatch) {
                val diffs = mutableListOf<String>()
                if (normNewAns != normExAns) {
                    diffs.add("Existing Answer: ${existing.answer.ifBlank { existing.banglaMeaning }.take(120)}")
                    diffs.add("New Answer: ${newAnswer.take(120)}")
                }
                if (existing.category != newCategory && newCategory.isNotBlank()) {
                    diffs.add("Category Mismatch: '${existing.category}' vs '$newCategory'")
                }
                if (existing.source != "ADMIN_TAUGHT") {
                    diffs.add("Existing Source Authority: ${existing.source} (${existing.sourceType})")
                }

                if (diffs.isNotEmpty()) {
                    return KnowledgeConflictResult(
                        hasConflict = true,
                        conflictingItem = existing,
                        conflictReason = "একটি বিদ্যমান যাচাইকৃত জ্ঞানের (${existing.title}) সাথে প্রশ্ন বা উত্তরের অসঙ্গতি পাওয়া গেছে।",
                        differences = diffs,
                        severity = if (existing.verificationStatus.equals("PUBLISHED", ignoreCase = true)) "HIGH" else "MEDIUM"
                    )
                }
            }
        }

        return KnowledgeConflictResult(hasConflict = false)
    }

    /**
     * Validates candidate knowledge before publishing (Approval Flow).
     */
    fun validateCandidate(item: KnowledgeEntity): KnowledgeValidationResult {
        val errors = mutableListOf<String>()
        val warnings = mutableListOf<String>()

        if (item.title.isBlank() && item.question.isBlank()) {
            errors.add("Title অথবা Question প্রদান করা বাধ্যতামূলক।")
        }
        if (item.answer.isBlank() && item.banglaMeaning.isBlank() && item.explanation.isBlank()) {
            errors.add("Answer অথবা মূল অর্থ প্রদান করা বাধ্যতামূলক।")
        }
        if (item.category.isBlank()) {
            errors.add("Category নির্বাচন করা আবশ্যক।")
        }
        if (item.source.isBlank()) {
            warnings.add("তথ্যটির প্রামাণ্য Source / Reference উল্লেখ করা শ্রেয়।")
        }

        return KnowledgeValidationResult(
            isValid = errors.isEmpty(),
            errors = errors,
            warnings = warnings
        )
    }

    private fun normalizeText(text: String): String {
        return text.lowercase()
            .replace("?", "")
            .replace("।", "")
            .replace(",", "")
            .replace("!", "")
            .replace(".", "")
            .replace(":", "")
            .replace("'", "")
            .replace("\"", "")
            .trim()
    }

    private fun normalizePhonetics(text: String): String {
        var str = normalizeText(text)
        str = str.replace("গিতা", "গীতা")
            .replace("ক্রিষ্ণ", "কৃষ্ণ")
            .replace("মহাদেব", "শিব")
            .replace("মহাদেব কে", "শিব কে")
            .replace("ধরম", "ধর্ম")
            .replace("ভগবান", "ঈশ্বর")
            .replace("উপনিসদ", "উপনিষদ")
            .replace("পুজো", "পূজা")
            .replace("পরনাম", "প্রণাম")
        return str
    }

    private fun tokenize(text: String): Set<String> {
        val stopWords = setOf("কী", "কে", "কেন", "কোথায়", "কীভাবে", "এবং", "বা", "ও", "এর", "কি", "বলো", "বলুন", "সম্পর্কে", "বলা", "হয়", "হল", "হলো")
        return text.split(Regex("[\\s,।?!]+"))
            .map { it.trim().lowercase() }
            .filter { it.length > 1 && !stopWords.contains(it) }
            .toSet()
    }

    private fun calculateTokenScore(queryTokens: Set<String>, corpus: String): Float {
        if (queryTokens.isEmpty()) return 0f
        var matchCount = 0
        for (token in queryTokens) {
            if (corpus.contains(token)) {
                matchCount++
            }
        }
        return matchCount.toFloat() / queryTokens.size.toFloat()
    }
}
