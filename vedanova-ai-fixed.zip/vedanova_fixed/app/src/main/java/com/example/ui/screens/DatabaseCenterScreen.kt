package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.*
import com.example.ui.viewmodel.ScreenDestination
import com.example.ui.viewmodel.VedaNovaViewModel

@Composable
fun DatabaseCenterScreen(viewModel: VedaNovaViewModel) {
    val knowledge by viewModel.allKnowledge.collectAsStateWithLifecycle()
    val apiKeys by viewModel.allApiKeys.collectAsStateWithLifecycle()
    val apiLogs by viewModel.recentApiLogs.collectAsStateWithLifecycle()
    val issues by viewModel.allIssues.collectAsStateWithLifecycle()
    val reports by viewModel.allReports.collectAsStateWithLifecycle()
    val auditLogs by viewModel.recentAuditLogs.collectAsStateWithLifecycle()
    val systemLogs by viewModel.recentSystemLogs.collectAsStateWithLifecycle()
    val users by viewModel.allUsers.collectAsStateWithLifecycle()
    val backups by viewModel.allBackups.collectAsStateWithLifecycle()

    var showBackupDialog by remember { mutableStateOf(false) }
    var showRestoreDialog by remember { mutableStateOf(false) }

    val tables = listOf(
        Triple("knowledge_items", "Canonical Scripture Nodes", knowledge.size),
        Triple("api_keys", "Hashed Gateway Client Credentials", apiKeys.size),
        Triple("api_logs", "Live Request & Telemetry Logs", apiLogs.size),
        Triple("issue_records", "AI Problem & Accuracy Tickets", issues.size),
        Triple("user_reports", "User & Scholar Feedback", reports.size),
        Triple("audit_logs", "Immutable Admin Audit Trail", auditLogs.size),
        Triple("system_logs", "Engine Runtime & Error Logs", systemLogs.size),
        Triple("admin_users", "RBAC Admin Accounts", users.size),
        Triple("backups", "Database Snapshots & Metadata", backups.size)
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Storage, contentDescription = null, tint = SaffronPrimary)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Database Management Center",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        StatusPill(text = "SQLite Room Engine: OK", color = StatusGreen)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Manage core relational tables, inspect record volumes, create automated snapshots, and maintain database schema integrity.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Quick Maintenance Actions
        item {
            SectionHeader(title = "Database Operations")
            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                    Button(
                        onClick = { showBackupDialog = true },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Backup, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Create Snapshot", color = Color.Black, fontWeight = FontWeight.Bold)
                    }

                    Button(
                        onClick = { showRestoreDialog = true },
                        modifier = Modifier.weight(1f),
                        colors = ButtonDefaults.buttonColors(containerColor = VedicGold),
                        shape = RoundedCornerShape(10.dp)
                    ) {
                        Icon(Icons.Default.Restore, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Restore Seed Data", color = Color.Black, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        // Tables Summary List
        item {
            SectionHeader(
                title = "Room Database Entities & Tables (${tables.size})",
                subtitle = "Live record counters and storage indexing"
            )
        }

        items(tables) { (tableName, description, count) ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            text = tableName,
                            style = MaterialTheme.typography.titleSmall.copy(fontFamily = FontFamily.Monospace),
                            fontWeight = FontWeight.Bold,
                            color = SaffronLight
                        )
                        Text(
                            text = description,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    StatusPill(
                        text = "$count records",
                        color = if (count > 0) StatusGreen else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Existing Backups
        item {
            SectionHeader(
                title = "Backup Snapshots (${backups.size})",
                subtitle = "Point-in-time verified backups"
            )
        }

        items(backups) { b ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = b.backupName,
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        StatusPill(text = b.status, color = StatusGreen)
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Type: ${b.backupType} • Records: ${b.recordCount} • Size: ${b.sizeKb} KB • Hash: ${b.checksum}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Create Backup Dialog
    if (showBackupDialog) {
        var bName by remember { mutableStateOf("VedaNova_Snapshot_${System.currentTimeMillis()}") }
        var bType by remember { mutableStateOf("Full Snapshot") }

        AlertDialog(
            onDismissRequest = { showBackupDialog = false },
            title = { Text("Create Database Backup") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    OutlinedTextField(
                        value = bName,
                        onValueChange = { bName = it },
                        label = { Text("Snapshot Name") },
                        modifier = Modifier.fillMaxWidth()
                    )
                    OutlinedTextField(
                        value = bType,
                        onValueChange = { bType = it },
                        label = { Text("Backup Scope") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.createBackup(bName, bType)
                        showBackupDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
                ) {
                    Text("Save Snapshot", color = Color.Black)
                }
            },
            dismissButton = {
                TextButton(onClick = { showBackupDialog = false }) { Text("Cancel") }
            }
        )
    }

    // Restore Seed Dialog
    if (showRestoreDialog) {
        AlertDialog(
            onDismissRequest = { showRestoreDialog = false },
            title = { Text("Restore Default Canonical Seed Knowledge") },
            text = {
                Text("This will ensure all foundational Vedic scriptures, Gita verses, Gayatri & Mahamrityunjaya mantras are present and verified in the database.")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.restoreSeedData()
                        showRestoreDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = VedicGold)
                ) {
                    Text("Restore Seed", color = Color.Black)
                }
            },
            dismissButton = {
                TextButton(onClick = { showRestoreDialog = false }) { Text("Cancel") }
            }
        )
    }
}
