package com.example.domain.ai

data class KnowledgeGapItem(
    val id: String,
    val topic: String,
    val bengaliTopic: String,
    val category: String,
    val demandLevel: String, // "HIGH", "MEDIUM", "CRITICAL"
    val currentCoverage: String, // "0 Records", "1 Partial Record", "Metadata Incomplete"
    val reason: String,
    val suggestedAction: String
)

object KnowledgeGapDetector {

    fun detectGaps(totalKnowledgeCount: Int, publishedCount: Int): List<KnowledgeGapItem> {
        return listOf(
            KnowledgeGapItem(
                id = "gap_1",
                topic = "Durga Puja & Navaratri Upacharas",
                bengaliTopic = "শ্রীশ্রী দুর্গাপূজা ও নবরাত্রির ষোড়শোপচার বিধি",
                category = "Puja & Rituals",
                demandLevel = "HIGH",
                currentCoverage = "Partial Coverage (Needs 16 Upacharas detailed)",
                reason = "High public chat queries regarding detailed ritual order and mudras.",
                suggestedAction = "Draft verified entry for 16 Upacharas with Markandeya Purana citations."
            ),
            KnowledgeGapItem(
                id = "gap_2",
                topic = "Vedic Shanti Mantras from 4 Vedas",
                bengaliTopic = "চার বেদের প্রধান শান্তিপাঠ সংকলন",
                category = "Mantras",
                demandLevel = "HIGH",
                currentCoverage = "2 Recorded / 8 Missing",
                reason = "Users frequently ask for Rigveda & Atharvaveda specific peace invocations.",
                suggestedAction = "Add Chamakam, Purusha Suktam & Vedic Shanti Patha nodes."
            ),
            KnowledgeGapItem(
                id = "gap_3",
                topic = "Mukhya Upanishad Mahavakyas Exegesis",
                bengaliTopic = "১২টি মুখ্য উপনিষদের মহাবাক্য ব্যাখ্যা",
                category = "Philosophy",
                demandLevel = "MEDIUM",
                currentCoverage = "Mandukya & Chandogya available; 10 others pending",
                reason = "Academic and spiritual seekers seeking Bhashya comparisons.",
                suggestedAction = "Add Shankara Bhashya commentary for Isha & Katha Upanishad."
            ),
            KnowledgeGapItem(
                id = "gap_4",
                topic = "Ekadashi Vrata Tithi & Paran Rules",
                bengaliTopic = "একাদশী ব্রতের মাহাত্ম্য ও পারণ বিধি",
                category = "Festivals & Vratas",
                demandLevel = "HIGH",
                currentCoverage = "1 Summary Record",
                reason = "Frequent queries on Harivasara timings and spiritual rules.",
                suggestedAction = "Publish comprehensive Padma Purana based Ekadashi guide."
            )
        )
    }
}
