package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.KnowledgeEntity
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.*
import com.example.ui.viewmodel.ScreenDestination
import com.example.ui.viewmodel.VedaNovaViewModel

@Composable
fun KnowledgeCenterScreen(viewModel: VedaNovaViewModel) {
    val knowledgeList by viewModel.allKnowledge.collectAsStateWithLifecycle()
    val draftCandidates by viewModel.draftKnowledge.collectAsStateWithLifecycle()
    val knowledgeGaps by viewModel.knowledgeGaps.collectAsStateWithLifecycle()

    var activeTab by remember { mutableStateOf(0) } // 0: Canonical Nodes, 1: Gap Detector, 2: Draft Review
    var selectedCategory by remember { mutableStateOf("All") }
    var selectedStatus by remember { mutableStateOf("All") }
    var searchQuery by remember { mutableStateOf("") }

    var itemToEdit by remember { mutableStateOf<KnowledgeEntity?>(null) }
    var itemToDelete by remember { mutableStateOf<KnowledgeEntity?>(null) }
    var itemToReview by remember { mutableStateOf<KnowledgeEntity?>(null) }

    val categories = listOf("All", "Mantras", "Bhagavad Gita", "Upanishads", "Puja", "Philosophy", "Festivals", "Hindu Traditions")
    val statuses = listOf("All", "Published", "Approved", "Pending Review", "Draft", "Rejected")

    val filteredList = knowledgeList.filter { item ->
        val matchesCategory = selectedCategory == "All" || item.category == selectedCategory
        val matchesStatus = selectedStatus == "All" || item.verificationStatus == selectedStatus
        val matchesSearch = searchQuery.isBlank() ||
                item.title.contains(searchQuery, ignoreCase = true) ||
                item.banglaMeaning.contains(searchQuery, ignoreCase = true) ||
                item.englishMeaning.contains(searchQuery, ignoreCase = true) ||
                item.sanskritText.contains(searchQuery, ignoreCase = true) ||
                item.scripture.contains(searchQuery, ignoreCase = true) ||
                item.tags.contains(searchQuery, ignoreCase = true)
        matchesCategory && matchesStatus && matchesSearch
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Banner & Stats
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.AutoStories, contentDescription = null, tint = VedicGold)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Knowledge & Gap Intelligence Center",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Button(
                            onClick = { viewModel.navigateTo(ScreenDestination.TEACH_AI) },
                            colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Teach AI", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Autonomous gap detection, canonical Vedic scripture nodes, and AI draft candidate review workflow.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    // Main Tabs
                    TabRow(
                        selectedTabIndex = activeTab,
                        containerColor = MaterialTheme.colorScheme.surface,
                        contentColor = SaffronPrimary
                    ) {
                        Tab(
                            selected = activeTab == 0,
                            onClick = { activeTab = 0 },
                            text = { Text("Canonical Nodes (${knowledgeList.size})") }
                        )
                        Tab(
                            selected = activeTab == 1,
                            onClick = { activeTab = 1 },
                            text = { Text("Gap Detector (${knowledgeGaps.size})") }
                        )
                        Tab(
                            selected = activeTab == 2,
                            onClick = { activeTab = 2 },
                            text = { Text("Draft Review (${draftCandidates.size})") }
                        )
                    }
                }
            }
        }

        if (activeTab == 0) {
            // Search Box
            item {
                OutlinedTextField(
                    value = searchQuery,
                    onValueChange = { searchQuery = it },
                    label = { Text("Search by Sanskrit shloka, Bengali, English, scripture, or tags") },
                    leadingIcon = { Icon(Icons.Default.Search, contentDescription = null) },
                    trailingIcon = {
                        if (searchQuery.isNotEmpty()) {
                            IconButton(onClick = { searchQuery = "" }) {
                                Icon(Icons.Default.Clear, contentDescription = "Clear")
                            }
                        }
                    },
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    singleLine = true
                )
            }

            // Category Filter Chips
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(categories) { cat ->
                        FilterChip(
                            selected = selectedCategory == cat,
                            onClick = { selectedCategory = cat },
                            label = { Text(cat) },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = SaffronPrimary,
                                selectedLabelColor = Color.Black
                            )
                        )
                    }
                }
            }

            // Status Lifecycle Filter Chips
            item {
                LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    items(statuses) { st ->
                        FilterChip(
                            selected = selectedStatus == st,
                            onClick = { selectedStatus = st },
                            label = { Text("Status: $st") },
                            colors = FilterChipDefaults.filterChipColors(
                                selectedContainerColor = VedicGold,
                                selectedLabelColor = Color.Black
                            )
                        )
                    }
                }
            }

            item {
                SectionHeader(
                    title = "Canonical Scripture Nodes (${filteredList.size})",
                    subtitle = "Grounding corpus used by VedaNova AI orchestrator"
                )
            }

            if (filteredList.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "No scripture records matching criteria found. Click 'Teach AI' to add a verified record.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(24.dp)
                        )
                    }
                }
            } else {
                items(filteredList) { item ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(16.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = item.title,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Text(
                                        text = "${item.category} • ${item.subcategory} • ${item.language}",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                StatusPill(
                                    text = item.verificationStatus,
                                    color = when (item.verificationStatus) {
                                        "Published" -> StatusGreen
                                        "Approved" -> StatusBlue
                                        "Pending Review" -> StatusYellow
                                        "Draft" -> StatusPurple
                                        else -> StatusRed
                                    }
                                )
                            }

                            if (item.sanskritText.isNotBlank()) {
                                Spacer(modifier = Modifier.height(10.dp))
                                Surface(
                                    color = MaterialTheme.colorScheme.surface,
                                    shape = RoundedCornerShape(8.dp),
                                    modifier = Modifier.fillMaxWidth()
                                ) {
                                    Text(
                                        text = item.sanskritText,
                                        style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold),
                                        color = VedicGold,
                                        modifier = Modifier.padding(10.dp)
                                    )
                                }
                            }

                            if (item.banglaMeaning.isNotBlank()) {
                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = "বাংলা: ${item.banglaMeaning}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            Spacer(modifier = Modifier.height(10.dp))
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = "📖 ${item.scripture} (${item.reference})",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = SaffronPrimary,
                                    fontWeight = FontWeight.Bold
                                )

                                Row {
                                    IconButton(onClick = { itemToReview = item }) {
                                        Icon(Icons.Default.Visibility, contentDescription = "View Details", tint = StatusBlue)
                                    }
                                    IconButton(onClick = { itemToEdit = item }) {
                                        Icon(Icons.Default.Edit, contentDescription = "Edit", tint = VedicGold)
                                    }
                                    IconButton(onClick = { itemToDelete = item }) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = StatusRed)
                                    }
                                }
                            }
                        }
                    }
                }
            }
        } else if (activeTab == 1) {
            // Knowledge Gap Detection (Requirement #12)
            item {
                SectionHeader(
                    title = "Autonomous Knowledge Gap Engine",
                    subtitle = "Identifies high-demand topics missing from canonical scripture database"
                )
            }

            items(knowledgeGaps) { gap ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = gap.topic,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "বাংলা: ${gap.bengaliTopic} • বিভাগ: ${gap.category}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            StatusPill(
                                text = "Demand: ${gap.demandLevel}",
                                color = if (gap.demandLevel == "HIGH") StatusRed else StatusYellow
                            )
                        }

                        Text(
                            text = "কারণ: ${gap.reason}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Text(
                            text = "প্রস্তাবিত পদক্ষেপ: ${gap.suggestedAction}",
                            style = MaterialTheme.typography.labelSmall,
                            color = SaffronPrimary,
                            fontWeight = FontWeight.Bold
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.End
                        ) {
                            Button(
                                onClick = {
                                    viewModel.createResearchTaskFromGap(gap)
                                },
                                colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                            ) {
                                Icon(Icons.Default.AddCircleOutline, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("Create Research Task (Draft Candidate)", color = Color.Black, fontWeight = FontWeight.Bold, fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        } else {
            // Draft Candidates Review (Requirement #11)
            item {
                SectionHeader(
                    title = "Pending Knowledge Candidates (${draftCandidates.size})",
                    subtitle = "AI-suggested candidates awaiting strict Admin review and verification"
                )
            }

            if (draftCandidates.isEmpty()) {
                item {
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            text = "No pending draft candidates. When the AI synthesizes novel verified research, it is queued here for review.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(24.dp)
                        )
                    }
                }
            } else {
                items(draftCandidates) { draft ->
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(16.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, SaffronPrimary.copy(alpha = 0.5f)),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = draft.title,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                StatusPill(text = "Draft Candidate", color = StatusPurple)
                            }

                            Text(
                                text = "Category: ${draft.category} | Source: ${draft.source} (${draft.sourceType})",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )

                            if (draft.banglaMeaning.isNotBlank()) {
                                Text(
                                    text = draft.banglaMeaning,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.End,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                TextButton(onClick = { viewModel.rejectDraftCandidate(draft) }) {
                                    Icon(Icons.Default.Close, contentDescription = null, tint = StatusRed, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Reject Candidate", color = StatusRed)
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Button(
                                    onClick = { viewModel.approveDraftCandidate(draft) },
                                    colors = ButtonDefaults.buttonColors(containerColor = StatusGreen),
                                    shape = RoundedCornerShape(8.dp)
                                ) {
                                    Icon(Icons.Default.Check, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Approve & Publish", color = Color.Black, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Detail Review Modal
    itemToReview?.let { item ->
        AlertDialog(
            onDismissRequest = { itemToReview = null },
            title = { Text(item.title, fontWeight = FontWeight.Bold) },
            text = {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    item { Text("Category: ${item.category} • ${item.subcategory}", style = MaterialTheme.typography.bodySmall) }
                    item { Text("Scripture Reference: ${item.scripture} (${item.reference})", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold, color = SaffronPrimary) }
                    if (item.sanskritText.isNotBlank()) {
                        item {
                            Surface(color = MaterialTheme.colorScheme.surfaceVariant, shape = RoundedCornerShape(8.dp), modifier = Modifier.fillMaxWidth()) {
                                Text(item.sanskritText, modifier = Modifier.padding(8.dp), fontWeight = FontWeight.Bold, color = VedicGold)
                            }
                        }
                    }
                    if (item.banglaMeaning.isNotBlank()) {
                        item { Text("বাংলা অনুবাদ:\n${item.banglaMeaning}", style = MaterialTheme.typography.bodyMedium) }
                    }
                    if (item.englishMeaning.isNotBlank()) {
                        item { Text("English Translation:\n${item.englishMeaning}", style = MaterialTheme.typography.bodyMedium) }
                    }
                    if (item.explanation.isNotBlank()) {
                        item { Text("Explanation:\n${item.explanation}", style = MaterialTheme.typography.bodySmall) }
                    }
                    item { Text("Source: ${item.source} (${item.sourceType})", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant) }
                }
            },
            confirmButton = {
                TextButton(onClick = { itemToReview = null }) { Text("Close") }
            }
        )
    }

    // Edit Item Dialog
    itemToEdit?.let { item ->
        var title by remember { mutableStateOf(item.title) }
        var bangla by remember { mutableStateOf(item.banglaMeaning) }
        var english by remember { mutableStateOf(item.englishMeaning) }
        var sanskrit by remember { mutableStateOf(item.sanskritText) }
        var ref by remember { mutableStateOf(item.reference) }

        AlertDialog(
            onDismissRequest = { itemToEdit = null },
            title = { Text("Edit Scripture Record") },
            text = {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item {
                        OutlinedTextField(
                            value = title,
                            onValueChange = { title = it },
                            label = { Text("Title") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    item {
                        OutlinedTextField(
                            value = sanskrit,
                            onValueChange = { sanskrit = it },
                            label = { Text("Sanskrit Shloka / Mantra") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2
                        )
                    }
                    item {
                        OutlinedTextField(
                            value = bangla,
                            onValueChange = { bangla = it },
                            label = { Text("Bengali Meaning") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2
                        )
                    }
                    item {
                        OutlinedTextField(
                            value = english,
                            onValueChange = { english = it },
                            label = { Text("English Meaning") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2
                        )
                    }
                    item {
                        OutlinedTextField(
                            value = ref,
                            onValueChange = { ref = it },
                            label = { Text("Scripture Reference (e.g. Gita 2.47)") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.updateKnowledge(
                            item.copy(
                                title = title,
                                sanskritText = sanskrit,
                                banglaMeaning = bangla,
                                englishMeaning = english,
                                reference = ref,
                                updatedDate = System.currentTimeMillis()
                            )
                        )
                        itemToEdit = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
                ) {
                    Text("Save Changes", color = Color.Black)
                }
            },
            dismissButton = {
                TextButton(onClick = { itemToEdit = null }) { Text("Cancel") }
            }
        )
    }

    // Delete Confirmation Dialog
    itemToDelete?.let { item ->
        AlertDialog(
            onDismissRequest = { itemToDelete = null },
            title = { Text("Delete Scripture Record", color = StatusRed) },
            text = {
                Text("Are you sure you want to delete '${item.title}' from the canonical knowledge database?")
            },
            confirmButton = {
                Button(
                    onClick = {
                        viewModel.deleteKnowledge(item)
                        itemToDelete = null
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = StatusRed)
                ) {
                    Text("Delete", color = Color.White)
                }
            },
            dismissButton = {
                TextButton(onClick = { itemToDelete = null }) { Text("Cancel") }
            }
        )
    }
}
