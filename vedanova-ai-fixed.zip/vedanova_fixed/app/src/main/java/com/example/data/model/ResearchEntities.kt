package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Phase 6: Web & YouTube Research Source Evidence Record
 */
@Entity(tableName = "research_sources")
data class ResearchSourceEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val sourceId: String, // e.g. "SRC-2026-001"
    val queryId: String,  // e.g. "QRY-892"
    val url: String,
    val domain: String,
    val title: String,
    val sourceType: String, // Canonical Scripture, Traditional Commentary, Academic/Institutional, Dharma Reference, Website/Blog, YouTube Video
    val sourceTier: String, // TIER 1, TIER 2, TIER 3, TIER 4, TIER 5, TIER 6
    val author: String = "Traditional",
    val publicationDate: String = "",
    val language: String = "SANSKRIT_BENGALI",
    val excerpt: String = "",
    val relevanceScore: Float = 0.95f,
    val authorityScore: Float = 0.98f,
    val verificationStatus: String = "VERIFIED", // VERIFIED, UNVERIFIED, CONFLICT, REJECTED
    val retrievedAt: Long = System.currentTimeMillis(),
    val contentFingerprint: String = "",
    val needsReverification: Boolean = false
)

/**
 * Phase 6: Admin Unknown Research Report & Issue Tracking
 */
@Entity(tableName = "research_issues")
data class ResearchIssueEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val reportId: String, // e.g. "REP-RES-101"
    val userQuery: String,
    val normalizedQuery: String,
    val language: String = "BENGALI",
    val intent: String = "UNKNOWN_QUERY",
    val localKnowledgeResult: String = "NOT_FOUND", // FOUND, NOT_FOUND, LOW_CONFIDENCE
    val webSearchAttempted: Boolean = true,
    val youtubeSearchAttempted: Boolean = true,
    val sourcesFound: Int = 0,
    val sourcesVerified: Int = 0,
    val conflictDetected: Boolean = false,
    val reason: String = "No verified canonical source found in local or external authoritative repositories",
    val confidence: Float = 0.0f,
    val status: String = "OPEN", // OPEN, RESEARCHING, SOURCE_FOUND, VERIFICATION_REQUIRED, ADMIN_REVIEW, RESOLVED, NO_RELIABLE_SOURCE
    val suggestedAction: String = "Admin Canonical Teaching",
    val createdAt: Long = System.currentTimeMillis(),
    val resolvedAt: Long? = null,
    val resolvedBy: String? = null
)

/**
 * Phase 6: Knowledge Candidate Entity for Harvesting Pipeline
 */
@Entity(tableName = "knowledge_candidates")
data class KnowledgeCandidateEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val candidateId: String, // e.g. "CAND-2026-001"
    val title: String,
    val question: String,
    val answer: String,
    val category: String = "MANTRA", // MANTRA, SCRIPTURE, UPANISHAD, VEDA, PHILOSOPHY, PUJA, FESTIVAL
    val language: String = "BENGALI",
    val sourceIds: String = "", // Comma-separated or source reference string
    val scripture: String = "",
    val chapter: String = "",
    val verse: String = "",
    val reference: String = "",
    val sanskritText: String = "",
    val transliteration: String = "",
    val bengaliMeaning: String = "",
    val englishMeaning: String = "",
    val sourceTier: String = "TIER 1", // TIER 1, TIER 2, TIER 3
    val confidence: Float = 0.95f,
    val verificationStatus: String = "VERIFIED", // VERIFIED, UNVERIFIED, CONFLICT
    val reviewStatus: String = "PENDING_REVIEW", // PENDING_REVIEW, APPROVED, REJECTED, EDITED, RESEARCH_AGAIN
    val conflictNotes: String = "",
    val duplicateMatchId: Long? = null,
    val duplicateMatchTitle: String = "",
    val sampradayaNotes: String = "", // Multi-tradition notes (Advaita, Dvaita, Vaishnava, Shaiva, Shakta)
    val approvedBy: String? = null,
    val approvedAt: Long? = null,
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * Phase 6: Fast Research Cache Entity to prevent duplicate expensive web queries
 */
@Entity(tableName = "research_cache")
data class ResearchCacheEntity(
    @PrimaryKey val normalizedQuery: String,
    val language: String = "BENGALI",
    val researchResultJson: String,
    val sourceIds: String = "",
    val confidence: Float = 0.95f,
    val lastVerifiedAt: Long = System.currentTimeMillis(),
    val expiresAt: Long = System.currentTimeMillis() + (7 * 24 * 60 * 60 * 1000L) // Default 7 days
)

/**
 * Phase 6: Detailed Research Activity Audit Log
 */
@Entity(tableName = "research_activity_logs")
data class ResearchActivityLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val researchId: String, // e.g. "RES-ACT-1001"
    val userQuery: String,
    val searchQueries: String,
    val providersUsed: String = "Web + YouTube + Canonical DB",
    val sourcesFound: Int = 0,
    val sourcesAccepted: Int = 0,
    val sourcesRejected: Int = 0,
    val verificationResult: String = "VERIFIED", // VERIFIED, CONFLICT, UNVERIFIED, NOT_FOUND
    val confidence: Float = 0.95f,
    val durationMs: Long = 180,
    val finalDecision: String = "ANSWERED_WITH_RESEARCH", // ANSWERED_WITH_RESEARCH, CREATED_CANDIDATE, UNKNOWN_REPORTED, CONFLICT_FLAGGED
    val timestamp: Long = System.currentTimeMillis()
)
