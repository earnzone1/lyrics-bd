package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.model.CapabilityProposalEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.VedaNovaViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CapabilityApprovalScreen(viewModel: VedaNovaViewModel) {
    val proposals by viewModel.allCapabilityProposals.collectAsState()

    var selectedFilter by remember { mutableStateOf("ALL") } // ALL, AI_PROPOSED, ACTIVE, REJECTED
    var reviewProposalDialog by remember { mutableStateOf<Pair<CapabilityProposalEntity, Boolean>?>(null) } // Proposal to isApprove
    var searchQuery by remember { mutableStateOf("") }

    val filteredProposals = proposals.filter { p ->
        val matchesQuery = p.name.contains(searchQuery, ignoreCase = true) ||
                p.bengaliName.contains(searchQuery, ignoreCase = true) ||
                p.capabilityCode.contains(searchQuery, ignoreCase = true) ||
                p.proposedByApp.contains(searchQuery, ignoreCase = true)
        val matchesFilter = when (selectedFilter) {
            "AI_PROPOSED" -> p.status.equals("AI_PROPOSED", ignoreCase = true)
            "ACTIVE" -> p.status.equals("ACTIVE", ignoreCase = true)
            "REJECTED" -> p.status.equals("REJECTED", ignoreCase = true)
            else -> true
        }
        matchesQuery && matchesFilter
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = {
                    Column {
                        Text(
                            "AI Dynamic Capability Approval Center",
                            style = MaterialTheme.typography.titleLarge.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            "VedaNova AI Proposes Functions — Admin Decides, Approves & Secures",
                            style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }
                }
            )
        }
    ) { padding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .padding(horizontal = 16.dp),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            // 1. Summary Cards
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    val pendingCount = proposals.count { it.status.equals("AI_PROPOSED", ignoreCase = true) }
                    val activeCount = proposals.count { it.status.equals("ACTIVE", ignoreCase = true) }
                    val rejectedCount = proposals.count { it.status.equals("REJECTED", ignoreCase = true) }

                    CapabilityStatCard(
                        title = "Pending Approval",
                        count = "$pendingCount",
                        subtitle = "Awaiting Admin Review",
                        color = VedicGold,
                        modifier = Modifier.weight(1f)
                    )
                    CapabilityStatCard(
                        title = "Approved & Active",
                        count = "$activeCount",
                        subtitle = "Live in Gateway Catalog",
                        color = Color(0xFF2E7D32),
                        modifier = Modifier.weight(1f)
                    )
                    CapabilityStatCard(
                        title = "Rejected / Safe Guarded",
                        count = "$rejectedCount",
                        subtitle = "Filtered by Canonical Safety",
                        color = Color(0xFFC62828),
                        modifier = Modifier.weight(1f)
                    )
                }
            }

            // 2. Search & Filter Bar
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(12.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier.weight(1f).testTag("search_capabilities_input"),
                        placeholder = { Text("Search by Capability Code, Name, or App...") },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search") },
                        singleLine = true,
                        shape = RoundedCornerShape(12.dp)
                    )

                    FilterChip(
                        selected = selectedFilter == "ALL",
                        onClick = { selectedFilter = "ALL" },
                        label = { Text("All (${proposals.size})") }
                    )
                    FilterChip(
                        selected = selectedFilter == "AI_PROPOSED",
                        onClick = { selectedFilter = "AI_PROPOSED" },
                        label = { Text("Pending") }
                    )
                    FilterChip(
                        selected = selectedFilter == "ACTIVE",
                        onClick = { selectedFilter = "ACTIVE" },
                        label = { Text("Active") }
                    )
                }
            }

            // 3. Capability Proposals List
            if (filteredProposals.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 40.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            "No capability proposals matching the selected filter.",
                            style = MaterialTheme.typography.bodyMedium.copy(color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                    }
                }
            } else {
                items(filteredProposals) { proposal ->
                    CapabilityProposalCard(
                        proposal = proposal,
                        onApprove = { reviewProposalDialog = proposal to true },
                        onReject = { reviewProposalDialog = proposal to false },
                        onDisable = { viewModel.disableCapabilityProposal(proposal) }
                    )
                }
            }

            item {
                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }

    // Modal: Admin Review & Notes Dialog
    reviewProposalDialog?.let { (proposal, isApprove) ->
        var adminNotes by remember { mutableStateOf(if (isApprove) "Approved for production use across authorized client apps." else "Non-standard request; rejected based on canonical scope boundaries.") }

        AlertDialog(
            onDismissRequest = { reviewProposalDialog = null },
            title = {
                Text(
                    if (isApprove) "Approve Capability: ${proposal.name}" else "Reject Capability Proposal",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        "Code: ${proposal.capabilityCode} • Proposed by: ${proposal.proposedByApp}",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
                    )
                    Text(
                        "Safety Rating: ${proposal.safetyRating}",
                        style = MaterialTheme.typography.bodySmall.copy(color = SpiritualTeal)
                    )

                    OutlinedTextField(
                        value = adminNotes,
                        onValueChange = { adminNotes = it },
                        label = { Text("Admin Review Notes & Audit Reason") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (isApprove) {
                            viewModel.approveCapabilityProposal(proposal, adminNotes)
                        } else {
                            viewModel.rejectCapabilityProposal(proposal, adminNotes)
                        }
                        reviewProposalDialog = null
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isApprove) Color(0xFF2E7D32) else Color(0xFFC62828)
                    )
                ) {
                    Text(if (isApprove) "Confirm Approval" else "Confirm Rejection")
                }
            },
            dismissButton = {
                TextButton(onClick = { reviewProposalDialog = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun CapabilityStatCard(
    title: String,
    count: String,
    subtitle: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f))
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Text(title, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.SemiBold))
            Spacer(modifier = Modifier.height(8.dp))
            Text(count, style = MaterialTheme.typography.headlineMedium.copy(fontWeight = FontWeight.Bold, color = color))
            Text(subtitle, style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurfaceVariant))
        }
    }
}

@Composable
fun CapabilityProposalCard(
    proposal: CapabilityProposalEntity,
    onApprove: () -> Unit,
    onReject: () -> Unit,
    onDisable: () -> Unit
) {
    var expandedSchema by remember { mutableStateOf(false) }

    val statusColor = when (proposal.status.uppercase()) {
        "ACTIVE" -> Color(0xFF2E7D32)
        "AI_PROPOSED" -> VedicGold
        "REJECTED" -> Color(0xFFC62828)
        else -> Color.Gray
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            proposal.name,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = statusColor.copy(alpha = 0.15f)
                        ) {
                            Text(
                                proposal.status.uppercase(),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = statusColor
                                )
                            )
                        }
                    }
                    Text(
                        proposal.bengaliName,
                        style = MaterialTheme.typography.bodyMedium.copy(color = SaffronPrimary, fontWeight = FontWeight.SemiBold)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(8.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Text(
                        proposal.capabilityCode,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold)
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                proposal.description,
                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurface)
            )

            Spacer(modifier = Modifier.height(10.dp))

            // AI Origin Context Box
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Origin: ${proposal.proposedByApp}", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                        Text("Safety: ${proposal.safetyRating}", style = MaterialTheme.typography.labelSmall.copy(color = SpiritualTeal, fontWeight = FontWeight.Bold))
                    }
                    if (proposal.triggerQuery.isNotBlank()) {
                        Spacer(modifier = Modifier.height(4.dp))
                        Text("Trigger Query: \"${proposal.triggerQuery}\"", style = MaterialTheme.typography.bodySmall.copy(fontStyle = androidx.compose.ui.text.font.FontStyle.Italic))
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Detected Needs: ${proposal.detectedNeeds}", style = MaterialTheme.typography.bodySmall)
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Toggle Schema JSON
            TextButton(
                onClick = { expandedSchema = !expandedSchema },
                contentPadding = PaddingValues(0.dp)
            ) {
                Icon(if (expandedSchema) Icons.Default.ExpandLess else Icons.Default.ExpandMore, contentDescription = null)
                Spacer(modifier = Modifier.width(4.dp))
                Text(if (expandedSchema) "Hide Input/Output JSON Schemas" else "View Input/Output JSON Schemas", fontSize = 12.sp)
            }

            AnimatedVisibility(visible = expandedSchema) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 6.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    Text("Input Schema:", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0xFF1E1E1E),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            proposal.inputSchemaJson,
                            modifier = Modifier.padding(8.dp),
                            style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFFE0E0E0), fontFamily = FontFamily.Monospace)
                        )
                    }

                    Text("Output Schema:", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold))
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0xFF1E1E1E),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            proposal.outputSchemaJson,
                            modifier = Modifier.padding(8.dp),
                            style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFFE0E0E0), fontFamily = FontFamily.Monospace)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
            Spacer(modifier = Modifier.height(8.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (proposal.status.equals("AI_PROPOSED", ignoreCase = true)) {
                    OutlinedButton(
                        onClick = onReject,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFC62828))
                    ) {
                        Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Reject")
                    }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = onApprove,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Approve for Integration", fontWeight = FontWeight.Bold)
                    }
                } else if (proposal.status.equals("ACTIVE", ignoreCase = true)) {
                    OutlinedButton(
                        onClick = onDisable,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFC62828))
                    ) {
                        Text("Disable Capability")
                    }
                }
            }
        }
    }
}
