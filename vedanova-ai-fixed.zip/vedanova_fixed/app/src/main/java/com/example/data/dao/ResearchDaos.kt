package com.example.data.dao

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface ResearchSourceDao {
    @Query("SELECT * FROM research_sources ORDER BY retrievedAt DESC")
    fun getAllSources(): Flow<List<ResearchSourceEntity>>

    @Query("SELECT * FROM research_sources WHERE queryId = :queryId ORDER BY authorityScore DESC")
    suspend fun getSourcesByQueryId(queryId: String): List<ResearchSourceEntity>

    @Query("SELECT * FROM research_sources WHERE sourceId = :sourceId LIMIT 1")
    suspend fun getSourceById(sourceId: String): ResearchSourceEntity?

    @Query("SELECT * FROM research_sources WHERE needsReverification = 1")
    fun getSourcesNeedingReverification(): Flow<List<ResearchSourceEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSource(source: ResearchSourceEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllSources(sources: List<ResearchSourceEntity>)

    @Update
    suspend fun updateSource(source: ResearchSourceEntity)

    @Query("DELETE FROM research_sources WHERE id = :id")
    suspend fun deleteSource(id: Long)

    @Query("DELETE FROM research_sources")
    suspend fun deleteAllSources()
}

@Dao
interface ResearchIssueDao {
    @Query("SELECT * FROM research_issues ORDER BY createdAt DESC")
    fun getAllIssues(): Flow<List<ResearchIssueEntity>>

    @Query("SELECT * FROM research_issues WHERE status = 'OPEN' ORDER BY createdAt DESC")
    fun getOpenIssues(): Flow<List<ResearchIssueEntity>>

    @Query("SELECT COUNT(*) FROM research_issues WHERE status = 'OPEN'")
    fun getOpenIssuesCount(): Flow<Int>

    @Query("SELECT * FROM research_issues WHERE reportId = :reportId LIMIT 1")
    suspend fun getIssueByReportId(reportId: String): ResearchIssueEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIssue(issue: ResearchIssueEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllIssues(issues: List<ResearchIssueEntity>)

    @Update
    suspend fun updateIssue(issue: ResearchIssueEntity)

    @Query("UPDATE research_issues SET status = :newStatus, resolvedAt = :resolvedAt, resolvedBy = :adminUser WHERE reportId = :reportId")
    suspend fun updateIssueStatus(reportId: String, newStatus: String, resolvedAt: Long = System.currentTimeMillis(), adminUser: String = "Admin")

    @Query("DELETE FROM research_issues WHERE id = :id")
    suspend fun deleteIssue(id: Long)

    @Query("DELETE FROM research_issues")
    suspend fun deleteAllIssues()
}

@Dao
interface KnowledgeCandidateDao {
    @Query("SELECT * FROM knowledge_candidates ORDER BY createdAt DESC")
    fun getAllCandidates(): Flow<List<KnowledgeCandidateEntity>>

    @Query("SELECT * FROM knowledge_candidates WHERE reviewStatus = 'PENDING_REVIEW' ORDER BY createdAt DESC")
    fun getPendingCandidates(): Flow<List<KnowledgeCandidateEntity>>

    @Query("SELECT COUNT(*) FROM knowledge_candidates WHERE reviewStatus = 'PENDING_REVIEW'")
    fun getPendingCandidatesCount(): Flow<Int>

    @Query("SELECT * FROM knowledge_candidates WHERE candidateId = :candidateId LIMIT 1")
    suspend fun getCandidateById(candidateId: String): KnowledgeCandidateEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCandidate(candidate: KnowledgeCandidateEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllCandidates(candidates: List<KnowledgeCandidateEntity>)

    @Update
    suspend fun updateCandidate(candidate: KnowledgeCandidateEntity)

    @Query("UPDATE knowledge_candidates SET reviewStatus = :newStatus, approvedBy = :adminUser, approvedAt = :timestamp WHERE candidateId = :candidateId")
    suspend fun updateCandidateStatus(candidateId: String, newStatus: String, adminUser: String = "Admin", timestamp: Long = System.currentTimeMillis())

    @Query("DELETE FROM knowledge_candidates WHERE id = :id")
    suspend fun deleteCandidate(id: Long)

    @Query("DELETE FROM knowledge_candidates")
    suspend fun deleteAllCandidates()
}

@Dao
interface ResearchCacheDao {
    @Query("SELECT * FROM research_cache WHERE normalizedQuery = :query LIMIT 1")
    suspend fun getCachedResearch(query: String): ResearchCacheEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCache(cache: ResearchCacheEntity)

    @Query("DELETE FROM research_cache WHERE expiresAt < :currentTime")
    suspend fun cleanExpiredCache(currentTime: Long = System.currentTimeMillis())

    @Query("DELETE FROM research_cache")
    suspend fun clearAllCache()
}

@Dao
interface ResearchActivityLogDao {
    @Query("SELECT * FROM research_activity_logs ORDER BY timestamp DESC LIMIT 200")
    fun getRecentActivityLogs(): Flow<List<ResearchActivityLogEntity>>

    @Query("SELECT COUNT(*) FROM research_activity_logs")
    fun getTotalResearchCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: ResearchActivityLogEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllLogs(logs: List<ResearchActivityLogEntity>)

    @Query("DELETE FROM research_activity_logs")
    suspend fun deleteAllLogs()
}
