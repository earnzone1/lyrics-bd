package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.IssueEntity
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.*
import com.example.ui.viewmodel.VedaNovaViewModel

@Composable
fun ProblemCenterScreen(viewModel: VedaNovaViewModel) {
    val issues by viewModel.allIssues.collectAsStateWithLifecycle()
    var selectedStatusFilter by remember { mutableStateOf("All") }
    var selectedSeverityFilter by remember { mutableStateOf("All") }
    var showCreateDialog by remember { mutableStateOf(false) }
    var selectedIssueToResolve by remember { mutableStateOf<IssueEntity?>(null) }

    val statusFilters = listOf("All", "Open", "Investigating", "Fixed", "Verified", "Closed")
    val severityFilters = listOf("All", "Critical", "High", "Medium", "Low")

    val filteredIssues = issues.filter {
        (selectedStatusFilter == "All" || it.status == selectedStatusFilter) &&
                (selectedSeverityFilter == "All" || it.severity == selectedSeverityFilter)
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.ReportProblem, contentDescription = null, tint = StatusYellow)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "Problem Center & Issue Tracker",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Button(
                            onClick = { showCreateDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Log Issue", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Systematic issue detection and lifecycle management for ambiguous queries, scriptural inaccuracies, and AI response deviations.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        // Status Filters
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(statusFilters) { st ->
                    FilterChip(
                        selected = selectedStatusFilter == st,
                        onClick = { selectedStatusFilter = st },
                        label = { Text("Status: $st") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = SaffronPrimary,
                            selectedLabelColor = Color.Black
                        )
                    )
                }
            }
        }

        // Severity Filters
        item {
            LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                items(severityFilters) { sev ->
                    FilterChip(
                        selected = selectedSeverityFilter == sev,
                        onClick = { selectedSeverityFilter = sev },
                        label = { Text("Severity: $sev") },
                        colors = FilterChipDefaults.filterChipColors(
                            selectedContainerColor = VedicGold,
                            selectedLabelColor = Color.Black
                        )
                    )
                }
            }
        }

        item {
            SectionHeader(
                title = "Reported Issues (${filteredIssues.size})",
                subtitle = "Manage remediation status and assign admin reviewers"
            )
        }

        if (filteredIssues.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "No issues recorded under the selected filters.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(24.dp)
                    )
                }
            }
        } else {
            items(filteredIssues) { issue ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "${issue.issueCode}: ${issue.title}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Category: ${issue.category} • Assigned: ${issue.assignedAdmin}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            StatusPill(
                                text = issue.severity,
                                color = when (issue.severity) {
                                    "Critical" -> StatusRed
                                    "High" -> StatusYellow
                                    "Medium" -> SaffronPrimary
                                    else -> StatusGreen
                                }
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Text(
                            text = issue.description,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        if (issue.userQuery.isNotBlank()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Surface(
                                color = CosmicNavyElevated,
                                shape = RoundedCornerShape(8.dp),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Column(modifier = Modifier.padding(10.dp)) {
                                    Text(
                                        text = "Query: \"${issue.userQuery}\"",
                                        style = MaterialTheme.typography.bodySmall,
                                        fontWeight = FontWeight.SemiBold,
                                        color = VedicGold
                                    )
                                    if (issue.actualResponse.isNotBlank()) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "Actual AI Output: ${issue.actualResponse}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = TextSecondaryDark
                                        )
                                    }
                                    if (issue.expectedResponse.isNotBlank()) {
                                        Spacer(modifier = Modifier.height(4.dp))
                                        Text(
                                            text = "Expected Scriptural Standard: ${issue.expectedResponse}",
                                            style = MaterialTheme.typography.bodySmall,
                                            color = StatusGreen
                                        )
                                    }
                                }
                            }
                        }

                        if (issue.resolution.isNotBlank()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Resolution: ${issue.resolution}",
                                style = MaterialTheme.typography.bodySmall,
                                color = StatusGreen
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                        Spacer(modifier = Modifier.height(8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            StatusPill(
                                text = "Status: ${issue.status}",
                                color = when (issue.status) {
                                    "Fixed", "Verified", "Closed" -> StatusGreen
                                    "Investigating" -> VedicGold
                                    else -> StatusYellow
                                }
                            )

                            Button(
                                onClick = { selectedIssueToResolve = issue },
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
                            ) {
                                Text("Update Status →", color = Color.Black, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Status Update Dialog
    selectedIssueToResolve?.let { issue ->
        var notes by remember { mutableStateOf(issue.resolution) }
        AlertDialog(
            onDismissRequest = { selectedIssueToResolve = null },
            title = { Text("Update Issue Lifecycle: ${issue.issueCode}") },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(text = "Title: ${issue.title}")
                    OutlinedTextField(
                        value = notes,
                        onValueChange = { notes = it },
                        label = { Text("Resolution / Audit Notes") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 2
                    )
                    Text(text = "Transition to Status:")
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Button(
                            onClick = {
                                viewModel.updateIssueStatus(issue, "Investigating", notes)
                                selectedIssueToResolve = null
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = VedicGold)
                        ) {
                            Text("Investigate", color = Color.Black, fontSize = 11.sp)
                        }
                        Button(
                            onClick = {
                                viewModel.updateIssueStatus(issue, "Fixed", notes)
                                selectedIssueToResolve = null
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
                        ) {
                            Text("Mark Fixed", color = Color.Black, fontSize = 11.sp)
                        }
                        Button(
                            onClick = {
                                viewModel.updateIssueStatus(issue, "Closed", notes)
                                selectedIssueToResolve = null
                            },
                            modifier = Modifier.weight(1f),
                            colors = ButtonDefaults.buttonColors(containerColor = StatusGreen)
                        ) {
                            Text("Close", color = Color.Black, fontSize = 11.sp)
                        }
                    }
                }
            },
            confirmButton = {},
            dismissButton = {
                TextButton(onClick = { selectedIssueToResolve = null }) { Text("Cancel") }
            }
        )
    }

    // Create Issue Dialog
    if (showCreateDialog) {
        var issueTitle by remember { mutableStateOf("") }
        var issueCategory by remember { mutableStateOf("Scripture Inaccuracy") }
        var issueSeverity by remember { mutableStateOf("Medium") }
        var issueDesc by remember { mutableStateOf("") }
        var userQuery by remember { mutableStateOf("") }
        var expected by remember { mutableStateOf("") }

        AlertDialog(
            onDismissRequest = { showCreateDialog = false },
            title = { Text("Log New Platform Issue") },
            text = {
                LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    item {
                        OutlinedTextField(
                            value = issueTitle,
                            onValueChange = { issueTitle = it },
                            label = { Text("Issue Title") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    item {
                        OutlinedTextField(
                            value = issueDesc,
                            onValueChange = { issueDesc = it },
                            label = { Text("Description & Root Cause") },
                            modifier = Modifier.fillMaxWidth(),
                            minLines = 2
                        )
                    }
                    item {
                        OutlinedTextField(
                            value = userQuery,
                            onValueChange = { userQuery = it },
                            label = { Text("Sample User Query") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                    item {
                        OutlinedTextField(
                            value = expected,
                            onValueChange = { expected = it },
                            label = { Text("Expected Scriptural Result") },
                            modifier = Modifier.fillMaxWidth()
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (issueTitle.isNotBlank()) {
                            val newIssue = IssueEntity(
                                issueCode = "ISS-2026-00${(issues.size + 1)}",
                                title = issueTitle,
                                description = issueDesc,
                                userQuery = userQuery,
                                aiResponse = "",
                                expectedResponse = expected,
                                actualResponse = "",
                                severity = issueSeverity,
                                category = issueCategory,
                                status = "Open",
                                assignedAdmin = "superadmin"
                            )
                            viewModel.createIssue(newIssue)
                            showCreateDialog = false
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
                ) {
                    Text("Save Issue", color = Color.Black)
                }
            },
            dismissButton = {
                TextButton(onClick = { showCreateDialog = false }) { Text("Cancel") }
            }
        )
    }
}
