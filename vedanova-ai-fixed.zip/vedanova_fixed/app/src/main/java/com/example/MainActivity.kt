package com.example

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.activity.viewModels
import com.example.ui.AdminAppScaffold
import com.example.ui.theme.VedaNovaTheme
import com.example.ui.viewmodel.VedaNovaViewModel

class MainActivity : ComponentActivity() {
    private val viewModel: VedaNovaViewModel by viewModels()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            VedaNovaTheme {
                AdminAppScaffold(viewModel = viewModel)
            }
        }
    }
}
