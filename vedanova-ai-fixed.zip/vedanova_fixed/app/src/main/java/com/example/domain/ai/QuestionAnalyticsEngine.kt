package com.example.domain.ai

data class TopicFrequency(
    val title: String,
    val bengaliTitle: String,
    val count: Int,
    val category: String,
    val growthRate: String
)

data class QuestionLearningReport(
    val topTopics: List<TopicFrequency>,
    val topMantras: List<TopicFrequency>,
    val topDeities: List<TopicFrequency>,
    val topScriptures: List<TopicFrequency>,
    val unknownQueries: List<String>,
    val repeatedQuestions: List<String>
)

object QuestionAnalyticsEngine {

    fun generateReport(): QuestionLearningReport {
        return QuestionLearningReport(
            topTopics = listOf(
                TopicFrequency("Nishkama Karma in Modern Life", "আধুনিক জীবনে নিষ্কাম কর্ম", 142, "Philosophy", "+34%"),
                TopicFrequency("Gayatri Mantra Daily Japa Method", "গায়ত্রী মন্ত্র জপের নিয়ম", 128, "Mantras", "+18%"),
                TopicFrequency("Maha Mrityunjaya Protection Meaning", "মহামৃত্যুঞ্জয় মন্ত্রের গভীর অর্থ", 96, "Mantras", "+22%"),
                TopicFrequency("Advaita vs Dvaita Philosophy", "অদ্বৈত ও দ্বৈত বেদান্তের পার্থক্য", 84, "Philosophy", "+15%"),
                TopicFrequency("Durga Puja Navaratri Vidhi", "দুর্গাপূজা ও নবরাত্রির তাৎপর্য", 76, "Festivals", "+45%")
            ),
            topMantras = listOf(
                TopicFrequency("Gayatri Mantra (Rigveda 3.62.10)", "গায়ত্রী মন্ত্র", 340, "Vedic", "+20%"),
                TopicFrequency("Maha Mrityunjaya Mantra (Rigveda 7.59.12)", "মহামৃত্যুঞ্জয় মন্ত্র", 280, "Vedic", "+25%"),
                TopicFrequency("Hare Krishna Maha-Mantra (Kalisantarana)", "মহামন্ত্র", 190, "Purana", "+12%"),
                TopicFrequency("Shiva Panchakshara (Om Namah Shivaya)", "শিব পঞ্চাক্ষর মন্ত্র", 165, "Tantra/Agama", "+10%"),
                TopicFrequency("Sarvamangala Mangalye (Devi Chandi)", "সর্বমঙ্গল মঙ্গল্যে", 145, "Shakta", "+30%")
            ),
            topDeities = listOf(
                TopicFrequency("Lord Shiva (মহাদেব শিব)", "শিব", 420, "Shaiva", "+18%"),
                TopicFrequency("Lord Krishna / Vishnu (শ্রীকৃষ্ণ / শ্রীবিষ্ণু)", "শ্রীকৃষ্ণ", 395, "Vaishnava", "+15%"),
                TopicFrequency("Maa Durga / Kali (মা দুর্গা / কালী)", "দুর্গা", 310, "Shakta", "+28%"),
                TopicFrequency("Lord Ganesha (শ্রীগণেশ)", "গণেশ", 180, "Ganapatya", "+8%"),
                TopicFrequency("Lord Hanuman (শ্রীহনুমান)", "হনুমান", 150, "Bhakti", "+14%")
            ),
            topScriptures = listOf(
                TopicFrequency("Srimad Bhagavad Gita", "শ্রীমদ্ভগবদ্গীতা", 580, "Smriti", "+22%"),
                TopicFrequency("Mukhya Upanishads (12 Principal)", "মুখ্য উপনিষদ", 240, "Shruti", "+14%"),
                TopicFrequency("Sri Sri Chandi / Devi Mahatmya", "শ্রীশ্রীচণ্ডী", 190, "Purana", "+32%"),
                TopicFrequency("Rigveda & Yajurveda Samhitas", "বেদ সংহিতা", 160, "Shruti", "+19%"),
                TopicFrequency("Srimad Bhagavatam", "শ্রীমদ্ভাগবত পুরাণ", 130, "Purana", "+11%")
            ),
            unknownQueries = listOf(
                "তন্ত্রোক্ত বিশেষ সংকল্প বিধি কি বৈদিক সংকল্প থেকে ভিন্ন?",
                "শ্রীবিদ্যা সাধনায় পঞ্চদশাক্ষরী মন্ত্রের ক্রম কি?",
                "অঙ্গিরা স্মৃতির প্রায়শ্চিত্ত বিধান বর্তমান যুগে প্রয়োগযোগ্য কি?"
            ),
            repeatedQuestions = listOf(
                "গায়ত্রী মন্ত্র জপের উপযুক্ত সময় কখন?",
                "গীতার ২.৪৭ শ্লোকের আসল ভাবার্থ কী?",
                "শিবরাত্রির চার প্রহরের পূজায় কী কী অর্পণ করতে হয়?"
            )
        )
    }
}
