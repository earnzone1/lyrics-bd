package com.example.domain.api

import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow

data class EmergencyControlsState(
    val isGlobalAiPaused: Boolean = false,
    val isApiPaused: Boolean = false,
    val isResearchPaused: Boolean = false,
    val isKnowledgePublishPaused: Boolean = false,
    val emergencyNotice: String? = null,
    val lastToggledAt: Long = System.currentTimeMillis(),
    val toggledBy: String = "Super Admin"
)

object EmergencyControlsManager {
    private val _controlsState = MutableStateFlow(EmergencyControlsState())
    val controlsState: StateFlow<EmergencyControlsState> = _controlsState.asStateFlow()

    fun setGlobalAiPaused(paused: Boolean, reason: String? = null, admin: String = "Super Admin") {
        _controlsState.value = _controlsState.value.copy(
            isGlobalAiPaused = paused,
            emergencyNotice = if (paused) (reason ?: "Global AI reasoning paused by emergency protocol.") else null,
            lastToggledAt = System.currentTimeMillis(),
            toggledBy = admin
        )
    }

    fun setApiPaused(paused: Boolean, reason: String? = null, admin: String = "Super Admin") {
        _controlsState.value = _controlsState.value.copy(
            isApiPaused = paused,
            emergencyNotice = if (paused) (reason ?: "API Gateway endpoints paused by administrator.") else null,
            lastToggledAt = System.currentTimeMillis(),
            toggledBy = admin
        )
    }

    fun setResearchPaused(paused: Boolean, admin: String = "Super Admin") {
        _controlsState.value = _controlsState.value.copy(
            isResearchPaused = paused,
            lastToggledAt = System.currentTimeMillis(),
            toggledBy = admin
        )
    }

    fun setKnowledgePublishPaused(paused: Boolean, admin: String = "Super Admin") {
        _controlsState.value = _controlsState.value.copy(
            isKnowledgePublishPaused = paused,
            lastToggledAt = System.currentTimeMillis(),
            toggledBy = admin
        )
    }

    fun resetAllControls(admin: String = "Super Admin") {
        _controlsState.value = EmergencyControlsState(
            isGlobalAiPaused = false,
            isApiPaused = false,
            isResearchPaused = false,
            isKnowledgePublishPaused = false,
            emergencyNotice = null,
            lastToggledAt = System.currentTimeMillis(),
            toggledBy = admin
        )
    }
}
