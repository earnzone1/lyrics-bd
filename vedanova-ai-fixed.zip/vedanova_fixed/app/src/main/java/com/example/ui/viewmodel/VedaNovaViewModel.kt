package com.example.ui.viewmodel

import android.app.Application
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.local.VedaNovaDatabase
import com.example.data.model.*
import com.example.data.repository.VedaNovaRepository
import com.example.domain.ai.DiagnosticInfo
import com.example.domain.ai.OrchestratedResponse
import com.example.domain.ai.SelfDiagnosticReport
import com.example.domain.api.ApiGatewayRequest
import com.example.domain.api.ApiGatewayResponse
import com.example.domain.voice.FunctionAnnouncementManager
import com.example.domain.voice.VoiceGuideSettings
import com.example.domain.diagnostic.CrashReportingManager
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch

enum class ScreenDestination(val title: String, val section: String) {
    DASHBOARD("Control Center", "Core"),
    EXTERNAL_APPS_MONITOR("External Apps Monitor", "External Apps"),
    CAPABILITY_APPROVAL("Capability Approval Center", "External Apps"),
    DAILY_DATA_MONITOR("Daily Data & Festivals", "External Apps"),
    EXTERNAL_APP_SIMULATOR("External App Simulator", "External Apps"),
    AI_TESTING_LAB("AI Testing Lab", "AI & Testing"),
    API_CENTER("API Center", "API Platform"),
    API_TESTING("API Testing Console", "API Platform"),
    EXTERNAL_TEST_CLIENT("API Test Client", "API Platform"),
    KNOWLEDGE_CENTER("Knowledge Center", "Knowledge"),
    TEACH_AI("Teach AI", "Knowledge"),
    PROBLEM_CENTER("Problem Center", "Monitoring"),
    REPORTS("User Reports", "Monitoring"),
    DATABASE_CENTER("Database Center", "Infrastructure"),
    USERS("Admin Users & RBAC", "Access Control"),
    ANALYTICS("API Analytics", "Monitoring"),
    LOGS("System Logs", "Monitoring"),
    AUDIT_LOGS("Audit Trail", "Security & Governance"),
    SYSTEM_HEALTH("System Health", "Infrastructure"),
    SECURITY("Security Center", "Security & Governance"),
    BACKUPS("Backup & Restore", "Infrastructure"),
    SETTINGS("Settings", "Core"),
    FUNCTION_MAP("Admin Function Map", "Core"),
    CRASH_REPORTS("Crash Diagnostic Center", "Monitoring"),
    RESEARCH_CENTER("Web Research & Harvesting Center", "Knowledge"),
    PUBLIC_APP("Public Dharma App", "Client App")
}

data class ResearchLabState(
    val query: String = "গায়ত্রী মহামন্ত্রের মূল উৎস, অর্থ ও ছন্দ কী?",
    val isLoading: Boolean = false,
    val webResult: com.example.domain.research.WebResearchResult? = null,
    val youtubeResult: com.example.domain.research.YouTubeResearchResult? = null,
    val crossVerificationReport: com.example.domain.research.CrossSourceVerificationReport? = null,
    val mantraShieldResult: com.example.domain.research.MantraVerificationShieldResult? = null,
    val discoveryResults: List<com.example.domain.research.TopicScanResult> = emptyList(),
    val isScanningDiscovery: Boolean = false,
    val discoveryCategories: Set<String> = setOf("Vedic Mantras", "Upanishadic Mantras", "Gita Verses", "Shiva Mantras"),
    val activeTab: Int = 0 // 0: Web & YouTube Research Engine, 1: Mantra Verification Shield, 2: Dharma Discovery Scanner, 3: Candidate Approval Center, 4: Research Issue Center, 5: Research Activity Audit Log
)

data class ExternalClientTestState(
    val baseUrl: String = "https://api.vedanova.ai",
    val apiKey: String = "vn_live_9a87f2e14bc8901ad47e3321",
    val isRunningSuite: Boolean = false,
    val suiteProgress: Float = 0f,
    val testResults: List<com.example.domain.api.RemoteTestResult> = emptyList(),
    val activeTab: Int = 0, // 0: Automated Test Suite (12 Tests), 1: Manual HTTP Playground
    val playgroundEndpoint: String = "/api/v1/chat",
    val playgroundMethod: String = "POST",
    val playgroundBody: String = "{\n  \"query\": \"শ্রীমদ্ভগবদ্গীতার মূল বার্তা কী?\"\n}",
    val playgroundResponse: ApiGatewayResponse? = null,
    val isPlaygroundLoading: Boolean = false
)

data class SystemHealthStatus(
    val backendStatus: String = "GREEN", // GREEN, YELLOW, RED
    val databaseStatus: String = "GREEN",
    val aiProviderStatus: String = "GREEN",
    val apiGatewayStatus: String = "GREEN",
    val knowledgeEngineStatus: String = "GREEN",
    val researchEngineStatus: String = "GREEN",
    val verificationEngineStatus: String = "GREEN",
    val authStatus: String = "GREEN",
    val storageStatus: String = "GREEN",
    val backupStatus: String = "GREEN"
)

data class AiLabTestState(
    val query: String = "",
    val isLoading: Boolean = false,
    val response: OrchestratedResponse? = null,
    val selfDiagnosticReport: SelfDiagnosticReport? = null,
    val selectedLanguageFilter: String = "All",
    val deepDiagnosticMode: Boolean = true, // Requirement #17: Admin Deep Diagnostic Mode
    val error: String? = null
)

data class ApiTestConsoleState(
    val selectedEndpoint: String = "/api/v1/chat",
    val selectedMethod: String = "POST",
    val selectedApiKeyId: Long = 1,
    val customBearerKey: String = "vn_live_9a87f2e14bc8901ad47e3321",
    val requestHeaders: String = "Content-Type: application/json\nAccept: application/json",
    val requestBody: String = "{\n  \"query\": \"গায়ত্রী মন্ত্রের অর্থ ও ঋষি কে?\"\n}",
    val isLoading: Boolean = false,
    val response: ApiGatewayResponse? = null,
    val requestHistory: List<Pair<ApiGatewayRequest, ApiGatewayResponse>> = emptyList()
)

data class TeachAiState(
    val title: String = "",
    val question: String = "",
    val answer: String = "",
    val category: String = "GENERAL_DHARMA",
    val source: String = "Admin Verified Scripture",
    val reference: String = "",
    val sanskritText: String = "",
    val transliteration: String = "",
    val explanation: String = "",
    val saveAsCandidate: Boolean = false,
    val selectedUnknownId: Long? = null,
    val conflictResult: com.example.domain.ai.KnowledgeConflictResult? = null,
    val isSaving: Boolean = false,
    val successMessage: String? = null,
    val errorMessage: String? = null,
    val activeTeachTab: Int = 0 // 0: Teach Knowledge, 1: Unknown Queue, 2: Candidate Approvals, 3: Version History, 4: Usage Analytics
)

class VedaNovaViewModel(application: Application) : AndroidViewModel(application) {
    private val database = VedaNovaDatabase.getInstance(application)
    val repository = VedaNovaRepository(database)

    // Navigation State
    private val _currentScreen = MutableStateFlow(ScreenDestination.DASHBOARD)
    val currentScreen: StateFlow<ScreenDestination> = _currentScreen.asStateFlow()

    // Auth & Session State
    val currentSession = repository.adminAuthManager.currentSession
    val allUsers = repository.allUsers.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Database Data Streams
    val allKnowledge = repository.allKnowledge.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val publishedKnowledge = repository.publishedKnowledge.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val candidateKnowledge = repository.candidateKnowledge.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allUnknownKnowledge = repository.allUnknownKnowledge.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val pendingUnknownKnowledge = repository.pendingUnknownKnowledge.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val pendingUnknownCount = repository.pendingUnknownCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val allKnowledgeVersions = repository.allKnowledgeVersions.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allUsageLogs = repository.allUsageLogs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val draftKnowledgeItems = repository.draftKnowledgeItems.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val draftKnowledge = draftKnowledgeItems
    val allApiKeys = repository.allApiKeys.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val recentApiLogs = repository.recentApiLogs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allIssues = repository.allIssues.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allReports = repository.allReports.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val recentAuditLogs = repository.recentAuditLogs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val recentSystemLogs = repository.recentSystemLogs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allSettings = repository.allSettings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allBackups = repository.allBackups.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allExternalApps = repository.allExternalApps.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allCapabilityProposals = repository.allCapabilityProposals.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val recentDailyJobLogs = repository.recentDailyJobLogs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val recentCrashReports = repository.recentCrashReports.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val totalCrashCount = repository.totalCrashCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val recentActivityLogs = repository.recentActivityLogs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Phase 6 Research & Harvesting Flows
    val allResearchSources = repository.allResearchSources.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val allResearchIssues = repository.allResearchIssues.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val openResearchIssues = repository.openResearchIssues.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val openResearchIssuesCount = repository.openResearchIssuesCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val allKnowledgeCandidates = repository.allKnowledgeCandidates.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val pendingCandidates = repository.pendingCandidates.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    val pendingCandidatesCount = repository.pendingCandidatesCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val recentResearchActivityLogs = repository.recentResearchActivityLogs.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Phase 6 Research Lab State
    private val _researchLabState = MutableStateFlow(ResearchLabState())
    val researchLabState: StateFlow<ResearchLabState> = _researchLabState.asStateFlow()

    // Phase 5.1 Voice Guide & Announcer
    val voiceAnnouncementManager = FunctionAnnouncementManager(application)
    val voiceSettings = voiceAnnouncementManager.settings.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), VoiceGuideSettings())
    val lastAnnouncement = voiceAnnouncementManager.lastAnnouncement.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), "")

    // Phase 8: Live Voice AI & Call Architecture
    val liveVoiceManager = com.example.domain.voice.LiveVoiceAiManager(application)
    val liveVoiceState = liveVoiceManager.voiceState
    val liveVoiceTranscript = liveVoiceManager.liveTranscript
    val liveVoiceAmplitude = liveVoiceManager.voiceAmplitude
    val liveVoiceError = liveVoiceManager.voiceError
    val isVoiceCallActive = liveVoiceManager.isCallOverlayActive
    val liveVoiceSettings = liveVoiceManager.settings

    fun startLiveVoiceCall() {
        liveVoiceManager.startLiveCallSession { recognizedText ->
            sendPublicChatMessage(customQuery = recognizedText, fromVoice = true)
        }
    }

    fun endLiveVoiceCall() {
        liveVoiceManager.endLiveCallSession()
    }

    fun triggerSingleVoiceInput() {
        liveVoiceManager.triggerSingleVoiceInput { recognizedText ->
            _publicChatQuery.value = recognizedText
            sendPublicChatMessage(fromVoice = true)
        }
    }

    fun toggleVoiceMute() {
        liveVoiceManager.toggleMute()
    }

    fun interruptVoiceAndListen() {
        liveVoiceManager.interruptAndListen()
    }

    fun updateLiveVoiceSettings(settings: com.example.domain.voice.LiveVoiceSettings) {
        liveVoiceManager.updateSettings(settings)
    }

    init {
        CrashReportingManager.initialize(application, database)
    }

    // Metrics
    val knowledgeCount = repository.knowledgeCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 9)
    val totalLogsCount = repository.totalLogsCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val failedLogsCount = repository.failedLogsCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 0)
    val averageResponseTime = repository.averageResponseTime.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 125.0)
    val pendingIssuesCount = repository.pendingIssuesCount.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), 1)

    // Phase 4: Daily Data State
    private val _selectedDailyRegion = MutableStateFlow(com.example.domain.ai.CalendarRegion.BANGLADESH_DHAKA)
    val selectedDailyRegion: StateFlow<com.example.domain.ai.CalendarRegion> = _selectedDailyRegion.asStateFlow()

    private val _dailyData = MutableStateFlow(com.example.domain.ai.DailyDataEngine.resolveDailyData(com.example.domain.ai.CalendarRegion.BANGLADESH_DHAKA))
    val dailyData: StateFlow<com.example.domain.ai.DailyDataResolution> = _dailyData.asStateFlow()

    private val _isDailyJobRunning = MutableStateFlow(false)
    val isDailyJobRunning: StateFlow<Boolean> = _isDailyJobRunning.asStateFlow()

    private val _dailyJobMessage = MutableStateFlow<String?>(null)
    val dailyJobMessage: StateFlow<String?> = _dailyJobMessage.asStateFlow()

    // Phase 4: External App Sandbox / Simulator State
    private val _simulatorAppId = MutableStateFlow("APP-DHARMAGUIDE-101")
    val simulatorAppId: StateFlow<String> = _simulatorAppId.asStateFlow()

    private val _simulatorRegion = MutableStateFlow(com.example.domain.ai.CalendarRegion.BANGLADESH_DHAKA)
    val simulatorRegion: StateFlow<com.example.domain.ai.CalendarRegion> = _simulatorRegion.asStateFlow()

    private val _simulatorActiveTab = MutableStateFlow(0) // 0: Dynamic Feed, 1: Live Countdown, 2: Capability Discovery, 3: Simulated App Chat, 4: Raw Gateway Inspection
    val simulatorActiveTab: StateFlow<Int> = _simulatorActiveTab.asStateFlow()

    private val _simulatorChatQuery = MutableStateFlow("আজকের তিথি ও পূজার শুভ মুহূর্ত কী?")
    val simulatorChatQuery: StateFlow<String> = _simulatorChatQuery.asStateFlow()

    private val _simulatorChatMessages = MutableStateFlow<List<Pair<String, String>>>(listOf(
        "APP_SYSTEM" to "Connected to VedaNova AI Cloud (API Key: vn_live_app_dharmaguide_a9102c). Scopes: [CALENDAR, CHAT, FESTIVAL, MANTRA]."
    ))
    val simulatorChatMessages: StateFlow<List<Pair<String, String>>> = _simulatorChatMessages.asStateFlow()

    private val _simulatorIsLoading = MutableStateFlow(false)
    val simulatorIsLoading: StateFlow<Boolean> = _simulatorIsLoading.asStateFlow()

    private val _simulatorLastResponse = MutableStateFlow<ApiGatewayResponse?>(null)
    val simulatorLastResponse: StateFlow<ApiGatewayResponse?> = _simulatorLastResponse.asStateFlow()

    private val _selectedAppForDetail = MutableStateFlow<ExternalAppEntity?>(null)
    val selectedAppForDetail: StateFlow<ExternalAppEntity?> = _selectedAppForDetail.asStateFlow()


    // Health Matrix
    private val _healthStatus = MutableStateFlow(SystemHealthStatus())
    val healthStatus: StateFlow<SystemHealthStatus> = _healthStatus.asStateFlow()

    // AI Testing Lab State
    private val _aiLabState = MutableStateFlow(AiLabTestState())
    val aiLabState: StateFlow<AiLabTestState> = _aiLabState.asStateFlow()

    // API Testing Console State
    private val _apiTestState = MutableStateFlow(ApiTestConsoleState())
    val apiTestState: StateFlow<ApiTestConsoleState> = _apiTestState.asStateFlow()

    // External Client State
    private val _externalClientState = MutableStateFlow(ExternalClientTestState())
    val externalClientState: StateFlow<ExternalClientTestState> = _externalClientState.asStateFlow()

    // Public App State
    private val _publicChatQuery = MutableStateFlow("")
    val publicChatQuery = _publicChatQuery.asStateFlow()

    private val _publicChatMessages = MutableStateFlow<List<Pair<String, String>>>(listOf(
        "AI" to "নমস্কার! আমি VedaNova AI। সনাতন হিন্দু ধর্ম, বেদ, উপনিষদ, শ্রীমদ্ভগবদ্গীতা, মন্ত্র, পূজা ও দর্শন সম্পর্কে আপনার কোনো প্রশ্ন থাকলে নির্দ্বিধায় জিজ্ঞাসা করুন।"
    ))
    val publicChatMessages = _publicChatMessages.asStateFlow()

    private val _publicClarificationOptions = MutableStateFlow<List<String>>(emptyList())
    val publicClarificationOptions = _publicClarificationOptions.asStateFlow()

    private val _lastPublicResponse = MutableStateFlow<OrchestratedResponse?>(null)
    val lastPublicResponse = _lastPublicResponse.asStateFlow()

    private val _publicIsLoading = MutableStateFlow(false)
    val publicIsLoading = _publicIsLoading.asStateFlow()

    // Global Search State
    private val _globalSearchQuery = MutableStateFlow("")
    val globalSearchQuery = _globalSearchQuery.asStateFlow()

    fun navigateTo(destination: ScreenDestination) {
        val prev = _currentScreen.value
        _currentScreen.value = destination
        CrashReportingManager.updateNavigationContext(
            current = destination.name,
            previous = prev.name,
            action = "Admin navigated from ${prev.title} to ${destination.title}"
        )
        voiceAnnouncementManager.announceNavigation(destination.name)
        viewModelScope.launch {
            val adminUser = currentSession.value.currentUser.username
            repository.logFunctionActivity(
                functionId = destination.name.lowercase(),
                functionName = destination.title,
                section = destination.section,
                previousScreen = prev.name,
                currentScreen = destination.name,
                adminUser = adminUser
            )
        }
    }

    fun switchAdminUser(user: AdminUserEntity) {
        viewModelScope.launch {
            repository.adminAuthManager.switchUser(user)
        }
    }

    // AI Lab Actions
    fun setAiLabQuery(q: String) {
        _aiLabState.update { it.copy(query = q) }
    }

    fun runAiLabTest(query: String? = null) {
        val q = query ?: _aiLabState.value.query
        if (q.isBlank()) return

        viewModelScope.launch {
            _aiLabState.update { it.copy(isLoading = true, error = null, query = q) }
            try {
                val result = repository.processAiQuery(q)
                val diagReport = repository.runSelfDiagnostics(q, result.answer, result)
                _aiLabState.update {
                    it.copy(
                        isLoading = false,
                        response = result,
                        selfDiagnosticReport = diagReport
                    )
                }
            } catch (e: Exception) {
                _aiLabState.update { it.copy(isLoading = false, error = e.message) }
            }
        }
    }

    // API Testing Console Actions
    fun updateApiTestEndpoint(endpoint: String) {
        val templateBody = when (endpoint) {
            "/api/v1/chat" -> "{\n  \"query\": \"শ্রীমদ্ভগবদ্গীতার ২.৪৭ শ্লোকের অর্থ কী?\"\n}"
            "/api/v1/research" -> "{\n  \"query\": \"Comparative analysis of Nishkama Karma in Gita vs Upanishadic Renunciation\"\n}"
            "/api/v1/knowledge/search" -> "{\n  \"query\": \"Gayatri Mantra\"\n}"
            "/api/v1/mantra/search" -> "{\n  \"query\": \"Mahamrityunjaya\"\n}"
            "/api/v1/scripture/search" -> "{\n  \"query\": \"Isha Upanishad\"\n}"
            "/api/v1/verify" -> "{\n  \"query\": \"যদা যদা হি ধর্মস্য গ্লানির্ভবতি\"\n}"
            "/api/v1/status" -> ""
            else -> "{\n  \"query\": \"Sanatan Dharma\"\n}"
        }
        val method = if (endpoint.contains("/status")) "GET" else "POST"
        _apiTestState.update { 
            it.copy(selectedEndpoint = endpoint, selectedMethod = method, requestBody = templateBody) 
        }
    }

    fun updateApiTestKey(apiKey: String) {
        _apiTestState.update { it.copy(customBearerKey = apiKey) }
    }

    fun updateApiTestBody(body: String) {
        _apiTestState.update { it.copy(requestBody = body) }
    }

    fun sendApiTestRequest() {
        val state = _apiTestState.value
        viewModelScope.launch {
            _apiTestState.update { it.copy(isLoading = true) }
            val request = ApiGatewayRequest(
                endpoint = state.selectedEndpoint,
                method = state.selectedMethod,
                apiKey = state.customBearerKey,
                body = state.requestBody
            )
            val response = repository.executeGatewayRequest(request)
            _apiTestState.update {
                it.copy(
                    isLoading = false,
                    response = response,
                    requestHistory = listOf(request to response) + it.requestHistory.take(15)
                )
            }
        }
    }

    // External Client Testing Actions
    fun setExternalBaseUrl(url: String) {
        _externalClientState.update { it.copy(baseUrl = url) }
    }

    fun setExternalApiKey(key: String) {
        _externalClientState.update { it.copy(apiKey = key) }
    }

    fun setExternalActiveTab(tab: Int) {
        _externalClientState.update { it.copy(activeTab = tab) }
    }

    fun setExternalPlaygroundEndpoint(endpoint: String) {
        val templateBody = when (endpoint) {
            "/api/v1/chat" -> "{\n  \"query\": \"শ্রীমদ্ভগবদ্গীতার মূল বার্তা কী?\"\n}"
            "/api/v1/research" -> "{\n  \"query\": \"Comparative analysis of Karma Yoga and Jnana Yoga\"\n}"
            "/api/v1/knowledge/search" -> "{\n  \"query\": \"Gayatri Mantra\"\n}"
            "/api/v1/mantra/search" -> "{\n  \"query\": \"Mahamrityunjaya\"\n}"
            "/api/v1/scripture/search" -> "{\n  \"query\": \"Isha Upanishad\"\n}"
            "/api/v1/verify" -> "{\n  \"query\": \"যদা যদা হি ধর্মস্য গ্লানির্ভবতি ভারত\"\n}"
            "/api/v1/status" -> ""
            else -> "{\n  \"query\": \"Sanatan Dharma\"\n}"
        }
        val method = if (endpoint.contains("/status")) "GET" else "POST"
        _externalClientState.update {
            it.copy(
                playgroundEndpoint = endpoint,
                playgroundMethod = method,
                playgroundBody = templateBody
            )
        }
    }

    fun setExternalPlaygroundBody(body: String) {
        _externalClientState.update { it.copy(playgroundBody = body) }
    }

    fun executeExternalPlaygroundRequest() {
        val state = _externalClientState.value
        viewModelScope.launch {
            _externalClientState.update { it.copy(isPlaygroundLoading = true) }
            val response = repository.remoteHttpClient.executeRemoteRequest(
                baseUrl = state.baseUrl,
                endpoint = state.playgroundEndpoint,
                method = state.playgroundMethod,
                apiKey = state.apiKey,
                body = state.playgroundBody
            )
            _externalClientState.update {
                it.copy(
                    isPlaygroundLoading = false,
                    playgroundResponse = response
                )
            }
        }
    }

    fun runExternalFullTestSuite() {
        val state = _externalClientState.value
        if (state.isRunningSuite) return

        viewModelScope.launch {
            _externalClientState.update {
                it.copy(isRunningSuite = true, suiteProgress = 0.05f, testResults = emptyList())
            }

            val testCases = listOf(
                Triple("1. API Key Creation & Handshake", "/api/v1/status", "GET" to ""),
                Triple("2. API Key Expiry Validation", "/api/v1/status", "GET" to ""),
                Triple("3. API Key Suspension Check", "/api/v1/chat", "POST" to "{\"query\": \"Dharma\"}"),
                Triple("4. API Key Revocation Enforcement", "/api/v1/chat", "POST" to "{\"query\": \"Dharma\"}"),
                Triple("5. Granular Scope Enforcer (/api/v1/research)", "/api/v1/research", "POST" to "{\"query\": \"Veda\"}"),
                Triple("6. Rate Limiting Enforcer (HTTP 429)", "/api/v1/chat", "POST" to "{\"query\": \"Speed test\"}"),
                Triple("7. Emergency Kill Switch Verification", "/api/v1/status", "GET" to ""),
                Triple("8. Central Request Logging & Auditing", "/api/v1/status", "GET" to ""),
                Triple("9. Application Data Isolation (App A vs App B)", "/api/v1/chat", "POST" to "{\"query\": \"Application isolation check\"}"),
                Triple("10. Shiva Inquiry ('শিব কে?')", "/api/v1/chat", "POST" to "{\"query\": \"শিব কে?\"}"),
                Triple("11. Shiva Mantra ('তাঁর একটি মন্ত্র বলো')", "/api/v1/chat", "POST" to "{\"query\": \"তাঁর একটি মন্ত্র বলো\"}"),
                Triple("12. Context Follow-up ('মন্ত্রটার অর্থ কী?')", "/api/v1/chat", "POST" to "{\"query\": \"মন্ত্রটার অর্থ কী?\"}"),
                Triple("13. Source Reference ('এটা কোথায় পাওয়া যায়?')", "/api/v1/chat", "POST" to "{\"query\": \"এটা কোথায় পাওয়া যায়?\"}"),
                Triple("14. Continued Context ('আরেকটা দাও')", "/api/v1/chat", "POST" to "{\"query\": \"আরেকটা দাও\"}"),
                Triple("15. Daily Dharma Tithi Data ('আজ কী তিথি?')", "/api/v1/chat", "POST" to "{\"query\": \"আজ কী তিথি?\"}"),
                Triple("16. Knowledge Search (/api/v1/knowledge/search)", "/api/v1/knowledge/search", "POST" to "{\"query\": \"Gayatri Mantra\"}"),
                Triple("17. Mantra Search (/api/v1/mantra/search)", "/api/v1/mantra/search", "POST" to "{\"query\": \"Mahamrityunjaya\"}"),
                Triple("18. Scripture Verse Search (/api/v1/scripture/search)", "/api/v1/scripture/search", "POST" to "{\"query\": \"Isha Upanishad\"}"),
                Triple("19. Scriptural Fact Verification (/api/v1/verify)", "/api/v1/verify", "POST" to "{\"query\": \"যদা যদা হি ধর্মস্য গ্লানির্ভবতি ভারত\"}"),
                Triple("20. Like/Dislike Feedback Pipeline", "/api/v1/chat", "POST" to "{\"query\": \"শ্রীমদ্ভগবদ্গীতা\"}"),
                Triple("21. Devotee Report System", "/api/v1/chat", "POST" to "{\"query\": \"Report Pipeline Verification\"}"),
                Triple("22. Admin Issue Center Resolution Handshake", "/api/v1/status", "GET" to ""),
                Triple("23. Human-like Conversational Guardrail", "/api/v1/chat", "POST" to "{\"query\": \"অদ্বৈত বেদান্ত বনাম দ্বৈত বেদান্ত\"}"),
                Triple("24. Audio Waveform & Visualizer State", "/api/v1/status", "GET" to ""),
                Triple("25. Live Voice Call Overlay Engine", "/api/v1/status", "GET" to ""),
                Triple("26. Voice Error & Safety Recovery Guard", "/api/v1/status", "GET" to ""),
                Triple("27. High-Concurrency Stress Test", "/api/v1/chat", "POST" to "{\"query\": \"Stress test payload\"}"),
                Triple("28. Overall System Integrity Verification", "/api/v1/status", "GET" to "")
            )

            val accumulatedResults = mutableListOf<com.example.domain.api.RemoteTestResult>()

            testCases.forEachIndexed { index, (testName, endpoint, methodAndBody) ->
                val (method, body) = methodAndBody
                val testApiKey = when (index) {
                    2 -> "vn_live_suspended_revoked_key_9999"
                    3 -> "vn_live_invalid_bad_key_0000"
                    else -> state.apiKey
                }

                val startTime = System.currentTimeMillis()
                val response = repository.remoteHttpClient.executeRemoteRequest(
                    baseUrl = state.baseUrl,
                    endpoint = endpoint,
                    method = method,
                    apiKey = testApiKey,
                    body = body
                )
                val latency = System.currentTimeMillis() - startTime

                val isSuccess = when (index) {
                    2, 3 -> response.statusCode in listOf(401, 403) // Expected auth failure
                    else -> response.statusCode in 200..299
                }

                val result = com.example.domain.api.RemoteTestResult(
                    testName = testName,
                    endpoint = endpoint,
                    method = method,
                    httpStatusCode = response.statusCode,
                    latencyMs = latency,
                    isSuccess = isSuccess,
                    responseBody = response.jsonBody,
                    requestId = response.requestId,
                    errorDescription = if (!isSuccess) response.statusText else null
                )

                accumulatedResults.add(result)
                val progress = (index + 1).toFloat() / testCases.size.toFloat()
                _externalClientState.update {
                    it.copy(
                        suiteProgress = progress,
                        testResults = accumulatedResults.toList()
                    )
                }
                kotlinx.coroutines.delay(100)
            }

            _externalClientState.update {
                it.copy(isRunningSuite = false, suiteProgress = 1f)
            }
        }
    }

    // Knowledge Actions
    private val _teachAiState = MutableStateFlow(TeachAiState())
    val teachAiState: StateFlow<TeachAiState> = _teachAiState.asStateFlow()

    fun setTeachTab(tab: Int) {
        _teachAiState.update { it.copy(activeTeachTab = tab, successMessage = null, errorMessage = null) }
    }

    fun updateTeachField(
        title: String? = null,
        question: String? = null,
        answer: String? = null,
        category: String? = null,
        source: String? = null,
        reference: String? = null,
        sanskrit: String? = null,
        transliteration: String? = null,
        explanation: String? = null,
        saveAsCandidate: Boolean? = null
    ) {
        _teachAiState.update { current ->
            current.copy(
                title = title ?: current.title,
                question = question ?: current.question,
                answer = answer ?: current.answer,
                category = category ?: current.category,
                source = source ?: current.source,
                reference = reference ?: current.reference,
                sanskritText = sanskrit ?: current.sanskritText,
                transliteration = transliteration ?: current.transliteration,
                explanation = explanation ?: current.explanation,
                saveAsCandidate = saveAsCandidate ?: current.saveAsCandidate,
                conflictResult = null,
                errorMessage = null
            )
        }
    }

    fun prefillTeachFromUnknown(item: UnknownKnowledgeEntity) {
        _teachAiState.update {
            it.copy(
                selectedUnknownId = item.id,
                title = item.userQuestion.take(60),
                question = item.userQuestion,
                answer = "",
                category = item.suggestedCategory.ifBlank { "GENERAL_DHARMA" },
                source = "Admin Verified Teaching",
                reference = "Veda / Gita / Agama Canonicals",
                activeTeachTab = 0,
                successMessage = "Pre-filled question from Unknown Queue (#${item.id})",
                errorMessage = null
            )
        }
    }

    fun clearTeachForm() {
        _teachAiState.update {
            TeachAiState(activeTeachTab = it.activeTeachTab)
        }
    }

    fun checkConflictAndTeachKnowledge(overrideConflict: Boolean = false) {
        val state = _teachAiState.value
        val cleanQ = state.question.trim()
        val cleanAns = state.answer.trim()
        val cleanTitle = state.title.ifBlank { cleanQ.take(60) }

        if (cleanQ.isBlank() && cleanTitle.isBlank()) {
            _teachAiState.update { it.copy(errorMessage = "প্রশ্ন বা শিরোনাম প্রদান করা বাধ্যতামূলক।") }
            return
        }
        if (cleanAns.isBlank()) {
            _teachAiState.update { it.copy(errorMessage = "উত্তর (Answer) প্রদান করা বাধ্যতামূলক।") }
            return
        }

        viewModelScope.launch {
            _teachAiState.update { it.copy(isSaving = true, errorMessage = null) }
            
            // Check Conflict
            if (!overrideConflict) {
                val published = allKnowledge.value
                val conflict = com.example.domain.ai.KnowledgeMatchingEngine.detectConflict(
                    newTitle = cleanTitle,
                    newQuestion = cleanQ,
                    newAnswer = cleanAns,
                    newCategory = state.category,
                    existingList = published
                )
                if (conflict.hasConflict) {
                    _teachAiState.update { it.copy(isSaving = false, conflictResult = conflict) }
                    return@launch
                }
            }

            try {
                if (state.selectedUnknownId != null) {
                    repository.teachFromUnknownQuery(
                        unknownId = state.selectedUnknownId,
                        question = cleanQ,
                        answer = cleanAns,
                        category = state.category,
                        source = state.source,
                        reference = state.reference,
                        saveAsCandidate = state.saveAsCandidate
                    )
                } else {
                    val code = "KB-" + (1000..9999).random()
                    val status = if (state.saveAsCandidate) "CANDIDATE" else "PUBLISHED"
                    val item = KnowledgeEntity(
                        knowledgeCode = code,
                        title = cleanTitle,
                        question = cleanQ,
                        answer = cleanAns,
                        category = state.category,
                        language = "BENGALI",
                        sanskritText = state.sanskritText,
                        transliteration = state.transliteration,
                        banglaMeaning = cleanAns,
                        explanation = state.explanation,
                        source = state.source,
                        reference = state.reference,
                        verificationStatus = status,
                        confidenceScore = 1.0f,
                        version = 1,
                        createdBy = "Admin Knowledge Teacher",
                        updatedBy = "Admin"
                    )
                    val newId = repository.insertKnowledge(item)
                    repository.knowledgeVersionDao.insertVersion(
                        KnowledgeVersionEntity(
                            knowledgeId = newId,
                            versionNumber = 1,
                            title = item.title,
                            question = item.question,
                            answer = item.answer,
                            category = item.category,
                            source = item.source,
                            reference = item.reference,
                            changedBy = "Admin",
                            changeReason = "Taught directly by Admin",
                            diffSummary = "Initial authoritative publication v1."
                        )
                    )
                }

                _teachAiState.update {
                    TeachAiState(
                        activeTeachTab = it.activeTeachTab,
                        successMessage = if (state.saveAsCandidate) "জ্ঞানটি সফলভাবে Candidate হিসেবে সংরক্ষিত হয়েছে (অনুমোদনের জন্য অপেক্ষমাণ)।" else "জ্ঞানটি সফলভাবে যাচাইকৃত ও প্রকাশিত হয়েছে! AI এখন তাৎক্ষণিকভাবে এটি ব্যবহার করতে পারবে।"
                    )
                }
            } catch (e: Exception) {
                _teachAiState.update { it.copy(isSaving = false, errorMessage = "সংরক্ষণে ব্যর্থ: ${e.message}") }
            }
        }
    }

    fun approveCandidateKnowledge(item: KnowledgeEntity) {
        viewModelScope.launch {
            repository.publishCandidate(item)
            _teachAiState.update { it.copy(successMessage = "Candidate '${item.title}' সফলভাবে Approved & Published হয়েছে!") }
        }
    }

    fun rejectCandidateKnowledge(item: KnowledgeEntity, reason: String = "Rejected by Admin") {
        viewModelScope.launch {
            repository.rejectDraftKnowledge(item)
            _teachAiState.update { it.copy(successMessage = "Candidate '${item.title}' সফলভাবে Rejected হয়েছে।") }
        }
    }

    fun ignoreUnknownQuery(item: UnknownKnowledgeEntity) {
        viewModelScope.launch {
            repository.unknownKnowledgeDao.updateUnknown(item.copy(status = "IGNORED", resolvedAt = System.currentTimeMillis()))
        }
    }

    fun recordUsageFeedback(knowledgeId: Long, query: String, isHelpful: Boolean) {
        viewModelScope.launch {
            val score = if (isHelpful) 1 else -1
            if (isHelpful) {
                repository.knowledgeDao.incrementSuccess(knowledgeId)
            }
            repository.knowledgeUsageLogDao.insertUsageLog(
                KnowledgeUsageLogEntity(
                    knowledgeId = knowledgeId,
                    userQuery = query,
                    matchedStrategy = "USER_FEEDBACK",
                    feedbackScore = score,
                    confidence = 1.0f
                )
            )
        }
    }

    fun createKnowledge(item: KnowledgeEntity, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.insertKnowledge(item)
            onComplete()
        }
    }

    fun updateKnowledge(item: KnowledgeEntity, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.updateKnowledge(item)
            onComplete()
        }
    }

    fun deleteKnowledge(item: KnowledgeEntity) {
        viewModelScope.launch {
            repository.deleteKnowledge(item)
        }
    }

    fun approveDraftKnowledge(item: KnowledgeEntity, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.approveDraftKnowledge(item)
            onComplete()
        }
    }

    fun approveDraftCandidate(item: KnowledgeEntity, onComplete: () -> Unit = {}) = approveDraftKnowledge(item, onComplete)

    fun rejectDraftKnowledge(item: KnowledgeEntity, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.rejectDraftKnowledge(item)
            onComplete()
        }
    }

    fun rejectDraftCandidate(item: KnowledgeEntity, onComplete: () -> Unit = {}) = rejectDraftKnowledge(item, onComplete)

    // API Key Actions
    fun createApiKey(
        name: String,
        appName: String,
        version: String,
        rateLimit: Int,
        dailyLimit: Int,
        monthlyLimit: Int,
        permissions: String,
        expiresInDays: Int = 0,
        onComplete: () -> Unit = {}
    ) {
        viewModelScope.launch {
            repository.createApiKey(name, appName, version, rateLimit, dailyLimit, monthlyLimit, permissions, expiresInDays)
            onComplete()
        }
    }

    fun extendApiKeyExpiry(key: ApiKeyEntity, additionalDays: Int) {
        viewModelScope.launch {
            repository.extendApiKeyExpiry(key, additionalDays)
        }
    }

    fun rotateApiKey(key: ApiKeyEntity) {
        viewModelScope.launch {
            repository.rotateApiKey(key)
        }
    }

    fun updateApiKeyStatus(key: ApiKeyEntity, status: String) {
        viewModelScope.launch {
            repository.updateApiKeyStatus(key, status)
        }
    }

    fun deleteApiKey(key: ApiKeyEntity) {
        viewModelScope.launch {
            repository.deleteApiKey(key)
        }
    }

    // Emergency Kill-Switch Controls
    val emergencyControlsState = com.example.domain.api.EmergencyControlsManager.controlsState

    fun toggleEmergencyGlobalAi(paused: Boolean, reason: String? = null) {
        com.example.domain.api.EmergencyControlsManager.setGlobalAiPaused(paused, reason)
    }

    fun toggleEmergencyApi(paused: Boolean, reason: String? = null) {
        com.example.domain.api.EmergencyControlsManager.setApiPaused(paused, reason)
    }

    fun toggleEmergencyResearch(paused: Boolean) {
        com.example.domain.api.EmergencyControlsManager.setResearchPaused(paused)
    }

    fun resetAllEmergencyControls() {
        com.example.domain.api.EmergencyControlsManager.resetAllControls()
    }

    // Issues & Reports Actions
    fun updateIssueStatus(issue: IssueEntity, newStatus: String, resolutionNotes: String = "") {
        viewModelScope.launch {
            repository.updateIssue(issue.copy(status = newStatus, resolution = resolutionNotes.ifBlank { issue.resolution }))
        }
    }

    fun createIssue(issue: IssueEntity, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.insertIssue(issue)
            onComplete()
        }
    }

    fun updateReportStatus(report: ReportEntity, newStatus: String, notes: String = "") {
        viewModelScope.launch {
            repository.updateReport(report.copy(status = newStatus, resolutionNotes = notes.ifBlank { report.resolutionNotes }))
        }
    }

    // Backups & DB Actions
    fun createBackup(name: String, type: String, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.createBackup(name, type)
            onComplete()
        }
    }

    fun restoreSeedData(onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.restoreDefaultSeedData()
            onComplete()
        }
    }

    fun updateSetting(key: String, value: String) {
        viewModelScope.launch {
            repository.updateSetting(key, value)
        }
    }

    // Public App Actions
    fun setPublicChatQuery(q: String) {
        _publicChatQuery.value = q
    }

    fun selectClarificationOption(option: String) {
        _publicClarificationOptions.value = emptyList()
        _publicChatQuery.value = option
        sendPublicChatMessage()
    }

    // Phase 3 Intelligence States
    val knowledgeGaps: StateFlow<List<com.example.domain.ai.KnowledgeGapItem>> = MutableStateFlow(
        com.example.domain.ai.KnowledgeGapDetector.detectGaps(20, 15)
    ).asStateFlow()

    val questionLearningReport: StateFlow<com.example.domain.ai.QuestionLearningReport> = MutableStateFlow(
        com.example.domain.ai.QuestionAnalyticsEngine.generateReport()
    ).asStateFlow()

    fun toggleDeepDiagnosticMode() {
        _aiLabState.update { it.copy(deepDiagnosticMode = !it.deepDiagnosticMode) }
    }

    fun createResearchTaskFromGap(gap: com.example.domain.ai.KnowledgeGapItem, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.createResearchTaskFromGap(gap)
            onComplete()
        }
    }

    fun submitPublicFeedback(feedbackText: String, messageSnippet: String, onComplete: () -> Unit = {}) {
        viewModelScope.launch {
            repository.submitUserFeedback(feedbackText, messageSnippet)
            onComplete()
        }
    }

    fun resetPublicChat() {
        repository.aiOrchestrator.resetContextState()
        _publicChatMessages.value = listOf(
            "AI" to "নমস্কার! আমি VedaNova AI। সনাতন হিন্দু ধর্ম, বেদ, উপনিষদ, শ্রীমদ্ভগবদ্গীতা, মন্ত্র, পূজা ও দর্শন সম্পর্কে আপনার কোনো প্রশ্ন থাকলে নির্দ্বিধায় জিজ্ঞাসা করুন।"
        )
        _publicClarificationOptions.value = emptyList()
        _lastPublicResponse.value = null
        _publicChatQuery.value = ""
    }

    fun sendPublicChatMessage(customQuery: String? = null, fromVoice: Boolean = false) {
        val q = customQuery?.trim() ?: _publicChatQuery.value.trim()
        if (q.isBlank()) return

        val currentHistory = _publicChatMessages.value
        _publicChatMessages.update { it + ("USER" to q) }
        _publicChatQuery.value = ""
        _publicClarificationOptions.value = emptyList()
        _publicIsLoading.value = true

        if (fromVoice || isVoiceCallActive.value) {
            liveVoiceManager.setAiThinking()
        }

        viewModelScope.launch {
            try {
                val result = repository.processAiConversationTurn(
                    query = q,
                    history = currentHistory
                )
                _lastPublicResponse.value = result
                _publicChatMessages.update { it + ("AI" to result.answer) }
                if (result.isClarificationPrompt && result.clarificationOptions.isNotEmpty()) {
                    _publicClarificationOptions.value = result.clarificationOptions
                }

                // Voice Playback if requested or in live call session
                if (fromVoice || isVoiceCallActive.value || liveVoiceSettings.value.autoSpeakResponse) {
                    liveVoiceManager.speak(result.answer)
                }
            } catch (e: Exception) {
                val errText = "নমস্কার। আপনার জিজ্ঞাসার উত্তর প্রস্তুত করতে সাময়িক বিঘ্ন ঘটেছে: ${e.message}। অনুগ্রহ করে পুনরায় জিজ্ঞাসা করুন।"
                _publicChatMessages.update { it + ("AI" to errText) }
                if (fromVoice || isVoiceCallActive.value) {
                    liveVoiceManager.speak(errText)
                }
            } finally {
                _publicIsLoading.value = false
            }
        }
    }

    fun setGlobalSearchQuery(q: String) {
        _globalSearchQuery.value = q
    }

    // Phase 4: External App Actions
    fun selectAppForDetail(app: ExternalAppEntity?) {
        _selectedAppForDetail.value = app
    }

    fun updateAppStatus(app: ExternalAppEntity, newStatus: String) {
        viewModelScope.launch {
            repository.updateAppStatus(app, newStatus)
            if (_selectedAppForDetail.value?.id == app.id) {
                _selectedAppForDetail.value = _selectedAppForDetail.value?.copy(status = newStatus)
            }
        }
    }

    fun updateAppScopesAndCapabilities(app: ExternalAppEntity, scopes: String, capabilities: String) {
        viewModelScope.launch {
            repository.updateAppScopesAndCapabilities(app, scopes, capabilities)
            if (_selectedAppForDetail.value?.id == app.id) {
                _selectedAppForDetail.value = _selectedAppForDetail.value?.copy(allowedScopes = scopes, activeCapabilities = capabilities)
            }
        }
    }

    fun updateAppRateLimit(app: ExternalAppEntity, rateLimitPerMin: Int, dailyQuota: Int) {
        viewModelScope.launch {
            repository.updateAppRateLimit(app, rateLimitPerMin, dailyQuota)
            if (_selectedAppForDetail.value?.id == app.id) {
                _selectedAppForDetail.value = _selectedAppForDetail.value?.copy(rateLimitPerMin = rateLimitPerMin, dailyQuota = dailyQuota)
            }
        }
    }

    fun rotateAppApiKey(app: ExternalAppEntity) {
        viewModelScope.launch {
            repository.rotateAppApiKey(app)
        }
    }

    fun registerExternalApp(
        appName: String,
        developerName: String,
        email: String,
        scopes: String,
        capabilities: String,
        rateLimit: Int,
        dailyQuota: Int,
        onSuccess: () -> Unit = {}
    ) {
        viewModelScope.launch {
            repository.registerExternalApp(
                appName = appName,
                developerName = developerName,
                email = email,
                scopes = scopes,
                capabilities = capabilities,
                rateLimit = rateLimit,
                dailyQuota = dailyQuota
            )
            onSuccess()
        }
    }

    // Phase 4: Capability Proposals
    fun approveCapabilityProposal(proposal: CapabilityProposalEntity, notes: String = "Approved by Admin") {
        viewModelScope.launch {
            repository.approveCapabilityProposal(proposal, notes)
        }
    }

    fun rejectCapabilityProposal(proposal: CapabilityProposalEntity, notes: String = "Rejected by Admin") {
        viewModelScope.launch {
            repository.rejectCapabilityProposal(proposal, notes)
        }
    }

    fun disableCapabilityProposal(proposal: CapabilityProposalEntity) {
        viewModelScope.launch {
            repository.disableCapabilityProposal(proposal)
        }
    }

    // Phase 4: Daily Data Actions
    fun selectDailyRegion(region: com.example.domain.ai.CalendarRegion) {
        _selectedDailyRegion.value = region
        _dailyData.value = com.example.domain.ai.DailyDataEngine.resolveDailyData(region)
    }

    fun triggerDailyDataUpdateJob(region: com.example.domain.ai.CalendarRegion = _selectedDailyRegion.value) {
        viewModelScope.launch {
            _isDailyJobRunning.value = true
            _dailyJobMessage.value = "Executing astronomical & calendar reconciliation for ${region.displayName}..."
            try {
                val log = repository.runDailyUpdateJob(region)
                _dailyData.value = com.example.domain.ai.DailyDataEngine.resolveDailyData(region)
                _dailyJobMessage.value = "Successfully updated ${log.updatedRecords} dynamic records for ${region.displayName} in ${log.executionDurationMs}ms."
            } catch (e: Exception) {
                _dailyJobMessage.value = "Error executing daily job: ${e.message}"
            } finally {
                _isDailyJobRunning.value = false
            }
        }
    }

    // Phase 4: External App Sandbox / Simulator Actions
    fun setSimulatorApp(appId: String) {
        _simulatorAppId.value = appId
    }

    fun setSimulatorRegion(region: com.example.domain.ai.CalendarRegion) {
        _simulatorRegion.value = region
    }

    fun setSimulatorActiveTab(tab: Int) {
        _simulatorActiveTab.value = tab
    }

    fun setSimulatorChatQuery(q: String) {
        _simulatorChatQuery.value = q
    }

    fun sendSimulatorChatMessage() {
        val q = _simulatorChatQuery.value.trim()
        if (q.isBlank()) return

        val app = allExternalApps.value.find { it.appId == _simulatorAppId.value } ?: allExternalApps.value.firstOrNull()
        val apiKey = app?.apiKey ?: "vn_live_app_dharmaguide_a9102c"

        _simulatorChatMessages.update { it + ("USER" to q) }
        _simulatorChatQuery.value = ""
        _simulatorIsLoading.value = true

        viewModelScope.launch {
            try {
                val request = ApiGatewayRequest(
                    endpoint = "/api/v1/chat",
                    method = "POST",
                    apiKey = apiKey,
                    body = "{\n  \"query\": \"${q.replace("\"", "\\\"")}\"\n}"
                )
                val response = repository.executeGatewayRequest(request)
                _simulatorLastResponse.value = response
                
                // Extract answer from JSON response
                val answer = extractFieldFromJson(response.jsonBody, "answer") ?: response.jsonBody
                _simulatorChatMessages.update { it + ("AI" to answer) }
            } catch (e: Exception) {
                _simulatorChatMessages.update { it + ("SYSTEM" to "Error communicating with VedaNova API Gateway: ${e.message}") }
            } finally {
                _simulatorIsLoading.value = false
            }
        }
    }

    fun executeSimulatorRawRequest(endpoint: String, method: String = "GET", body: String = "") {
        val app = allExternalApps.value.find { it.appId == _simulatorAppId.value } ?: allExternalApps.value.firstOrNull()
        val apiKey = app?.apiKey ?: "vn_live_app_dharmaguide_a9102c"

        _simulatorIsLoading.value = true
        viewModelScope.launch {
            try {
                val request = ApiGatewayRequest(
                    endpoint = endpoint,
                    method = method,
                    apiKey = apiKey,
                    body = body
                )
                val response = repository.executeGatewayRequest(request)
                _simulatorLastResponse.value = response
            } catch (e: Exception) {
                // Ignore or capture
            } finally {
                _simulatorIsLoading.value = false
            }
        }
    }

    private fun extractFieldFromJson(json: String, field: String): String? {
        val regex = Regex("\"$field\"\\s*:\\s*\"([^\"]+)\"")
        val match = regex.find(json)
        return match?.groupValues?.get(1)?.replace("\\n", "\n")?.replace("\\\"", "\"")
    }

    // Phase 5.1 Voice Guide & Announcer Functions
    fun setVoiceGuideEnabled(enabled: Boolean) {
        voiceAnnouncementManager.setVoiceGuideEnabled(enabled)
    }

    fun setVoiceLanguage(lang: String) {
        voiceAnnouncementManager.setLanguage(lang)
    }

    fun setVoiceSpeed(speed: String) {
        voiceAnnouncementManager.setSpeechSpeed(speed)
    }

    fun setAnnouncementMode(mode: String) {
        voiceAnnouncementManager.setAnnouncementMode(mode)
    }

    fun announceButtonClick(buttonNameBn: String, buttonNameEn: String) {
        voiceAnnouncementManager.announceButtonClick(buttonNameBn, buttonNameEn)
    }

    fun announceSection(sectionNameBn: String, sectionNameEn: String) {
        voiceAnnouncementManager.announceSection(sectionNameBn, sectionNameEn)
    }

    fun testVoiceAnnouncement(textBn: String = "নমস্কার! VedaNova AI ভয়েস গাইড সফলভাবে কাজ করছে।", textEn: String = "Greetings! VedaNova AI Voice Guide is working successfully.") {
        voiceAnnouncementManager.speakCustom(textBn, textEn)
    }

    // Phase 5.1 Crash & Diagnostic Functions
    fun clearAllCrashReports() {
        viewModelScope.launch {
            repository.clearAllCrashReports()
        }
    }

    fun clearAllActivityLogs() {
        viewModelScope.launch {
            repository.clearAllActivityLogs()
        }
    }

    fun triggerDiagnosticCrashTest() {
        val testException = IllegalStateException("Simulated Diagnostic Exception: Verification of Crash Reporting Pipeline & Room DB persistence.")
        CrashReportingManager.recordException(
            screen = _currentScreen.value.name,
            route = _currentScreen.value.name,
            throwable = testException,
            action = "Admin initiated manual diagnostic test crash from Crash Diagnostic Center"
        )
    }

    // Phase 6 Web Research & Harvesting Functions
    fun setResearchTab(tab: Int) {
        _researchLabState.value = _researchLabState.value.copy(activeTab = tab)
    }

    fun updateResearchQuery(q: String) {
        _researchLabState.value = _researchLabState.value.copy(query = q)
    }

    fun toggleDiscoveryCategory(category: String) {
        val current = _researchLabState.value.discoveryCategories.toMutableSet()
        if (current.contains(category)) {
            if (current.size > 1) current.remove(category)
        } else {
            current.add(category)
        }
        _researchLabState.value = _researchLabState.value.copy(discoveryCategories = current)
    }

    fun executeResearchLabSearch(customQuery: String? = null) {
        val q = customQuery ?: _researchLabState.value.query
        if (q.isBlank()) return
        viewModelScope.launch {
            _researchLabState.value = _researchLabState.value.copy(isLoading = true)
            try {
                val web = repository.executeManualWebResearch(q)
                val yt = com.example.domain.research.YouTubeResearchProvider.performYouTubeResearch(q, web.queryId)
                val cross = com.example.domain.research.CrossSourceVerificationEngine.performCrossVerification(q, web.sources, yt.supportingEvidenceSources)
                _researchLabState.value = _researchLabState.value.copy(
                    isLoading = false,
                    webResult = web,
                    youtubeResult = yt,
                    crossVerificationReport = cross
                )
            } catch (e: Exception) {
                _researchLabState.value = _researchLabState.value.copy(isLoading = false)
            }
        }
    }

    fun executeMantraShieldVerification(customQuery: String? = null) {
        val q = customQuery ?: _researchLabState.value.query
        if (q.isBlank()) return
        viewModelScope.launch {
            _researchLabState.value = _researchLabState.value.copy(isLoading = true)
            try {
                val shield = repository.executeManualMantraVerification(q)
                _researchLabState.value = _researchLabState.value.copy(
                    isLoading = false,
                    mantraShieldResult = shield
                )
            } catch (e: Exception) {
                _researchLabState.value = _researchLabState.value.copy(isLoading = false)
            }
        }
    }

    fun runTopicDiscoveryScan() {
        val categories = _researchLabState.value.discoveryCategories.toList()
        viewModelScope.launch {
            _researchLabState.value = _researchLabState.value.copy(isScanningDiscovery = true)
            try {
                val results = repository.runTopicDiscoveryScan(categories)
                _researchLabState.value = _researchLabState.value.copy(
                    isScanningDiscovery = false,
                    discoveryResults = results
                )
            } catch (e: Exception) {
                _researchLabState.value = _researchLabState.value.copy(isScanningDiscovery = false)
            }
        }
    }

    fun approveResearchCandidate(candidateId: String) {
        viewModelScope.launch {
            repository.approveKnowledgeCandidate(candidateId, currentSession.value?.currentUser?.username ?: "Super Admin")
        }
    }

    fun rejectResearchCandidate(candidateId: String, reason: String = "Admin Scholarly Rejection") {
        viewModelScope.launch {
            repository.rejectKnowledgeCandidate(candidateId, reason, currentSession.value?.currentUser?.username ?: "Super Admin")
        }
    }

    fun resolveResearchIssue(reportId: String, status: String, notes: String = "Resolved by Admin") {
        viewModelScope.launch {
            repository.resolveResearchIssue(reportId, status, notes, currentSession.value?.currentUser?.username ?: "Super Admin")
        }
    }

    override fun onCleared() {
        super.onCleared()
        liveVoiceManager.release()
        voiceAnnouncementManager.destroy()
    }
}

