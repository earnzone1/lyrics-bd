package com.example.ui.screens

import java.util.*
import java.util.*
import java.util.Locale
import java.text.SimpleDateFormat

@Composable
fun ApiCenterScreen(viewModel: VedaNovaViewModel) {
    val apiKeys by viewModel.allApiKeys.collectAsStateWithLifecycle()
    val testState by viewModel.realApiTestingState.collectAsStateWithLifecycle()

    var showCreateDialog by remember { mutableStateOf(false) }
    var keyToEdit by remember { mutableStateOf<ApiKeyEntity?>(null) }
    var selectedKeyForAction by remember { mutableStateOf<ApiKeyEntity?>(null) }
    var actionDialogType by remember { mutableStateOf<String?>(null) } // "ROTATE", "DELETE"
    var showDocsTab by remember { mutableStateOf(false) }

    val timeFormat = remember { SimpleDateFormat("yyyy-MM-dd HH:mm", Locale.getDefault()) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Box(
                                modifier = Modifier
                                    .size(36.dp)
                                    .clip(CircleShape)
                                    .background(SaffronPrimary.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(Icons.Default.Key, contentDescription = null, tint = SaffronPrimary)
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "API Manager & Control",
                                    style = MaterialTheme.typography.titleLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "Manage external & provider APIs with real HTTP ping tests",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                        Button(
                            onClick = { showCreateDialog = true },
                            colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                            shape = RoundedCornerShape(10.dp)
                        ) {
                            Icon(Icons.Default.Add, contentDescription = null, tint = Color.Black, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("New API", color = Color.Black, fontWeight = FontWeight.Bold)
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        FilterChip(
                            selected = !showDocsTab,
                            onClick = { showDocsTab = false },
                            label = { Text("Active APIs (${apiKeys.size})") },
                            leadingIcon = { Icon(Icons.Default.Key, contentDescription = null, modifier = Modifier.size(14.dp)) }
                        )
                        FilterChip(
                            selected = showDocsTab,
                            onClick = { showDocsTab = true },
                            label = { Text("OpenAPI Specifications") },
                            leadingIcon = { Icon(Icons.Default.MenuBook, contentDescription = null, modifier = Modifier.size(14.dp)) }
                        )
                        AssistChip(
                            onClick = { viewModel.navigateTo(ScreenDestination.API_TESTING) },
                            label = { Text("API Console", color = SaffronPrimary, fontWeight = FontWeight.Bold) },
                            leadingIcon = { Icon(Icons.Default.Terminal, contentDescription = null, tint = SaffronPrimary, modifier = Modifier.size(14.dp)) }
                        )
                    }
                }
            }
        }

        // Live Test Banner Result if active
        testState.lastResult?.let { result ->
            item {
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (result.isSuccess) StatusGreen.copy(alpha = 0.12f) else StatusRed.copy(alpha = 0.12f)
                    ),
                    shape = RoundedCornerShape(12.dp),
                    border = androidx.compose.foundation.BorderStroke(
                        1.dp,
                        if (result.isSuccess) StatusGreen.copy(alpha = 0.4f) else StatusRed.copy(alpha = 0.4f)
                    )
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    imageVector = if (result.isSuccess) Icons.Default.CheckCircle else Icons.Default.Error,
                                    contentDescription = null,
                                    tint = if (result.isSuccess) StatusGreen else StatusRed,
                                    modifier = Modifier.size(20.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = if (result.isSuccess) "Real API Test Passed (HTTP ${result.statusCode})" else "Real API Test Failed (HTTP ${result.statusCode})",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                            }
                            IconButton(
                                onClick = { viewModel.dismissRealApiTestResult() },
                                modifier = Modifier.size(24.dp)
                            ) {
                                Icon(Icons.Default.Close, contentDescription = "Dismiss", modifier = Modifier.size(16.dp))
                            }
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                            StatusPill(text = "Latency: ${result.latencyMs} ms", color = VedicGold)
                            StatusPill(text = if (result.isSuccess) "Operational" else "Unreachable", color = if (result.isSuccess) StatusGreen else StatusRed)
                        }

                        if (!result.errorMessage.isNullOrBlank()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Error: ${result.errorMessage}",
                                style = MaterialTheme.typography.bodySmall,
                                color = StatusRed
                            )
                        }

                        if (result.responseBody.isNotBlank()) {
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(
                                text = "Response Preview: ${result.responseBody.take(180)}...",
                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        if (!showDocsTab) {
            // API Keys List
            items(apiKeys) { keyItem ->
                val isCurrentlyTesting = testState.isTesting && testState.activeTestingKeyId == keyItem.id
                val providerColor = when (keyItem.provider.lowercase()) {
                    "google gemini" -> SaffronPrimary
                    "openai" -> SpiritualTeal
                    "anthropic" -> VedicGold
                    else -> StatusPurple
                }

                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(16.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        // Header
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        text = keyItem.name,
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onSurface
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    StatusPill(text = keyItem.provider, color = providerColor)
                                }
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Client: ${keyItem.appName} • Model: ${keyItem.model.ifBlank { "Default" }}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            StatusPill(
                                text = keyItem.status,
                                color = when (keyItem.status) {
                                    "Active" -> StatusGreen
                                    "Suspended" -> StatusYellow
                                    else -> StatusRed
                                }
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Endpoint display
                        if (keyItem.endpoint.isNotBlank()) {
                            Text(
                                text = "Endpoint: ${keyItem.endpoint}",
                                style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                        }

                        // Masked Key Box
                        Surface(
                            color = Color(0xFF0E0717),
                            shape = RoundedCornerShape(8.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2E1B4E)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(horizontal = 12.dp, vertical = 8.dp),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Text(
                                    text = keyItem.maskedKey,
                                    style = MaterialTheme.typography.bodyMedium.copy(
                                        fontFamily = FontFamily.Monospace,
                                        fontWeight = FontWeight.SemiBold
                                    ),
                                    color = VedicGold
                                )
                                Text(
                                    text = if (keyItem.lastResponseTimeMs > 0) "Last: ${keyItem.lastResponseTimeMs}ms" else "Securely Stored",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = if (keyItem.lastResponseTimeMs > 0) StatusGreen else MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Stats Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Column {
                                Text(text = "Total Requests", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(text = "${keyItem.requestCount}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = SaffronPrimary)
                            }
                            Column {
                                Text(text = "Error Count", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(text = "${keyItem.errorCount}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = if (keyItem.errorCount > 0) StatusRed else StatusGreen)
                            }
                            Column {
                                Text(text = "Rate Limit", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(text = "${keyItem.rateLimitPerMin} req/m", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                            }
                            Column {
                                Text(text = "Daily Quota", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                Text(text = "${keyItem.dailyLimit}", style = MaterialTheme.typography.titleSmall, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onSurface)
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                        Spacer(modifier = Modifier.height(10.dp))

                        // Actions Row
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Real HTTP Ping Button
                            Button(
                                onClick = { viewModel.testRealApiKey(keyItem) },
                                enabled = !isCurrentlyTesting,
                                shape = RoundedCornerShape(8.dp),
                                contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = SpiritualTeal)
                            ) {
                                if (isCurrentlyTesting) {
                                    CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp, color = Color.White)
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text("Testing...", style = MaterialTheme.typography.labelSmall)
                                } else {
                                    Icon(Icons.Default.NetworkCheck, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Real HTTP Test", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                }
                            }

                            Row(verticalAlignment = Alignment.CenterVertically) {
                                OutlinedButton(
                                    onClick = { keyToEdit = keyItem },
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Configure", style = MaterialTheme.typography.labelSmall)
                                }

                                Spacer(modifier = Modifier.width(6.dp))

                                IconButton(
                                    onClick = { viewModel.toggleApiKeyStatus(keyItem) }
                                ) {
                                    Icon(
                                        imageVector = if (keyItem.status == "Active") Icons.Default.PauseCircle else Icons.Default.PlayCircle,
                                        contentDescription = "Toggle Status",
                                        tint = if (keyItem.status == "Active") StatusYellow else StatusGreen
                                    )
                                }

                                IconButton(
                                    onClick = {
                                        selectedKeyForAction = keyItem
                                        actionDialogType = "DELETE"
                                    }
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = StatusRed)
                                }
                            }
                        }
                    }
                }
            }
        } else {
            // Interactive OpenAPI Documentation
            item {
                SectionHeader(
                    title = "Dharma AI Core REST API Specification (v1)",
                    subtitle = "Production endpoints for mobile, web, and external applications"
                )
            }

            item {
                ApiDocCard(
                    method = "POST",
                    endpoint = "/api/v1/chat",
                    description = "Interactive Sanskrit & Dharma AI reasoning engine with scripture grounding.",
                    sampleBody = """
                        {
                          "query": "শ্রীমদ্ভগবদ্গীতা ২.৪৭ শ্লোকের তাৎপর্য কী?",
                          "temperature": 0.2
                        }
                    """.trimIndent(),
                    onTestClick = {
                        viewModel.updateApiTestEndpoint("/api/v1/chat")
                        viewModel.navigateTo(ScreenDestination.API_TESTING)
                    }
                )
            }

            item {
                ApiDocCard(
                    method = "POST",
                    endpoint = "/api/v1/knowledge/search",
                    description = "Search verified Hindu scripture canonical records (Gita, Vedas, Upanishads, Mantras, Pujas).",
                    sampleBody = """
                        {
                          "query": "Gayatri Mantra",
                          "limit": 5
                        }
                    """.trimIndent(),
                    onTestClick = {
                        viewModel.updateApiTestEndpoint("/api/v1/knowledge/search")
                        viewModel.navigateTo(ScreenDestination.API_TESTING)
                    }
                )
            }

            item {
                ApiDocCard(
                    method = "POST",
                    endpoint = "/api/v1/mantra/search",
                    description = "Dedicated Mantra & Stotra lookup with IAST transliteration and audio metric guidance.",
                    sampleBody = """
                        {
                          "query": "Mahamrityunjaya",
                          "include_transliteration": true
                        }
                    """.trimIndent(),
                    onTestClick = {
                        viewModel.updateApiTestEndpoint("/api/v1/mantra/search")
                        viewModel.navigateTo(ScreenDestination.API_TESTING)
                    }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(32.dp))
        }
    }

    // CREATE / EDIT API KEY DIALOG
    val editing = keyToEdit
    if (showCreateDialog || editing != null) {
        var keyName by remember(editing) { mutableStateOf(editing?.name ?: "") }
        var appName by remember(editing) { mutableStateOf(editing?.appName ?: "") }
        var provider by remember(editing) { mutableStateOf(editing?.provider ?: "Google Gemini") }
        var endpoint by remember(editing) { mutableStateOf(editing?.endpoint ?: "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent") }
        var model by remember(editing) { mutableStateOf(editing?.model ?: "gemini-2.5-flash") }
        var rawKey by remember(editing) { mutableStateOf(editing?.apiKey ?: "") }
        var rateLimit by remember(editing) { mutableStateOf(editing?.rateLimitPerMin?.toString() ?: "60") }
        var dailyLimit by remember(editing) { mutableStateOf(editing?.dailyLimit?.toString() ?: "5000") }

        AlertDialog(
            onDismissRequest = {
                showCreateDialog = false
                keyToEdit = null
            },
            title = {
                Text(
                    text = if (editing != null) "Configure API: ${editing.name}" else "Create New API Key",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    OutlinedTextField(
                        value = keyName,
                        onValueChange = { keyName = it },
                        label = { Text("API Identifier Name") },
                        placeholder = { Text("e.g. Gemini Production Core") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = appName,
                        onValueChange = { appName = it },
                        label = { Text("Application / Client") },
                        placeholder = { Text("e.g. Dharma AI Mobile") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    // Provider Selector
                    Text("AI / API Provider", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        listOf("Google Gemini", "OpenAI", "Anthropic", "Custom").forEach { p ->
                            FilterChip(
                                selected = provider.equals(p, ignoreCase = true),
                                onClick = {
                                    provider = p
                                    when (p) {
                                        "Google Gemini" -> {
                                            endpoint = "https://generativelanguage.googleapis.com/v1beta/models/gemini-2.5-flash:generateContent"
                                            model = "gemini-2.5-flash"
                                        }
                                        "OpenAI" -> {
                                            endpoint = "https://api.openai.com/v1/chat/completions"
                                            model = "gpt-4o-mini"
                                        }
                                        "Anthropic" -> {
                                            endpoint = "https://api.anthropic.com/v1/messages"
                                            model = "claude-3-5-sonnet-20241022"
                                        }
                                        else -> {
                                            endpoint = "https://api.vedanova.ai/v1"
                                            model = "custom"
                                        }
                                    }
                                },
                                label = { Text(p, fontSize = 11.sp) }
                            )
                        }
                    }

                    OutlinedTextField(
                        value = endpoint,
                        onValueChange = { endpoint = it },
                        label = { Text("Endpoint URL") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = model,
                        onValueChange = { model = it },
                        label = { Text("Model Name") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    OutlinedTextField(
                        value = rawKey,
                        onValueChange = { rawKey = it },
                        label = { Text("API Secret Key (Stored Securely)") },
                        placeholder = { Text("AIzaSy... / sk-...") },
                        modifier = Modifier.fillMaxWidth()
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = rateLimit,
                            onValueChange = { rateLimit = it },
                            label = { Text("Req / Min") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = dailyLimit,
                            onValueChange = { dailyLimit = it },
                            label = { Text("Daily Quota") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (keyName.isNotBlank() && appName.isNotBlank()) {
                            viewModel.saveOperationalApiKey(
                                id = editing?.id ?: 0L,
                                name = keyName,
                                appName = appName,
                                apiKey = rawKey,
                                provider = provider,
                                endpoint = endpoint,
                                model = model,
                                status = editing?.status ?: "Active",
                                dailyLimit = dailyLimit.toIntOrNull() ?: 5000,
                                rateLimitPerMin = rateLimit.toIntOrNull() ?: 60
                            )
                            showCreateDialog = false
                            keyToEdit = null
                        }
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
                ) {
                    Text(if (editing != null) "Save Config" else "Generate & Activate", color = Color.Black, fontWeight = FontWeight.Bold)
                }
            },
            dismissButton = {
                TextButton(onClick = {
                    showCreateDialog = false
                    keyToEdit = null
                }) {
                    Text("Cancel")
                }
            }
        )
    }

    // Delete Confirmation
    selectedKeyForAction?.let { key ->
        if (actionDialogType == "DELETE") {
            AlertDialog(
                onDismissRequest = { actionDialogType = null },
                title = { Text("Revoke & Delete API Key", color = StatusRed) },
                text = {
                    Text("This will permanently remove '${key.name}'. External applications using this key will immediately fail.")
                },
                confirmButton = {
                    Button(
                        onClick = {
                            viewModel.deleteApiKey(key)
                            actionDialogType = null
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = StatusRed)
                    ) {
                        Text("Permanent Delete", color = Color.White)
                    }
                },
                dismissButton = {
                    TextButton(onClick = { actionDialogType = null }) { Text("Cancel") }
                }
            )
        }
    }
}

@Composable
private fun ApiDocCard(
    method: String,
    endpoint: String,
    description: String,
    sampleBody: String,
    onTestClick: () -> Unit
) {
    Card(
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
        shape = RoundedCornerShape(14.dp),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    StatusPill(
                        text = method,
                        color = if (method == "POST") SaffronPrimary else StatusGreen
                    )
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = endpoint,
                        style = MaterialTheme.typography.titleMedium.copy(fontFamily = FontFamily.Monospace),
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
                Button(
                    onClick = onTestClick,
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp),
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary.copy(alpha = 0.2f))
                ) {
                    Text("Try in Console →", color = SaffronPrimary, style = MaterialTheme.typography.labelSmall)
                }
            }
            Spacer(modifier = Modifier.height(6.dp))
            Text(
                text = description,
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurfaceVariant
            )
            Spacer(modifier = Modifier.height(10.dp))
            CodeBlockViewer(code = sampleBody, language = "JSON Payload")
        }
    }
}
