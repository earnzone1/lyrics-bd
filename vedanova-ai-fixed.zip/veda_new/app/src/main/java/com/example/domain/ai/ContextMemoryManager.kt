package com.example.domain.ai

import java.util.Locale
import java.util.UUID

data class ConversationTurn(
    val id: String = UUID.randomUUID().toString(),
    val userQuery: String,
    val aiResponse: String,
    val intentDetected: String,
    val resolvedSubject: String?,
    val timestamp: Long = System.currentTimeMillis()
)

data class ConversationContextState(
    val sessionId: String = UUID.randomUUID().toString(),
    val activeSubject: String? = null,
    val activeDeity: String? = null,
    val activeDeityKey: String? = null, // "SHIVA", "KRISHNA", "DURGA", "GANESHA", "SARASWATI", "LAKSHMI", "SURYA", "HANUMAN"
    val activeScripture: String? = null,
    val activeMantra: String? = null,
    val activeMantraSanskrit: String? = null,
    val activeMantraMeaning: String? = null,
    val activeMantraSource: String? = null,
    val activeChapter: String? = null,
    val lastDetectedLanguage: String = "Bengali (বাংলা)",
    val threadTurnCount: Int = 0,
    val contextSummary: String = "Fresh Context",
    val recentTurns: List<ConversationTurn> = emptyList(),
    val isAwaitingMantraDisambiguation: Boolean = false
)

data class MultiIntentAnalysis(
    val isGreeting: Boolean = false,
    val isCreatorInquiry: Boolean = false,
    val isIdentityInquiry: Boolean = false,
    val isDeityInquiry: Boolean = false,
    val isMantraRequest: Boolean = false,
    val isMeaningRequest: Boolean = false,
    val isSourceRequest: Boolean = false,
    val isChantingMethodRequest: Boolean = false,
    val isAnotherMantraRequest: Boolean = false,
    val isMantraClarificationAnswer: Boolean = false,
    val isBroadMantraInquiry: Boolean = false,
    val detectedDeity: String? = null,
    val detectedScripture: String? = null,
    val detectedMantra: String? = null,
    val primaryIntent: String = "GENERAL_DHARMA",
    val secondaryIntents: List<String> = emptyList()
)

object ContextMemoryManager {

    // In-memory Session Cache for Multi-Turn API & UI conversations (SessionId -> State)
    private val sessionStore = mutableMapOf<String, ConversationContextState>()

    fun getOrCreateSession(sessionId: String): ConversationContextState {
        return sessionStore.getOrPut(sessionId) {
            ConversationContextState(sessionId = sessionId)
        }
    }

    fun updateSession(sessionId: String, updatedState: ConversationContextState) {
        sessionStore[sessionId] = updatedState
    }

    fun clearSession(sessionId: String) {
        sessionStore.remove(sessionId)
    }

    fun analyzeMultiIntent(query: String, previousState: ConversationContextState): MultiIntentAnalysis {
        val q = query.trim().lowercase(Locale.ROOT)

        val isCreator = q.contains("কে বানিয়েছে") || q.contains("কে তৈরি করেছে") || q.contains("কে বানিয়েছে") ||
                q.contains("কে বানাইছে") || q.contains("creator কে") || q.contains("নির্মাতা কে") ||
                q.contains("প্রস্তুতকারক") || q.contains("আবিষ্কারক") || q.contains("বানিয়েছে কে") ||
                q.contains("বানিয়েছে কে") || q.contains("তৈরি করেছে কে") ||
                q.contains("who created you") || q.contains("who made you") || q.contains("who is your creator") ||
                q.contains("who built you") || q.contains("who developed you") || q.contains("your creator") ||
                q.contains("who created dharma ai") || q.contains("creator of dharma ai") ||
                q.contains("মহামতি মিলন চন্দ্র") || q.contains("মিলন চন্দ্র") || q.contains("milon chandra")

        val isIdentity = !isCreator && (
                q.contains("তুমি কে") || q.contains("তোমার নাম কি") || q.contains("তোমার নাম কী") ||
                q.contains("তোমার পরিচয়") || q.contains("who are you") || q.contains("what is your name") ||
                q == "who are you?" || q == "who are you" || q.startsWith("tell me about yourself")
                )

        val isGreeting = !isCreator && (
                q.startsWith("নমস্কার") || q.startsWith("প্রণাম") || q.startsWith("কেমন আছো") ||
                q.startsWith("কেমন আছেন") || q == "hello" || q == "hi" || q == "namaste" ||
                q.startsWith("শুভ সকাল") || q.startsWith("শুভ সন্ধ্যা") || q.startsWith("শুভ রাত্রি") ||
                q == "ধন্যবাদ" || q == "thanks" || q == "thank you" || q.startsWith("ভালো থেকো")
                )

        val hasPronoun = q.contains("তার ") || q.contains("তাঁর ") || q.contains("উহার ") ||
                q.contains("এর ") || q.contains("এটার ") || q.contains("মন্ত্রটার") || q.contains("মন্ত্রটির") ||
                q.startsWith("তার") || q.startsWith("তাঁর") || q.startsWith("এর") || q.startsWith("এটার") ||
                q.startsWith("মন্ত্রটার") || q.startsWith("মন্ত্রটির") ||
                q.contains("his ") || q.contains("her ") || q.contains("its ")

        val isMantra = q.contains("মন্ত্র") || q.contains("স্তোত্র") || q.contains("শ্লোক") ||
                q.contains("mantra") || q.contains("stotra") || q.contains("verse") ||
                q.contains("জপ") || q.contains("প্রণাম মন্ত্র")

        val isMeaning = q.contains("অর্থ") || q.contains("অনুবাদ") || q.contains("ভাবার্থ") ||
                q.contains("ব্যাখ্যা") || q.contains("meaning") || q.contains("translate") ||
                q.contains("explain") || q.contains("significance")

        val isSource = q.contains("কোথায় পাওয়া যায়") || q.contains("কোথায় পাওয়া যায়") ||
                q.contains("উৎস") || q.contains("কোন শাস্ত্রে") || q.contains("কোন্ গ্রন্থে") ||
                q.contains("source") || q.contains("scripture") || q.contains("which book") ||
                q.contains("reference") || q.contains("origin") || q.contains("কোথায় আছে")

        val isChanting = q.contains("কীভাবে জপ") || q.contains("কিভাবে জপ") ||
                q.contains("জপের নিয়ম") || q.contains("how to chant") || q.contains("procedure")

        val isAnother = q.contains("আরেকটা") || q.contains("আরেকটি") || q.contains("অন্য একটি") ||
                q.contains("অন্যান্য") || q.contains("another") || q.contains("one more") ||
                q.contains("more mantras") || q.contains("আরেকটা দাও")

        // Check if query is answering a broad mantra clarification (e.g. user just typed "শিব" or "shiva")
        val isMantraClarificationAnswer = previousState.isAwaitingMantraDisambiguation && (
                q.contains("শিব") || q.contains("shiva") || q.contains("কৃষ্ণ") || q.contains("krishna") ||
                        q.contains("দুর্গা") || q.contains("durga") || q.contains("গণেশ") || q.contains("ganesha") ||
                        q.contains("সরস্বতী") || q.contains("saraswati") || q.contains("লক্ষ্মী") || q.contains("lakshmi")
                )

        val isBroadMantraInquiry = (q == "আমাকে একটি মন্ত্র দাও" || q == "একটি মন্ত্র দাও" ||
                q == "একটি মন্ত্র বলো" || q == "give me a mantra" || q == "tell me a mantra" ||
                q == "মন্ত্র দাও" || q == "mantra please") && !hasPronoun && previousState.activeDeity == null

        // Detect Deity
        val detectedDeity = when {
            q.contains("শিব") || q.contains("shiva") || q.contains("মহাদেব") || q.contains("ভোলানাথ") || q.contains("রুদ্র") -> "Lord Shiva (মহাদেব শিব)"
            q.contains("কৃষ্ণ") || q.contains("krishna") || q.contains("নারায়ণ") || q.contains("বিষ্ণু") || q.contains("গোবিন্দ") -> "Lord Krishna (শ্রীকৃষ্ণ / শ্রীবিষ্ণু)"
            q.contains("দুর্গা") || q.contains("durga") || q.contains("চণ্ডী") || q.contains("কালী") || q.contains("মহিষাসুরমর্দিনী") -> "Maa Durga / Shakti (মা দুর্গা)"
            q.contains("গণেশ") || q.contains("ganesha") || q.contains("সিদ্ধিদাতা") || q.contains("গণপতি") -> "Lord Ganesha (শ্রীগণেশ)"
            q.contains("সরস্বতী") || q.contains("saraswati") || q.contains("বাগদেবী") -> "Maa Saraswati (মা সরস্বতী)"
            q.contains("লক্ষ্মী") || q.contains("lakshmi") || q.contains("কমলা") -> "Maa Lakshmi (মা লক্ষ্মী)"
            q.contains("গায়ত্রী") || q.contains("gayatri") || q.contains("সবিতা") || q.contains("সূর্য") -> "Savitr / Gayatri Devata (সূর্য / গায়ত্রী দেবী)"
            q.contains("হনুমান") || q.contains("hanuman") || q.contains("বজরংবলী") -> "Lord Hanuman (শ্রীহনুমানজী)"
            hasPronoun -> previousState.activeDeity
            else -> null
        }

        // Detect Scripture
        val detectedScripture = when {
            q.contains("গীতা") || q.contains("gita") -> "Bhagavad Gita (শ্রীমদ্ভগবদ্গীতা)"
            q.contains("উপনিষদ") || q.contains("upanishad") -> "Mukhya Upanishads (উপনিষদ)"
            q.contains("ঋগ্বেদ") || q.contains("বেদ") || q.contains("veda") -> "Vedas (বেদ সংহিতা)"
            q.contains("চণ্ডী") || q.contains("দেবী মাহাত্ম্য") -> "Devi Mahatmya (শ্রীশ্রীচণ্ডী)"
            q.contains("ভাগবত") || q.contains("পুরাণ") || q.contains("purana") -> "Puranas (পুরাণ)"
            else -> previousState.activeScripture
        }

        // Detect Mantra
        val detectedMantra = when {
            q.contains("মহামৃত্যুঞ্জয়") || q.contains("mrityunjaya") || q.contains("ত্র্যম্বক") -> "Maha Mrityunjaya Mantra (মহামৃত্যুঞ্জয় মন্ত্র)"
            q.contains("গায়ত্রী") || q.contains("gayatri") -> "Gayatri Mantra (গায়ত্রী মন্ত্র)"
            q.contains("হরে কৃষ্ণ") || q.contains("মহামন্ত্র") -> "Hare Krishna Mahamantra (হরে কৃষ্ণ মহামন্ত্র)"
            q.contains("পরাশক্তি") || q.contains("সর্বমঙ্গল") -> "Sarvamangala Mangalye (দুর্গা প্রণাম মন্ত্র)"
            q.contains("শিব প্রণাম") || q.contains("নমঃ শিবায়") || q.contains("নমঃ শিবায়") -> "Shiva Namaskar Mantra (শিব প্রণাম মন্ত্র)"
            q.contains("শান্তিপাঠ") || q.contains("shanti") -> "Shanti Patha (শান্তিপাঠ)"
            hasPronoun && previousState.activeMantra != null -> previousState.activeMantra
            else -> null
        }

        val secondaryList = mutableListOf<String>()
        if (isCreator) secondaryList.add("CREATOR_IDENTITY")
        if (isIdentity) secondaryList.add("AI_IDENTITY")
        if (isMantra) secondaryList.add("MANTRA_TEXT")
        if (isMeaning) secondaryList.add("MEANING")
        if (isSource) secondaryList.add("CANONICAL_SOURCE")
        if (isChanting) secondaryList.add("CHANTING_PROCEDURE")
        if (isAnother) secondaryList.add("ANOTHER_MANTRA")

        val primaryIntent = when {
            isCreator -> "CREATOR_IDENTITY"
            isIdentity -> "AI_IDENTITY"
            isGreeting -> "GREETING"
            isBroadMantraInquiry -> "INTERACTIVE_MANTRA_CLARIFICATION"
            isMantraClarificationAnswer -> "MANTRA_SELECTION"
            isAnother -> "ANOTHER_MANTRA_REQUEST"
            isMeaning && isSource && isMantra -> "MULTI_INTENT_MANTRA_DECOMPOSITION"
            isMeaning && isSource -> "MULTI_INTENT_SOURCE_AND_MEANING"
            isMeaning -> "MANTRA_MEANING_QUERY"
            isSource -> "SCRIPTURE_SOURCE_QUERY"
            isChanting -> "CHANTING_PROCEDURE_QUERY"
            isMantra -> "MANTRA_REQUEST"
            detectedDeity != null && hasPronoun -> "DEITY_FOLLOW_UP"
            detectedDeity != null -> "DEITY_INQUIRY"
            else -> "GENERAL_DHARMA"
        }

        return MultiIntentAnalysis(
            isGreeting = isGreeting,
            isCreatorInquiry = isCreator,
            isIdentityInquiry = isIdentity,
            isDeityInquiry = detectedDeity != null,
            isMantraRequest = isMantra,
            isMeaningRequest = isMeaning,
            isSourceRequest = isSource,
            isChantingMethodRequest = isChanting,
            isAnotherMantraRequest = isAnother,
            isMantraClarificationAnswer = isMantraClarificationAnswer,
            isBroadMantraInquiry = isBroadMantraInquiry,
            detectedDeity = detectedDeity,
            detectedScripture = detectedScripture,
            detectedMantra = detectedMantra,
            primaryIntent = primaryIntent,
            secondaryIntents = secondaryList
        )
    }

    fun extractContextEntities(query: String, previousState: ConversationContextState): ConversationContextState {
        val analysis = analyzeMultiIntent(query, previousState)

        val resolvedDeity = analysis.detectedDeity ?: previousState.activeDeity
        val resolvedScripture = analysis.detectedScripture ?: previousState.activeScripture
        val resolvedMantra = analysis.detectedMantra ?: previousState.activeMantra

        val deityKey = when {
            resolvedDeity?.contains("Shiva", ignoreCase = true) == true || resolvedDeity?.contains("শিব") == true -> "SHIVA"
            resolvedDeity?.contains("Krishna", ignoreCase = true) == true || resolvedDeity?.contains("কৃষ্ণ") == true -> "KRISHNA"
            resolvedDeity?.contains("Durga", ignoreCase = true) == true || resolvedDeity?.contains("দুর্গা") == true -> "DURGA"
            resolvedDeity?.contains("Ganesha", ignoreCase = true) == true || resolvedDeity?.contains("গণেশ") == true -> "GANESHA"
            resolvedDeity?.contains("Saraswati", ignoreCase = true) == true || resolvedDeity?.contains("সরস্বতী") == true -> "SARASWATI"
            resolvedDeity?.contains("Lakshmi", ignoreCase = true) == true || resolvedDeity?.contains("লক্ষ্মী") == true -> "LAKSHMI"
            resolvedDeity?.contains("Gayatri", ignoreCase = true) == true || resolvedDeity?.contains("সূর্য") == true -> "SURYA"
            else -> previousState.activeDeityKey
        }

        val resolvedSubject = resolvedMantra ?: resolvedDeity ?: resolvedScripture ?: previousState.activeSubject

        val summaryParts = listOfNotNull(
            resolvedDeity?.let { "Deity: $it" },
            resolvedScripture?.let { "Scripture: $it" },
            resolvedMantra?.let { "Mantra: $it" }
        )
        val summary = if (summaryParts.isNotEmpty()) summaryParts.joinToString(" | ") else "General Context"

        return previousState.copy(
            activeSubject = resolvedSubject,
            activeDeity = resolvedDeity,
            activeDeityKey = deityKey,
            activeScripture = resolvedScripture,
            activeMantra = resolvedMantra,
            threadTurnCount = previousState.threadTurnCount + 1,
            contextSummary = summary,
            isAwaitingMantraDisambiguation = analysis.isBroadMantraInquiry
        )
    }

    fun resolveMultiTurnQuery(
        query: String,
        history: List<Pair<String, String>>,
        contextState: ConversationContextState
    ): String {
        val trimmed = query.trim()
        val lower = trimmed.lowercase(Locale.ROOT)
        val analysis = analyzeMultiIntent(query, contextState)

        // Case 1: Anaphora resolution for deity ("তার একটি মন্ত্র বলো" / "তাঁর মন্ত্র")
        if ((lower.contains("তার ") || lower.contains("তাঁর ") || lower.startsWith("তার") || lower.startsWith("তাঁর")) &&
            (lower.contains("মন্ত্র") || lower.contains("শ্লোক") || lower.contains("স্তোত্র") || lower.contains("প্রণাম"))
        ) {
            val deityName = contextState.activeDeity ?: "Lord Shiva (মহাদেব শিব)"
            return "$deityName এর প্রামাণিক মন্ত্র ও স্তোত্র"
        }

        // Case 2: Meaning follow up ("এই মন্ত্রের অর্থ কী?" / "এর অর্থ কী?" / "মন্ত্রটার অর্থ কী?")
        if ((lower.contains("এর অর্থ") || lower.contains("এই মন্ত্রের অর্থ") || lower.contains("এটার অর্থ") ||
                lower.contains("মন্ত্রটার অর্থ") || lower.contains("মন্ত্রটির অর্থ") || lower.contains("its meaning")) &&
            contextState.activeMantra != null
        ) {
            return "${contextState.activeMantra} এর শাস্ত্রীয় সংস্কৃত অর্থ, বঙ্গানুবাদ ও ভাবার্থ"
        }

        // Case 3: Source follow up ("এটা কোথায় পাওয়া যায়?" / "কোন শাস্ত্রে আছে?")
        if ((lower.contains("কোথায় পাওয়া যায়") || lower.contains("কোথায় পাওয়া যায়") || lower.contains("উৎস") ||
                lower.contains("কোন শাস্ত্রে") || lower.contains("কোথায় আছে") || lower.contains("where is it found")) &&
            contextState.activeMantra != null
        ) {
            return "${contextState.activeMantra} এর প্রামাণিক শাস্ত্রীয় গ্রন্থসূত্র ও বৈদিক প্রসঙ্গ"
        }

        // Case 4: Another mantra follow up ("আরেকটা দাও" / "আরেকটি মন্ত্র বলো")
        if (analysis.isAnotherMantraRequest && contextState.activeDeity != null) {
            return "${contextState.activeDeity} এর আরেকটি প্রামাণিক বৈদিক বা পৌরাণিক মন্ত্র"
        }

        // Case 5: Answering disambiguation prompt with just a deity name (e.g. "শিব" / "কৃষ্ণ")
        if (contextState.isAwaitingMantraDisambiguation && analysis.detectedDeity != null) {
            return "${analysis.detectedDeity} এর প্রামাণিক প্রণাম ও ধ্যান মন্ত্র"
        }

        // Case 6: Compound multi-intent (e.g. "গায়ত্রী মন্ত্রটা লিখে অর্থ বলো আর কোথায় পাওয়া যায়")
        if (analysis.primaryIntent == "MULTI_INTENT_MANTRA_DECOMPOSITION" || analysis.primaryIntent == "MULTI_INTENT_SOURCE_AND_MEANING") {
            val targetSubject = analysis.detectedMantra ?: contextState.activeMantra ?: analysis.detectedDeity ?: "গায়ত্রী মন্ত্র"
            return "$targetSubject - মূল সংস্কৃত শ্লোক, বাংলা অর্থ, শাস্ত্রীয় উৎস ও আধ্যাত্মিক তাৎপর্য"
        }

        return trimmed
    }
}
