package com.example.ui.screens

import com.example.ui.viewmodel.VedaNovaViewModel
import com.example.ui.viewmodel.VedaNovaViewModel
import java.util.Date

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DailyDataEngineScreen(viewModel: VedaNovaViewModel) {
    val selectedRegion by viewModel.selectedDailyRegion.collectAsStateWithLifecycle()
    val dailyData by viewModel.dailyData.collectAsStateWithLifecycle()
    val isJobRunning by viewModel.isDailyJobRunning.collectAsStateWithLifecycle()
    val jobMessage by viewModel.dailyJobMessage.collectAsStateWithLifecycle()
    val jobLogs by viewModel.recentDailyJobLogs.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .testTag("daily_data_engine_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Sub-Navigation Tabs for External App Subsystems
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    OutlinedButton(
                        onClick = { viewModel.navigateTo(ScreenDestination.EXTERNAL_APPS_MONITOR) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Apps, contentDescription = null, modifier = Modifier.size(14.dp), tint = SaffronPrimary)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Apps", fontSize = 11.sp)
                    }

                    OutlinedButton(
                        onClick = { viewModel.navigateTo(ScreenDestination.CAPABILITY_APPROVAL) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.VerifiedUser, contentDescription = null, modifier = Modifier.size(14.dp), tint = VedicGold)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Capabilities", fontSize = 11.sp)
                    }

                    FilledTonalButton(
                        onClick = { viewModel.navigateTo(ScreenDestination.DAILY_DATA_MONITOR) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = SpiritualTeal,
                            contentColor = Color.White
                        ),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Daily Data", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = { viewModel.navigateTo(ScreenDestination.EXTERNAL_APP_SIMULATOR) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Science, contentDescription = null, modifier = Modifier.size(14.dp), tint = SaffronPrimary)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Sandbox", fontSize = 11.sp)
                    }
                }
            }
        }

        // Header Banner with Job Run Action
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "📅", fontSize = 20.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                "Dynamic Daily Data & Ephemeris Engine",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            "Surya Siddhanta & Drik Ephemeris Real-Time Resolution",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                        )
                    }

                    Button(
                        onClick = { viewModel.triggerDailyDataUpdateJob(selectedRegion) },
                        enabled = !isJobRunning,
                        colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("trigger_daily_job_button")
                    ) {
                        if (isJobRunning) {
                            CircularProgressIndicator(modifier = Modifier.size(14.dp), color = Color.White, strokeWidth = 2.dp)
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Calculating...", fontSize = 11.sp)
                        } else {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Run Job", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        // Status Notification
        jobMessage?.let { msg ->
            item {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = SpiritualTeal.copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SpiritualTeal),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = SpiritualTeal, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(msg, style = MaterialTheme.typography.bodySmall.copy(color = SpiritualTeal, fontWeight = FontWeight.SemiBold))
                    }
                }
            }
        }

        // 1. Region Selector Tab Bar
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Text(
                        "Astronomical Calendar Region:",
                        style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        CalendarRegion.values().forEach { region ->
                            val isSelected = region == selectedRegion
                            FilterChip(
                                selected = isSelected,
                                onClick = { viewModel.selectDailyRegion(region) },
                                label = {
                                    Text(
                                        region.displayName,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 11.sp
                                    )
                                },
                                leadingIcon = if (isSelected) {
                                    { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                                } else null,
                                shape = RoundedCornerShape(6.dp)
                            )
                        }
                    }
                }
            }
        }

        // 2. Primary Date & Panchang Display
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text(
                                dailyData.gregorianDateFormatted,
                                style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                            )
                            Text(
                                "Region: ${dailyData.region.displayName} (${dailyData.region.standardConvention})",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                        }

                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = SaffronPrimary.copy(alpha = 0.15f)
                        ) {
                            Text(
                                "LIVE EPHEMERIS",
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = SaffronPrimary, fontSize = 10.sp)
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                    Spacer(modifier = Modifier.height(10.dp))

                    // Bengali Calendar Highlight
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text("বঙ্গাব্দ ও পঞ্জিকা", style = MaterialTheme.typography.labelSmall.copy(color = SaffronPrimary, fontWeight = FontWeight.Bold, fontSize = 10.sp))
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    "${dailyData.bengaliDate.dayBangla} ${dailyData.bengaliDate.monthBangla}, ${dailyData.bengaliDate.yearBangla}",
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    dailyData.bengaliDate.dayOfWeekBangla,
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            }
                        }

                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                            modifier = Modifier.weight(1f)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Text("তিথি ও নক্ষত্র", style = MaterialTheme.typography.labelSmall.copy(color = SpiritualTeal, fontWeight = FontWeight.Bold, fontSize = 10.sp))
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    dailyData.bengaliDate.fullTithiTitle,
                                    style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold)
                                )
                                Text(
                                    dailyData.bengaliDate.nakshatra,
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Solar & Lunar Timings Grid
                    Text("Solar & Muhurta Coordinates", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 11.sp))
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        TimingChip(label = "Sunrise", value = dailyData.bengaliDate.sunriseTime, modifier = Modifier.weight(1f))
                        TimingChip(label = "Sunset", value = dailyData.bengaliDate.sunsetTime, modifier = Modifier.weight(1f))
                        TimingChip(label = "Brahma", value = dailyData.bengaliDate.brahmaMuhurta, modifier = Modifier.weight(1.2f))
                        TimingChip(label = "Abhijit", value = dailyData.bengaliDate.abhijitMuhurta, modifier = Modifier.weight(1.1f))
                    }
                }
            }
        }

        // 3. Next Major Festival Countdown
        dailyData.nextMajorFestival?.let { nextFest ->
            item {
                Card(
                    modifier = Modifier.fillMaxWidth(),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = VedicGold.copy(alpha = 0.12f)),
                    border = androidx.compose.foundation.BorderStroke(1.dp, VedicGold.copy(alpha = 0.5f))
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.Celebration, contentDescription = null, tint = SaffronPrimary, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(6.dp))
                                Text("আসন্ন প্রধান উৎসব", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = SaffronPrimary, fontSize = 11.sp))
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(nextFest.nameBn, style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                            Text(
                                "তারিখ: ${nextFest.targetGregorianDate} • ${nextFest.descriptionBn}",
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            )
                        }

                        Column(horizontalAlignment = Alignment.End) {
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = SaffronPrimary
                            ) {
                                Column(
                                    modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                                    horizontalAlignment = Alignment.CenterHorizontally
                                ) {
                                    Text("${nextFest.daysRemaining}", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color.White))
                                    Text("দিন বাকি", style = MaterialTheme.typography.labelSmall.copy(color = Color.White, fontSize = 9.sp))
                                }
                            }
                        }
                    }
                }
            }
        }

        // 4. Daily Spiritual Feed Preview
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(12.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.MenuBook, contentDescription = null, tint = SpiritualTeal, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Daily Spiritual Feed (Supplied to External Apps)", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                    }
                    Spacer(modifier = Modifier.height(8.dp))

                    // Daily Gita Verse
                    Text("শ্রীমদ্ভগবদ্গীতা শ্লোক (${dailyData.spiritualFeed.dailyGitaChapterVerse}):", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = SaffronPrimary, fontSize = 10.sp))
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        dailyData.spiritualFeed.dailyGitaSanskrit,
                        style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Serif, fontWeight = FontWeight.Bold)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        dailyData.spiritualFeed.dailyGitaBn,
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    // Daily Dharma Thought
                    Text("আজকের আধ্যাত্মিক সুবচন:", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = SpiritualTeal, fontSize = 10.sp))
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        "\"${dailyData.spiritualFeed.dailyDharmaQuoteBn}\"",
                        style = MaterialTheme.typography.bodySmall.copy(fontStyle = androidx.compose.ui.text.font.FontStyle.Italic)
                    )
                    Text("— ${dailyData.spiritualFeed.quoteSource}", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant))
                }
            }
        }

        // 5. Daily Job Logs Table
        item {
            Column(modifier = Modifier.fillMaxWidth()) {
                Text("Daily Job Execution Audit Logs", style = MaterialTheme.typography.titleSmall.copy(fontWeight = FontWeight.Bold))
                Text("Historical tracking of ephemeris reconciliation runs", style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant))
            }
        }

        items(jobLogs, key = { it.id }) { log ->
            JobLogCard(log = log)
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun TimingChip(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        modifier = modifier,
        shape = RoundedCornerShape(6.dp),
        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)
    ) {
        Column(modifier = Modifier.padding(4.dp), horizontalAlignment = Alignment.CenterHorizontally) {
            Text(label, style = MaterialTheme.typography.labelSmall.copy(fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant))
            Text(value, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, fontSize = 10.sp))
        }
    }
}

@Composable
fun JobLogCard(log: DailyJobLogEntity) {
    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Row(
            modifier = Modifier.padding(10.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column(modifier = Modifier.weight(1f)) {
                Text(log.jobName, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, fontSize = 12.sp))
                Text(
                    "Region: ${log.region} • Date: ${log.gregorianDate} • ${log.bengaliDate}",
                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                )
                Text(
                    "Updated: ${log.updatedRecords} records in ${log.executionDurationMs}ms • Status: ${log.status}",
                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = if (log.status == "SUCCESS") Color(0xFF2E7D32) else Color(0xFFC62828), fontWeight = FontWeight.Bold)
                )
            }

            Surface(
                shape = RoundedCornerShape(4.dp),
                color = Color(0xFF2E7D32).copy(alpha = 0.15f)
            ) {
                Text(
                    log.verificationStatus,
                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                    style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = Color(0xFF2E7D32), fontSize = 10.sp)
                )
            }
        }
    }
}
