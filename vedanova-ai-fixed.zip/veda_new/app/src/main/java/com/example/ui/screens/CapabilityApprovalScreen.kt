package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.CapabilityProposalEntity
import com.example.ui.theme.*
import com.example.ui.viewmodel.ScreenDestination
import com.example.ui.viewmodel.VedaNovaViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CapabilityApprovalScreen(viewModel: VedaNovaViewModel) {
    val proposals by viewModel.allCapabilityProposals.collectAsStateWithLifecycle()

    var selectedFilter by remember { mutableStateOf("ALL") } // ALL, AI_PROPOSED, ACTIVE, REJECTED
    var reviewProposalDialog by remember { mutableStateOf<Pair<CapabilityProposalEntity, Boolean>?>(null) } // Proposal to isApprove
    var searchQuery by remember { mutableStateOf("") }

    val filteredProposals = remember(proposals, searchQuery, selectedFilter) {
        proposals.filter { p ->
            val name = p.name.orEmpty()
            val bengaliName = p.bengaliName.orEmpty()
            val capCode = p.capabilityCode.orEmpty()
            val proposedBy = p.proposedByApp.orEmpty()
            val status = p.status.orEmpty()

            val matchesQuery = searchQuery.isBlank() ||
                    name.contains(searchQuery, ignoreCase = true) ||
                    bengaliName.contains(searchQuery, ignoreCase = true) ||
                    capCode.contains(searchQuery, ignoreCase = true) ||
                    proposedBy.contains(searchQuery, ignoreCase = true)

            val matchesFilter = when (selectedFilter) {
                "AI_PROPOSED" -> status.equals("AI_PROPOSED", ignoreCase = true)
                "ACTIVE" -> status.equals("ACTIVE", ignoreCase = true)
                "REJECTED" -> status.equals("REJECTED", ignoreCase = true)
                else -> true
            }
            matchesQuery && matchesFilter
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .testTag("capability_approval_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Sub-Navigation Tabs for External App Subsystems
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    OutlinedButton(
                        onClick = { viewModel.navigateTo(ScreenDestination.EXTERNAL_APPS_MONITOR) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Apps, contentDescription = null, modifier = Modifier.size(14.dp), tint = SaffronPrimary)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Apps", fontSize = 11.sp)
                    }

                    FilledTonalButton(
                        onClick = { viewModel.navigateTo(ScreenDestination.CAPABILITY_APPROVAL) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = VedicGold,
                            contentColor = Color.Black
                        ),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.VerifiedUser, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Capabilities", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = { viewModel.navigateTo(ScreenDestination.DAILY_DATA_MONITOR) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(14.dp), tint = SpiritualTeal)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Daily Data", fontSize = 11.sp)
                    }

                    OutlinedButton(
                        onClick = { viewModel.navigateTo(ScreenDestination.EXTERNAL_APP_SIMULATOR) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Science, contentDescription = null, modifier = Modifier.size(14.dp), tint = SaffronPrimary)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Sandbox", fontSize = 11.sp)
                    }
                }
            }
        }

        // Header Banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(text = "🛡️", fontSize = 20.sp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            "AI Dynamic Capability Approval Center",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onPrimaryContainer
                        )
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        "Review AI-discovered functions, approve schemas, and guard canonical safety",
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                        color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                    )
                }
            }
        }

        // 1. Summary Cards
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                val pendingCount = proposals.count { it.status.equals("AI_PROPOSED", ignoreCase = true) }
                val activeCount = proposals.count { it.status.equals("ACTIVE", ignoreCase = true) }
                val rejectedCount = proposals.count { it.status.equals("REJECTED", ignoreCase = true) }

                CapabilityStatCard(
                    title = "Pending Approval",
                    count = "$pendingCount",
                    subtitle = "Awaiting Admin Review",
                    color = VedicGold,
                    modifier = Modifier.weight(1f)
                )
                CapabilityStatCard(
                    title = "Approved & Active",
                    count = "$activeCount",
                    subtitle = "Live in Gateway",
                    color = Color(0xFF2E7D32),
                    modifier = Modifier.weight(1f)
                )
                CapabilityStatCard(
                    title = "Rejected",
                    count = "$rejectedCount",
                    subtitle = "Safety Guarded",
                    color = Color(0xFFC62828),
                    modifier = Modifier.weight(1f)
                )
            }
        }

        // 2. Search & Filter Bar
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(10.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    OutlinedTextField(
                        value = searchQuery,
                        onValueChange = { searchQuery = it },
                        modifier = Modifier.fillMaxWidth().testTag("search_capabilities_input"),
                        placeholder = { Text("Search by Capability Code, Name, or App...", fontSize = 12.sp) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = "Search", modifier = Modifier.size(18.dp)) },
                        trailingIcon = {
                            if (searchQuery.isNotEmpty()) {
                                IconButton(onClick = { searchQuery = "" }) {
                                    Icon(Icons.Default.Clear, contentDescription = "Clear", modifier = Modifier.size(16.dp))
                                }
                            }
                        },
                        singleLine = true,
                        shape = RoundedCornerShape(8.dp)
                    )

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        FilterChip(
                            selected = selectedFilter == "ALL",
                            onClick = { selectedFilter = "ALL" },
                            label = { Text("All (${proposals.size})", fontSize = 11.sp) },
                            shape = RoundedCornerShape(6.dp)
                        )
                        FilterChip(
                            selected = selectedFilter == "AI_PROPOSED",
                            onClick = { selectedFilter = "AI_PROPOSED" },
                            label = { Text("Pending (${proposals.count { it.status.equals("AI_PROPOSED", ignoreCase = true) }})", fontSize = 11.sp) },
                            shape = RoundedCornerShape(6.dp)
                        )
                        FilterChip(
                            selected = selectedFilter == "ACTIVE",
                            onClick = { selectedFilter = "ACTIVE" },
                            label = { Text("Active (${proposals.count { it.status.equals("ACTIVE", ignoreCase = true) }})", fontSize = 11.sp) },
                            shape = RoundedCornerShape(6.dp)
                        )
                    }
                }
            }
        }

        // 3. Capability Proposals List
        if (filteredProposals.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.Center
                    ) {
                        Icon(
                            Icons.Default.SearchOff,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(36.dp)
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            "No capability proposals matching the selected filter.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        } else {
            items(filteredProposals, key = { it.id }) { proposal ->
                CapabilityProposalCard(
                    proposal = proposal,
                    onApprove = { reviewProposalDialog = proposal to true },
                    onReject = { reviewProposalDialog = proposal to false },
                    onDisable = { viewModel.disableCapabilityProposal(proposal) }
                )
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }

    // Modal: Admin Review & Notes Dialog
    reviewProposalDialog?.let { (proposal, isApprove) ->
        var adminNotes by remember { mutableStateOf(if (isApprove) "Approved for production use across authorized client apps." else "Non-standard request; rejected based on canonical scope boundaries.") }

        AlertDialog(
            onDismissRequest = { reviewProposalDialog = null },
            title = {
                Text(
                    if (isApprove) "Approve Capability: ${proposal.name}" else "Reject Capability Proposal",
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(
                    modifier = Modifier.fillMaxWidth(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Text(
                        "Code: ${proposal.capabilityCode} • Proposed by: ${proposal.proposedByApp}",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold)
                    )
                    Text(
                        "Safety Rating: ${proposal.safetyRating}",
                        style = MaterialTheme.typography.bodySmall.copy(color = SpiritualTeal)
                    )

                    OutlinedTextField(
                        value = adminNotes,
                        onValueChange = { adminNotes = it },
                        label = { Text("Admin Review Notes & Audit Reason") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        if (isApprove) {
                            viewModel.approveCapabilityProposal(proposal, adminNotes)
                        } else {
                            viewModel.rejectCapabilityProposal(proposal, adminNotes)
                        }
                        reviewProposalDialog = null
                    },
                    colors = ButtonDefaults.buttonColors(
                        containerColor = if (isApprove) Color(0xFF2E7D32) else Color(0xFFC62828)
                    )
                ) {
                    Text(if (isApprove) "Confirm Approval" else "Confirm Rejection")
                }
            },
            dismissButton = {
                TextButton(onClick = { reviewProposalDialog = null }) {
                    Text("Cancel")
                }
            }
        )
    }
}

@Composable
fun CapabilityStatCard(
    title: String,
    count: String,
    subtitle: String,
    color: Color,
    modifier: Modifier = Modifier
) {
    Card(
        modifier = modifier,
        shape = RoundedCornerShape(10.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(10.dp)) {
            Text(title, style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.SemiBold), maxLines = 1)
            Spacer(modifier = Modifier.height(4.dp))
            Text(count, style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = color))
            Text(subtitle, style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant), maxLines = 1)
        }
    }
}

@Composable
fun CapabilityProposalCard(
    proposal: CapabilityProposalEntity,
    onApprove: () -> Unit,
    onReject: () -> Unit,
    onDisable: () -> Unit
) {
    var expandedSchema by remember { mutableStateOf(false) }

    val statusColor = when (proposal.status.uppercase()) {
        "ACTIVE" -> Color(0xFF2E7D32)
        "AI_PROPOSED" -> VedicGold
        "REJECTED" -> Color(0xFFC62828)
        else -> Color.Gray
    }

    Card(
        modifier = Modifier.fillMaxWidth(),
        shape = RoundedCornerShape(12.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            // Header
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Text(
                            proposal.name,
                            style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = statusColor.copy(alpha = 0.15f)
                        ) {
                            Text(
                                proposal.status.uppercase(),
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = statusColor,
                                    fontSize = 10.sp
                                )
                            )
                        }
                    }
                    Text(
                        proposal.bengaliName,
                        style = MaterialTheme.typography.bodyMedium.copy(color = SaffronPrimary, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                    )
                }

                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant
                ) {
                    Text(
                        proposal.capabilityCode,
                        modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp),
                        style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                proposal.description,
                style = MaterialTheme.typography.bodySmall.copy(color = MaterialTheme.colorScheme.onSurface, fontSize = 11.sp)
            )

            Spacer(modifier = Modifier.height(8.dp))

            // AI Origin Context Box
            Surface(
                shape = RoundedCornerShape(8.dp),
                color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(8.dp)) {
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                        Text("Origin: ${proposal.proposedByApp}", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 10.sp))
                        Text("Safety: ${proposal.safetyRating}", style = MaterialTheme.typography.labelSmall.copy(color = SpiritualTeal, fontWeight = FontWeight.Bold, fontSize = 10.sp))
                    }
                    if (proposal.triggerQuery.isNotBlank()) {
                        Spacer(modifier = Modifier.height(2.dp))
                        Text("Trigger Query: \"${proposal.triggerQuery}\"", style = MaterialTheme.typography.bodySmall.copy(fontStyle = androidx.compose.ui.text.font.FontStyle.Italic, fontSize = 11.sp))
                    }
                    Spacer(modifier = Modifier.height(2.dp))
                    Text("Detected Needs: ${proposal.detectedNeeds}", style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp))
                }
            }

            Spacer(modifier = Modifier.height(6.dp))

            // Toggle Schema JSON
            TextButton(
                onClick = { expandedSchema = !expandedSchema },
                contentPadding = PaddingValues(0.dp)
            ) {
                Icon(if (expandedSchema) Icons.Default.ExpandLess else Icons.Default.ExpandMore, contentDescription = null, modifier = Modifier.size(16.dp))
                Spacer(modifier = Modifier.width(4.dp))
                Text(if (expandedSchema) "Hide Input/Output JSON Schemas" else "View Input/Output JSON Schemas", fontSize = 11.sp)
            }

            AnimatedVisibility(visible = expandedSchema) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(top = 4.dp),
                    verticalArrangement = Arrangement.spacedBy(6.dp)
                ) {
                    Text("Input Schema:", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 10.sp))
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0xFF1E1E1E),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            proposal.inputSchemaJson,
                            modifier = Modifier.padding(8.dp),
                            style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFFE0E0E0), fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                        )
                    }

                    Text("Output Schema:", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 10.sp))
                    Surface(
                        shape = RoundedCornerShape(6.dp),
                        color = Color(0xFF1E1E1E),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Text(
                            proposal.outputSchemaJson,
                            modifier = Modifier.padding(8.dp),
                            style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFFE0E0E0), fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(10.dp))
            HorizontalDivider(color = MaterialTheme.colorScheme.outline)
            Spacer(modifier = Modifier.height(8.dp))

            // Action Buttons
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                if (proposal.status.equals("AI_PROPOSED", ignoreCase = true)) {
                    OutlinedButton(
                        onClick = onReject,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFC62828)),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("Reject", fontSize = 11.sp)
                    }
                    Spacer(modifier = Modifier.width(6.dp))
                    Button(
                        onClick = onApprove,
                        colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
                    ) {
                        Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(3.dp))
                        Text("Approve", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                    }
                } else if (proposal.status.equals("ACTIVE", ignoreCase = true)) {
                    OutlinedButton(
                        onClick = onDisable,
                        colors = ButtonDefaults.outlinedButtonColors(contentColor = Color(0xFFC62828)),
                        shape = RoundedCornerShape(6.dp),
                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                    ) {
                        Text("Disable Capability", fontSize = 11.sp)
                    }
                }
            }
        }
    }
}
