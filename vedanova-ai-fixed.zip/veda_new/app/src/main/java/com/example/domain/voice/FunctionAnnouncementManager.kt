package com.example.domain.voice

import android.content.Context
import android.speech.tts.TextToSpeech
import android.util.Log
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import java.util.Locale

data class FunctionMetadata(
    val functionId: String,
    val bengaliName: String,
    val englishName: String,
    val parentSection: String,
    val navigationRoute: String,
    val description: String,
    val isMajorFunction: Boolean = true,
    val customAnnouncementBn: String? = null
)

data class VoiceGuideSettings(
    val isEnabled: Boolean = true,
    val language: String = "BENGALI", // "BENGALI" or "ENGLISH"
    val speechSpeed: String = "NORMAL", // "SLOW", "NORMAL", "FAST"
    val announcementMode: String = "ALL" // "ALL", "MAJOR_ONLY", "NAVIGATION_ONLY", "DISABLED"
)

class FunctionAnnouncementManager(private val context: Context) : TextToSpeech.OnInitListener {

    private val TAG = "FunctionAnnouncement"
    private var tts: TextToSpeech? = null
    private var isTtsReady = false

    private val _settings = MutableStateFlow(VoiceGuideSettings())
    val settings: StateFlow<VoiceGuideSettings> = _settings.asStateFlow()

    private val _lastAnnouncement = MutableStateFlow("")
    val lastAnnouncement: StateFlow<String> = _lastAnnouncement.asStateFlow()

    private val functionCatalog = mapOf(
        "DASHBOARD" to FunctionMetadata(
            functionId = "control_center",
            bengaliName = "Control Center",
            englishName = "Control Center",
            parentSection = "Core",
            navigationRoute = "DASHBOARD",
            description = "Central command overview of AI intelligence, Gateway metrics, and database status",
            isMajorFunction = true,
            customAnnouncementBn = "আপনি এখন Control Center-এ প্রবেশ করেছেন।"
        ),
        "API_CENTER" to FunctionMetadata(
            functionId = "api_center",
            bengaliName = "API Manager",
            englishName = "API Manager",
            parentSection = "API Platform",
            navigationRoute = "API_CENTER",
            description = "Provision API keys, configure rate limits, and view endpoints",
            isMajorFunction = true,
            customAnnouncementBn = "আপনি এখন API Manager-এ প্রবেশ করেছেন।"
        ),
        "TEACH_AI" to FunctionMetadata(
            functionId = "teach_ai",
            bengaliName = "Teach AI",
            englishName = "Teach AI Knowledge Engine",
            parentSection = "Knowledge Management",
            navigationRoute = "TEACH_AI",
            description = "Direct knowledge ingestion and human-guided teaching console",
            isMajorFunction = true,
            customAnnouncementBn = "আপনি এখন Teach AI ফাংশনে আছেন।"
        ),
        "AI_TESTING_LAB" to FunctionMetadata(
            functionId = "ai_testing_lab",
            bengaliName = "AI Test Chat",
            englishName = "AI Test Chat",
            parentSection = "AI Engine",
            navigationRoute = "AI_TESTING_LAB",
            description = "Interactive test lab for multi-turn conversations and scriptural answers",
            isMajorFunction = true,
            customAnnouncementBn = "আপনি এখন AI Test Chat ব্যবহার করছেন।"
        ),
        "EXTERNAL_APPS_MONITOR" to FunctionMetadata(
            functionId = "external_apps",
            bengaliName = "Apps & Usage",
            englishName = "Apps & Usage",
            parentSection = "External App Engine",
            navigationRoute = "EXTERNAL_APPS_MONITOR",
            description = "Monitor connected external applications, quotas, and capability scopes",
            isMajorFunction = true,
            customAnnouncementBn = "আপনি এখন Apps & Usage ফাংশনে আছেন।"
        ),
        "PROJECT_MONITOR" to FunctionMetadata(
            functionId = "project_monitor",
            bengaliName = "Project Monitor",
            englishName = "Project Monitor & Dev Tasks",
            parentSection = "Operations",
            navigationRoute = "PROJECT_MONITOR",
            description = "Operational project tasks and implementation tracker",
            isMajorFunction = true,
            customAnnouncementBn = "আপনি এখন Project Monitor ফাংশনে আছেন।"
        ),
        "KNOWLEDGE_CENTER" to FunctionMetadata(
            functionId = "knowledge_center",
            bengaliName = "Knowledge Center",
            englishName = "Canonical Knowledge Center",
            parentSection = "Knowledge Management",
            navigationRoute = "KNOWLEDGE_CENTER",
            description = "Search, review, and manage verified scriptural knowledge records",
            isMajorFunction = true,
            customAnnouncementBn = "আপনি এখন Knowledge Center-এ প্রবেশ করছেন।"
        ),
        "RESEARCH_CENTER" to FunctionMetadata(
            functionId = "research_center",
            bengaliName = "Web Research & Knowledge Harvesting",
            englishName = "Web Research & Knowledge Harvesting Center",
            parentSection = "Knowledge Management",
            navigationRoute = "RESEARCH_CENTER",
            description = "Multi-tier scholarly research, mantra verification shield, and candidate harvesting pipeline",
            isMajorFunction = true,
            customAnnouncementBn = "আপনি এখন Web Research ও Knowledge Harvesting সেন্টারে প্রবেশ করছেন।"
        ),
        "UNKNOWN_KNOWLEDGE" to FunctionMetadata(
            functionId = "unknown_knowledge",
            bengaliName = "Unknown Knowledge Queue",
            englishName = "Unknown Knowledge Queue",
            parentSection = "Knowledge Management",
            navigationRoute = "UNKNOWN_KNOWLEDGE",
            description = "Review user queries with missing knowledge and approve candidate records",
            isMajorFunction = true,
            customAnnouncementBn = "আপনি এখন Unknown Knowledge Queue-তে প্রবেশ করছেন।"
        ),
        "CAPABILITY_APPROVAL" to FunctionMetadata(
            functionId = "capability_approval",
            bengaliName = "AI Capability Approval Center",
            englishName = "AI Capability Approval Center",
            parentSection = "External App Engine",
            navigationRoute = "CAPABILITY_APPROVAL",
            description = "Review and activate dynamic capabilities proposed by external apps",
            isMajorFunction = true,
            customAnnouncementBn = "আপনি এখন AI Capability Approval Center-এ প্রবেশ করছেন।"
        ),
        "EXTERNAL_APPS" to FunctionMetadata(
            functionId = "external_apps",
            bengaliName = "External Apps Monitor",
            englishName = "External Apps Monitor",
            parentSection = "External App Engine",
            navigationRoute = "EXTERNAL_APPS",
            description = "Monitor connected external applications, quotas, and capability scopes",
            isMajorFunction = true,
            customAnnouncementBn = "আপনি এখন External Apps Monitor-এ প্রবেশ করছেন।"
        ),
        "EXTERNAL_APP_SIMULATOR" to FunctionMetadata(
            functionId = "external_app_simulator",
            bengaliName = "External App Simulator",
            englishName = "External App Simulator",
            parentSection = "External App Engine",
            navigationRoute = "EXTERNAL_APP_SIMULATOR",
            description = "Simulate real-time requests from third-party client apps",
            isMajorFunction = false,
            customAnnouncementBn = "আপনি এখন External App Simulator ফাংশনে প্রবেশ করছেন।"
        ),
        "DAILY_DATA" to FunctionMetadata(
            functionId = "daily_data",
            bengaliName = "Daily Dharma Data Center",
            englishName = "Daily Dharma Data Center",
            parentSection = "External App Engine",
            navigationRoute = "DAILY_DATA",
            description = "Dynamic daily almanac, sunrise, tithi, and festival resolution engine",
            isMajorFunction = true,
            customAnnouncementBn = "আপনি এখন Daily Dharma Data Center-এ প্রবেশ করছেন।"
        ),
        "API_CENTER" to FunctionMetadata(
            functionId = "api_center",
            bengaliName = "API Gateway Management",
            englishName = "API Gateway Management",
            parentSection = "API Platform",
            navigationRoute = "API_CENTER",
            description = "Provision API keys, configure rate limits, and view endpoints",
            isMajorFunction = true,
            customAnnouncementBn = "আপনি এখন API Gateway Management-এ প্রবেশ করছেন।"
        ),
        "API_TESTING" to FunctionMetadata(
            functionId = "api_testing",
            bengaliName = "API Testing Console",
            englishName = "API Testing Console",
            parentSection = "API Platform",
            navigationRoute = "API_TESTING",
            description = "Simulate and test REST and RPC API endpoints directly",
            isMajorFunction = false,
            customAnnouncementBn = "আপনি এখন API Testing Console-এ প্রবেশ করছেন।"
        ),
        "EXTERNAL_TEST_CLIENT" to FunctionMetadata(
            functionId = "external_test_client",
            bengaliName = "External API Client",
            englishName = "External API Client",
            parentSection = "API Platform",
            navigationRoute = "EXTERNAL_TEST_CLIENT",
            description = "HTTP mock testing client for external API keys",
            isMajorFunction = false,
            customAnnouncementBn = "আপনি এখন External API Client-এ প্রবেশ করছেন।"
        ),
        "PROJECT_MONITOR" to FunctionMetadata(
            functionId = "project_monitor",
            bengaliName = "Project Task Monitor",
            englishName = "Project Task Monitor",
            parentSection = "Monitoring & Diagnostics",
            navigationRoute = "PROJECT_MONITOR",
            description = "Track codebase development milestones and tasks",
            isMajorFunction = true,
            customAnnouncementBn = "আপনি এখন Project Task Monitor সেন্টারে প্রবেশ করছেন।"
        ),
        "REPORTS" to FunctionMetadata(
            functionId = "reports",
            bengaliName = "User Reports Center",
            englishName = "User Reports Center",
            parentSection = "Monitoring & Diagnostics",
            navigationRoute = "REPORTS",
            description = "Review community feedback and user submitted correction requests",
            isMajorFunction = true,
            customAnnouncementBn = "আপনি এখন User Reports Center-এ প্রবেশ করছেন।"
        ),
        "ANALYTICS" to FunctionMetadata(
            functionId = "analytics",
            bengaliName = "API Analytics",
            englishName = "API Analytics & Metrics",
            parentSection = "Monitoring & Diagnostics",
            navigationRoute = "ANALYTICS",
            description = "Real-time Gateway throughput, latency distributions, and usage analytics",
            isMajorFunction = true,
            customAnnouncementBn = "আপনি এখন API Analytics-এ প্রবেশ করছেন।"
        ),
        "LOGS" to FunctionMetadata(
            functionId = "logs",
            bengaliName = "System Logs",
            englishName = "System Logs",
            parentSection = "Monitoring & Diagnostics",
            navigationRoute = "LOGS",
            description = "Examine live server telemetry, security events, and database operations",
            isMajorFunction = false,
            customAnnouncementBn = "আপনি এখন System Logs-এ প্রবেশ করছেন।"
        ),
        "AUDIT_LOGS" to FunctionMetadata(
            functionId = "audit_logs",
            bengaliName = "Audit Trail",
            englishName = "Admin Audit Trail",
            parentSection = "Security & Governance",
            navigationRoute = "AUDIT_LOGS",
            description = "Immutable compliance audit records of all administrative actions",
            isMajorFunction = false,
            customAnnouncementBn = "আপনি এখন Audit Trail-এ প্রবেশ করছেন।"
        ),
        "SECURITY" to FunctionMetadata(
            functionId = "security",
            bengaliName = "Security Center",
            englishName = "Security Center",
            parentSection = "Security & Governance",
            navigationRoute = "SECURITY",
            description = "Configure firewalls, IP blacklists, and role-based access rules",
            isMajorFunction = true,
            customAnnouncementBn = "আপনি এখন Security Center-এ প্রবেশ করছেন।"
        ),
        "USERS" to FunctionMetadata(
            functionId = "users",
            bengaliName = "Admin Users & RBAC",
            englishName = "Admin Users & RBAC",
            parentSection = "Security & Governance",
            navigationRoute = "USERS",
            description = "Manage administrator credentials, roles, and fine-grained permissions",
            isMajorFunction = false,
            customAnnouncementBn = "আপনি এখন Admin Users বিভাগে প্রবেশ করছেন।"
        ),
        "DATABASE_CENTER" to FunctionMetadata(
            functionId = "database_center",
            bengaliName = "Database Management Center",
            englishName = "Database Management Center",
            parentSection = "Infrastructure & Database",
            navigationRoute = "DATABASE_CENTER",
            description = "Inspect Room SQLite tables, schema integrity, and live row counts",
            isMajorFunction = true,
            customAnnouncementBn = "আপনি এখন Database Management Center-এ প্রবেশ করছেন।"
        ),
        "BACKUPS" to FunctionMetadata(
            functionId = "backups",
            bengaliName = "Backup & Restore",
            englishName = "Backup & Restore",
            parentSection = "Infrastructure & Database",
            navigationRoute = "BACKUPS",
            description = "Generate SHA-256 verified database snapshots and perform restores",
            isMajorFunction = true,
            customAnnouncementBn = "আপনি এখন Backup and Restore সেন্টারে প্রবেশ করছেন।"
        ),
        "SYSTEM_HEALTH" to FunctionMetadata(
            functionId = "system_health",
            bengaliName = "System Health Matrix",
            englishName = "System Health Matrix",
            parentSection = "Infrastructure & Database",
            navigationRoute = "SYSTEM_HEALTH",
            description = "Real-time health status of all 10 VedaNova backend subsystems",
            isMajorFunction = false,
            customAnnouncementBn = "আপনি এখন System Health Matrix-এ প্রবেশ করছেন।"
        ),
        "SETTINGS" to FunctionMetadata(
            functionId = "settings",
            bengaliName = "Platform Settings",
            englishName = "Platform Settings",
            parentSection = "Core",
            navigationRoute = "SETTINGS",
            description = "Fine-tune AI model temperature, voice guide preferences, and guardrails",
            isMajorFunction = true,
            customAnnouncementBn = "আপনি এখন Platform Settings-এ প্রবেশ করছেন।"
        ),
        "PUBLIC_APP" to FunctionMetadata(
            functionId = "public_app",
            bengaliName = "Public Dharma App",
            englishName = "Public Dharma App",
            parentSection = "Client App",
            navigationRoute = "PUBLIC_APP",
            description = "Client-facing end user conversation and scripture exploration view",
            isMajorFunction = true,
            customAnnouncementBn = "আপনি এখন Public Dharma App-এ প্রবেশ করছেন।"
        ),
        "FUNCTION_MAP" to FunctionMetadata(
            functionId = "function_map",
            bengaliName = "Admin Function Map",
            englishName = "Admin Function Map",
            parentSection = "Core",
            navigationRoute = "FUNCTION_MAP",
            description = "Visual hierarchical map of all admin modules and direct navigation",
            isMajorFunction = true,
            customAnnouncementBn = "আপনি এখন Admin Function Map-এ প্রবেশ করছেন।"
        ),
        "CRASH_REPORTS" to FunctionMetadata(
            functionId = "crash_reports",
            bengaliName = "Crash Diagnostic Center",
            englishName = "Crash Diagnostic Center",
            parentSection = "Monitoring & Diagnostics",
            navigationRoute = "CRASH_REPORTS",
            description = "Diagnostic inspection of application exceptions and stack traces",
            isMajorFunction = true,
            customAnnouncementBn = "আপনি এখন Crash Diagnostic Center-এ প্রবেশ করছেন।"
        )
    )

    init {
        try {
            tts = TextToSpeech(context.applicationContext, this)
        } catch (e: Exception) {
            Log.e(TAG, "Error initializing TextToSpeech", e)
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsReady = true
            applyLanguageSettings()
        } else {
            Log.w(TAG, "TextToSpeech init failed with status: $status")
        }
    }

    fun getAllFunctionMetadata(): List<FunctionMetadata> = functionCatalog.values.toList()

    fun getMetadataForRoute(route: String): FunctionMetadata? = functionCatalog[route]

    fun updateSettings(newSettings: VoiceGuideSettings) {
        _settings.value = newSettings
        if (isTtsReady) {
            applyLanguageSettings()
        }
    }

    fun setVoiceGuideEnabled(enabled: Boolean) {
        _settings.value = _settings.value.copy(isEnabled = enabled)
    }

    fun setLanguage(lang: String) {
        _settings.value = _settings.value.copy(language = lang)
        if (isTtsReady) {
            applyLanguageSettings()
        }
    }

    fun setSpeechSpeed(speed: String) {
        _settings.value = _settings.value.copy(speechSpeed = speed)
        if (isTtsReady) {
            applySpeechRate()
        }
    }

    fun setAnnouncementMode(mode: String) {
        _settings.value = _settings.value.copy(announcementMode = mode)
    }

    private fun applyLanguageSettings() {
        tts?.let { engine ->
            val lang = _settings.value.language
            val locale = if (lang == "ENGLISH") {
                Locale.US
            } else {
                Locale("bn", "BD")
            }

            val result = engine.setLanguage(locale)
            if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
                // Fallback to default or English
                engine.setLanguage(Locale.getDefault())
            }
            applySpeechRate()
        }
    }

    private fun applySpeechRate() {
        tts?.let { engine ->
            val rate = when (_settings.value.speechSpeed) {
                "SLOW" -> 0.8f
                "FAST" -> 1.3f
                else -> 1.0f
            }
            engine.setSpeechRate(rate)
            engine.setPitch(1.05f)
        }
    }

    fun announceNavigation(destinationRoute: String) {
        val currentSettings = _settings.value
        if (!currentSettings.isEnabled || currentSettings.announcementMode == "DISABLED") return

        val metadata = functionCatalog[destinationRoute] ?: FunctionMetadata(
            functionId = destinationRoute.lowercase(),
            bengaliName = destinationRoute,
            englishName = destinationRoute,
            parentSection = "Navigation",
            navigationRoute = destinationRoute,
            description = "Navigating to $destinationRoute"
        )

        if (currentSettings.announcementMode == "MAJOR_ONLY" && !metadata.isMajorFunction) {
            return
        }

        val announcement = if (currentSettings.language == "ENGLISH") {
            "You are now entering ${metadata.englishName}."
        } else {
            metadata.customAnnouncementBn ?: "আপনি এখন ${metadata.bengaliName} ফাংশনে প্রবেশ করছেন।"
        }

        speakText(announcement)
    }

    fun announceSection(sectionNameBn: String, sectionNameEn: String) {
        val currentSettings = _settings.value
        if (!currentSettings.isEnabled || currentSettings.announcementMode == "DISABLED") return

        val announcement = if (currentSettings.language == "ENGLISH") {
            "You are now entering $sectionNameEn section."
        } else {
            "আপনি এখন $sectionNameBn বিভাগে প্রবেশ করছেন।"
        }

        speakText(announcement)
    }

    fun announceButtonClick(buttonNameBn: String, buttonNameEn: String) {
        val currentSettings = _settings.value
        if (!currentSettings.isEnabled || currentSettings.announcementMode == "DISABLED") return
        if (currentSettings.announcementMode == "NAVIGATION_ONLY") return

        val announcement = if (currentSettings.language == "ENGLISH") {
            "Action $buttonNameEn initiated."
        } else {
            "$buttonNameBn ফাংশন সক্রিয় করা হয়েছে।"
        }

        speakText(announcement)
    }

    fun speakCustom(textBn: String, textEn: String) {
        val currentSettings = _settings.value
        if (!currentSettings.isEnabled || currentSettings.announcementMode == "DISABLED") return

        val announcement = if (currentSettings.language == "ENGLISH") textEn else textBn
        speakText(announcement)
    }

    private fun speakText(text: String) {
        _lastAnnouncement.value = text
        if (isTtsReady && tts != null) {
            try {
                tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "announcement_${System.currentTimeMillis()}")
            } catch (e: Exception) {
                Log.e(TAG, "TTS speak error", e)
            }
        }
    }

    fun stopSpeaking() {
        tts?.stop()
    }

    fun destroy() {
        try {
            tts?.stop()
            tts?.shutdown()
            tts = null
            isTtsReady = false
        } catch (e: Exception) {
            Log.e(TAG, "Error shutting down TTS", e)
        }
    }
}
