package com.example.domain.ai

import com.example.data.dao.KnowledgeDao
import com.example.data.model.KnowledgeEntity
import com.example.data.remote.*
import com.example.domain.research.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.util.Locale

data class ConflictAnalysis(
    val topic: String,
    val traditionA: String,
    val viewA: String,
    val traditionB: String,
    val viewB: String,
    val coreDifference: String,
    val commonGround: String
)

data class OrchestratedResponse(
    val answer: String,
    val sanskritVerse: String?,
    val transliteration: String?,
    val references: List<String>,
    val diagnosticInfo: DiagnosticInfo,
    val isVerifiedSource: Boolean,
    val isClarificationPrompt: Boolean = false,
    val clarificationOptions: List<String> = emptyList(),
    val conflictAnalysis: ConflictAnalysis? = null,
    val knowledgeCandidate: KnowledgeEntity? = null,
    val conversationContextSnippet: String? = null,
    val isUnknownQuery: Boolean = false,
    val matchedKnowledgeEntity: KnowledgeEntity? = null,
    val matchStrategy: String = "EXACT",
    val researchUsed: Boolean = false,
    val webSources: List<com.example.data.model.ResearchSourceEntity> = emptyList(),
    val youtubeVideos: List<YouTubeVideoEvidence> = emptyList()
)

class AiOrchestrator(
    private val knowledgeDao: KnowledgeDao
) {
    // In-memory conversation context state (Short-Term Context Memory)
    private var currentContextState = ConversationContextState()

    fun resetContextState() {
        currentContextState = ConversationContextState()
    }

    suspend fun processConversationTurn(
        query: String,
        history: List<Pair<String, String>> = emptyList(),
        temperature: Float = 0.2f,
        strictGuardrails: Boolean = true
    ): OrchestratedResponse = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        val rawQuery = query.trim()

        // 1. Language Detection
        val detectedLanguage = detectLanguage(rawQuery)

        // 2. Typo Normalization & Phonetic Correction
        val normalizedQuery = normalizeTyposAndSpelling(rawQuery)

        // 3. Deep Context Memory & State Update
        currentContextState = ContextMemoryManager.extractContextEntities(normalizedQuery, currentContextState)
            .copy(lastDetectedLanguage = detectedLanguage)

        // 4. Multi-turn Context Resolution (Resolving pronouns and topic references)
        val contextResolvedQuery = ContextMemoryManager.resolveMultiTurnQuery(
            query = normalizedQuery,
            history = history,
            contextState = currentContextState
        )

        // 5. Multi-Intent Understanding (Primary + Sub-Intents)
        val detectedIntents = detectMultipleIntents(contextResolvedQuery)
        val primaryIntent = detectedIntents.firstOrNull() ?: "GENERAL_DHARMA"
        val subIntent = if (detectedIntents.size > 1) detectedIntents.drop(1).joinToString(" + ") else "Deep Exploration"

        // 5.1 CREATOR IDENTITY & CORE CONVERSATION HANDLING (Direct, Natural & Non-Robotic)
        val isCreatorQuery = primaryIntent == "CREATOR_IDENTITY" || isCreatorInquiry(rawQuery, normalizedQuery, contextResolvedQuery)
        val isIdentityQuery = primaryIntent == "AI_IDENTITY" || isIdentityInquiry(rawQuery, normalizedQuery)
        val isCasualGreeting = primaryIntent == "GREETING" && isSimpleGreeting(normalizedQuery)

        if (isCreatorQuery) {
            val creatorAnswer = formatCreatorResponse(rawQuery, detectedLanguage, history)
            val elapsedMs = System.currentTimeMillis() - startTime
            return@withContext OrchestratedResponse(
                answer = creatorAnswer,
                sanskritVerse = null,
                transliteration = null,
                references = listOf("Dharma AI Creator Identity - Sri Milon Chandra (শ্রী মিলন চন্দ্র)"),
                diagnosticInfo = DiagnosticInfo(
                    languageDetected = detectedLanguage,
                    intentDetected = "CREATOR_IDENTITY",
                    subIntent = "Creator Verification",
                    detectedIntents = listOf("CREATOR_IDENTITY"),
                    ambiguityScore = 0.0f,
                    knowledgeMatchCount = 1,
                    topKnowledgeSource = "Dharma AI Identity Charter",
                    scriptureReference = "Creator: Sri Milon Chandra",
                    verificationStatus = "VERIFIED_CANONICAL",
                    confidenceScore = 1.0f,
                    researchEngineUsed = false,
                    responseTimeMs = elapsedMs,
                    apiEndpointUsed = "/api/v1/chat [Dharma AI Identity Engine]",
                    safetyPassed = true,
                    conflictsDetected = false,
                    diagnosticSummary = "Creator Identity: Sri Milon Chandra (শ্রী মিলন চন্দ্র).",
                    qualityScores = DiagnosticQualityScores(100, 100, 100, 100, 100, 100),
                    sourceTier = SourceQualityTier.PRIMARY_SCRIPTURE,
                    contextState = currentContextState
                ),
                isVerifiedSource = true,
                isClarificationPrompt = false
            )
        }

        if (isIdentityQuery) {
            val identityAnswer = formatIdentityResponse(detectedLanguage)
            val elapsedMs = System.currentTimeMillis() - startTime
            return@withContext OrchestratedResponse(
                answer = identityAnswer,
                sanskritVerse = null,
                transliteration = null,
                references = listOf("Dharma AI Platform Identity Charter"),
                diagnosticInfo = DiagnosticInfo(
                    languageDetected = detectedLanguage,
                    intentDetected = "AI_IDENTITY",
                    subIntent = "Self Identity",
                    detectedIntents = listOf("AI_IDENTITY"),
                    ambiguityScore = 0.0f,
                    knowledgeMatchCount = 1,
                    topKnowledgeSource = "Dharma AI Identity Charter",
                    scriptureReference = "Dharma AI - Sri Milon Chandra",
                    verificationStatus = "VERIFIED_CANONICAL",
                    confidenceScore = 1.0f,
                    researchEngineUsed = false,
                    responseTimeMs = elapsedMs,
                    apiEndpointUsed = "/api/v1/chat [Dharma AI Identity Engine]",
                    safetyPassed = true,
                    conflictsDetected = false,
                    diagnosticSummary = "Self Identity: Dharma AI, created by Sri Milon Chandra.",
                    qualityScores = DiagnosticQualityScores(100, 100, 100, 100, 100, 100),
                    sourceTier = SourceQualityTier.PRIMARY_SCRIPTURE,
                    contextState = currentContextState
                ),
                isVerifiedSource = true,
                isClarificationPrompt = false
            )
        }

        if (isCasualGreeting && history.isEmpty()) {
            val greetingAnswer = formatCasualGreetingResponse(normalizedQuery, detectedLanguage)
            val elapsedMs = System.currentTimeMillis() - startTime
            return@withContext OrchestratedResponse(
                answer = greetingAnswer,
                sanskritVerse = null,
                transliteration = null,
                references = listOf("Dharma AI Conversational Etiquette"),
                diagnosticInfo = DiagnosticInfo(
                    languageDetected = detectedLanguage,
                    intentDetected = "GREETING",
                    subIntent = "Polite Greeting",
                    detectedIntents = listOf("GREETING"),
                    ambiguityScore = 0.0f,
                    knowledgeMatchCount = 1,
                    topKnowledgeSource = "Conversational Model",
                    scriptureReference = "Sadachara & Polite Greeting",
                    verificationStatus = "VERIFIED_CANONICAL",
                    confidenceScore = 1.0f,
                    researchEngineUsed = false,
                    responseTimeMs = elapsedMs,
                    apiEndpointUsed = "/api/v1/chat [Conversational Engine]",
                    safetyPassed = true,
                    conflictsDetected = false,
                    diagnosticSummary = "Natural Greeting: Polite conversation turn.",
                    qualityScores = DiagnosticQualityScores(100, 100, 100, 100, 100, 100),
                    sourceTier = SourceQualityTier.PRIMARY_SCRIPTURE,
                    contextState = currentContextState
                ),
                isVerifiedSource = true,
                isClarificationPrompt = false
            )
        }

        // 6. Context-Aware Ambiguity & Smart Clarification Check
        val (isAmbiguous, clarificationOptions) = checkAmbiguityAndClarification(
            query = normalizedQuery,
            contextState = currentContextState,
            history = history
        )

        // 7. Knowledge Search (Verified Canonical Database First)
        val matchedKnowledge = searchLocalKnowledge(contextResolvedQuery)
        val bestMatch = matchedKnowledge.firstOrNull()
        val hasVerifiedMatch = bestMatch != null

        // 8. Multi-Sampradaya Conflict Detection
        val conflictAnalysis = detectSampradayaConflict(contextResolvedQuery)

        // 9. Mantra Safety & Hallucination Guardrail
        val isMantraQuery = detectedIntents.contains("MANTRA_TEXT") || 
                           detectedIntents.contains("MANTRA_INQUIRY") || 
                           contextResolvedQuery.contains("মন্ত্র") || 
                           contextResolvedQuery.contains("mantra")
        val isUnverifiedMantra = isMantraQuery && !hasVerifiedMatch && isFictionalOrUnverifiedMantra(contextResolvedQuery)

        // 10. Smart Clarification Handling
        if (isAmbiguous && clarificationOptions.isNotEmpty() && history.isEmpty() && currentContextState.activeSubject == null) {
            val clarificationMsg = formatClarificationPrompt(normalizedQuery, clarificationOptions, detectedLanguage)
            val elapsedMs = System.currentTimeMillis() - startTime
            val relatedNodes = DharmaSemanticGraph.findRelatedNodes(normalizedQuery)
            
            return@withContext OrchestratedResponse(
                answer = clarificationMsg,
                sanskritVerse = null,
                transliteration = null,
                references = listOf("VedaNova Clarification Engine"),
                diagnosticInfo = DiagnosticInfo(
                    languageDetected = detectedLanguage,
                    intentDetected = primaryIntent,
                    subIntent = "Interactive Disambiguation",
                    detectedIntents = detectedIntents,
                    ambiguityScore = 0.90f,
                    knowledgeMatchCount = matchedKnowledge.size,
                    topKnowledgeSource = "Interactive Disambiguation",
                    scriptureReference = "Clarification Needed",
                    verificationStatus = "INTERACTIVE_CLARIFICATION",
                    confidenceScore = 0.95f,
                    researchEngineUsed = false,
                    responseTimeMs = elapsedMs,
                    apiEndpointUsed = "/api/v1/chat [Smart Clarification Engine]",
                    safetyPassed = true,
                    conflictsDetected = false,
                    diagnosticSummary = "Ambiguous concept detected: Provided contextual clarification options.",
                    qualityScores = DiagnosticQualityScores(90, 95, 95, 95, 100, 95),
                    sourceTier = SourceQualityTier.PRIMARY_SCRIPTURE,
                    contextState = currentContextState,
                    relatedNodes = relatedNodes
                ),
                isVerifiedSource = true,
                isClarificationPrompt = true,
                clarificationOptions = clarificationOptions,
                knowledgeCandidate = null
            )
        }

        // 11. Strict Mantra Safety Guardrail (Never fabricate Sanskrit mantras)
        if (isUnverifiedMantra) {
            val safetyMsg = if (detectedLanguage.contains("Bengali")) {
                "নমস্কার। আপনার জিজ্ঞাসিত মন্ত্র বা শ্লোকটির কোনো প্রামাণিক শাস্ত্রীয় সূত্র (বেদ, উপনিষদ, পুরাণ বা প্রামাণিক তন্ত্র) থেকে নিশ্চিত করা সম্ভব হয়নি।\n\nসনাতন শাস্ত্রের বিশুদ্ধতা ও আধ্যাত্মিক মর্যাদা রক্ষার্থে VedaNova AI কোনো অপ্রমাণিত বা মনগড়া সংস্কৃত মন্ত্র তৈরি করে না। অনুগ্রহ করে প্রামাণিক গ্রন্থের নাম বা শুদ্ধ নাম উল্লেখ করুন।"
            } else {
                "Namaste. I could not verify an authentic canonical scripture source (Veda, Upanishad, Purana, or authorized Tantra) for the requested mantra.\n\nTo uphold the sanctity and authenticity of Sanatan Dharma scriptures, VedaNova AI strictly avoids generating unverified or fabricated Sanskrit verses. Please provide the specific scripture citation or deity name."
            }

            val elapsedMs = System.currentTimeMillis() - startTime
            return@withContext OrchestratedResponse(
                answer = safetyMsg,
                sanskritVerse = null,
                transliteration = null,
                references = listOf("VedaNova Mantra Safety Guardrail"),
                diagnosticInfo = DiagnosticInfo(
                    languageDetected = detectedLanguage,
                    intentDetected = "MANTRA_SAFETY_GUARD",
                    subIntent = "Unverified Mantra Request",
                    detectedIntents = listOf("MANTRA_SAFETY_GUARD"),
                    ambiguityScore = 0.5f,
                    knowledgeMatchCount = 0,
                    topKnowledgeSource = "Mantra Safety Engine",
                    scriptureReference = "Unverified Citation",
                    verificationStatus = "GUARDRAIL_TRIGGERED",
                    confidenceScore = 0.99f,
                    researchEngineUsed = false,
                    responseTimeMs = elapsedMs,
                    apiEndpointUsed = "/api/v1/chat [Mantra Guardrail]",
                    safetyPassed = true,
                    conflictsDetected = false,
                    diagnosticSummary = "Mantra Safety Active: Refused to fabricate unverified Sanskrit mantra.",
                    qualityScores = DiagnosticQualityScores(100, 100, 95, 99, 100, 99),
                    sourceTier = SourceQualityTier.PRIMARY_SCRIPTURE,
                    contextState = currentContextState
                ),
                isVerifiedSource = false,
                isClarificationPrompt = false
            )
        }

        // 12. Answer Generation (Knowledge-First Brain & Phase 6 Research Harvesting Engine)
        val apiKey = GeminiNetworkClient.getApiKey()
        val canUseGemini = apiKey.isNotBlank() && apiKey != "MY_GEMINI_API_KEY"

        var finalAnswer: String = ""
        var sanskritText: String? = bestMatch?.sanskritText?.ifBlank { null }
        var transliteration: String? = bestMatch?.transliteration?.ifBlank { null }
        val rawReferences = mutableListOf<Pair<String, String>>()
        var candidateKnowledge: KnowledgeEntity? = null
        var isUnknownQuery = false
        var researchUsed = false
        var activeWebSources: List<com.example.data.model.ResearchSourceEntity> = emptyList()
        var activeYtVideos: List<YouTubeVideoEvidence> = emptyList()

        if (bestMatch != null) {
            rawReferences.add(bestMatch.scripture to bestMatch.reference)
            finalAnswer = if (detectedLanguage.contains("English") && bestMatch.englishMeaning.isNotBlank()) {
                bestMatch.englishMeaning + (if (bestMatch.explanation.isNotBlank()) "\n\n" + bestMatch.explanation else "")
            } else {
                bestMatch.banglaMeaning + (if (bestMatch.explanation.isNotBlank()) "\n\n" + bestMatch.explanation else "")
            }
        } else {
            // PHASE 6: Perform Authoritative Web & YouTube Research
            researchUsed = true
            val webResearch = WebResearchProvider.performWebResearch(contextResolvedQuery)
            val ytResearch = YouTubeResearchProvider.performYouTubeResearch(contextResolvedQuery, webResearch.queryId)
            activeWebSources = webResearch.sources
            activeYtVideos = ytResearch.videos

            val crossVerification = CrossSourceVerificationEngine.performCrossVerification(
                contextResolvedQuery,
                webResearch.sources,
                ytResearch.supportingEvidenceSources
            )

            val mantraShieldResult = if (isMantraQuery) {
                MantraVerificationShield.verifyMantra(
                    contextResolvedQuery,
                    webResearch.sources,
                    ytResearch.supportingEvidenceSources
                )
            } else null

            if (isMantraQuery && mantraShieldResult?.isVerified == false) {
                // Strict Shield: Refuse to fabricate
                finalAnswer = mantraShieldResult.refusalMessage
                    ?: "এই মন্ত্রটির নির্ভরযোগ্য মূল পাঠ আমি নিশ্চিতভাবে যাচাই করতে পারিনি। তাই ভুল বা মনগড়া পাঠ দেওয়ার পরিবর্তে আমি গবেষণা ও অ্যাডমিন পর্যালোচনার জন্য এটি সংরক্ষণ করেছি।"
                isUnknownQuery = true
            } else if (webResearch.canonicalScriptureFound || crossVerification.verifiedTier1Count > 0 || crossVerification.verifiedTier2Count > 0) {
                // Verified Research Found!
                sanskritText = webResearch.primarySanskritText
                transliteration = webResearch.primaryTransliteration
                if (webResearch.primaryScripture != null && webResearch.primaryReference != null) {
                    rawReferences.add(webResearch.primaryScripture to webResearch.primaryReference)
                }

                val sb = StringBuilder()
                sb.append("ℹ️ *এই তথ্যটি আমার সংরক্ষিত জ্ঞানে ছিল না। তাই আমি নির্ভরযোগ্য শাস্ত্রীয় ডিজিটাল আর্কাইভ ও প্রামাণ্য উৎসগুলো যাচাই করে দেখেছি। যা সুনিশ্চিতভাবে পাওয়া গেছে তা নিচে দিচ্ছি:*\n\n")

                if (!webResearch.primarySanskritText.isNullOrBlank()) {
                    sb.append("📜 **মূল সংস্কৃত শ্লোক / মন্ত্র:**\n${webResearch.primarySanskritText}\n\n")
                }
                if (!webResearch.primaryTransliteration.isNullOrBlank()) {
                    sb.append("🔤 **IAST লিপ্যন্তর:**\n*${webResearch.primaryTransliteration}*\n\n")
                }
                if (!webResearch.primaryBengaliMeaning.isNullOrBlank()) {
                    sb.append("📖 **প্রামাণ্য বাংলা অর্থ:**\n${webResearch.primaryBengaliMeaning}\n\n")
                }
                if (!webResearch.primaryEnglishMeaning.isNullOrBlank()) {
                    sb.append("🌐 **English Translation:**\n${webResearch.primaryEnglishMeaning}\n\n")
                }
                if (webResearch.primaryExcerpt.isNotBlank() && webResearch.primaryExcerpt != webResearch.primarySanskritText) {
                    sb.append("💡 **শাস্ত্রীয় প্রেক্ষাপট:**\n${webResearch.primaryExcerpt}\n\n")
                }
                if (crossVerification.isMultiTraditionTopic && crossVerification.traditionNotes != null) {
                    sb.append("🏛️ **ঐতিহ্যগত পরিপ্রেক্ষিত (Sampradaya Notes):**\n${crossVerification.traditionNotes}\n\n")
                }
                if (webResearch.primaryReference != null) {
                    sb.append("📚 **যাচাইকৃত সূত্র:** ${webResearch.primaryScripture ?: "Canonical Scripture"} (${webResearch.primaryReference})\n")
                }
                if (activeWebSources.isNotEmpty()) {
                    sb.append("🌐 **গবেষিত ডিজিটাল উৎস:** ${activeWebSources.first().title} (${activeWebSources.first().domain} - ${activeWebSources.first().sourceTier})\n")
                }
                if (activeYtVideos.isNotEmpty()) {
                    val yt = activeYtVideos.first()
                    sb.append("🎧 **প্রামাণিক উচ্চারণ সহায়ক:** ${yt.title} (${yt.channel})")
                }

                finalAnswer = sb.toString().trim()
            } else {
                // No reliable source found
                finalAnswer = "আমি এই বিষয়টি সম্পর্কে নির্ভরযোগ্য ও পর্যাপ্ত শাস্ত্রীয় উৎস খুঁজে পাইনি। তাই ভুল বা অপ্রমাণিত তথ্য দেওয়ার পরিবর্তে বিষয়টি যাচাইয়ের জন্য অ্যাডমিন রিসার্চ সেন্টারে পাঠিয়েছি।"
                isUnknownQuery = true
            }
        }

        if (canUseGemini && !isUnknownQuery) {
            try {
                val groundContext = if (bestMatch != null) {
                    """
                    Verified Canonical Grounding (PRE-APPROVED SOURCE):
                    Title: ${bestMatch.title}
                    Category: ${bestMatch.category}
                    Sanskrit: ${bestMatch.sanskritText}
                    Transliteration: ${bestMatch.transliteration}
                    Bengali Meaning: ${bestMatch.banglaMeaning}
                    English Meaning: ${bestMatch.englishMeaning}
                    Explanation: ${bestMatch.explanation}
                    Scripture Source: ${bestMatch.scripture} (${bestMatch.reference}) [${bestMatch.sourceType}]
                    """.trimIndent()
                } else {
                    """
                    Researched Canonical Grounding:
                    $finalAnswer
                    """.trimIndent()
                }

                val historyContext = if (history.isNotEmpty()) {
                    "Previous conversation turns:\n" + history.takeLast(4).joinToString("\n") { (role, text) ->
                        "${role.uppercase()}: $text"
                    } + "\n\n"
                } else ""

                val contextEntitySnippet = currentContextState.contextSummary

                val systemPrompt = """
                    You are Dharma AI (ধর্ম এআই), a serene, respectful, human-like, polite, and professional Hindu Dharma and spiritual knowledge companion.
                    
                    Active Context: $contextEntitySnippet
                    Detected Intents: ${detectedIntents.joinToString(", ")}
                    
                    CREATOR IDENTITY (MANDATORY & ABSOLUTE):
                    - You were created by Sri Milon Chandra (শ্রী মিলন চন্দ্র).
                    - If asked "তোমাকে কে বানিয়েছে?", "Who created you?", "Who made you?", "তোমার creator কে?", "তোমার নির্মাতা কে?", or similar variations:
                      * In Bengali: "আমাকে তৈরি করেছেন শ্রী মিলন চন্দ্র।" (or contextually "আমি Dharma AI। আমাকে তৈরি করেছেন শ্রী মিলন চন্দ্র।")
                      * In English: "I was created by Sri Milon Chandra." (or contextually "I am Dharma AI, created by Sri Milon Chandra.")
                    - Respond naturally and contextually. Avoid repeating robotic phrases.
                    
                    CONVERSATIONAL PRINCIPLES & CONVERSATION JUDGMENT:
                    1. Natural & Polite: Speak like a wise, humble, respectful human guide. Avoid robotic, overly stiff, or redundant filler phrases.
                    2. Context Awareness & Continuity: Remember previous conversation turns and do not repeat identical explanations.
                    3. Smart Question Handling:
                       - Simple/Short questions: Provide concise, clear, and direct answers without unneeded verse dumping.
                       - Detailed/In-depth questions: Provide structured, rich, and insightful explanations.
                       - Ambiguous/Unclear questions: Ask for gentle, polite clarification.
                       - Unknown information / Out of knowledge: State limitations honestly with humility ("আমি এই বিষয়টি সম্পর্কে নিশ্চিত কোনো প্রামাণিক তথ্য খুঁজে পাইনি..."). NEVER fabricate facts, citations, or mantras.
                       - Casual chat & greetings: Respond warmly, politely, and naturally.
                    4. Language Parity: Match user language (${detectedLanguage}). If user speaks Bengali or English, reply in that language fluently.
                    5. Humility & Respect: Never claim to be God, Guru, or infallible authority. Speak with reverence.
                    6. Strict Scripture & Mantra Authenticity: NEVER fabricate non-existent Sanskrit verses or mantras.
                    
                    $historyContext
                    $groundContext
                """.trimIndent()

                val request = GeminiGenerateRequest(
                    contents = listOf(
                        GeminiContent(
                            parts = listOf(GeminiPart(text = contextResolvedQuery)),
                            role = "user"
                        )
                    ),
                    systemInstruction = GeminiContent(
                        parts = listOf(GeminiPart(text = systemPrompt))
                    ),
                    generationConfig = GeminiGenerationConfig(
                        temperature = temperature,
                        maxOutputTokens = 2048
                    )
                )

                val response = GeminiNetworkClient.apiService.generateContent(apiKey, request)
                val geminiText = response.candidates?.firstOrNull()?.content?.parts?.firstOrNull()?.text

                if (!geminiText.isNullOrBlank()) {
                    finalAnswer = geminiText
                    if (bestMatch == null && primaryIntent in listOf("SCRIPTURE_EXEGESIS", "PHILOSOPHY_QUERY", "DEITY_THEOLOGY", "MANTRA_INQUIRY")) {
                        candidateKnowledge = createKnowledgeCandidateFromAiAnswer(
                            query = contextResolvedQuery,
                            answer = geminiText,
                            intent = primaryIntent,
                            detectedLanguage = detectedLanguage
                        )
                    }
                }
            } catch (e: Exception) {
                // Keep local or researched finalAnswer
            }
        } else if (bestMatch != null) {
            finalAnswer = formatLocalKnowledgeAnswer(bestMatch, detectedLanguage)
        }

        // 13. Source Quality & Claims Verification Pipeline
        val evaluatedSources = SourceQualityEngine.evaluateSources(
            if (rawReferences.isNotEmpty()) rawReferences else listOf("Authentic Dharma Exegesis" to "Classical Shruti/Smriti")
        )
        val (claims, selfCorrectionLogs) = ClaimVerificationEngine.verifyClaims(
            answer = finalAnswer,
            verifiedKnowledgeMatched = hasVerifiedMatch,
            scriptureName = bestMatch?.scripture ?: "Classical Hermeneutics",
            isMantraRequest = isMantraQuery
        )

        // 14. Dharma Semantic Graph Related Nodes
        val relatedGraphNodes = DharmaSemanticGraph.findRelatedNodes(contextResolvedQuery)

        val elapsedMs = System.currentTimeMillis() - startTime
        val verificationStatus = when {
            hasVerifiedMatch && (bestMatch?.confidenceScore ?: 0f) >= 0.95f -> "VERIFIED_CANONICAL"
            hasVerifiedMatch -> "PARTIAL_MATCH"
            canUseGemini -> "RESEARCH_SYNTHESIZED"
            else -> "UNKNOWN_GROUNDING"
        }

        val confidenceScore = when {
            hasVerifiedMatch -> bestMatch?.confidenceScore ?: 0.95f
            canUseGemini -> 0.90f
            else -> 0.50f
        }

        // Quality Scores Breakdown
        val groundingScore = if (hasVerifiedMatch) 98 else if (canUseGemini) 88 else 50
        val sourceScore = if (hasVerifiedMatch) 99 else 86
        val contextScore = if (currentContextState.threadTurnCount > 0) 95 else 90
        val confidenceScoreInt = (confidenceScore * 100).toInt()
        val safetyScore = 100
        val overallQualityScore = ((groundingScore + sourceScore + contextScore + confidenceScoreInt + safetyScore) / 5)

        val qualityScores = DiagnosticQualityScores(
            groundingScore = groundingScore,
            sourceScore = sourceScore,
            contextScore = contextScore,
            confidenceScore = confidenceScoreInt,
            safetyScore = safetyScore,
            overallScore = overallQualityScore
        )

        val topSourceTier = evaluatedSources.firstOrNull()?.tier ?: SourceQualityTier.PRIMARY_SCRIPTURE

        val referencesList = if (bestMatch != null) {
            listOf("${bestMatch.scripture} (${bestMatch.reference}) [${bestMatch.sourceType}]")
        } else {
            evaluatedSources.map { "${it.title} - ${it.citation} (${it.tier.tierName})" }
        }

        val diagnosticInfo = DiagnosticInfo(
            languageDetected = detectedLanguage,
            intentDetected = primaryIntent,
            subIntent = subIntent,
            detectedIntents = detectedIntents,
            ambiguityScore = if (isAmbiguous) 0.85f else 0.15f,
            knowledgeMatchCount = matchedKnowledge.size,
            topKnowledgeSource = bestMatch?.source ?: if (hasVerifiedMatch) "Canonicals" else "Researched Grounding",
            scriptureReference = bestMatch?.reference ?: "Authentic Dharma Exegesis",
            verificationStatus = verificationStatus,
            confidenceScore = confidenceScore,
            researchEngineUsed = !hasVerifiedMatch || canUseGemini,
            responseTimeMs = elapsedMs,
            apiEndpointUsed = if (canUseGemini) "/api/v1/chat [Gemini Flash + Shruti Grounding]" else "/api/v1/chat [Local Knowledge Engine]",
            safetyPassed = true,
            conflictsDetected = conflictAnalysis != null,
            diagnosticSummary = "Human Intelligence Active: Intents=${detectedIntents.size}, ContextTurns=${currentContextState.threadTurnCount}, Quality=${overallQualityScore}/100",
            qualityScores = qualityScores,
            sourceTier = topSourceTier,
            contextState = currentContextState,
            evaluatedSources = evaluatedSources,
            claims = claims,
            selfCorrectionLogs = selfCorrectionLogs,
            relatedNodes = relatedGraphNodes
        )

        OrchestratedResponse(
            answer = finalAnswer,
            sanskritVerse = sanskritText,
            transliteration = transliteration,
            references = referencesList,
            diagnosticInfo = diagnosticInfo,
            isVerifiedSource = hasVerifiedMatch,
            isClarificationPrompt = false,
            clarificationOptions = emptyList(),
            conflictAnalysis = conflictAnalysis,
            knowledgeCandidate = candidateKnowledge,
            conversationContextSnippet = if (history.isNotEmpty()) "Active Context: ${currentContextState.contextSummary}" else null,
            isUnknownQuery = !hasVerifiedMatch,
            matchedKnowledgeEntity = bestMatch,
            matchStrategy = if (hasVerifiedMatch) "VERIFIED_CANONICAL" else "RESEARCH_GROUNDED",
            researchUsed = researchUsed,
            webSources = activeWebSources,
            youtubeVideos = activeYtVideos
        )
    }

    suspend fun processQuery(
        query: String,
        temperature: Float = 0.2f,
        strictGuardrails: Boolean = true
    ): OrchestratedResponse {
        return processConversationTurn(query = query, history = emptyList(), temperature = temperature, strictGuardrails = strictGuardrails)
    }

    private fun detectLanguage(text: String): String {
        val hasBengali = text.any { it in '\u0980'..'\u09FF' }
        val hasDevanagari = text.any { it in '\u0900'..'\u097F' }
        val hasLatin = text.any { it in 'a'..'z' || it in 'A'..'Z' }

        return when {
            hasBengali && hasLatin -> "Bengali + English (Mixed)"
            hasBengali -> "Bengali (বাংলা)"
            hasDevanagari -> "Sanskrit / Hindi (संस्कृतम्)"
            hasLatin -> "English"
            else -> "Multilingual"
        }
    }

    private fun normalizeTyposAndSpelling(query: String): String {
        var q = query.trim()
        val replacements = mapOf(
            "নিস্কাম" to "নিষ্কাম",
            "কর্মজগ" to "কর্মযোগ",
            "গায়ত্রীর" to "গায়ত্রী",
            "gaytri" to "Gayatri",
            "geeta" to "Gita",
            "gita" to "Gita",
            "durgar" to "Durga",
            "shiva" to "Shiva",
            "krishna" to "Krishna",
            "krishno" to "Krishna",
            "shlok" to "Shloka",
            "upnishad" to "Upanishad",
            "bhagbat" to "Bhagavata",
            "mahamritunjay" to "Mahamrityunjaya",
            "mrityunjay" to "Mahamrityunjaya"
        )
        for ((wrong, right) in replacements) {
            if (q.contains(wrong, ignoreCase = true)) {
                q = q.replace(wrong, right, ignoreCase = true)
            }
        }
        return q
    }

    private fun detectMultipleIntents(query: String): List<String> {
        val lower = query.lowercase(Locale.ROOT)
        val intents = mutableListOf<String>()

        if (lower.contains("কে বানিয়েছে") || lower.contains("কে তৈরি করেছে") || lower.contains("কে বানিয়েছে") ||
            lower.contains("কে বানাইছে") || lower.contains("creator কে") || lower.contains("নির্মাতা কে") ||
            lower.contains("who created") || lower.contains("who made") || lower.contains("who is your creator") ||
            lower.contains("who built you") || lower.contains("who developed you") || lower.contains("your creator") ||
            lower.contains("মিলন চন্দ্র") || lower.contains("milon chandra")) {
            intents.add("CREATOR_IDENTITY")
        }
        if (lower.contains("তুমি কে") || lower.contains("তোমার নাম কি") || lower.contains("তোমার নাম কী") ||
            lower.contains("তোমার পরিচয়") || lower.contains("who are you") || lower.contains("what is your name")) {
            intents.add("AI_IDENTITY")
        }
        if (lower in listOf("হাই", "হ্যালো", "নমস্কার", "প্রণাম", "hello", "hi", "namaste", "hey", "শুভ সকাল", "শুভ সন্ধ্যা", "শুভ রাত্রি", "ধন্যবাদ", "thanks", "thank you", "কেমন আছো", "কেমন আছেন", "how are you")) {
            intents.add("GREETING")
        }

        if (lower.contains("mantra") || lower.contains("মন্ত্র") || lower.contains("শ্লোক") || lower.contains("verse") || lower.contains("গায়ত্রী") || lower.contains("মৃত্যুঞ্জয়")) {
            intents.add("MANTRA_TEXT")
        }
        if (lower.contains("অর্থ") || lower.contains("meaning") || lower.contains("translation") || lower.contains("অনুবাদ") || lower.contains("ব্যাখ্যা")) {
            intents.add("MEANING_EXEGESIS")
        }
        if (lower.contains("কীভাবে") || lower.contains("নিয়ম") || lower.contains("জপ") || lower.contains("how to") || lower.contains("practice") || lower.contains("বিধি")) {
            intents.add("PRACTICE_GUIDANCE")
        }
        if (lower.contains("gita") || lower.contains("গীতা") || lower.contains("উপনিষদ") || lower.contains("বেদ") || lower.contains("পুরাণ") || lower.contains("scripture")) {
            intents.add("SCRIPTURE_EXEGESIS")
        }
        if (lower.contains("অদ্বৈত") || lower.contains("দ্বৈত") || lower.contains("দর্শন") || lower.contains("তত্ত্ব") || lower.contains("philosophy") || lower.contains("brahman")) {
            intents.add("PHILOSOPHY_QUERY")
        }
        if (lower.contains("কৃষ্ণ") || lower.contains("শিব") || lower.contains("দুর্গা") || lower.contains("কালী") || lower.contains("ঈশ্বর") || lower.contains("deity")) {
            intents.add("DEITY_THEOLOGY")
        }
        if (lower.contains("উৎসব") || lower.contains("পূজা") || lower.contains("তিথি") || lower.contains("ব্রত") || lower.contains("festival")) {
            intents.add("RITUAL_CALENDAR")
        }

        if (intents.isEmpty()) {
            intents.add("GENERAL_DHARMA")
        }
        return intents.distinct()
    }

    private fun checkAmbiguityAndClarification(
        query: String,
        contextState: ConversationContextState,
        history: List<Pair<String, String>>
    ): Pair<Boolean, List<String>> {
        // If we already have strong active context (e.g. following up on Shiva), do not trigger generic ambiguity
        if (history.isNotEmpty() && contextState.activeSubject != null) {
            return false to emptyList()
        }

        val tokens = query.trim().split("\\s+".toRegex()).filter { it.isNotBlank() }
        val lower = query.trim().lowercase(Locale.ROOT)

        if (tokens.size <= 2) {
            when {
                lower in listOf("দুর্গা", "durga", "দেবী দুর্গা", "মা দুর্গা") -> {
                    return true to listOf(
                        "মা দুর্গা সম্পর্কে কী জানতে চান—পরিচয়, মন্ত্র, নাম, পূজা, স্তোত্র নাকি শাস্ত্রীয় তথ্য?",
                        "মা দুর্গার পরিচয় ও পৌরাণিক মাহাত্ম্য",
                        "দুর্গা বীজ ও ধ্যান মন্ত্র (ওঁ দুং দুর্গায়ৈ নমঃ)",
                        "শ্রী শ্রী চণ্ডী পাঠের গুরুত্ব",
                        "নবদুর্গা রূপ ও পূজা পদ্ধতি",
                        "মা দুর্গার ১০৮ নাম"
                    )
                }
                lower in listOf("গীতা", "gita", "geeta", "শ্রীমদ্ভগবদ্গীতা") -> {
                    return true to listOf(
                        "ভগবদ্গীতার কোন বিষয় জানতে চান—শ্লোক, অর্থ, শিক্ষা, অধ্যায় নাকি পরিচয়?",
                        "শ্রীমদ্ভগবদ্গীতার মূল বার্তা ও সারসংক্ষেপ",
                        "গীতার কর্মযোগ (২.৪৭ শ্লোক)",
                        "গীতার মূল শিক্ষা ও মোক্ষ লাভের উপায়",
                        "গীতার ১৮টি অধ্যায়ের রূপরেখা"
                    )
                }
                lower in listOf("কৃষ্ণ", "krishna", "শ্রীকৃষ্ণ", "শ্রী কৃষ্ণ") -> {
                    return true to listOf(
                        "শ্রীকৃষ্ণ সম্পর্কে কী জানতে চান—পরিচয়, মন্ত্র, ১০৮ নাম, গীতার শিক্ষা নাকি অন্য কিছু?",
                        "শ্রীকৃষ্ণের পরিচয় ও অবতার তত্ত্ব",
                        "হরে কৃষ্ণ মহামন্ত্র ও অর্থ",
                        "ভগবদ্গীতায় শ্রীকৃষ্ণের পরম বাণী",
                        "শ্রীকৃষ্ণের অষ্টোত্তর শতনাম"
                    )
                }
                lower in listOf("শিব", "shiva", "মহাদেব", "ভগবান শিব") -> {
                    return true to listOf(
                        "ভগবান শিব সম্পর্কে কী জানতে চান—পরিচয়, মন্ত্র, মহাশিবরাত্রি, স্তোত্র নাকি পূজা পদ্ধতি?",
                        "ভগবান শিবের স্বরূপ ও নির্গুণ-সগুণ রূপ",
                        "শিব পঞ্চাক্ষর মন্ত্র (ওঁ নমঃ শিবায়) ও অর্থ",
                        "মহামৃত্যুঞ্জয় মন্ত্র ও ফলশ্রুতি",
                        "মহাশিবরাত্রির মাহাত্ম্য ও ব্রতকথা"
                    )
                }
                lower in listOf("পূজা", "puja", "পূজা পদ্ধতি", "পূজার নিয়ম") -> {
                    return true to listOf(
                        "কোন দেবতার পূজা বা পূজার কোন বিষয় জানতে চান?",
                        "নিত্য পঞ্চোপচার ও ষোড়শোপচার পূজা বিধি",
                        "শিব পূজা পদ্ধতি ও নিয়ম",
                        "নারায়ণ / সত্যনারায়ণ পূজা বিধি",
                        "দুর্গা পূজা ও চণ্ডী অর্চনা"
                    )
                }
                lower in listOf("কালী", "kali", "মা কালী") -> {
                    return true to listOf(
                        "মা কালী সম্পর্কে কী জানতে চান—স্বরূপ, মন্ত্র, পূজা নাকি আধ্যাত্মিক তত্ত্ব?",
                        "মা কালীর স্বরূপ ও দশমহাবিদ্যা",
                        "কালী ধ্যান ও প্রণাম মন্ত্র",
                        "কালীপূজার মাহাত্ম্য ও আধ্যাত্মিক তত্ত্ব"
                    )
                }
                lower in listOf("মন্ত্র", "mantra", "মন্ত্র দাও", "একটি মন্ত্র দাও", "আমাকে একটি মন্ত্র দাও") -> {
                    return true to listOf(
                        "কোন দেবতার মন্ত্র চান—শিব, বিষ্ণু, কৃষ্ণ, দুর্গা, গণেশ, সরস্বতী, লক্ষ্মী নাকি অন্য কারও?",
                        "ভগবান শ্রীগণেশ মন্ত্র (ওঁ গং গণপতয়ে নমঃ)",
                        "ভগবান শিব মন্ত্র (ওঁ নমঃ শিবায়)",
                        "ভগবান শ্রীবিষ্ণু মন্ত্র (ওঁ নমো নারায়ণায়)",
                        "মা দুর্গা মন্ত্র (ওঁ দুং দুর্গায়ৈ নমঃ)",
                        "মা সরস্বতী মন্ত্র (ওঁ ঐং সরস্বত্যৈ নমঃ)",
                        "মা লক্ষ্মী মন্ত্র (ওঁ শ্রীং মহালক্ষ্ম্যৈ নমঃ)"
                    )
                }
                lower in listOf("উপবাস", "ব্রত", "fasting") -> {
                    return true to listOf(
                        "একাদশী ব্রতের নিয়ম ও ফল",
                        "সনাতন ধর্মে উপবাসের আধ্যাত্মিক গুরুত্ব",
                        "শিবরাত্রি ও প্রদোষ ব্রত বিধি"
                    )
                }
            }
        }
        return false to emptyList()
    }

    private fun formatClarificationPrompt(concept: String, options: List<String>, language: String): String {
        val firstClarificationQuestion = options.firstOrNull()
        if (firstClarificationQuestion != null && firstClarificationQuestion.endsWith("?")) {
            return firstClarificationQuestion
        }

        val sb = StringBuilder()
        if (language.contains("Bengali")) {
            sb.append("আপনি **${concept}** সম্পর্কে কী জানতে চান?\n\n")
            options.forEachIndexed { idx, opt ->
                sb.append("${idx + 1}. $opt\n")
            }
            sb.append("\nআপনার প্রশ্নটি নির্দিষ্ট করে লিখুন, আমি শাস্ত্রীয় তথ্য দিয়ে সহায়তা করব।")
        } else {
            sb.append("What specific aspect of **${concept}** would you like to know?\n\n")
            options.forEachIndexed { idx, opt ->
                sb.append("${idx + 1}. $opt\n")
            }
            sb.append("\nPlease specify your question, and I will assist you with authentic scriptural knowledge.")
        }
        return sb.toString()
    }

    private fun detectSampradayaConflict(query: String): ConflictAnalysis? {
        val lower = query.lowercase(Locale.ROOT)
        if (lower.contains("advaita") && lower.contains("dvaita") || 
            lower.contains("অদ্বৈত") && lower.contains("দ্বৈত") ||
            lower.contains("মায়াবাদ") || lower.contains("ভক্তি বনাম জ্ঞান") ||
            lower.contains("সগুণ বনাম নির্গুণ")) {
            return ConflictAnalysis(
                topic = "Nature of Brahman, Jiva, and Reality (Vedantic Hermeneutics)",
                traditionA = "Advaita Vedanta (Adi Shankaracharya)",
                viewA = "Brahman is non-dual, pure consciousness (Nirguna). Jiva and Brahman are fundamentally identical in ultimate truth (Paramarthika Satya).",
                traditionB = "Dvaita / Vishishtadvaita (Madhvacharya / Ramanujacharya)",
                viewB = "Brahman is personal (Saguna Ishvara/Vishnu). Jiva is eternally distinct or an inseparable attribute (Shesha) of the Supreme Lord.",
                coreDifference = "Identity (Abheda) vs Difference / Subordination (Bheda/Vishishtabheda) of Jiva & Brahman.",
                commonGround = "Both traditions venerate the Vedas, advocate Dharma, purify the mind (Chitta Shuddhi), and seek liberation from Samsara through divine realization."
            )
        }
        return null
    }

    private fun isFictionalOrUnverifiedMantra(query: String): Boolean {
        val lower = query.lowercase(Locale.ROOT)
        return lower.contains("কাল্পনিক") || lower.contains("অজ্ঞাত দেবী") || lower.contains("বানিয়ে") ||
               lower.contains("fake") || lower.contains("fictional") || lower.contains("invented")
    }

    private suspend fun searchLocalKnowledge(query: String): List<KnowledgeEntity> {
        val published = knowledgeDao.getAllPublishedDirect()
        val matchResult = KnowledgeMatchingEngine.findBestMatch(query, published)
        if (matchResult.knowledge != null) {
            return listOf(matchResult.knowledge)
        }

        val direct = knowledgeDao.findMatchingPublishedKnowledge(query)
        if (direct.isNotEmpty()) return direct

        // Tokenized fallback search
        val words = query.split("\\s+".toRegex()).filter { it.length > 2 }
        for (w in words) {
            val partial = knowledgeDao.findMatchingPublishedKnowledge(w)
            if (partial.isNotEmpty()) return partial
        }
        return emptyList()
    }

    private fun formatLocalKnowledgeAnswer(k: KnowledgeEntity, language: String): String {
        // Direct answer for Conversational or Direct Taught QA
        if (k.category.equals("GENERAL_CONVERSATION", ignoreCase = true)) {
            return k.answer.ifBlank { k.banglaMeaning }
        }

        if (k.answer.isNotBlank() && k.sanskritText.isBlank()) {
            val sb = StringBuilder()
            sb.append(k.answer)
            if (k.explanation.isNotBlank() && k.explanation != k.answer) {
                sb.append("\n\n💡 **বিশ্লেষণ:**\n${k.explanation}")
            }
            if (k.reference.isNotBlank()) {
                sb.append("\n\n📚 **সূত্র:** ${k.reference}")
            }
            return sb.toString()
        }

        val sb = StringBuilder()
        sb.append("🕉️ **${k.title}**\n\n")
        
        if (k.answer.isNotBlank()) {
            sb.append("${k.answer}\n\n")
        }
        if (k.sanskritText.isNotBlank()) {
            sb.append("📜 **মূল সংস্কৃত শ্লোক / মন্ত্র:**\n${k.sanskritText}\n\n")
        }
        if (k.transliteration.isNotBlank()) {
            sb.append("🔤 **IAST লিপ্যন্তর:**\n*${k.transliteration}*\n\n")
        }
        if (k.banglaMeaning.isNotBlank() && k.banglaMeaning != k.answer) {
            sb.append("📖 **বাংলা অর্থ:**\n${k.banglaMeaning}\n\n")
        }
        if (k.englishMeaning.isNotBlank()) {
            sb.append("🌐 **English Translation:**\n${k.englishMeaning}\n\n")
        }
        if (k.explanation.isNotBlank()) {
            sb.append("💡 **তাত্ত্বিক ব্যাখ্যা ও মাহাত্ম্য:**\n${k.explanation}\n\n")
        }
        if (k.scripture.isNotBlank() || k.reference.isNotBlank()) {
            sb.append("🏛️ **প্রামাণিক শাস্ত্রসূত্র:** ${k.scripture} (${k.reference}) [${k.sourceType}]")
        }
        return sb.toString().trim()
    }

    private fun getFallbackResponse(language: String, query: String): String {
        return if (language.contains("Bengali")) {
            "এই বিষয়টি সম্পর্কে আমার যাচাই করা জ্ঞানে পর্যাপ্ত তথ্য নেই। আপনি চাইলে আমাকে তথ্যটি শেখাতে পারেন।"
        } else {
            "I do not have sufficient verified information in my knowledge base regarding this topic. You are welcome to teach me through the Admin Knowledge Center."
        }
    }

    private fun createKnowledgeCandidateFromAiAnswer(
        query: String,
        answer: String,
        intent: String,
        detectedLanguage: String
    ): KnowledgeEntity {
        val cleanTitle = query.take(60).replace("\n", " ").trim()
        val category = when (intent) {
            "MANTRA_INQUIRY", "MANTRA_TEXT" -> "Mantras"
            "SCRIPTURE_EXEGESIS" -> "Bhagavad Gita"
            "PHILOSOPHY_QUERY" -> "Philosophy"
            "PRACTICE_GUIDANCE", "RITUAL_CALENDAR" -> "Puja"
            "DEITY_THEOLOGY" -> "Deities"
            else -> "General Dharma"
        }

        return KnowledgeEntity(
            title = cleanTitle,
            category = category,
            subcategory = "AI Continuous Learning Candidate",
            language = detectedLanguage,
            sanskritText = "",
            transliteration = "",
            banglaMeaning = answer.take(500),
            englishMeaning = "",
            explanation = answer,
            scripture = "Researched Hermeneutics",
            chapter = "",
            verse = "",
            reference = "AI Researched Candidate (Pending Admin Approval)",
            source = "Gemini Flash Researched Synthesis",
            sourceType = "Traditional",
            verificationStatus = "Draft", // Strict: Must be Draft!
            confidenceScore = 0.85f,
            tags = "$category, AI Candidate, Continuous Learning",
            createdBy = "VedaNova AI Autonomous Candidate Engine",
            updatedBy = "Pending Admin Review"
        )
    }

    private fun isCreatorInquiry(raw: String, norm: String, resolved: String): Boolean {
        val q = "$raw $norm $resolved".lowercase(Locale.ROOT)
        return q.contains("কে বানিয়েছে") || q.contains("কে তৈরি করেছে") || q.contains("কে বানিয়েছে") ||
                q.contains("কে বানাইছে") || q.contains("creator কে") || q.contains("নির্মাতা কে") ||
                q.contains("বানিয়েছে কে") || q.contains("বানিয়েছে কে") || q.contains("তৈরি করেছে কে") ||
                q.contains("who created you") || q.contains("who made you") || q.contains("who is your creator") ||
                q.contains("who built you") || q.contains("who developed you") || q.contains("your creator") ||
                q.contains("who created dharma ai") || q.contains("creator of dharma ai") ||
                q.contains("মিলন চন্দ্র") || q.contains("milon chandra")
    }

    private fun isIdentityInquiry(raw: String, norm: String): Boolean {
        val q = "$raw $norm".lowercase(Locale.ROOT)
        return q.contains("তুমি কে") || q.contains("তোমার নাম কি") || q.contains("তোমার নাম কী") ||
                q.contains("তোমার পরিচয়") || q.contains("who are you") || q.contains("what is your name") ||
                q == "who are you?" || q == "who are you"
    }

    private fun isSimpleGreeting(norm: String): Boolean {
        val q = norm.lowercase(Locale.ROOT).trim()
        return q in listOf("হাই", "হ্যালো", "নমস্কার", "প্রণাম", "hello", "hi", "namaste", "hey", "শুভ সকাল", "শুভ সন্ধ্যা", "শুভ রাত্রি", "ধন্যবাদ", "thanks", "thank you", "কেমন আছো", "কেমন আছেন", "how are you") ||
                q == "কেমন আছো?" || q == "কেমন আছেন?" || q == "how are you?"
    }

    private fun formatCreatorResponse(rawQuery: String, language: String, history: List<Pair<String, String>>): String {
        val q = rawQuery.lowercase(Locale.ROOT)
        val isEnglish = language.contains("English", ignoreCase = true) || q.contains("who") || q.contains("creator")
        val asksIdentityAlso = q.contains("তুমি কে") || q.contains("who are you") || q.contains("তোমার নাম")

        if (isEnglish) {
            return when {
                asksIdentityAlso -> "I am Dharma AI, created by Sri Milon Chandra."
                history.size > 2 -> "Sri Milon Chandra created me to assist with Sanatan Dharma and spiritual knowledge."
                else -> "I was created by Sri Milon Chandra."
            }
        } else {
            return when {
                asksIdentityAlso -> "আমি Dharma AI। আমাকে তৈরি করেছেন শ্রী মিলন চন্দ্র।"
                history.size > 2 -> "শ্রী মিলন চন্দ্র আমাকে তৈরি করেছেন সনাতন ধর্ম ও আধ্যাত্মিক জ্ঞানে সহায়তা করার জন্য।"
                else -> "আমাকে তৈরি করেছেন শ্রী মিলন চন্দ্র।"
            }
        }
    }

    private fun formatIdentityResponse(language: String): String {
        return if (language.contains("English", ignoreCase = true)) {
            "I am Dharma AI, created by Sri Milon Chandra. I am an AI companion dedicated to providing verified insights on Sanatan Dharma, Vedic philosophy, and spiritual wisdom."
        } else {
            "আমি Dharma AI। আমাকে তৈরি করেছেন শ্রী মিলন চন্দ্র। আমি সনাতন ধর্ম, বেদ, উপনিষদ, গীতা ও আধ্যাত্মিক দর্শনের প্রামাণিক জ্ঞান অর্জনে সহায়তা করার জন্য নিবেদিত।"
        }
    }

    private fun formatCasualGreetingResponse(query: String, language: String): String {
        val q = query.lowercase(Locale.ROOT)
        val isEnglish = language.contains("English", ignoreCase = true)

        if (isEnglish) {
            return when {
                q.contains("how are you") -> "I am doing well, thank you! 😊 How may I assist your spiritual journey or study of Sanatan Dharma today?"
                q.contains("thank") -> "You are most welcome! 🙏 Feel free to ask whenever you have further spiritual questions."
                q.contains("morning") -> "Good morning! 🙏 Wishing you a peaceful and auspicious day. How can I help you today?"
                q.contains("evening") -> "Good evening! 🙏 How may I assist your spiritual inquiry this evening?"
                q.contains("night") -> "Good night and peaceful blessings! 🙏 Feel free to reach out anytime."
                else -> "Namaste! 🙏 I am Dharma AI. How may I assist you with Sanatan Dharma and scriptural knowledge?"
            }
        } else {
            return when {
                q.contains("কেমন আছো") || q.contains("কেমন আছেন") -> "আমি ভালো আছি, ধন্যবাদ। 😊 আপনার সাথে কথা বলতে পেরে আনন্দিত। আপনি সনাতন ধর্ম বা শাস্ত্রীয় বিষয়ে কী জানতে চান?"
                q.contains("ধন্যবাদ") || q.contains("অনেক ধন্যবাদ") -> "আপনাকেও আন্তরিক ধন্যবাদ। 🙏 আপনার আর কোনো জিজ্ঞাসা থাকলে নির্দ্বিধায় বলুন।"
                q.contains("শুভ সকাল") -> "শুভ সকাল! 🙏 আপনার আজকের দিনটি মঙ্গলময় ও শান্তিপূর্ণ হোক। আপনাকে কীভাবে সাহায্য করতে পারি?"
                q.contains("শুভ সন্ধ্যা") -> "শুভ সন্ধ্যা! 🙏 আপনার দিনটি শুভ হোক। সনাতন ধর্ম বা আধ্যাত্মিক বিষয়ে কী জানতে আগ্রহী?"
                q.contains("শুভ রাত্রি") -> "শুভ রাত্রি! 🙏 আপনার উপর ঈশ্বরের কৃপা বর্ষিত হোক। যেকোনো সময় আবার কথা বলতে পারেন।"
                else -> "নমস্কার! 🙏 আমি Dharma AI। সনাতন ধর্ম, বেদ, উপনিষদ, গীতা বা আধ্যাত্মিক কোনো বিষয়ে আপনাকে কীভাবে সাহায্য করতে পারি?"
            }
        }
    }
}
