package com.example.data.dao

import androidx.room.Dao
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import androidx.room.Delete
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface KnowledgeDao {
    @Query("SELECT * FROM knowledge_items ORDER BY updatedDate DESC")
    fun getAllKnowledge(): Flow<List<KnowledgeEntity>>

    @Query("SELECT * FROM knowledge_items WHERE verificationStatus = 'PUBLISHED' OR verificationStatus = 'Published' ORDER BY updatedDate DESC")
    fun getPublishedKnowledge(): Flow<List<KnowledgeEntity>>

    @Query("SELECT * FROM knowledge_items WHERE verificationStatus = 'CANDIDATE' OR verificationStatus = 'Pending Review' OR verificationStatus = 'Draft' OR verificationStatus = 'PENDING' ORDER BY updatedDate DESC")
    fun getCandidateKnowledge(): Flow<List<KnowledgeEntity>>

    @Query("SELECT * FROM knowledge_items WHERE category = :category ORDER BY updatedDate DESC")
    fun getKnowledgeByCategory(category: String): Flow<List<KnowledgeEntity>>

    @Query("SELECT * FROM knowledge_items WHERE verificationStatus = :status ORDER BY updatedDate DESC")
    fun getKnowledgeByStatus(status: String): Flow<List<KnowledgeEntity>>

    @Query("""
        SELECT * FROM knowledge_items 
        WHERE title LIKE '%' || :query || '%' 
           OR question LIKE '%' || :query || '%'
           OR answer LIKE '%' || :query || '%'
           OR banglaMeaning LIKE '%' || :query || '%' 
           OR englishMeaning LIKE '%' || :query || '%' 
           OR sanskritText LIKE '%' || :query || '%'
           OR transliteration LIKE '%' || :query || '%'
           OR tags LIKE '%' || :query || '%'
           OR scripture LIKE '%' || :query || '%'
        ORDER BY updatedDate DESC
    """)
    fun searchKnowledge(query: String): Flow<List<KnowledgeEntity>>

    @Query("""
        SELECT * FROM knowledge_items 
        WHERE (verificationStatus = 'PUBLISHED' OR verificationStatus = 'Published') AND (
           title LIKE '%' || :query || '%' 
           OR question LIKE '%' || :query || '%'
           OR answer LIKE '%' || :query || '%'
           OR banglaMeaning LIKE '%' || :query || '%' 
           OR englishMeaning LIKE '%' || :query || '%' 
           OR sanskritText LIKE '%' || :query || '%'
           OR transliteration LIKE '%' || :query || '%'
           OR tags LIKE '%' || :query || '%'
           OR scripture LIKE '%' || :query || '%'
        )
        LIMIT 10
    """)
    suspend fun findMatchingPublishedKnowledge(query: String): List<KnowledgeEntity>

    @Query("SELECT * FROM knowledge_items WHERE id = :id")
    suspend fun getKnowledgeById(id: Long): KnowledgeEntity?

    @Query("SELECT * FROM knowledge_items WHERE (verificationStatus = 'PUBLISHED' OR verificationStatus = 'Published')")
    suspend fun getAllPublishedDirect(): List<KnowledgeEntity>

    @Query("SELECT COUNT(*) FROM knowledge_items")
    fun getKnowledgeCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM knowledge_items")
    suspend fun getKnowledgeCountDirect(): Int

    @Query("UPDATE knowledge_items SET usageCount = usageCount + 1, lastUsedDate = :timestamp WHERE id = :id")
    suspend fun incrementUsage(id: Long, timestamp: Long = System.currentTimeMillis())

    @Query("UPDATE knowledge_items SET successCount = successCount + 1 WHERE id = :id")
    suspend fun incrementSuccess(id: Long)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertKnowledge(item: KnowledgeEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllKnowledge(items: List<KnowledgeEntity>)

    @Update
    suspend fun updateKnowledge(item: KnowledgeEntity)

    @Delete
    suspend fun deleteKnowledge(item: KnowledgeEntity)

    @Query("DELETE FROM knowledge_items WHERE id = :id")
    suspend fun deleteKnowledgeById(id: Long)

    @Query("DELETE FROM knowledge_items")
    suspend fun deleteAllKnowledge()
}

@Dao
interface UnknownKnowledgeDao {
    @Query("SELECT * FROM unknown_knowledge_queue ORDER BY frequency DESC, createdAt DESC")
    fun getAllUnknown(): Flow<List<UnknownKnowledgeEntity>>

    @Query("SELECT * FROM unknown_knowledge_queue WHERE status = 'PENDING' ORDER BY frequency DESC, createdAt DESC")
    fun getPendingUnknown(): Flow<List<UnknownKnowledgeEntity>>

    @Query("SELECT COUNT(*) FROM unknown_knowledge_queue WHERE status = 'PENDING'")
    fun getPendingCount(): Flow<Int>

    @Query("SELECT * FROM unknown_knowledge_queue WHERE userQuestion = :question LIMIT 1")
    suspend fun findByQuestion(question: String): UnknownKnowledgeEntity?

    @Query("SELECT * FROM unknown_knowledge_queue WHERE id = :id")
    suspend fun getById(id: Long): UnknownKnowledgeEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUnknown(item: UnknownKnowledgeEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllUnknown(items: List<UnknownKnowledgeEntity>)

    @Update
    suspend fun updateUnknown(item: UnknownKnowledgeEntity)

    @Query("DELETE FROM unknown_knowledge_queue WHERE id = :id")
    suspend fun deleteUnknownById(id: Long)

    @Query("DELETE FROM unknown_knowledge_queue")
    suspend fun deleteAllUnknown()
}

@Dao
interface KnowledgeVersionDao {
    @Query("SELECT * FROM knowledge_versions WHERE knowledgeId = :knowledgeId ORDER BY versionNumber DESC")
    fun getVersionsForKnowledge(knowledgeId: Long): Flow<List<KnowledgeVersionEntity>>

    @Query("SELECT * FROM knowledge_versions ORDER BY timestamp DESC")
    fun getAllVersions(): Flow<List<KnowledgeVersionEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVersion(item: KnowledgeVersionEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllVersions(items: List<KnowledgeVersionEntity>)
}

@Dao
interface KnowledgeUsageLogDao {
    @Query("SELECT * FROM knowledge_usage_logs WHERE knowledgeId = :knowledgeId ORDER BY timestamp DESC")
    fun getLogsForKnowledge(knowledgeId: Long): Flow<List<KnowledgeUsageLogEntity>>

    @Query("SELECT * FROM knowledge_usage_logs ORDER BY timestamp DESC LIMIT 100")
    fun getAllUsageLogs(): Flow<List<KnowledgeUsageLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUsageLog(item: KnowledgeUsageLogEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllUsageLogs(items: List<KnowledgeUsageLogEntity>)
}

@Dao
interface ApiKeyDao {
    @Query("SELECT * FROM api_keys ORDER BY createdAt DESC")
    fun getAllApiKeys(): Flow<List<ApiKeyEntity>>

    @Query("SELECT * FROM api_keys WHERE status = 'Active' ORDER BY createdAt DESC")
    fun getActiveApiKeys(): Flow<List<ApiKeyEntity>>

    @Query("SELECT * FROM api_keys WHERE apiKey = :key LIMIT 1")
    suspend fun getApiKeyByValue(key: String): ApiKeyEntity?

    @Query("SELECT * FROM api_keys WHERE id = :id")
    suspend fun getApiKeyById(id: Long): ApiKeyEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertApiKey(item: ApiKeyEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllApiKeys(items: List<ApiKeyEntity>)

    @Update
    suspend fun updateApiKey(item: ApiKeyEntity)

    @Delete
    suspend fun deleteApiKey(item: ApiKeyEntity)

    @Query("UPDATE api_keys SET requestCount = requestCount + 1, lastUsed = :timestamp WHERE id = :id")
    suspend fun incrementRequestCount(id: Long, timestamp: Long)

    @Query("UPDATE api_keys SET errorCount = errorCount + 1 WHERE id = :id")
    suspend fun incrementErrorCount(id: Long)
}

@Dao
interface ApiLogDao {
    @Query("SELECT * FROM api_logs ORDER BY timestamp DESC LIMIT 200")
    fun getRecentLogs(): Flow<List<ApiLogEntity>>

    @Query("SELECT COUNT(*) FROM api_logs")
    fun getTotalLogsCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM api_logs WHERE statusCode >= 400")
    fun getFailedLogsCount(): Flow<Int>

    @Query("SELECT AVG(responseTimeMs) FROM api_logs")
    fun getAverageResponseTime(): Flow<Double?>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertLog(log: ApiLogEntity): Long

    @Query("DELETE FROM api_logs")
    suspend fun clearLogs()
}

@Dao
interface IssueDao {
    @Query("SELECT * FROM issue_records ORDER BY detectedDate DESC")
    fun getAllIssues(): Flow<List<IssueEntity>>

    @Query("SELECT * FROM issue_records WHERE status = :status ORDER BY detectedDate DESC")
    fun getIssuesByStatus(status: String): Flow<List<IssueEntity>>

    @Query("SELECT COUNT(*) FROM issue_records WHERE status != 'Closed'")
    fun getPendingIssuesCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertIssue(issue: IssueEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllIssues(issues: List<IssueEntity>)

    @Update
    suspend fun updateIssue(issue: IssueEntity)

    @Delete
    suspend fun deleteIssue(issue: IssueEntity)
}

@Dao
interface ReportDao {
    @Query("SELECT * FROM user_reports ORDER BY createdAt DESC")
    fun getAllReports(): Flow<List<ReportEntity>>

    @Query("SELECT * FROM user_reports WHERE status = 'Pending' ORDER BY createdAt DESC")
    fun getPendingReports(): Flow<List<ReportEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertReport(report: ReportEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllReports(reports: List<ReportEntity>)

    @Update
    suspend fun updateReport(report: ReportEntity)

    @Delete
    suspend fun deleteReport(report: ReportEntity)
}

@Dao
interface AuditLogDao {
    @Query("SELECT * FROM audit_logs ORDER BY timestamp DESC LIMIT 300")
    fun getRecentAuditLogs(): Flow<List<AuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: AuditLogEntity): Long

    @Query("DELETE FROM audit_logs")
    suspend fun clearAuditLogs()
}

@Dao
interface SystemLogDao {
    @Query("SELECT * FROM system_logs ORDER BY timestamp DESC LIMIT 300")
    fun getRecentSystemLogs(): Flow<List<SystemLogEntity>>

    @Query("SELECT * FROM system_logs WHERE category = :category ORDER BY timestamp DESC LIMIT 100")
    fun getSystemLogsByCategory(category: String): Flow<List<SystemLogEntity>>

    @Query("SELECT * FROM system_logs WHERE level = :level ORDER BY timestamp DESC LIMIT 100")
    fun getSystemLogsByLevel(level: String): Flow<List<SystemLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSystemLog(log: SystemLogEntity): Long

    @Query("DELETE FROM system_logs")
    suspend fun clearSystemLogs()
}

@Dao
interface AdminUserDao {
    @Query("SELECT * FROM admin_users ORDER BY id ASC")
    fun getAllUsers(): Flow<List<AdminUserEntity>>

    @Query("SELECT * FROM admin_users WHERE username = :username LIMIT 1")
    suspend fun getUserByUsername(username: String): AdminUserEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertUser(user: AdminUserEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllUsers(users: List<AdminUserEntity>)

    @Update
    suspend fun updateUser(user: AdminUserEntity)

    @Delete
    suspend fun deleteUser(user: AdminUserEntity)
}

@Dao
interface SystemSettingDao {
    @Query("SELECT * FROM system_settings")
    fun getAllSettings(): Flow<List<SystemSettingEntity>>

    @Query("SELECT * FROM system_settings WHERE `key` = :key LIMIT 1")
    suspend fun getSetting(key: String): SystemSettingEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertSetting(setting: SystemSettingEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllSettings(settings: List<SystemSettingEntity>)
}

@Dao
interface BackupDao {
    @Query("SELECT * FROM backups ORDER BY createdAt DESC")
    fun getAllBackups(): Flow<List<BackupEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertBackup(backup: BackupEntity): Long

    @Delete
    suspend fun deleteBackup(backup: BackupEntity)
}

@Dao
interface CapabilityProposalDao {
    @Query("SELECT * FROM capability_proposals ORDER BY createdAt DESC")
    fun getAllProposals(): Flow<List<CapabilityProposalEntity>>

    @Query("SELECT * FROM capability_proposals WHERE status = :status ORDER BY createdAt DESC")
    fun getProposalsByStatus(status: String): Flow<List<CapabilityProposalEntity>>

    @Query("SELECT * FROM capability_proposals WHERE id = :id LIMIT 1")
    suspend fun getProposalById(id: Long): CapabilityProposalEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertProposal(proposal: CapabilityProposalEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllProposals(proposals: List<CapabilityProposalEntity>)

    @Update
    suspend fun updateProposal(proposal: CapabilityProposalEntity)

    @Delete
    suspend fun deleteProposal(proposal: CapabilityProposalEntity)
}

@Dao
interface DailyJobLogDao {
    @Query("SELECT * FROM daily_job_logs ORDER BY timestamp DESC LIMIT 50")
    fun getRecentJobLogs(): Flow<List<DailyJobLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertJobLog(log: DailyJobLogEntity): Long

    @Query("SELECT * FROM daily_job_logs ORDER BY timestamp DESC LIMIT 1")
    suspend fun getLatestJobLog(): DailyJobLogEntity?
}

@Dao
interface ExternalAppDao {
    @Query("SELECT * FROM external_apps ORDER BY lastActiveTimestamp DESC")
    fun getAllApps(): Flow<List<ExternalAppEntity>>

    @Query("SELECT * FROM external_apps WHERE appId = :appId LIMIT 1")
    suspend fun getAppById(appId: String): ExternalAppEntity?

    @Query("SELECT * FROM external_apps WHERE apiKey = :apiKey LIMIT 1")
    suspend fun getAppByApiKey(apiKey: String): ExternalAppEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertApp(app: ExternalAppEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllApps(apps: List<ExternalAppEntity>)

    @Update
    suspend fun updateApp(app: ExternalAppEntity)

    @Delete
    suspend fun deleteApp(app: ExternalAppEntity)
}

@Dao
interface CrashReportDao {
    @Query("SELECT * FROM crash_reports ORDER BY timestamp DESC")
    fun getAllCrashReports(): Flow<List<CrashReportEntity>>

    @Query("SELECT * FROM crash_reports ORDER BY timestamp DESC LIMIT 10")
    fun getRecentCrashReports(): Flow<List<CrashReportEntity>>

    @Query("SELECT COUNT(*) FROM crash_reports")
    fun getCrashCount(): Flow<Int>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertCrashReport(report: CrashReportEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllCrashReports(reports: List<CrashReportEntity>)

    @Query("DELETE FROM crash_reports WHERE id = :id")
    suspend fun deleteCrashReportById(id: Long)

    @Query("DELETE FROM crash_reports")
    suspend fun deleteAllCrashReports()
}

@Dao
interface FunctionActivityLogDao {
    @Query("SELECT * FROM function_activity_logs ORDER BY timestamp DESC")
    fun getAllActivityLogs(): Flow<List<FunctionActivityLogEntity>>

    @Query("SELECT * FROM function_activity_logs ORDER BY timestamp DESC LIMIT 50")
    fun getRecentActivityLogs(): Flow<List<FunctionActivityLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertActivityLog(log: FunctionActivityLogEntity): Long

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllActivityLogs(logs: List<FunctionActivityLogEntity>)

    @Query("DELETE FROM function_activity_logs")
    suspend fun deleteAllLogs()
}

@Dao
interface DevelopmentTaskDao {
    @Query("SELECT * FROM development_tasks ORDER BY createdAt DESC")
    fun getAllTasks(): Flow<List<DevelopmentTaskEntity>>

    @Query("SELECT * FROM development_tasks WHERE status = :status ORDER BY createdAt DESC")
    fun getTasksByStatus(status: String): Flow<List<DevelopmentTaskEntity>>

    @Query("SELECT * FROM development_tasks WHERE status = 'WAITING_FOR_APPROVAL' ORDER BY createdAt DESC")
    fun getPendingApprovalTasks(): Flow<List<DevelopmentTaskEntity>>

    @Query("SELECT COUNT(*) FROM development_tasks WHERE status = 'WAITING_FOR_APPROVAL'")
    fun getPendingApprovalCount(): Flow<Int>

    @Query("SELECT * FROM development_tasks WHERE id = :id")
    suspend fun getTaskById(id: Long): DevelopmentTaskEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTask(task: DevelopmentTaskEntity): Long

    @Update
    suspend fun updateTask(task: DevelopmentTaskEntity)

    @Delete
    suspend fun deleteTask(task: DevelopmentTaskEntity)

    @Query("UPDATE development_tasks SET status = :status, currentStep = :currentStep, completedAt = :completedAt WHERE id = :id")
    suspend fun updateTaskStatus(id: Long, status: String, currentStep: String, completedAt: Long? = null)
}


