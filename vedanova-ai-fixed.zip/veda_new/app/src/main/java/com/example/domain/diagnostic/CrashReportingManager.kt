package com.example.domain.diagnostic

import java.util.*
import java.util.*
import java.util.Locale
import java.util.Date
import java.text.SimpleDateFormat

object CrashReportingManager {
    private const val TAG = "CrashReportingManager"
    private var database: VedaNovaDatabase? = null
    private var isInitialized = false

    @Volatile
    var currentScreen: String = "DASHBOARD"
        private set

    @Volatile
    var previousScreen: String = "DASHBOARD"
        private set

    @Volatile
    var lastAction: String = "App Launch"
        private set

    fun initialize(context: Context, db: VedaNovaDatabase) {
        if (isInitialized) return
        database = db
        isInitialized = true

        val defaultHandler = Thread.getDefaultUncaughtExceptionHandler()

        Thread.setDefaultUncaughtExceptionHandler { thread, throwable ->
            try {
                val sw = StringWriter()
                val pw = PrintWriter(sw)
                throwable.printStackTrace(pw)
                val stackTraceString = sw.toString()

                val timeFormat = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.getDefault()).format(Date())
                val randomSuffix = (1000..9999).random()
                val crashId = "CRASH-$timeFormat-$randomSuffix"

                val crashReport = CrashReportEntity(
                    crashId = crashId,
                    screen = currentScreen,
                    navigationRoute = currentScreen,
                    timestamp = System.currentTimeMillis(),
                    exceptionType = throwable.javaClass.simpleName.ifEmpty { "FatalException" },
                    errorMessage = throwable.message ?: "Uncaught Exception in thread ${thread.name}",
                    stackTrace = stackTraceString,
                    lastAction = lastAction,
                    previousRoute = previousScreen,
                    currentRoute = currentScreen,
                    userRole = "Admin",
                    appVersion = "v5.1.0-prod"
                )

                Log.e(TAG, "FATAL CRASH INTERCEPTED: $crashId - ${throwable.message}")
                
                // Write synchronously / launch IO
                CoroutineScope(Dispatchers.IO).launch {
                    try {
                        db.crashReportDao().insertCrashReport(crashReport)
                    } catch (e: Exception) {
                        Log.e(TAG, "Failed to save crash to Room DB", e)
                    }
                }
            } catch (e: Exception) {
                Log.e(TAG, "Error in crash handler", e)
            } finally {
                defaultHandler?.uncaughtException(thread, throwable)
            }
        }
    }

    fun updateNavigationContext(current: String, previous: String, action: String = "Navigate to $current") {
        this.previousScreen = previous
        this.currentScreen = current
        this.lastAction = action
    }

    fun recordException(
        screen: String = currentScreen,
        route: String = currentScreen,
        throwable: Throwable,
        action: String = lastAction,
        userRole: String = "Admin"
    ) {
        val sw = StringWriter()
        val pw = PrintWriter(sw)
        throwable.printStackTrace(pw)
        val stackTraceString = sw.toString()

        val timeFormat = SimpleDateFormat("yyyyMMdd-HHmmss", Locale.getDefault()).format(Date())
        val randomSuffix = (1000..9999).random()
        val crashId = "ERR-$timeFormat-$randomSuffix"

        val report = CrashReportEntity(
            crashId = crashId,
            screen = screen,
            navigationRoute = route,
            timestamp = System.currentTimeMillis(),
            exceptionType = throwable.javaClass.simpleName.ifEmpty { "HandledException" },
            errorMessage = throwable.message ?: "Handled application exception",
            stackTrace = stackTraceString,
            lastAction = action,
            previousRoute = previousScreen,
            currentRoute = screen,
            userRole = userRole,
            appVersion = "v5.1.0-prod"
        )

        database?.let { db ->
            CoroutineScope(Dispatchers.IO).launch {
                try {
                    db.crashReportDao().insertCrashReport(report)
                } catch (e: Exception) {
                    Log.e(TAG, "Failed to record handled exception", e)
                }
            }
        }
    }
}
