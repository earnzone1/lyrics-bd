# হিন্দু ধর্ম AI 🕉️

বাংলা ভাষায় হিন্দু ধর্মীয় AI সফটওয়্যার।

## ফিচার
- 🤖 AI ধর্মীয় সহায়তা (৬টি ক্যাটাগরি)
- 📿 পবিত্র মন্ত্র সংগ্রহ
- 🎉 হিন্দু উৎসব তথ্য
- 📅 পঞ্চাঙ্গ ও শুভ সময়
- 🙏 ব্যক্তিগত প্রার্থনা
- 📖 ভগবদ্গীতা জ্ঞান

## Tech Stack
- Android WebView
- VedaNova AI API
- HTML / CSS / JavaScript

## Package
`com.hindudharma.ai`

## Build
Android Studio বা GitHub Actions দিয়ে APK বানান।

---
*ঈশ্বরের কৃপায় সকলের কল্যাণ হোক 🙏*
