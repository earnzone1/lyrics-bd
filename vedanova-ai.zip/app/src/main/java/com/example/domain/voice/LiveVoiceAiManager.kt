package com.example.domain.voice

import android.content.Context
import android.content.Intent
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.speech.tts.UtteranceProgressListener
import android.util.Log
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.launch
import java.util.Locale
import java.util.UUID

enum class LiveVoiceState {
    IDLE,
    LISTENING,
    THINKING,
    SPEAKING,
    MUTED,
    ERROR
}

data class LiveVoiceSettings(
    val isVoiceEnabled: Boolean = true,
    val language: String = "BENGALI", // "BENGALI", "ENGLISH", "SANSKRIT"
    val speechSpeed: Float = 1.0f, // 0.8f, 1.0f, 1.25f
    val autoSpeakResponse: Boolean = true,
    val isLiveContinuousMode: Boolean = false
)

class LiveVoiceAiManager(private val context: Context) : TextToSpeech.OnInitListener {

    private val TAG = "LiveVoiceAiManager"
    private var tts: TextToSpeech? = null
    private var speechRecognizer: SpeechRecognizer? = null
    private val mainHandler = Handler(Looper.getMainLooper())

    private val _voiceState = MutableStateFlow(LiveVoiceState.IDLE)
    val voiceState: StateFlow<LiveVoiceState> = _voiceState.asStateFlow()

    private val _liveTranscript = MutableStateFlow("")
    val liveTranscript: StateFlow<String> = _liveTranscript.asStateFlow()

    private val _lastAiSpeech = MutableStateFlow("")
    val lastAiSpeech: StateFlow<String> = _lastAiSpeech.asStateFlow()

    private val _voiceAmplitude = MutableStateFlow(0f)
    val voiceAmplitude: StateFlow<Float> = _voiceAmplitude.asStateFlow()

    private val _voiceError = MutableStateFlow<String?>(null)
    val voiceError: StateFlow<String?> = _voiceError.asStateFlow()

    private val _settings = MutableStateFlow(LiveVoiceSettings())
    val settings: StateFlow<LiveVoiceSettings> = _settings.asStateFlow()

    private val _isCallOverlayActive = MutableStateFlow(false)
    val isCallOverlayActive: StateFlow<Boolean> = _isCallOverlayActive.asStateFlow()

    private val _currentlySpeakingText = MutableStateFlow<String?>(null)
    val currentlySpeakingText: StateFlow<String?> = _currentlySpeakingText.asStateFlow()

    private var onSpeechResultCallback: ((String) -> Unit)? = null
    private var isTtsReady = false

    init {
        try {
            tts = TextToSpeech(context, this)
        } catch (e: Exception) {
            Log.e(TAG, "Failed to initialize TTS", e)
            _voiceError.value = "TTS Error: ${e.message}"
        }
    }

    override fun onInit(status: Int) {
        if (status == TextToSpeech.SUCCESS) {
            isTtsReady = true
            applyLanguageSettings(_settings.value.language)
            tts?.setOnUtteranceProgressListener(object : UtteranceProgressListener() {
                override fun onStart(utteranceId: String?) {
                    _voiceState.value = LiveVoiceState.SPEAKING
                }

                override fun onDone(utteranceId: String?) {
                    mainHandler.post {
                        _currentlySpeakingText.value = null
                        if (_settings.value.isLiveContinuousMode && _isCallOverlayActive.value) {
                            // Turn-by-turn continuation in Call Mode
                            startListeningInternal()
                        } else {
                            _voiceState.value = LiveVoiceState.IDLE
                        }
                    }
                }

                override fun onError(utteranceId: String?) {
                    mainHandler.post {
                        _currentlySpeakingText.value = null
                        _voiceState.value = LiveVoiceState.IDLE
                    }
                }
            })
        } else {
            isTtsReady = false
            _voiceError.value = "TTS Initialization failed (Code: $status)"
            Log.e(TAG, "TTS Initialization failed with status $status")
        }
    }

    fun updateSettings(newSettings: LiveVoiceSettings) {
        _settings.value = newSettings
        applyLanguageSettings(newSettings.language)
        tts?.setSpeechRate(newSettings.speechSpeed)
    }

    private fun applyLanguageSettings(lang: String) {
        val locale = when (lang.uppercase(Locale.ROOT)) {
            "BENGALI", "BN" -> Locale("bn", "BD")
            "SANSKRIT", "SA" -> Locale("sa", "IN")
            else -> Locale.ENGLISH
        }
        val result = tts?.setLanguage(locale)
        if (result == TextToSpeech.LANG_MISSING_DATA || result == TextToSpeech.LANG_NOT_SUPPORTED) {
            // Fallback to English / default
            tts?.setLanguage(Locale.ENGLISH)
        }
    }

    /**
     * Start Call-Like Live Voice Session
     */
    fun startLiveCallSession(onQueryCaptured: (String) -> Unit) {
        _isCallOverlayActive.value = true
        _voiceError.value = null
        this.onSpeechResultCallback = onQueryCaptured
        _settings.value = _settings.value.copy(isLiveContinuousMode = true)
        startListeningInternal()
    }

    /**
     * End Live Call Session
     */
    fun endLiveCallSession() {
        stopSpeaking()
        stopListening()
        _isCallOverlayActive.value = false
        _voiceState.value = LiveVoiceState.IDLE
        _settings.value = _settings.value.copy(isLiveContinuousMode = false)
    }

    /**
     * Single Voice Input button trigger
     */
    fun triggerSingleVoiceInput(onQueryCaptured: (String) -> Unit) {
        // Step 18: Voice Interruption — Stop TTS if already speaking
        if (_voiceState.value == LiveVoiceState.SPEAKING) {
            stopSpeaking()
        }

        this.onSpeechResultCallback = onQueryCaptured
        startListeningInternal()
    }

    private fun startListeningInternal() {
        mainHandler.post {
            try {
                if (!SpeechRecognizer.isRecognitionAvailable(context)) {
                    _voiceError.value = "VOICE_UNAVAILABLE: Speech recognition service not available on this device"
                    _voiceState.value = LiveVoiceState.ERROR
                    return@post
                }

                speechRecognizer?.destroy()
                speechRecognizer = SpeechRecognizer.createSpeechRecognizer(context).apply {
                    setRecognitionListener(createRecognitionListener())
                }

                val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    val langTag = when (_settings.value.language.uppercase(Locale.ROOT)) {
                        "BENGALI", "BN" -> "bn-BD"
                        "SANSKRIT", "SA" -> "sa-IN"
                        else -> "en-US"
                    }
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE, langTag)
                    putExtra(RecognizerIntent.EXTRA_LANGUAGE_PREFERENCE, langTag)
                    putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, context.packageName)
                    putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, true)
                    putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
                }

                _voiceState.value = LiveVoiceState.LISTENING
                _voiceError.value = null
                _liveTranscript.value = "শুনছি... কথা বলুন (Listening...)"
                speechRecognizer?.startListening(intent)
            } catch (e: SecurityException) {
                _voiceError.value = "VOICE_PERMISSION_REQUIRED: Microphone permission is needed for voice chat"
                _voiceState.value = LiveVoiceState.ERROR
            } catch (e: Exception) {
                _voiceError.value = "VOICE_ERROR: ${e.message}"
                _voiceState.value = LiveVoiceState.ERROR
            }
        }
    }

    private fun createRecognitionListener(): RecognitionListener {
        return object : RecognitionListener {
            override fun onReadyForSpeech(params: Bundle?) {
                _voiceState.value = LiveVoiceState.LISTENING
                _voiceAmplitude.value = 0.2f
            }

            override fun onBeginningOfSpeech() {
                _voiceAmplitude.value = 0.6f
            }

            override fun onRmsChanged(rmsdB: Float) {
                // Voice Activity Detection (VAD) visualizer amplitude normalized to 0.0 - 1.0
                val normalized = ((rmsdB + 2f) / 12f).coerceIn(0.1f, 1.0f)
                _voiceAmplitude.value = normalized
            }

            override fun onBufferReceived(buffer: ByteArray?) {}

            override fun onEndOfSpeech() {
                _voiceState.value = LiveVoiceState.THINKING
                _voiceAmplitude.value = 0f
            }

            override fun onError(error: Int) {
                val errorMsg = when (error) {
                    SpeechRecognizer.ERROR_AUDIO -> "Audio recording error"
                    SpeechRecognizer.ERROR_CLIENT -> "Client side error"
                    SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> "VOICE_PERMISSION_REQUIRED"
                    SpeechRecognizer.ERROR_NETWORK, SpeechRecognizer.ERROR_NETWORK_TIMEOUT -> "NETWORK_UNAVAILABLE: Connection issue for voice processing"
                    SpeechRecognizer.ERROR_NO_MATCH -> "কোনো কথা শনাক্ত করা যায়নি (No speech detected)"
                    SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> "কথা শনাক্তের সময় শেষ হয়েছে"
                    else -> "Voice recognition code $error"
                }

                _voiceAmplitude.value = 0f
                if (error == SpeechRecognizer.ERROR_NO_MATCH || error == SpeechRecognizer.ERROR_SPEECH_TIMEOUT) {
                    if (_isCallOverlayActive.value) {
                        // Keep call open in listening mode
                        _voiceState.value = LiveVoiceState.IDLE
                    } else {
                        _voiceState.value = LiveVoiceState.IDLE
                    }
                } else {
                    _voiceError.value = errorMsg
                    _voiceState.value = LiveVoiceState.ERROR
                }
            }

            override fun onResults(results: Bundle?) {
                val matches = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                val recognizedText = matches?.firstOrNull()?.trim()

                if (!recognizedText.isNullOrBlank()) {
                    _liveTranscript.value = recognizedText
                    _voiceState.value = LiveVoiceState.THINKING
                    onSpeechResultCallback?.invoke(recognizedText)
                } else {
                    _voiceState.value = LiveVoiceState.IDLE
                }
            }

            override fun onPartialResults(partialResults: Bundle?) {
                val partial = partialResults?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)?.firstOrNull()
                if (!partial.isNullOrBlank()) {
                    _liveTranscript.value = partial
                }
            }

            override fun onEvent(eventType: Int, params: Bundle?) {}
        }
    }

    fun stopListening() {
        mainHandler.post {
            try {
                speechRecognizer?.stopListening()
                speechRecognizer?.cancel()
            } catch (e: Exception) {
                Log.e(TAG, "Error stopping SpeechRecognizer", e)
            }
        }
    }

    /**
     * Speak response with Interruption Support
     */
    fun speak(text: String, onCompleted: (() -> Unit)? = null) {
        if (!_settings.value.isVoiceEnabled || text.isBlank()) {
            return
        }
        if (!isTtsReady) {
            _voiceError.value = "TTS ইঞ্জিন প্রস্তুত হচ্ছে বা ডিভাইসে উপলব্ধ নয় (TTS not ready)"
            return
        }

        // Clean markdown formatting for clean spoken narration
        val cleanSpeechText = cleanTextForSpeech(text)
        _lastAiSpeech.value = cleanSpeechText
        _currentlySpeakingText.value = text
        _voiceState.value = LiveVoiceState.SPEAKING

        val utteranceId = "vn_voice_${UUID.randomUUID().toString().take(8)}"
        val params = Bundle().apply {
            putString(TextToSpeech.Engine.KEY_PARAM_UTTERANCE_ID, utteranceId)
        }

        tts?.speak(cleanSpeechText, TextToSpeech.QUEUE_FLUSH, params, utteranceId)
    }

    /**
     * Toggle play/stop for a given text snippet
     */
    fun toggleSpeak(text: String) {
        if (_voiceState.value == LiveVoiceState.SPEAKING && _currentlySpeakingText.value == text) {
            stopSpeaking()
        } else {
            speak(text)
        }
    }

    /**
     * Step 18: Voice Interruption (Barge-in)
     */
    fun interruptAndListen() {
        stopSpeaking()
        startListeningInternal()
    }

    fun stopSpeaking() {
        try {
            if (tts?.isSpeaking == true) {
                tts?.stop()
            }
        } catch (e: Exception) {
            Log.e(TAG, "Error stopping TTS", e)
        }
        _currentlySpeakingText.value = null
        if (_voiceState.value == LiveVoiceState.SPEAKING) {
            _voiceState.value = LiveVoiceState.IDLE
        }
    }

    fun toggleMute() {
        if (_voiceState.value == LiveVoiceState.MUTED) {
            _voiceState.value = LiveVoiceState.IDLE
            if (_isCallOverlayActive.value) {
                startListeningInternal()
            }
        } else {
            stopListening()
            stopSpeaking()
            _voiceState.value = LiveVoiceState.MUTED
        }
    }

    fun setAiThinking() {
        _voiceState.value = LiveVoiceState.THINKING
    }

    private fun cleanTextForSpeech(text: String): String {
        return text
            .replace(Regex("[#*`_~>\\[\\]()]"), " ")
            .replace("🕉️", "ওঁ")
            .replace("🙏", "নমস্কার")
            .replace("💡", "")
            .replace("📚", "")
            .replace("🏛️", "")
            .replace("📜", "")
            .replace("🔤", "")
            .replace("📖", "")
            .replace(Regex("\\s+"), " ")
            .trim()
    }

    fun release() {
        try {
            speechRecognizer?.destroy()
            tts?.stop()
            tts?.shutdown()
        } catch (e: Exception) {
            Log.e(TAG, "Error releasing voice resources", e)
        }
    }
}
