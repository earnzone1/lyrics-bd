package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.ScreenDestination
import com.example.ui.viewmodel.VedaNovaViewModel
import java.text.SimpleDateFormat
import java.util.*

@Composable
fun DashboardScreen(viewModel: VedaNovaViewModel) {
    val health by viewModel.healthStatus.collectAsStateWithLifecycle()
    val session by viewModel.currentSession.collectAsStateWithLifecycle()
    val knowledgeCount by viewModel.knowledgeCount.collectAsStateWithLifecycle()
    val apiKeys by viewModel.allApiKeys.collectAsStateWithLifecycle()
    val recentLogs by viewModel.recentApiLogs.collectAsStateWithLifecycle()
    val auditLogs by viewModel.recentAuditLogs.collectAsStateWithLifecycle()
    val pendingTasks by viewModel.pendingApprovalTasks.collectAsStateWithLifecycle()
    val allTasks by viewModel.allDevelopmentTasks.collectAsStateWithLifecycle()
    val totalRequests by viewModel.totalLogsCount.collectAsStateWithLifecycle()
    val pendingUnknown by viewModel.pendingUnknownCount.collectAsStateWithLifecycle()

    val totalReqs = totalRequests + apiKeys.sumOf { it.requestCount }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Welcome Banner & Role Badge
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "🕉️", style = MaterialTheme.typography.titleMedium)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "VedaNova AI Control Center",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "Authenticated as ${session.currentUser.fullName} (${session.currentUser.role})",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                            color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            StatusPill(text = "Gateway: v1.0 Active", color = StatusGreen)
                            StatusPill(text = "RBAC: Enforced", color = SaffronPrimary)
                        }
                    }
                }
            }
        }

        // System Health Matrix Cards
        item {
            SectionHeader(
                title = "System Health & Module Status",
                subtitle = "Diagnostic status of core AI & services"
            ) {
                TextButton(onClick = { viewModel.navigateTo(ScreenDestination.SYSTEM_HEALTH) }, contentPadding = PaddingValues(4.dp)) {
                    Text("Diagnostics →", color = SaffronPrimary, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
            }

            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        HealthBadge(status = health.backendStatus, label = "Core Backend")
                        HealthBadge(status = health.databaseStatus, label = "Room DB")
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        HealthBadge(status = health.aiProviderStatus, label = "AI Orchestrator")
                        HealthBadge(status = health.apiGatewayStatus, label = "API Gateway")
                    }
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween
                    ) {
                        HealthBadge(status = health.knowledgeEngineStatus, label = "Knowledge Base")
                        HealthBadge(status = health.verificationEngineStatus, label = "Verification")
                    }
                }
            }
        }

        // Metrics Grid (4 Top Stat Cards)
        item {
            SectionHeader(
                title = "Platform Metrics",
                subtitle = "Throughput, canonical nodes & workloads"
            )

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatCard(
                    title = "Total API Requests",
                    value = "$totalReqs",
                    subtitle = "Across all keys",
                    icon = Icons.Default.CloudQueue,
                    accentColor = SaffronPrimary,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.navigateTo(ScreenDestination.ANALYTICS) }
                )
                StatCard(
                    title = "Verified Knowledge",
                    value = "$knowledgeCount",
                    subtitle = "Canonical nodes",
                    icon = Icons.Default.AutoStories,
                    accentColor = VedicGold,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.navigateTo(ScreenDestination.KNOWLEDGE_CENTER) }
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatCard(
                    title = "Active API Clients",
                    value = "${apiKeys.count { it.status == "Active" }}",
                    subtitle = "${apiKeys.size} Total keys",
                    icon = Icons.Default.Key,
                    accentColor = StatusGreen,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.navigateTo(ScreenDestination.API_CENTER) }
                )
                StatCard(
                    title = "Project Dev Tasks",
                    value = "${allTasks.size}",
                    subtitle = if (pendingTasks.isNotEmpty()) "${pendingTasks.size} pending approval" else "All up-to-date",
                    icon = Icons.Default.Engineering,
                    accentColor = if (pendingTasks.isNotEmpty()) StatusYellow else StatusGreen,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.navigateTo(ScreenDestination.PROJECT_MONITOR) }
                )
            }
            Spacer(modifier = Modifier.height(8.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                StatCard(
                    title = "Unknown Queries Queue",
                    value = "$pendingUnknown",
                    subtitle = if (pendingUnknown > 0) "Awaiting Teach AI" else "All resolved",
                    icon = Icons.Default.HelpOutline,
                    accentColor = if (pendingUnknown > 0) AmberAlert else StatusGreen,
                    modifier = Modifier.weight(1f),
                    onClick = { 
                        viewModel.setTeachTab(1)
                        viewModel.navigateTo(ScreenDestination.TEACH_AI) 
                    }
                )
                StatCard(
                    title = "Knowledge Teacher",
                    value = "Phase 5",
                    subtitle = "Continuous Learning Active",
                    icon = Icons.Default.School,
                    accentColor = SaffronPrimary,
                    modifier = Modifier.weight(1f),
                    onClick = { viewModel.navigateTo(ScreenDestination.TEACH_AI) }
                )
            }
        }

        // Quick Actions Launcher
        item {
            SectionHeader(title = "Operational Actions")
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(6.dp)
            ) {
                OutlinedButton(
                    onClick = { viewModel.navigateTo(ScreenDestination.AI_TESTING_LAB) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Science, contentDescription = null, modifier = Modifier.size(14.dp), tint = SaffronPrimary)
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("AI Lab", style = MaterialTheme.typography.labelSmall)
                }

                OutlinedButton(
                    onClick = { viewModel.navigateTo(ScreenDestination.API_TESTING) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Terminal, contentDescription = null, modifier = Modifier.size(14.dp), tint = VedicGold)
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("Console", style = MaterialTheme.typography.labelSmall)
                }

                OutlinedButton(
                    onClick = { viewModel.navigateTo(ScreenDestination.TEACH_AI) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 6.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.AddCircleOutline, contentDescription = null, modifier = Modifier.size(14.dp), tint = StatusGreen)
                    Spacer(modifier = Modifier.width(3.dp))
                    Text("Teach AI", style = MaterialTheme.typography.labelSmall)
                }
            }
        }

        // Recent Activity Feed
        item {
            SectionHeader(
                title = "Recent Admin & API Activity",
                subtitle = "Real-time audit log of operations"
            ) {
                TextButton(onClick = { viewModel.navigateTo(ScreenDestination.AUDIT_LOGS) }, contentPadding = PaddingValues(4.dp)) {
                    Text("View Trail →", color = SaffronPrimary, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                }
            }
        }

        if (auditLogs.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        text = "No recent admin activity recorded.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(12.dp)
                    )
                }
            }
        } else {
            items(auditLogs.take(5)) { log ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(8.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(30.dp)
                                .clip(CircleShape)
                                .background(SaffronPrimary.copy(alpha = 0.12f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                imageVector = Icons.Default.History,
                                contentDescription = null,
                                tint = SaffronPrimary,
                                modifier = Modifier.size(16.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = log.action,
                                    style = MaterialTheme.typography.labelLarge,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                val timeFormat = SimpleDateFormat("HH:mm:ss", Locale.getDefault())
                                Text(
                                    text = timeFormat.format(Date(log.timestamp)),
                                    style = MaterialTheme.typography.labelSmall.copy(fontSize = 11.sp),
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = log.details,
                                style = MaterialTheme.typography.bodySmall.copy(fontSize = 12.sp),
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                StatusPill(text = log.adminUsername, color = StatusPurple)
                                StatusPill(text = log.targetType, color = VedicGold)
                            }
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(16.dp))
        }
    }
}
