package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.window.Dialog
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.CalendarAuditLogEntity
import com.example.data.model.CalendarDayEntity
import com.example.data.model.CalendarEventEntity
import com.example.data.model.CalendarVersionEntity
import com.example.domain.ai.CalendarRegion
import com.example.ui.theme.*
import com.example.ui.viewmodel.ScreenDestination
import com.example.ui.viewmodel.VedaNovaViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DailyDataEngineScreen(viewModel: VedaNovaViewModel) {
    val selectedRegion by viewModel.selectedDailyRegion.collectAsStateWithLifecycle()
    val dailyData by viewModel.dailyData.collectAsStateWithLifecycle()
    val isJobRunning by viewModel.isDailyJobRunning.collectAsStateWithLifecycle()
    val jobMessage by viewModel.dailyJobMessage.collectAsStateWithLifecycle()

    val calendarState by viewModel.calendarAdminState.collectAsStateWithLifecycle()
    val allDays by viewModel.allCalendarDays.collectAsStateWithLifecycle()
    val allEvents by viewModel.allCalendarEvents.collectAsStateWithLifecycle()
    val allVersions by viewModel.allCalendarVersions.collectAsStateWithLifecycle()
    val allAuditLogs by viewModel.allCalendarAuditLogs.collectAsStateWithLifecycle()
    val allClientCaches by viewModel.allClientCalendarCaches.collectAsStateWithLifecycle()
    val totalDaysCount by viewModel.totalCalendarDaysCount.collectAsStateWithLifecycle()
    val totalEventsCount by viewModel.totalCalendarEventsCount.collectAsStateWithLifecycle()
    val pendingDaysCount by viewModel.pendingVerificationDaysCount.collectAsStateWithLifecycle()
    val pendingEventsCount by viewModel.pendingVerificationEventsCount.collectAsStateWithLifecycle()

    var showPublishDialog by remember { mutableStateOf(false) }
    var rollbackTargetVersion by remember { mutableStateOf<CalendarVersionEntity?>(null) }

    // Dialog for Day Editing
    if (calendarState.isEditingDay && calendarState.editingDayDraft != null) {
        CalendarDayEditDialog(
            draft = calendarState.editingDayDraft!!,
            validationErrors = calendarState.validationErrors,
            onUpdate = { viewModel.updateDayDraft(it) },
            onAutoCompute = { date, region -> viewModel.autoComputeAstronomicalForDate(date, region) },
            onSave = { viewModel.saveDayDraft("admin") },
            onDismiss = { viewModel.cancelEditDay() }
        )
    }

    // Dialog for Event Editing
    if (calendarState.isEditingEvent && calendarState.editingEventDraft != null) {
        CalendarEventEditDialog(
            draft = calendarState.editingEventDraft!!,
            validationErrors = calendarState.validationErrors,
            onUpdate = { viewModel.updateEventDraft(it) },
            onSave = { viewModel.saveEventDraft("admin") },
            onDismiss = { viewModel.cancelEditEvent() }
        )
    }

    // Dialog for Publishing Snapshot
    if (showPublishDialog) {
        PublishSnapshotDialog(
            defaultVersionName = calendarState.snapshotVersionNameInput,
            defaultNotes = calendarState.snapshotNotesInput,
            onPublish = { name, notes ->
                viewModel.publishCalendarSnapshot(name, notes, "admin")
                showPublishDialog = false
            },
            onDismiss = { showPublishDialog = false }
        )
    }

    // Dialog for Rollback Confirmation
    rollbackTargetVersion?.let { target ->
        RollbackConfirmDialog(
            targetVersion = target,
            onConfirm = {
                viewModel.rollbackCalendarToVersion(target.versionId, "admin")
                rollbackTargetVersion = null
            },
            onDismiss = { rollbackTargetVersion = null }
        )
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .testTag("universal_calendar_admin_screen"),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        // Subsystem Breadcrumbs
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(4.dp),
                    horizontalArrangement = Arrangement.spacedBy(4.dp)
                ) {
                    OutlinedButton(
                        onClick = { viewModel.navigateTo(ScreenDestination.EXTERNAL_APPS_MONITOR) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Apps, contentDescription = null, modifier = Modifier.size(14.dp), tint = SaffronPrimary)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Apps", fontSize = 11.sp)
                    }

                    OutlinedButton(
                        onClick = { viewModel.navigateTo(ScreenDestination.CAPABILITY_APPROVAL) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.VerifiedUser, contentDescription = null, modifier = Modifier.size(14.dp), tint = VedicGold)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Capabilities", fontSize = 11.sp)
                    }

                    FilledTonalButton(
                        onClick = { viewModel.navigateTo(ScreenDestination.DAILY_DATA_MONITOR) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        colors = ButtonDefaults.filledTonalButtonColors(
                            containerColor = SpiritualTeal,
                            contentColor = Color.White
                        ),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Calendar", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }

                    OutlinedButton(
                        onClick = { viewModel.navigateTo(ScreenDestination.EXTERNAL_APP_SIMULATOR) },
                        modifier = Modifier.weight(1f),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                    ) {
                        Icon(Icons.Default.Science, contentDescription = null, modifier = Modifier.size(14.dp), tint = SaffronPrimary)
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Sandbox", fontSize = 11.sp)
                    }
                }
            }
        }

        // Header Banner & Universal Update Control Architecture
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                shape = RoundedCornerShape(12.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(text = "🕉️", fontSize = 22.sp)
                            Spacer(modifier = Modifier.width(8.dp))
                            Column {
                                Text(
                                    "Calendar & Panchang — Universal Update Control",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer
                                )
                                Text(
                                    "Admin Panel → Central VedaNova API → Database → Client Apps",
                                    style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp),
                                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                                )
                            }
                        }

                        // Seed Initial Button
                        IconButton(
                            onClick = { viewModel.seedCalendarInitialData() },
                            modifier = Modifier.size(32.dp)
                        ) {
                            Icon(Icons.Default.CloudDownload, contentDescription = "Seed Database", tint = SaffronPrimary)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Emergency Master Switch Bar
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = if (calendarState.isApiMasterEnabled) Color(0xFF1B5E20).copy(alpha = 0.15f) else Color(0xFFB71C1C).copy(alpha = 0.2f),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (calendarState.isApiMasterEnabled) Color(0xFF2E7D32) else Color(0xFFC62828)
                        ),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(horizontal = 12.dp, vertical = 8.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(
                                    if (calendarState.isApiMasterEnabled) Icons.Default.CheckCircle else Icons.Default.Warning,
                                    contentDescription = null,
                                    tint = if (calendarState.isApiMasterEnabled) Color(0xFF2E7D32) else Color(0xFFC62828),
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        if (calendarState.isApiMasterEnabled) "Calendar API Master Switch: ENABLED (200 OK)" else "EMERGENCY: Calendar API Master Switch DISABLED (503 Service Unavailable)",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (calendarState.isApiMasterEnabled) Color(0xFF1B5E20) else Color(0xFFB71C1C)
                                    )
                                    Text(
                                        if (calendarState.isApiMasterEnabled) "Authoritative Central API serving verified calendar data to client apps." else "Central API serving offline circuit-breaker to preserve client data safety.",
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            Switch(
                                checked = calendarState.isApiMasterEnabled,
                                onCheckedChange = { viewModel.toggleCalendarApiMasterSwitch("admin") },
                                colors = SwitchDefaults.colors(
                                    checkedThumbColor = Color.White,
                                    checkedTrackColor = Color(0xFF2E7D32),
                                    uncheckedThumbColor = Color.White,
                                    uncheckedTrackColor = Color(0xFFC62828)
                                ),
                                modifier = Modifier.testTag("api_master_switch")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Overview Metrics Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        MetricCard(
                            label = "Authoritative Days",
                            value = "$totalDaysCount",
                            icon = Icons.Default.CalendarToday,
                            tint = SpiritualTeal,
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            label = "Pujas & Festivals",
                            value = "$totalEventsCount",
                            icon = Icons.Default.Festival,
                            tint = SaffronPrimary,
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            label = "Pending Verify",
                            value = "${pendingDaysCount + pendingEventsCount}",
                            icon = Icons.Default.HourglassEmpty,
                            tint = if (pendingDaysCount + pendingEventsCount > 0) Color(0xFFE65100) else Color(0xFF2E7D32),
                            modifier = Modifier.weight(1f)
                        )
                        MetricCard(
                            label = "Live Version",
                            value = allVersions.firstOrNull()?.versionName ?: "v1.0",
                            icon = Icons.Default.Layers,
                            tint = VedicGold,
                            modifier = Modifier.weight(1.2f)
                        )
                    }
                }
            }
        }

        // Status or Error Message Alert
        calendarState.statusMessage?.let { msg ->
            item {
                Surface(
                    shape = RoundedCornerShape(10.dp),
                    color = SpiritualTeal.copy(alpha = 0.15f),
                    border = androidx.compose.foundation.BorderStroke(1.dp, SpiritualTeal),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(Icons.Default.Info, contentDescription = null, tint = SpiritualTeal, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            msg,
                            style = MaterialTheme.typography.bodySmall.copy(color = SpiritualTeal, fontWeight = FontWeight.SemiBold)
                        )
                    }
                }
            }
        }

        // Region Selector Row (Regional Calendar Support)
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Regional Calendar Standard (আঞ্চলিক মান):",
                            style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
                        )
                        Text(
                            "Surya Siddhanta & Drik Precision",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(
                        horizontalArrangement = Arrangement.spacedBy(6.dp),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        items(CalendarRegion.values()) { region ->
                            val isSelected = region == calendarState.selectedRegion
                            FilterChip(
                                selected = isSelected,
                                onClick = { viewModel.selectCalendarRegion(region) },
                                label = {
                                    Text(
                                        region.displayName,
                                        fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal,
                                        fontSize = 11.sp
                                    )
                                },
                                leadingIcon = if (isSelected) {
                                    { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(14.dp)) }
                                } else null,
                                shape = RoundedCornerShape(6.dp)
                            )
                        }
                    }
                }
            }
        }

        // Section Navigation Tabs (14 Core Mandates)
        item {
            ScrollableTabRow(
                selectedTabIndex = calendarState.selectedTab,
                edgePadding = 0.dp,
                modifier = Modifier.clip(RoundedCornerShape(8.dp))
            ) {
                val tabs = listOf(
                    "🕉️ Panchang",
                    "📆 Month Grid",
                    "🪔 Pujas & Festivals",
                    "🔱 Multi-Day",
                    "🛡️ Validation",
                    "📜 Versions & Rollback",
                    "📲 Client Sync & Safety",
                    "🔍 Audit Trail"
                )
                tabs.forEachIndexed { index, title ->
                    Tab(
                        selected = calendarState.selectedTab == index,
                        onClick = { viewModel.selectCalendarTab(index) },
                        text = {
                            Text(
                                title,
                                fontSize = 11.sp,
                                fontWeight = if (calendarState.selectedTab == index) FontWeight.Bold else FontWeight.Normal
                            )
                        }
                    )
                }
            }
        }

        // Tab Content Switching
        when (calendarState.selectedTab) {
            0 -> renderDailyPanchangTab(
                viewModel = viewModel,
                calendarState = calendarState,
                dailyData = dailyData,
                allDays = allDays
            )
            1 -> renderMonthGridTab(
                viewModel = viewModel,
                calendarState = calendarState,
                allDays = allDays
            )
            2 -> renderPujaFestivalTab(
                viewModel = viewModel,
                calendarState = calendarState,
                allEvents = allEvents
            )
            3 -> renderMultiDayBreakdownTab(
                viewModel = viewModel,
                calendarState = calendarState,
                allEvents = allEvents
            )
            4 -> renderValidationSystemTab(
                viewModel = viewModel,
                allDays = allDays,
                allEvents = allEvents
            )
            5 -> renderVersionControlTab(
                viewModel = viewModel,
                allVersions = allVersions,
                onShowPublish = { showPublishDialog = true },
                onSelectRollback = { rollbackTargetVersion = it }
            )
            6 -> renderClientSyncTab(
                viewModel = viewModel,
                calendarState = calendarState,
                allClientCaches = allClientCaches
            )
            7 -> renderAuditTrailTab(
                allAuditLogs = allAuditLogs
            )
        }
    }
}

// ----------------------------------------------------
// TAB 0: DAILY PANCHANG & DAY EDITOR
// ----------------------------------------------------

private fun androidx.compose.foundation.lazy.LazyListScope.renderDailyPanchangTab(
    viewModel: VedaNovaViewModel,
    calendarState: com.example.domain.ai.CalendarAdminUiState,
    dailyData: com.example.domain.ai.DailyDataResolution,
    allDays: List<CalendarDayEntity>
) {
    item {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            "Authoritative Dynamic Ephemeris",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Central DB Source: ${dailyData.gregorianDateFormatted} (${dailyData.region.displayName})",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Edit Button for Selected Day
                    Button(
                        onClick = {
                            val existingDay = allDays.find { it.gregorianDate == calendarState.selectedDate && it.region == calendarState.selectedRegion.name }
                                ?: com.example.domain.ai.CalendarAdminEngine.computeAstronomicalDay(calendarState.selectedDate, calendarState.selectedRegion)
                            viewModel.startEditDay(existingDay)
                        },
                        colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("edit_day_button")
                    ) {
                        Icon(Icons.Default.Edit, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Edit Day Data", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Date Picker Quick Bar
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    val dates = listOf("2026-09-08", "2026-09-09", "2026-09-10", "2026-10-16", "2026-10-17", "2026-10-18")
                    Text("Select Date:", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        items(dates) { d ->
                            val isSel = calendarState.selectedDate == d
                            FilterChip(
                                selected = isSel,
                                onClick = { viewModel.selectCalendarDate(d) },
                                label = { Text(d, fontSize = 11.sp) }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Detailed Panchang Card
                Surface(
                    color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f),
                    shape = RoundedCornerShape(10.dp),
                    border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                "বাংলা: ${dailyData.bengaliDate.dayBangla} ${dailyData.bengaliDate.monthBangla} ${dailyData.bengaliDate.yearBangla}",
                                fontWeight = FontWeight.Bold,
                                color = SaffronPrimary,
                                fontSize = 15.sp
                            )
                            StatusBadge(status = "PUBLISHED")
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            "তিথি: ${dailyData.bengaliDate.fullTithiTitle} (${dailyData.bengaliDate.paksha})",
                            fontWeight = FontWeight.SemiBold,
                            fontSize = 13.sp
                        )
                        Text(
                            "নক্ষত্র: ${dailyData.bengaliDate.nakshatra}",
                            fontSize = 12.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        HorizontalDivider(modifier = Modifier.padding(vertical = 8.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("🌅 সূর্যোদয়: ${dailyData.bengaliDate.sunriseTime}", fontSize = 12.sp)
                            Text("🌇 সূর্যাস্ত: ${dailyData.bengaliDate.sunsetTime}", fontSize = 12.sp)
                            Text("ব্রাহ্ম মুহূর্ত: ${dailyData.bengaliDate.brahmaMuhurta}", fontSize = 12.sp)
                        }

                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("অভিজিৎ মুহূর্ত: ${dailyData.bengaliDate.abhijitMuhurta}", fontSize = 11.sp, color = Color(0xFF2E7D32))
                            Text("রাহু কাল: ${dailyData.bengaliDate.rahuKala}", fontSize = 11.sp, color = Color(0xFFC62828))
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// TAB 1: MONTH GRID VIEW
// ----------------------------------------------------

private fun androidx.compose.foundation.lazy.LazyListScope.renderMonthGridTab(
    viewModel: VedaNovaViewModel,
    calendarState: com.example.domain.ai.CalendarAdminUiState,
    allDays: List<CalendarDayEntity>
) {
    item {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            "Monthly Calendar Matrix (${calendarState.activeMonth})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Status legend: Published (Green), Draft (Orange), Pending Verification (Amber)",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    // Month Switcher
                    Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                        listOf("2026-09", "2026-10", "2026-11").forEach { m ->
                            val isSel = calendarState.activeMonth == m
                            FilterChip(
                                selected = isSel,
                                onClick = { viewModel.selectCalendarMonth(m) },
                                label = { Text(m, fontSize = 11.sp) }
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Days List for Selected Month
                val monthDays = allDays.filter { it.gregorianDate.startsWith(calendarState.activeMonth) && it.region == calendarState.selectedRegion.name }
                    .sortedBy { it.gregorianDate }

                if (monthDays.isEmpty()) {
                    Text(
                        "No calendar days recorded for this month in local DB. Click 'Seed Universal Calendar' or edit days.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(vertical = 12.dp)
                    )
                } else {
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        monthDays.forEach { day ->
                            Surface(
                                shape = RoundedCornerShape(8.dp),
                                color = if (calendarState.selectedDate == day.gregorianDate) MaterialTheme.colorScheme.primaryContainer else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                                border = androidx.compose.foundation.BorderStroke(
                                    1.dp,
                                    if (calendarState.selectedDate == day.gregorianDate) SaffronPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)
                                ),
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clickable {
                                        viewModel.selectCalendarDate(day.gregorianDate)
                                        viewModel.startEditDay(day)
                                    }
                            ) {
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(10.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Column {
                                        Row(verticalAlignment = Alignment.CenterVertically) {
                                            Text(
                                                day.gregorianDate,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 13.sp
                                            )
                                            Spacer(modifier = Modifier.width(6.dp))
                                            Text(
                                                day.dayOfWeekBangla,
                                                fontSize = 11.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                        Text(
                                            "${day.dayBangla} ${day.monthBangla} ${day.yearBangla} | ${day.fullTithiTitle}",
                                            fontSize = 11.sp,
                                            color = SaffronPrimary,
                                            fontWeight = FontWeight.SemiBold
                                        )
                                    }

                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        StatusBadge(status = day.status)
                                        Spacer(modifier = Modifier.width(6.dp))
                                        Icon(Icons.Default.ChevronRight, contentDescription = null, modifier = Modifier.size(16.dp))
                                    }
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// TAB 2: PUJA & FESTIVAL MANAGEMENT
// ----------------------------------------------------

private fun androidx.compose.foundation.lazy.LazyListScope.renderPujaFestivalTab(
    viewModel: VedaNovaViewModel,
    calendarState: com.example.domain.ai.CalendarAdminUiState,
    allEvents: List<CalendarEventEntity>
) {
    item {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            "Puja & Festival Registry",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Central authoritative registry with scripture & mantra linkages",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Button(
                        onClick = { viewModel.startEditEvent(null) },
                        colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("add_festival_button")
                    ) {
                        Icon(Icons.Default.Add, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Add Puja / Festival", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                allEvents.forEach { event ->
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.5f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween,
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        when (event.category) {
                                            "PUJA" -> "🪔"
                                            "FESTIVAL" -> "🎉"
                                            "VRATA" -> "🕉️"
                                            else -> "✨"
                                        },
                                        fontSize = 16.sp
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Column {
                                        Text(
                                            event.nameBn,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 13.sp
                                        )
                                        Text(
                                            event.nameEn,
                                            fontSize = 11.sp,
                                            color = MaterialTheme.colorScheme.onSurfaceVariant
                                        )
                                    }
                                }

                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    StatusBadge(status = event.status)
                                    Spacer(modifier = Modifier.width(4.dp))
                                    IconButton(
                                        onClick = { viewModel.startEditEvent(event) },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.Edit, contentDescription = "Edit", modifier = Modifier.size(14.dp))
                                    }
                                    IconButton(
                                        onClick = { viewModel.deleteCalendarEvent(event.id, "admin") },
                                        modifier = Modifier.size(28.dp)
                                    ) {
                                        Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFC62828), modifier = Modifier.size(14.dp))
                                    }
                                }
                            }

                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                "তারিখ: ${event.targetGregorianDate} | সময়: ${event.timeDetails}",
                                fontSize = 11.sp,
                                color = SaffronPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                            Text(
                                "নিয়ম/পদ্ধতি: ${event.rituals}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            if (event.relatedMantra.isNotBlank()) {
                                Text(
                                    "মন্ত্র: ${event.relatedMantra}",
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Serif,
                                    color = SpiritualTeal
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// TAB 3: MULTI-DAY BREAKDOWN
// ----------------------------------------------------

private fun androidx.compose.foundation.lazy.LazyListScope.renderMultiDayBreakdownTab(
    viewModel: VedaNovaViewModel,
    calendarState: com.example.domain.ai.CalendarAdminUiState,
    allEvents: List<CalendarEventEntity>
) {
    item {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    "Multi-Day Festival Hierarchical Breakdown",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "দুর্গাপূজা ও নবরাত্রির মতো বহুদিনের উৎসবের ক্ষেত্রে প্রতিটি দিনের সুনির্দিষ্ট সময় ও পূজা বিধি",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(12.dp))

                val multiDayEvents = allEvents.filter { it.isMultiDay }.sortedBy { it.daySequence }
                multiDayEvents.forEach { dayEvent ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = CircleShape,
                                    color = SaffronPrimary,
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            "${dayEvent.daySequence}",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 12.sp
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(10.dp))
                                Column {
                                    Text(
                                        dayEvent.nameBn,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 13.sp
                                    )
                                    Text(
                                        "তারিখ: ${dayEvent.targetGregorianDate} (${dayEvent.tithi}) | ${dayEvent.timeDetails}",
                                        fontSize = 11.sp,
                                        color = SaffronPrimary
                                    )
                                    Text(
                                        "বিধি: ${dayEvent.rituals}",
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                            }

                            IconButton(
                                onClick = { viewModel.startEditEvent(dayEvent) },
                                modifier = Modifier.size(28.dp)
                            ) {
                                Icon(Icons.Default.Edit, contentDescription = "Edit", modifier = Modifier.size(14.dp))
                            }
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// TAB 4: VALIDATION SYSTEM
// ----------------------------------------------------

private fun androidx.compose.foundation.lazy.LazyListScope.renderValidationSystemTab(
    viewModel: VedaNovaViewModel,
    allDays: List<CalendarDayEntity>,
    allEvents: List<CalendarEventEntity>
) {
    item {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    "Universal Calendar Sanity & Validation Shield",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "Active guards protecting client apps from invalid dates, unverified mantras, and astronomical contradictions",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(12.dp))

                val validationRules = listOf(
                    "Rule 1: Gregorian & Bengali Date Logical Harmony" to "Validates that Bengali month days never exceed 32 and match solar astronomical ingress.",
                    "Rule 2: Tithi & Paksha Sequential Progression" to "Guarantees Shukla Paksha (Pratipada to Purnima) and Krishna Paksha (Pratipada to Amavasya) maintain Vedic integrity.",
                    "Rule 3: Astronomical Sunrise & Sunset Coherence" to "Ensures sunrise strictly precedes sunset and solar transit times adhere to latitude coordinates.",
                    "Rule 4: Multi-Day Sequence Continuity" to "Ensures Durga Puja Day 1 (Sasthi) sequentially connects through Dashami with no gaps.",
                    "Rule 5: Duplicate Festival Detection" to "Prevents multiple conflicting timings for the same festival on the same regional date.",
                    "Rule 6: Mantra Shield & Shastra Verification" to "Ensures unverified chants or dates cannot be tagged as 'PUBLISHED' without admin review."
                )

                validationRules.forEachIndexed { idx, (title, desc) ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color(0xFF1B5E20).copy(alpha = 0.08f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, Color(0xFF2E7D32).copy(alpha = 0.4f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Row(modifier = Modifier.padding(10.dp), verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Verified, contentDescription = null, tint = Color(0xFF2E7D32), modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(title, fontWeight = FontWeight.Bold, fontSize = 12.sp, color = Color(0xFF1B5E20))
                                Text(desc, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// TAB 5: VERSION CONTROL & ROLLBACK
// ----------------------------------------------------

private fun androidx.compose.foundation.lazy.LazyListScope.renderVersionControlTab(
    viewModel: VedaNovaViewModel,
    allVersions: List<CalendarVersionEntity>,
    onShowPublish: () -> Unit,
    onSelectRollback: (CalendarVersionEntity) -> Unit
) {
    item {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            "Calendar Version Control & Atomic Rollback",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Publish immutable snapshots. Rollback with 1-click if errors are discovered.",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Button(
                        onClick = onShowPublish,
                        colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("publish_snapshot_button")
                    ) {
                        Icon(Icons.Default.Publish, contentDescription = null, modifier = Modifier.size(14.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("Publish Snapshot", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                allVersions.forEach { ver ->
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = if (ver.isPublished) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.5f) else MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                        border = androidx.compose.foundation.BorderStroke(
                            1.dp,
                            if (ver.isPublished) SaffronPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)
                        ),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 4.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(12.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(
                                        ver.versionName,
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 14.sp
                                    )
                                    Spacer(modifier = Modifier.width(8.dp))
                                    if (ver.isPublished) {
                                        Surface(
                                            shape = RoundedCornerShape(4.dp),
                                            color = SaffronPrimary
                                        ) {
                                            Text(
                                                "ACTIVE LIVE",
                                                color = Color.White,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 9.sp,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                    }
                                }
                                Text(
                                    "Days: ${ver.totalDaysCount} | Events: ${ver.totalEventsCount} | By: ${ver.createdBy}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    ver.changeDescription,
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            if (!ver.isPublished) {
                                OutlinedButton(
                                    onClick = { onSelectRollback(ver) },
                                    shape = RoundedCornerShape(6.dp),
                                    contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp),
                                    modifier = Modifier.testTag("rollback_button_${ver.versionId}")
                                ) {
                                    Icon(Icons.Default.History, contentDescription = null, modifier = Modifier.size(14.dp))
                                    Spacer(modifier = Modifier.width(4.dp))
                                    Text("Rollback", fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// TAB 6: CLIENT SYNC & OFFLINE SAFETY
// ----------------------------------------------------

private fun androidx.compose.foundation.lazy.LazyListScope.renderClientSyncTab(
    viewModel: VedaNovaViewModel,
    calendarState: com.example.domain.ai.CalendarAdminUiState,
    allClientCaches: List<com.example.data.model.ClientCalendarCacheEntity>
) {
    item {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Column {
                        Text(
                            "Client App Auto-Sync & Offline Architecture",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Text(
                            "Client apps cache authoritative data and auto-sync without app updates",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Button(
                        onClick = { viewModel.testClientAppSync("VedaNova_DharmaApp_Client") },
                        enabled = !calendarState.isTestingSync,
                        colors = ButtonDefaults.buttonColors(containerColor = SpiritualTeal),
                        shape = RoundedCornerShape(8.dp),
                        contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp),
                        modifier = Modifier.testTag("simulate_client_sync_button")
                    ) {
                        if (calendarState.isTestingSync) {
                            CircularProgressIndicator(modifier = Modifier.size(14.dp), color = Color.White, strokeWidth = 2.dp)
                        } else {
                            Icon(Icons.Default.Sync, contentDescription = null, modifier = Modifier.size(14.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("Simulate Client Sync", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Sync Result Card
                calendarState.lastSyncResultJson?.let { result ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(10.dp)) {
                            Text("Simulated Client Response Payload:", fontWeight = FontWeight.Bold, fontSize = 11.sp)
                            Text(result, fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                        }
                    }
                    Spacer(modifier = Modifier.height(10.dp))
                }

                // Connected Client Apps Registry
                Text("Known Connected Client Apps:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                Spacer(modifier = Modifier.height(6.dp))

                val defaultClients = listOf(
                    Triple("VedaNova_DailyDharma_Android", "LIVE_SYNCED", "Calendar 2026 v1"),
                    Triple("VedaNova_PujaGuide_iOS", "OFFLINE_CACHE", "Calendar 2026 v1"),
                    Triple("VedaNova_TemplePortal_Web", "LIVE_SYNCED", "Calendar 2026 v1")
                )

                defaultClients.forEach { (appId, status, ver) ->
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f)),
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 3.dp)
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(10.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Icon(Icons.Default.PhoneAndroid, contentDescription = null, tint = SpiritualTeal, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(appId, fontWeight = FontWeight.SemiBold, fontSize = 12.sp)
                                    Text("Cached Version: $ver", fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                                }
                            }

                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = if (status == "LIVE_SYNCED") Color(0xFF1B5E20) else Color(0xFFE65100)
                            ) {
                                Text(
                                    status,
                                    color = Color.White,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 9.sp,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// TAB 7: AUDIT TRAIL
// ----------------------------------------------------

private fun androidx.compose.foundation.lazy.LazyListScope.renderAuditTrailTab(
    allAuditLogs: List<CalendarAuditLogEntity>
) {
    item {
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(12.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Text(
                    "Calendar Audit Trail & Historical Accountability",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "Logs admin identity, exact timestamp, field alterations, and reason note for every update",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                Spacer(modifier = Modifier.height(12.dp))

                if (allAuditLogs.isEmpty()) {
                    Text(
                        "No audit logs recorded yet.",
                        fontSize = 12.sp,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                } else {
                    allAuditLogs.forEach { log ->
                        val dateStr = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.US).format(Date(log.timestamp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f)),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 4.dp)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween
                                ) {
                                    Text(
                                        "${log.action} • ${log.targetType}",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = SaffronPrimary
                                    )
                                    Text(
                                        dateStr,
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                }
                                Text(
                                    "Admin: ${log.adminUsername} | Target: ${log.targetKey}",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold
                                )
                                Text(
                                    "Old: ${log.oldValue.take(60)} → New: ${log.newValue.take(60)}",
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                                Text(
                                    "Note: ${log.notes}",
                                    fontSize = 10.sp,
                                    fontStyle = androidx.compose.ui.text.font.FontStyle.Italic
                                )
                            }
                        }
                    }
                }
            }
        }
    }
}

// ----------------------------------------------------
// DIALOGS & COMPONENTS
// ----------------------------------------------------

@Composable
fun StatusBadge(status: String) {
    val (bg, fg, label) = when (status) {
        "PUBLISHED" -> Triple(Color(0xFF1B5E20), Color.White, "PUBLISHED")
        "VERIFIED" -> Triple(Color(0xFF0D47A1), Color.White, "VERIFIED")
        "DRAFT" -> Triple(Color(0xFFE65100), Color.White, "DRAFT")
        "PENDING_VERIFICATION" -> Triple(Color(0xFFFF8F00), Color.White, "যাচাই প্রক্রিয়াধীন")
        else -> Triple(Color.Gray, Color.White, status)
    }

    Surface(
        shape = RoundedCornerShape(4.dp),
        color = bg
    ) {
        Text(
            label,
            color = fg,
            fontWeight = FontWeight.Bold,
            fontSize = 9.sp,
            modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
        )
    }
}

@Composable
fun MetricCard(label: String, value: String, icon: androidx.compose.ui.graphics.vector.ImageVector, tint: Color, modifier: Modifier = Modifier) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = MaterialTheme.colorScheme.surface,
        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
        modifier = modifier
    ) {
        Column(
            modifier = Modifier.padding(8.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(icon, contentDescription = null, tint = tint, modifier = Modifier.size(18.dp))
            Spacer(modifier = Modifier.height(2.dp))
            Text(value, fontWeight = FontWeight.Bold, fontSize = 13.sp)
            Text(label, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalendarDayEditDialog(
    draft: CalendarDayEntity,
    validationErrors: List<String>,
    onUpdate: (CalendarDayEntity) -> Unit,
    onAutoCompute: (String, CalendarRegion) -> Unit,
    onSave: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.9f)
                .padding(8.dp)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Edit Calendar Day (${draft.gregorianDate})",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "Close")
                        }
                    }

                    OutlinedButton(
                        onClick = {
                            val r = try { CalendarRegion.valueOf(draft.region) } catch (_: Exception) { CalendarRegion.BANGLADESH_DHAKA }
                            onAutoCompute(draft.gregorianDate, r)
                        },
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = SaffronPrimary, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Auto-Compute Surya Siddhanta Ephemeris", fontSize = 11.sp)
                    }
                }

                if (validationErrors.isNotEmpty()) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFFFFEBEE),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("Validation Errors:", color = Color(0xFFC62828), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                validationErrors.forEach {
                                    Text("• $it", color = Color(0xFFC62828), fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = draft.dayBangla,
                        onValueChange = { onUpdate(draft.copy(dayBangla = it)) },
                        label = { Text("বাংলা দিন (যেমন: ৯ বা ০৯)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = draft.monthBangla,
                        onValueChange = { onUpdate(draft.copy(monthBangla = it)) },
                        label = { Text("বাংলা মাস (যেমন: আশ্বিন, কার্তিক)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = draft.fullTithiTitle,
                        onValueChange = { onUpdate(draft.copy(fullTithiTitle = it)) },
                        label = { Text("পূর্ণ তিথি বিবরণ (যেমন: শুক্লা অষ্টমী তিথি)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = draft.nakshatra,
                        onValueChange = { onUpdate(draft.copy(nakshatra = it)) },
                        label = { Text("নক্ষত্র (যেমন: মূলা, পূর্বাষাঢ়া)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = draft.yoga,
                            onValueChange = { onUpdate(draft.copy(yoga = it)) },
                            label = { Text("যোগ") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = draft.karana,
                            onValueChange = { onUpdate(draft.copy(karana = it)) },
                            label = { Text("করণ") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = draft.sunriseTime,
                            onValueChange = { onUpdate(draft.copy(sunriseTime = it)) },
                            label = { Text("সূর্যোদয় (HH:MM AM)") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = draft.sunsetTime,
                            onValueChange = { onUpdate(draft.copy(sunsetTime = it)) },
                            label = { Text("সূর্যাস্ত (HH:MM PM)") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = draft.brahmaMuhurta,
                            onValueChange = { onUpdate(draft.copy(brahmaMuhurta = it)) },
                            label = { Text("ব্রাহ্ম মুহূর্ত") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = draft.abhijitMuhurta,
                            onValueChange = { onUpdate(draft.copy(abhijitMuhurta = it)) },
                            label = { Text("অভিজিৎ মুহূর্ত") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = draft.rahuKala,
                        onValueChange = { onUpdate(draft.copy(rahuKala = it)) },
                        label = { Text("রাহু কাল") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    Text("Publication Workflow Status:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("DRAFT", "PENDING_VERIFICATION", "VERIFIED", "PUBLISHED").forEach { st ->
                            val isSel = draft.status == st
                            FilterChip(
                                selected = isSel,
                                onClick = { onUpdate(draft.copy(status = st)) },
                                label = { Text(st, fontSize = 10.sp) }
                            )
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = onDismiss) { Text("Cancel") }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = onSave,
                            colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
                        ) {
                            Text("Save Day Data")
                        }
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun CalendarEventEditDialog(
    draft: CalendarEventEntity,
    validationErrors: List<String>,
    onUpdate: (CalendarEventEntity) -> Unit,
    onSave: () -> Unit,
    onDismiss: () -> Unit
) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .fillMaxHeight(0.9f)
                .padding(8.dp)
        ) {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            "Add / Edit Puja & Festival",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        IconButton(onClick = onDismiss) {
                            Icon(Icons.Default.Close, contentDescription = "Close")
                        }
                    }
                }

                if (validationErrors.isNotEmpty()) {
                    item {
                        Surface(
                            shape = RoundedCornerShape(6.dp),
                            color = Color(0xFFFFEBEE),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Column(modifier = Modifier.padding(8.dp)) {
                                Text("Validation Errors:", color = Color(0xFFC62828), fontWeight = FontWeight.Bold, fontSize = 11.sp)
                                validationErrors.forEach {
                                    Text("• $it", color = Color(0xFFC62828), fontSize = 10.sp)
                                }
                            }
                        }
                    }
                }

                item {
                    OutlinedTextField(
                        value = draft.nameBn,
                        onValueChange = { onUpdate(draft.copy(nameBn = it)) },
                        label = { Text("উৎসবের নাম (বাংলায়, যেমন: শ্রীশ্রীদুর্গাপূজা)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = draft.nameEn,
                        onValueChange = { onUpdate(draft.copy(nameEn = it)) },
                        label = { Text("উৎসবের নাম (English)") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(
                            value = draft.targetGregorianDate,
                            onValueChange = { onUpdate(draft.copy(targetGregorianDate = it, startDate = it, endDate = it)) },
                            label = { Text("তারিখ (YYYY-MM-DD)") },
                            modifier = Modifier.weight(1f)
                        )
                        OutlinedTextField(
                            value = draft.timeDetails,
                            onValueChange = { onUpdate(draft.copy(timeDetails = it)) },
                            label = { Text("পূজার সময়সূচি") },
                            modifier = Modifier.weight(1f)
                        )
                    }
                }

                item {
                    OutlinedTextField(
                        value = draft.rituals,
                        onValueChange = { onUpdate(draft.copy(rituals = it)) },
                        label = { Text("পূজা পদ্ধতি / নিয়ম / বিধি") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    OutlinedTextField(
                        value = draft.relatedMantra,
                        onValueChange = { onUpdate(draft.copy(relatedMantra = it)) },
                        label = { Text("সংযুক্ত বৈদিক/শাস্ত্রীয় মন্ত্র") },
                        modifier = Modifier.fillMaxWidth()
                    )
                }

                item {
                    Text("Category & Importance:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("PUJA", "FESTIVAL", "VRATA", "JAYANTI").forEach { cat ->
                            FilterChip(
                                selected = draft.category == cat,
                                onClick = { onUpdate(draft.copy(category = cat)) },
                                label = { Text(cat, fontSize = 10.sp) }
                            )
                        }
                    }
                }

                item {
                    Text("Publication Workflow Status:", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        listOf("DRAFT", "PENDING_VERIFICATION", "VERIFIED", "PUBLISHED").forEach { st ->
                            FilterChip(
                                selected = draft.status == st,
                                onClick = { onUpdate(draft.copy(status = st)) },
                                label = { Text(st, fontSize = 10.sp) }
                            )
                        }
                    }
                }

                item {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.End
                    ) {
                        TextButton(onClick = onDismiss) { Text("Cancel") }
                        Spacer(modifier = Modifier.width(8.dp))
                        Button(
                            onClick = onSave,
                            colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
                        ) {
                            Text("Save Festival")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun PublishSnapshotDialog(
    defaultVersionName: String,
    defaultNotes: String,
    onPublish: (String, String) -> Unit,
    onDismiss: () -> Unit
) {
    var verName by remember { mutableStateOf(defaultVersionName) }
    var notes by remember { mutableStateOf(defaultNotes) }

    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(14.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(16.dp)
        ) {
            Column(
                modifier = Modifier.padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    "Publish Authoritative Calendar Snapshot",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Text(
                    "This creates an immutable snapshot version and instantly notifies connected client apps to auto-sync.",
                    fontSize = 11.sp,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )

                OutlinedTextField(
                    value = verName,
                    onValueChange = { verName = it },
                    label = { Text("Version Identifier") },
                    modifier = Modifier.fillMaxWidth()
                )

                OutlinedTextField(
                    value = notes,
                    onValueChange = { notes = it },
                    label = { Text("Release Notes & Changes") },
                    modifier = Modifier.fillMaxWidth()
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.End
                ) {
                    TextButton(onClick = onDismiss) { Text("Cancel") }
                    Spacer(modifier = Modifier.width(8.dp))
                    Button(
                        onClick = { onPublish(verName, notes) },
                        colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
                    ) {
                        Text("Publish Snapshot")
                    }
                }
            }
        }
    }
}

@Composable
fun RollbackConfirmDialog(
    targetVersion: CalendarVersionEntity,
    onConfirm: () -> Unit,
    onDismiss: () -> Unit
) {
    AlertDialog(
        onDismissRequest = onDismiss,
        title = { Text("Confirm Atomic Rollback", fontWeight = FontWeight.Bold) },
        text = {
            Text(
                "Are you sure you want to rollback all calendar data to snapshot \"${targetVersion.versionName}\"?\n\nCurrent day and event records will be atomically replaced with this verified version."
            )
        },
        confirmButton = {
            Button(
                onClick = onConfirm,
                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB71C1C))
            ) {
                Text("Execute Rollback")
            }
        },
        dismissButton = {
            TextButton(onClick = onDismiss) { Text("Cancel") }
        }
    )
}
