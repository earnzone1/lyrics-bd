package com.example.ui

import androidx.activity.compose.BackHandler
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.StatusPill
import com.example.ui.screens.*
import com.example.ui.theme.SaffronPrimary
import com.example.ui.theme.SpiritualTeal
import com.example.ui.theme.VedicGold
import com.example.ui.viewmodel.ScreenDestination
import com.example.ui.viewmodel.VedaNovaViewModel
import kotlinx.coroutines.launch

data class NavItem(
    val destination: ScreenDestination,
    val icon: ImageVector,
    val section: String
)

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AdminAppScaffold(viewModel: VedaNovaViewModel) {
    val currentScreen by viewModel.currentScreen.collectAsStateWithLifecycle()
    val session by viewModel.currentSession.collectAsStateWithLifecycle()
    val drawerState = rememberDrawerState(initialValue = DrawerValue.Closed)
    val coroutineScope = rememberCoroutineScope()

    // Handle back button
    BackHandler(enabled = drawerState.isOpen || currentScreen != ScreenDestination.DASHBOARD) {
        if (drawerState.isOpen) {
            coroutineScope.launch { drawerState.close() }
        } else {
            if (!viewModel.navigateBack()) {
                viewModel.navigateTo(ScreenDestination.DASHBOARD)
            }
        }
    }

    if (currentScreen == ScreenDestination.PUBLIC_CHAT) {
        PublicChatScreen(viewModel)
        return
    }

    // Core Navigation Items
    val coreNavItems = listOf(
        NavItem(ScreenDestination.PUBLIC_CHAT, Icons.Default.Chat, "0. PUBLIC DHARMA CHAT"),
        NavItem(ScreenDestination.DASHBOARD, Icons.Default.Dashboard, "1. CONTROL CENTER"),
        NavItem(ScreenDestination.DAILY_DATA_MONITOR, Icons.Default.CalendarMonth, "2. CALENDAR & PANCHANG"),
        NavItem(ScreenDestination.API_CENTER, Icons.Default.Key, "3. API MANAGER"),
        NavItem(ScreenDestination.TEACH_AI, Icons.Default.School, "4. TEACH / COMMAND"),
        NavItem(ScreenDestination.AI_TESTING_LAB, Icons.Default.Forum, "5. AI TEST CHAT"),
        NavItem(ScreenDestination.IMAGE_GENERATION_CENTER, Icons.Default.Palette, "6. IMAGE & VISION STUDIO"),
        NavItem(ScreenDestination.EXTERNAL_APPS_MONITOR, Icons.Default.Apps, "7. APPS & USAGE"),
        NavItem(ScreenDestination.PROJECT_MONITOR, Icons.Default.Engineering, "8. PROJECT MONITOR"),
        NavItem(ScreenDestination.KIRTAN_CREATOR, Icons.Default.MusicNote, "9. KIRTAN CREATOR & STUDIO"),
        NavItem(ScreenDestination.VIDEO_STUDIO, Icons.Default.Videocam, "10. AI VIDEO STUDIO")
    )

    // Secondary Auxiliary Tools
    val secondaryNavItems = listOf(
        NavItem(ScreenDestination.SETTINGS, Icons.Default.Tune, "System Settings"),
        NavItem(ScreenDestination.APP_OVERVIEW, Icons.Default.AccountTree, "App Overview & Architecture")
    )

    ModalNavigationDrawer(
        drawerState = drawerState,
        drawerContent = {
            ModalDrawerSheet(
                drawerContainerColor = MaterialTheme.colorScheme.surface,
                modifier = Modifier.width(300.dp)
            ) {
                LazyColumn(
                    modifier = Modifier
                        .fillMaxSize()
                        .padding(horizontal = 12.dp, vertical = 16.dp),
                    verticalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Drawer Header
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
                            shape = RoundedCornerShape(12.dp),
                            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Text(text = "🕉️", fontSize = 22.sp)
                                    Spacer(modifier = Modifier.width(8.dp))
                                    Text(
                                        text = "VedaNova AI",
                                        style = MaterialTheme.typography.titleMedium,
                                        fontWeight = FontWeight.Bold,
                                        color = MaterialTheme.colorScheme.onPrimaryContainer
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "Central Admin Control Center",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.85f)
                                )
                                Spacer(modifier = Modifier.height(8.dp))
                                StatusPill(
                                    text = "${session.currentUser.role}: @${session.currentUser.username}",
                                    color = SaffronPrimary
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "6 MAIN CONTROL MODULES",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = VedicGold,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        )
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                        Spacer(modifier = Modifier.height(4.dp))
                    }

                    // 6 Primary Modules
                    items(coreNavItems) { item ->
                        val isSelected = currentScreen == item.destination
                        NavigationDrawerItem(
                            icon = {
                                Icon(
                                    imageVector = item.icon,
                                    contentDescription = null,
                                    tint = if (isSelected) MaterialTheme.colorScheme.onPrimary else SaffronPrimary
                                )
                            },
                            label = {
                                Text(
                                    text = item.destination.title,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium
                                )
                            },
                            selected = isSelected,
                            onClick = {
                                viewModel.navigateTo(item.destination)
                                coroutineScope.launch { drawerState.close() }
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = NavigationDrawerItemDefaults.colors(
                                selectedContainerColor = SaffronPrimary,
                                selectedTextColor = MaterialTheme.colorScheme.onPrimary,
                                unselectedTextColor = MaterialTheme.colorScheme.onSurface
                            ),
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }

                    // Auxiliary Section
                    item {
                        Spacer(modifier = Modifier.height(8.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "PREFERENCES & CLIENT",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 4.dp)
                        )
                    }

                    items(secondaryNavItems) { item ->
                        val isSelected = currentScreen == item.destination
                        NavigationDrawerItem(
                            icon = {
                                Icon(
                                    imageVector = item.icon,
                                    contentDescription = null,
                                    tint = if (isSelected) MaterialTheme.colorScheme.onPrimary else SpiritualTeal
                                )
                            },
                            label = {
                                Text(
                                    text = item.destination.title,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            selected = isSelected,
                            onClick = {
                                viewModel.navigateTo(item.destination)
                                coroutineScope.launch { drawerState.close() }
                            },
                            shape = RoundedCornerShape(8.dp),
                            colors = NavigationDrawerItemDefaults.colors(
                                selectedContainerColor = SpiritualTeal,
                                selectedTextColor = Color.White,
                                unselectedTextColor = MaterialTheme.colorScheme.onSurface
                            ),
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }

                    item {
                        Spacer(modifier = Modifier.height(24.dp))
                    }
                }
            }
        }
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text(
                                text = currentScreen.title,
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "VedaNova AI Core • ${session.currentUser.role}",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    },
                    navigationIcon = {
                        IconButton(onClick = { coroutineScope.launch { drawerState.open() } }) {
                            Icon(Icons.Default.Menu, contentDescription = "Open Navigation Menu", tint = SaffronPrimary)
                        }
                    },
                    actions = {
                        IconButton(onClick = { viewModel.navigateTo(ScreenDestination.PUBLIC_CHAT) }) {
                            Icon(
                                imageVector = Icons.Default.ChatBubble,
                                contentDescription = "Public Dharma Chat",
                                tint = SaffronPrimary
                            )
                        }
                        IconButton(onClick = { viewModel.navigateTo(ScreenDestination.SETTINGS) }) {
                            Icon(
                                imageVector = Icons.Default.Tune,
                                contentDescription = "System Settings",
                                tint = if (currentScreen == ScreenDestination.SETTINGS) SaffronPrimary else MaterialTheme.colorScheme.onSurface
                            )
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = MaterialTheme.colorScheme.surface,
                        titleContentColor = MaterialTheme.colorScheme.onSurface
                    )
                )
            },
            containerColor = MaterialTheme.colorScheme.background,
            bottomBar = {
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.surface,
                    tonalElevation = 6.dp
                ) {
                    val bottomBarItems = listOf(
                        Triple(ScreenDestination.PUBLIC_CHAT, Icons.Default.ChatBubble, "Public Chat"),
                        Triple(ScreenDestination.DASHBOARD, Icons.Default.Dashboard, "Control"),
                        Triple(ScreenDestination.TEACH_AI, Icons.Default.School, "Teach"),
                        Triple(ScreenDestination.AI_TESTING_LAB, Icons.Default.Forum, "Test Lab"),
                        Triple(ScreenDestination.SETTINGS, Icons.Default.Tune, "Settings"),
                        Triple(ScreenDestination.PROJECT_MONITOR, Icons.Default.Engineering, "Monitor")
                    )

                    bottomBarItems.forEach { (destination, icon, label) ->
                        val isSelected = currentScreen == destination
                        NavigationBarItem(
                            selected = isSelected,
                            onClick = { viewModel.navigateTo(destination) },
                            icon = { Icon(icon, contentDescription = label) },
                            label = {
                                Text(
                                    text = label,
                                    fontSize = 10.sp,
                                    fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Normal
                                )
                            },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.onPrimary,
                                selectedTextColor = SaffronPrimary,
                                indicatorColor = SaffronPrimary,
                                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        )
                    }
                }
            }
        ) { paddingValues ->
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(paddingValues)
            ) {
                when (currentScreen) {
                    ScreenDestination.PUBLIC_CHAT -> PublicChatScreen(viewModel)
                    ScreenDestination.DASHBOARD -> DashboardScreen(viewModel)
                    ScreenDestination.EXTERNAL_APPS_MONITOR -> ExternalAppsMonitorScreen(viewModel)
                    ScreenDestination.CAPABILITY_APPROVAL -> CapabilityApprovalScreen(viewModel)
                    ScreenDestination.DAILY_DATA_MONITOR -> DailyDataEngineScreen(viewModel)
                    ScreenDestination.EXTERNAL_APP_SIMULATOR -> ExternalAppSimulatorScreen(viewModel)
                    ScreenDestination.AI_TESTING_LAB -> AiTestingLabScreen(viewModel)
                    ScreenDestination.IMAGE_GENERATION_CENTER -> ImageGenerationCenterScreen(viewModel)
                    ScreenDestination.API_CENTER -> ApiCenterScreen(viewModel)
                    ScreenDestination.API_TESTING -> ApiTestingScreen(viewModel)
                    ScreenDestination.EXTERNAL_TEST_CLIENT -> ExternalTestClientScreen(viewModel)
                    ScreenDestination.KNOWLEDGE_CENTER -> KnowledgeCenterScreen(viewModel)
                    ScreenDestination.RESEARCH_CENTER -> ResearchCenterScreen(viewModel)
                    ScreenDestination.TEACH_AI -> TeachAiScreen(viewModel)
                    ScreenDestination.PROJECT_MONITOR -> ProjectMonitorScreen(viewModel)
                    ScreenDestination.REPORTS -> ReportCenterScreen(viewModel)
                    ScreenDestination.DATABASE_CENTER, ScreenDestination.BACKUPS -> DatabaseCenterScreen(viewModel)
                    ScreenDestination.USERS -> UsersCenterScreen(viewModel)
                    ScreenDestination.ANALYTICS -> AnalyticsScreen(viewModel)
                    ScreenDestination.LOGS -> LogsScreen(viewModel)
                    ScreenDestination.AUDIT_LOGS -> AuditLogScreen(viewModel)
                    ScreenDestination.SYSTEM_HEALTH -> SystemHealthScreen(viewModel)
                    ScreenDestination.SECURITY -> SecurityCenterScreen(viewModel)
                    ScreenDestination.SETTINGS -> SettingsScreen(viewModel)
                    ScreenDestination.FUNCTION_MAP -> AdminFunctionMapScreen(viewModel)
                    ScreenDestination.APP_OVERVIEW -> AppOverviewScreen(viewModel)
                    ScreenDestination.CRASH_REPORTS -> CrashDiagnosticCenterScreen(viewModel)
                    ScreenDestination.KIRTAN_CREATOR, ScreenDestination.KIRTAN_CATALOG -> KirtanCreatorScreen(viewModel)
                    ScreenDestination.VIDEO_STUDIO -> VideoStudioScreen(viewModel)
                }
            }
        }
    }
}
