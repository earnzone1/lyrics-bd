package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.core.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.KirtanEntity
import com.example.data.model.KirtanAudioEntity
import com.example.data.model.KirtanAudioTrackEntity
import com.example.data.model.AudioGenerationStage
import com.example.ui.theme.*
import com.example.ui.viewmodel.VedaNovaViewModel
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KirtanCreatorScreen(viewModel: VedaNovaViewModel) {
    val kirtanState by viewModel.kirtanUiState.collectAsStateWithLifecycle()
    val allKirtans by viewModel.allKirtans.collectAsStateWithLifecycle()
    val publishedKirtans by viewModel.publishedKirtans.collectAsStateWithLifecycle()
    val auditLogs by viewModel.kirtanAuditLogs.collectAsStateWithLifecycle()

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(kirtanState.toastMessage) {
        kirtanState.toastMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearKirtanToast()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
                    .padding(horizontal = 16.dp, vertical = 12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(RoundedCornerShape(12.dp))
                            .background(SaffronPrimary.copy(alpha = 0.15f))
                            .border(1.dp, SaffronPrimary.copy(alpha = 0.4f), RoundedCornerShape(12.dp)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text("🎶", fontSize = 22.sp)
                    }
                    Spacer(modifier = Modifier.width(12.dp))
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = "VedaNova AI — Kirtan Creator",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Text(
                            text = "মৌলিক ভক্তিগীতি ও সংকীর্তন উদ্ভাবনী ইঞ্জিন • Central Single Source of Truth",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                    // Status Badge
                    Surface(
                        color = Color(0xFF1B5E20).copy(alpha = 0.12f),
                        border = BorderStroke(1.dp, Color(0xFF2E7D32)),
                        shape = RoundedCornerShape(20.dp)
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp)
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(8.dp)
                                    .clip(CircleShape)
                                    .background(Color(0xFF2E7D32))
                            )
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "Zero-Copyright Guaranteed",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.SemiBold,
                                color = Color(0xFF2E7D32)
                            )
                        }
                    }
                }

                Spacer(modifier = Modifier.height(8.dp))

                // Stats Chips Row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    AssistChip(
                        onClick = { viewModel.updateKirtanActiveTab(2) },
                        label = { Text("মোট কীর্তন: ${allKirtans.size}", fontSize = 11.sp) },
                        leadingIcon = { Icon(Icons.Default.LibraryMusic, null, modifier = Modifier.size(14.dp)) }
                    )
                    AssistChip(
                        onClick = {
                            viewModel.updateKirtanActiveTab(2)
                            viewModel.updateKirtanFilterStatus("PUBLISHED")
                        },
                        label = { Text("প্রকাশিত: ${publishedKirtans.size}", fontSize = 11.sp) },
                        leadingIcon = { Icon(Icons.Default.CloudDone, null, modifier = Modifier.size(14.dp), tint = Color(0xFF2E7D32)) }
                    )
                    AssistChip(
                        onClick = { },
                        label = { Text("শাস্ত্রীয় প্রামাণ্য: ১০০%", fontSize = 11.sp) },
                        leadingIcon = { Icon(Icons.Default.Verified, null, modifier = Modifier.size(14.dp), tint = SaffronPrimary) }
                    )
                }

                Spacer(modifier = Modifier.height(4.dp))

                // Tabs
                ScrollableTabRow(
                    selectedTabIndex = kirtanState.activeTab,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = SaffronPrimary,
                    edgePadding = 8.dp
                ) {
                    val tabs = listOf(
                        "রচয়িতা স্টুডিও",
                        "কীর্তন পদাবলী ও সুর",
                        "সেন্ট্রাল ক্যাটালগ",
                        "বাদ্য ও রাগ গাইড",
                        "অডিও ও সঙ্গীত স্টুডিও"
                    )
                    tabs.forEachIndexed { index, title ->
                        Tab(
                            selected = kirtanState.activeTab == index,
                            onClick = { viewModel.updateKirtanActiveTab(index) },
                            text = {
                                Text(
                                    text = title,
                                    fontSize = 12.sp,
                                    fontWeight = if (kirtanState.activeTab == index) FontWeight.Bold else FontWeight.Normal
                                )
                            }
                        )
                    }
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (kirtanState.activeTab) {
                0 -> KirtanStudioTab(viewModel, kirtanState)
                1 -> KirtanLyricsAndPreviewTab(viewModel, kirtanState)
                2 -> KirtanCatalogTab(viewModel, kirtanState, allKirtans, auditLogs)
                3 -> KirtanPerformanceGuideTab(kirtanState)
                4 -> KirtanAudioStudioTab(viewModel, kirtanState)
            }
        }
    }
}

// =======================================================================
// TAB 0: KIRTAN CREATOR STUDIO
// =======================================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KirtanStudioTab(
    viewModel: VedaNovaViewModel,
    state: com.example.ui.viewmodel.KirtanUiState
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // AI Instructions Banner
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(12.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.primary.copy(alpha = 0.2f))
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.Top
                ) {
                    Text("💡", fontSize = 20.sp)
                    Spacer(modifier = Modifier.width(10.dp))
                    Column {
                        Text(
                            text = "স্বাভাবিক ভাষায় নির্দেশ করুন",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "আপনি যে কোনো দেবদেবী, ভাব (প্রেম, দাস্য, শান্ত, গম্ভীর, উৎসবমুখর) অথবা বিশেষ উৎসব (যেমন জন্মাষ্টমী, শিবরাত্রি, দুর্গাপূজা) উল্লেখ করে সরাসরি নির্দেশ দিতে পারেন। এআই সম্পূর্ণরূপে মৌলিক শব্দাবলী, ধ্রুবপদ ও কল-রেসপন্স রচনা করবে।",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Quick Preset Prompts
        item {
            Column {
                Text(
                    text = "দ্রুত নির্দেশাবলি (Quick Presets):",
                    style = MaterialTheme.typography.labelLarge,
                    fontWeight = FontWeight.SemiBold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(8.dp))
                val presets = listOf(
                    "শ্রীকৃষ্ণকে নিয়ে একটি আনন্দময় বাংলা কীর্তন তৈরি করো",
                    "রাধা-কৃষ্ণের মিলন ও বিরহ নিয়ে একটি গভীর ভক্তিভাবের কীর্তন",
                    "মহাদেব শিবের তাণ্ডব ও শান্ত রূপ নিয়ে ওঙ্কার ধ্বনির গম্ভীর কীর্তন",
                    "মা দুর্গার আগমনি ও বিজয়া নিয়ে একটি ভক্তিসুধা কীর্তন",
                    "শ্রীচৈতন্য মহাপ্রভুর সংকীর্তন আন্দোলনের হরিনাম মহিমা কীর্তন",
                    "শ্রীরামচন্দ্র ও হনুমানজির দাস্যভাবের একটি ভক্তি সংকীর্তন"
                )
                LazyRow(
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    items(presets) { preset ->
                        ElevatedFilterChip(
                            selected = state.prompt == preset,
                            onClick = {
                                viewModel.updateKirtanPrompt(preset)
                            },
                            label = {
                                Text(
                                    text = preset.take(32) + "...",
                                    fontSize = 12.sp
                                )
                            },
                            shape = RoundedCornerShape(16.dp)
                        )
                    }
                }
            }
        }

        // Input Box
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "আপনার কীর্তন রচনার নির্দেশ (Prompt):",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = state.prompt,
                        onValueChange = { viewModel.updateKirtanPrompt(it) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 100.dp)
                            .testTag("kirtan_prompt_input"),
                        placeholder = { Text("যেমন: ‘জগন্নাথ দেবের রথযাত্রা নিয়ে একটি দ্রুত লয়ের আনন্দঘন সংকীর্তন রচনা করো...’") },
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    // Configuration Controls
                    Text(
                        text = "সমন্বয় ও পরামিতি (Parameters):",
                        style = MaterialTheme.typography.labelMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    // Deity Selector
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        val deities = listOf("শ্রীকৃষ্ণ", "রাধা-কৃষ্ণ", "মহাদেব শিব", "মা দুর্গা", "শ্রীরাম", "হরি ওঁ")
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            items(deities) { deity ->
                                FilterChip(
                                    selected = state.selectedDeity == deity,
                                    onClick = {
                                        viewModel.updateKirtanDeity(deity)
                                        viewModel.updateKirtanPrompt("${deity}কে নিয়ে একটি ভাবময় কীর্তন তৈরি করো")
                                    },
                                    label = { Text(deity, fontSize = 11.sp) }
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Mood & Tempo Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        // Mood
                        val moods = listOf("Joyful (আনন্দময়)", "Devotional (ভক্তিভাব)", "Peaceful (শান্ত)", "Energetic (উত্তাল)", "Meditative (ধ্যানমগ্ন)")
                        Column(modifier = Modifier.weight(1f)) {
                            Text("ভাব / Mood", style = MaterialTheme.typography.labelSmall)
                            Spacer(modifier = Modifier.height(4.dp))
                            LazyRow(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                items(listOf("Joyful", "Devotional", "Meditative", "Energetic")) { m ->
                                    FilterChip(
                                        selected = state.selectedMood == m,
                                        onClick = { viewModel.updateKirtanMood(m) },
                                        label = { Text(m, fontSize = 10.sp) }
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Duration & Language Row
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("সময়কাল (Duration): ${state.selectedDurationMinutes} মিনিট", style = MaterialTheme.typography.labelSmall)
                            Slider(
                                value = state.selectedDurationMinutes.toFloat(),
                                onValueChange = { viewModel.updateKirtanDuration(it.toInt()) },
                                valueRange = 3f..25f,
                                steps = 21,
                                colors = SliderDefaults.colors(thumbColor = SaffronPrimary, activeTrackColor = SaffronPrimary)
                            )
                        }

                        Column(modifier = Modifier.width(130.dp)) {
                            Text("ভাষা (Language)", style = MaterialTheme.typography.labelSmall)
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                listOf("Bengali", "Sanskrit", "Hindi").forEach { lang ->
                                    FilterChip(
                                        selected = state.selectedLanguage == lang,
                                        onClick = { viewModel.updateKirtanLanguage(lang) },
                                        label = { Text(lang.take(3), fontSize = 10.sp) }
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(16.dp))

                    // Generate Button
                    Button(
                        onClick = { viewModel.generateKirtanFromCurrentPrompt() },
                        enabled = !state.isGenerating && state.prompt.isNotBlank(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                            .testTag("generate_kirtan_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
                    ) {
                        if (state.isGenerating) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text("মৌলিক কীর্তন ও শাস্ত্রীয় ছন্দ রচনা হচ্ছে...", color = Color.White, fontWeight = FontWeight.Bold)
                        } else {
                            Icon(Icons.Default.AutoAwesome, null, tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("সম্পূর্ণ মৌলিক কীর্তন রচনা করুন", color = Color.White, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }

        // Feature Highlights Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f)),
                shape = RoundedCornerShape(12.dp)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "💎 VedaNova Kirtan Creator বিশেষত্বসমূহ:",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    val features = listOf(
                        "১. কপিরাইট সুরক্ষা গার্ড: প্রচলিত বা কপিরাইটযুক্ত কোনো সুর বা পদ নকল না করে সম্পূর্ণ স্বকীয় ভক্তি পদাবলী তৈরি করে।",
                        "২. সম্পূর্ণ ৭-ধাপ কাঠামো: বন্দনা ➔ ধ্রুবপদ ➔ কল-রেসপন্স ➔ অন্তরা ➔ ক্লাইম্যাক্স ➔ সমাপনী ➔ শান্তিপাঠ।",
                        "৩. বাদ্যযন্ত্র ও রাগমালিকা সমন্বয়: খোল, করতাল, হারমোনিয়াম ও বংশী বাদনের বিশদ তাল ও লয় নির্দেশিকা।",
                        "৪. সেন্ট্রাল এপিআই ও ক্যাটালগ সংরক্ষণ: অ্যাডমিন যাচাইয়ের পর যেকোনো ভক্তিমূলক অ্যাপ সরাসরি এই কীর্তন ব্যবহার করতে পারে।"
                    )
                    features.forEach { feat ->
                        Text(
                            text = feat,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.padding(vertical = 2.dp)
                        )
                    }
                }
            }
        }
    }
}

// =======================================================================
// TAB 1: KIRTAN LYRICS & FULL PREVIEW
// =======================================================================

@Composable
fun KirtanLyricsAndPreviewTab(
    viewModel: VedaNovaViewModel,
    state: com.example.ui.viewmodel.KirtanUiState
) {
    val kirtan = state.selectedKirtanForDetails ?: state.currentGeneratedKirtan

    if (kirtan == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Text("🎵", fontSize = 48.sp)
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "এখনও কোনো কীর্তন নির্বাচিত বা তৈরি করা হয়নি",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
                Spacer(modifier = Modifier.height(6.dp))
                Text(
                    text = "‘রচয়িতা স্টুডিও’ ট্যাব থেকে নতুন কীর্তন রচনা করুন অথবা ‘ক্যাটালগ’ থেকে একটি কীর্তন নির্বাচন করুন।",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
                Spacer(modifier = Modifier.height(16.dp))
                Button(
                    onClick = { viewModel.updateKirtanActiveTab(0) },
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
                ) {
                    Icon(Icons.Default.Add, null)
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("কীর্তন স্টুডিওতে যান")
                }
            }
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Title & Header Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, SaffronPrimary.copy(alpha = 0.3f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.Top
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = kirtan.title,
                                style = MaterialTheme.typography.headlineSmall,
                                fontWeight = FontWeight.Bold,
                                color = SaffronPrimary
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "দেবতা: ${kirtan.deity} • থিম: ${kirtan.theme}",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }

                        // Bookmark & Actions
                        IconButton(
                            onClick = { viewModel.toggleKirtanBookmark(kirtan.id, kirtan.isBookmarked) }
                        ) {
                            Icon(
                                imageVector = if (kirtan.isBookmarked) Icons.Default.Bookmark else Icons.Default.BookmarkBorder,
                                contentDescription = "Bookmark",
                                tint = SaffronPrimary
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    // Metadata Badges
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Surface(
                            color = MaterialTheme.colorScheme.primaryContainer,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "লয়: ${kirtan.tempo}",
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                        }
                        Surface(
                            color = MaterialTheme.colorScheme.secondaryContainer,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "সময়: ${kirtan.durationMinutes} মি.",
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                color = MaterialTheme.colorScheme.onSecondaryContainer
                            )
                        }
                        Surface(
                            color = MaterialTheme.colorScheme.tertiaryContainer,
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = "ভাষা: ${kirtan.language}",
                                fontSize = 11.sp,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                color = MaterialTheme.colorScheme.onTertiaryContainer
                            )
                        }
                        // Status Badge
                        val statusColor = when (kirtan.verificationStatus) {
                            "PUBLISHED" -> Color(0xFF2E7D32)
                            "VERIFIED" -> SaffronPrimary
                            "NEEDS_REVISION" -> Color(0xFFC62828)
                            else -> Color(0xFF757575)
                        }
                        Surface(
                            color = statusColor.copy(alpha = 0.15f),
                            border = BorderStroke(1.dp, statusColor),
                            shape = RoundedCornerShape(12.dp)
                        ) {
                            Text(
                                text = kirtan.verificationStatus,
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp),
                                color = statusColor
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Structure Flow Line
                    Text(
                        text = "কাঠামো ক্রম: ${kirtan.structure}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Action Buttons Row (Verify & Publish & Play)
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.verifyCurrentKirtan(kirtan.id) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                        ) {
                            Icon(Icons.Default.Verified, null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("যাচাই করুন", fontSize = 12.sp)
                        }

                        Button(
                            onClick = { viewModel.publishCurrentKirtan(kirtan.id) },
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                        ) {
                            Icon(Icons.Default.CloudUpload, null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("প্রকাশ করুন", fontSize = 12.sp)
                        }

                        FilledTonalButton(
                            onClick = { viewModel.togglePlaybackPreview("FULL") },
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(
                                if (state.isPlayingPreview) Icons.Default.Stop else Icons.Default.PlayArrow,
                                null,
                                modifier = Modifier.size(16.dp)
                            )
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (state.isPlayingPreview) "থামান" else "সুর শুনুন", fontSize = 12.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Real Audio Generation CTA
                    Button(
                        onClick = { viewModel.generateAudioForCurrentKirtan(kirtan.id) },
                        enabled = !state.isGeneratingAudio,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                            .testTag("generate_audio_cta_button"),
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
                    ) {
                        if (state.isGeneratingAudio) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(16.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("আসল অডিও সিন্থেসিস হচ্ছে...", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        } else {
                            Icon(Icons.Default.GraphicEq, null, modifier = Modifier.size(18.dp), tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("🎵 সম্পূর্ণ আসল কীর্তন অডিও সিন্থেসিস করুন", color = Color.White, fontSize = 12.sp, fontWeight = FontWeight.Bold)
                        }
                    }

                    if (state.currentGeneratedAudio != null && state.currentGeneratedAudio.kirtanId == kirtan.id) {
                        Spacer(modifier = Modifier.height(8.dp))
                        OutlinedButton(
                            onClick = { viewModel.updateKirtanActiveTab(4) },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(40.dp)
                                .testTag("open_audio_studio_button"),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, SaffronPrimary)
                        ) {
                            Icon(Icons.Default.Headphones, null, modifier = Modifier.size(16.dp), tint = SaffronPrimary)
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "🎧 অডিও শুনুন ও মাল্টি-ট্র্যাক স্টুডিওতে দেখুন (${state.currentGeneratedAudio.durationSeconds}s, ${state.currentGeneratedAudio.ragaName})",
                                fontSize = 12.sp,
                                color = SaffronPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }
                    }
                }
            }
        }

        // Metronome / Audio Simulation Active Bar
        if (state.isPlayingPreview) {
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = SaffronPrimary.copy(alpha = 0.12f)),
                    border = BorderStroke(1.dp, SaffronPrimary)
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        // Animated pulsing wave indicator
                        val infiniteTransition = rememberInfiniteTransition(label = "kirtan_wave")
                        val scale by infiniteTransition.animateFloat(
                            initialValue = 0.8f,
                            targetValue = 1.3f,
                            animationSpec = infiniteRepeatable(
                                animation = tween(600, easing = FastOutSlowInEasing),
                                repeatMode = RepeatMode.Reverse
                            ),
                            label = "wave_scale"
                        )
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(SaffronPrimary.copy(alpha = 0.3f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("🪘", fontSize = (16 * scale).sp)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "কীর্তন সুর ও রিদম সিমুলেশন চলছে (${kirtan.tempo})",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = SaffronPrimary
                            )
                            Text(
                                text = "মৃদঙ্গ: তা-ধে-তাং-ঝাঁঝর • করতাল: দ্রুত খেমটা ছন্দ • ভাব: ${kirtan.mood}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        IconButton(onClick = { viewModel.togglePlaybackPreview("") }) {
                            Icon(Icons.Default.Close, null, tint = SaffronPrimary)
                        }
                    }
                }
            }
        }

        // Section 1: Opening / বন্দনা
        item {
            KirtanSectionCard(
                title = "১. বন্দনা ও ধ্যানের প্রারম্ভ (Opening Invocation)",
                content = kirtan.opening,
                icon = "🪷",
                sectionTag = "OPENING",
                isPlaying = state.isPlayingPreview && state.playingSection == "OPENING",
                onPlayToggle = { viewModel.togglePlaybackPreview("OPENING") }
            )
        }

        // Section 2: Main Chorus / ধ্রুবপদ
        item {
            KirtanSectionCard(
                title = "২. মূল ধ্রুবপদ (Main Chorus / মহাধ্বনি)",
                content = kirtan.chorus,
                icon = "👑",
                sectionTag = "CHORUS",
                isPlaying = state.isPlayingPreview && state.playingSection == "CHORUS",
                onPlayToggle = { viewModel.togglePlaybackPreview("CHORUS") },
                isHighlight = true
            )
        }

        // Section 3: Call & Response / মূল সুর ও প্রতিধ্বনি
        item {
            KirtanSectionCard(
                title = "৩. কল ও রেসপন্স পদাবলী (Call & Response)",
                content = kirtan.callResponse,
                icon = "🗣️",
                sectionTag = "CALL_RESPONSE",
                isPlaying = state.isPlayingPreview && state.playingSection == "CALL_RESPONSE",
                onPlayToggle = { viewModel.togglePlaybackPreview("CALL_RESPONSE") }
            )
        }

        // Section 4: Verses / অন্তরা
        item {
            KirtanSectionCard(
                title = "৪. অন্তরা ও পদমালা (Verses / পদাবলী)",
                content = kirtan.verses,
                icon = "📜",
                sectionTag = "VERSES",
                isPlaying = state.isPlayingPreview && state.playingSection == "VERSES",
                onPlayToggle = { viewModel.togglePlaybackPreview("VERSES") }
            )
        }

        // Section 5: Climax / দ্রুত লয় ও ভাবোচ্ছ্বাস
        item {
            KirtanSectionCard(
                title = "৫. ক্লাইম্যাক্স ও দ্রুত লয়ের মহামিলন (Climax)",
                content = kirtan.climax,
                icon = "⚡",
                sectionTag = "CLIMAX",
                isPlaying = state.isPlayingPreview && state.playingSection == "CLIMAX",
                onPlayToggle = { viewModel.togglePlaybackPreview("CLIMAX") }
            )
        }

        // Section 6: Ending / লয় সমাপন
        item {
            KirtanSectionCard(
                title = "৬. সমাপনী সুর ও ধীরে লয় (Ending)",
                content = kirtan.ending,
                icon = "🕊️",
                sectionTag = "ENDING",
                isPlaying = state.isPlayingPreview && state.playingSection == "ENDING",
                onPlayToggle = { viewModel.togglePlaybackPreview("ENDING") }
            )
        }

        // Section 7: Closing Prayer / শান্তিপাঠ
        item {
            KirtanSectionCard(
                title = "৭. শান্তিপাঠ ও আশীর্বাদ (Closing Shanti Prayer)",
                content = kirtan.closingPrayer,
                icon = "🕉️",
                sectionTag = "PRAYER",
                isPlaying = state.isPlayingPreview && state.playingSection == "PRAYER",
                onPlayToggle = { viewModel.togglePlaybackPreview("PRAYER") }
            )
        }

        // Variation Generator Box
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
            ) {
                var variationInstruction by remember { mutableStateOf("") }
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "নতুন রূপভেদ তৈরি করুন (Generate Variation):",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "যেমন: ‘ধীর লয়ের বৈষ্ণব বিরহ পদাবলী যোগ করো’ অথবা ‘দ্রুত সংকীর্তন রূপান্তর করো’",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = variationInstruction,
                        onValueChange = { variationInstruction = it },
                        modifier = Modifier.fillMaxWidth(),
                        placeholder = { Text("কী পরিবর্তন চান নির্দেশ করুন...") },
                        shape = RoundedCornerShape(10.dp)
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Button(
                        onClick = {
                            if (variationInstruction.isNotBlank()) {
                                viewModel.createKirtanVariation(kirtan.id, variationInstruction)
                                variationInstruction = ""
                            }
                        },
                        enabled = variationInstruction.isNotBlank(),
                        colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Icon(Icons.Default.Transform, null)
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("রূপভেদ সংকীর্তন সৃষ্টি করুন")
                    }
                }
            }
        }
    }
}

@Composable
fun KirtanSectionCard(
    title: String,
    content: String,
    icon: String,
    sectionTag: String,
    isPlaying: Boolean,
    onPlayToggle: () -> Unit,
    isHighlight: Boolean = false
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(
            containerColor = if (isHighlight) MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f) else MaterialTheme.colorScheme.surface
        ),
        border = BorderStroke(
            1.dp,
            if (isHighlight) SaffronPrimary else MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isHighlight) 3.dp else 1.dp)
    ) {
        Column(modifier = Modifier.padding(16.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(verticalAlignment = Alignment.CenterVertically) {
                    Text(icon, fontSize = 18.sp)
                    Spacer(modifier = Modifier.width(8.dp))
                    Text(
                        text = title,
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = if (isHighlight) SaffronPrimary else MaterialTheme.colorScheme.onSurface
                    )
                }

                IconButton(
                    onClick = onPlayToggle,
                    modifier = Modifier.size(32.dp)
                ) {
                    Icon(
                        imageVector = if (isPlaying) Icons.Default.PauseCircle else Icons.Default.PlayCircle,
                        contentDescription = "Play Section",
                        tint = if (isPlaying) SaffronPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            // Lyrics Text
            Box(
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(8.dp))
                    .background(MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.3f))
                    .padding(12.dp)
            ) {
                Text(
                    text = content,
                    style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 22.sp),
                    fontWeight = if (isHighlight) FontWeight.SemiBold else FontWeight.Normal,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }
        }
    }
}

// =======================================================================
// TAB 2: CENTRAL CATALOG & VERIFICATION
// =======================================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KirtanCatalogTab(
    viewModel: VedaNovaViewModel,
    state: com.example.ui.viewmodel.KirtanUiState,
    allKirtans: List<KirtanEntity>,
    auditLogs: List<com.example.data.model.KirtanAuditLogEntity>
) {
    var selectedSubTab by remember { mutableStateOf(0) } // 0: All Kirtans, 1: Audit Trail

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Sub-Tab Switcher
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                FilterChip(
                    selected = selectedSubTab == 0,
                    onClick = { selectedSubTab = 0 },
                    label = { Text("কীর্তন ভাণ্ডার (${allKirtans.size})", fontWeight = FontWeight.Bold) },
                    leadingIcon = { Icon(Icons.Default.LibraryMusic, null, modifier = Modifier.size(16.dp)) }
                )
                FilterChip(
                    selected = selectedSubTab == 1,
                    onClick = { selectedSubTab = 1 },
                    label = { Text("নিরীক্ষা লগ ও পরিবর্তন ইতিহাস (${auditLogs.size})", fontWeight = FontWeight.Bold) },
                    leadingIcon = { Icon(Icons.Default.History, null, modifier = Modifier.size(16.dp)) }
                )
            }
        }

        if (selectedSubTab == 0) {
            // Search and Filters
            item {
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        OutlinedTextField(
                            value = state.searchQuery,
                            onValueChange = { viewModel.updateKirtanSearchQuery(it) },
                            modifier = Modifier.fillMaxWidth(),
                            placeholder = { Text("শিরোনাম, দেবতা বা থিম দিয়ে খুঁজুন...") },
                            leadingIcon = { Icon(Icons.Default.Search, null) },
                            trailingIcon = {
                                if (state.searchQuery.isNotBlank()) {
                                    IconButton(onClick = { viewModel.updateKirtanSearchQuery("") }) {
                                        Icon(Icons.Default.Clear, null)
                                    }
                                }
                            },
                            shape = RoundedCornerShape(10.dp)
                        )

                        Spacer(modifier = Modifier.height(10.dp))

                        // Status filter chips
                        Text("অবস্থা অনুযায়ী ফিল্টার:", style = MaterialTheme.typography.labelSmall)
                        Spacer(modifier = Modifier.height(4.dp))
                        LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                            val statuses = listOf("ALL" to "সবগুলো", "PUBLISHED" to "প্রকাশিত", "VERIFIED" to "যাচাইকৃত", "DRAFT" to "খসড়া")
                            items(statuses) { (code, label) ->
                                FilterChip(
                                    selected = state.filterStatus == code,
                                    onClick = { viewModel.updateKirtanFilterStatus(code) },
                                    label = { Text(label, fontSize = 11.sp) }
                                )
                            }
                        }
                    }
                }
            }

            // Filtered Items List
            val filtered = allKirtans.filter { k ->
                val matchesQuery = state.searchQuery.isBlank() ||
                        k.title.contains(state.searchQuery, ignoreCase = true) ||
                        k.deity.contains(state.searchQuery, ignoreCase = true) ||
                        k.theme.contains(state.searchQuery, ignoreCase = true) ||
                        k.chorus.contains(state.searchQuery, ignoreCase = true)
                val matchesStatus = state.filterStatus == "ALL" || k.verificationStatus == state.filterStatus
                matchesQuery && matchesStatus
            }

            if (filtered.isEmpty()) {
                item {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(32.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "কোনো কীর্তন পাওয়া যায়নি।",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            } else {
                items(filtered, key = { it.id }) { kirtan ->
                    KirtanCatalogCard(
                        kirtan = kirtan,
                        onSelect = {
                            viewModel.selectKirtanForDetails(kirtan)
                            viewModel.updateKirtanActiveTab(1) // Open Lyrics Tab
                        },
                        onVerify = { viewModel.verifyCurrentKirtan(kirtan.id) },
                        onPublish = { viewModel.publishCurrentKirtan(kirtan.id) },
                        onDelete = { viewModel.deleteKirtan(kirtan.id) }
                    )
                }
            }
        } else {
            // Audit Logs List
            if (auditLogs.isEmpty()) {
                item {
                    Text(
                        text = "এখনও কোনো নিরীক্ষা বা পরিবর্তনের রেকর্ড নেই।",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        modifier = Modifier.padding(16.dp)
                    )
                }
            } else {
                items(auditLogs, key = { it.id }) { log ->
                    Card(
                        shape = RoundedCornerShape(10.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                    ) {
                        Column(modifier = Modifier.padding(12.dp)) {
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = log.action,
                                    fontWeight = FontWeight.Bold,
                                    color = SaffronPrimary,
                                    fontSize = 12.sp
                                )
                                val dateFormat = SimpleDateFormat("dd MMM, hh:mm a", Locale.getDefault())
                                Text(
                                    text = dateFormat.format(Date(log.timestamp)),
                                    fontSize = 10.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "কীর্তন ID: ${log.kirtanId} • সম্পাদনকারী: ${log.adminUsername}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = log.notes,
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun KirtanCatalogCard(
    kirtan: KirtanEntity,
    onSelect: () -> Unit,
    onVerify: () -> Unit,
    onPublish: () -> Unit,
    onDelete: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.2f)),
        elevation = CardDefaults.cardElevation(defaultElevation = 1.dp),
        modifier = Modifier.clickable { onSelect() }
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = kirtan.title,
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        text = "দেবতা: ${kirtan.deity} • সুর: ${kirtan.tempo} • সময়: ${kirtan.durationMinutes} মি.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                // Verification Status Chip
                val statusColor = when (kirtan.verificationStatus) {
                    "PUBLISHED" -> Color(0xFF2E7D32)
                    "VERIFIED" -> SaffronPrimary
                    "NEEDS_REVISION" -> Color(0xFFC62828)
                    else -> Color(0xFF757575)
                }
                Surface(
                    color = statusColor.copy(alpha = 0.15f),
                    border = BorderStroke(1.dp, statusColor),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text(
                        text = kirtan.verificationStatus,
                        fontSize = 10.sp,
                        fontWeight = FontWeight.Bold,
                        modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp),
                        color = statusColor
                    )
                }
            }

            Spacer(modifier = Modifier.height(8.dp))

            // Short Chorus Preview
            Text(
                text = "ধ্রুবপদ: " + kirtan.chorus.take(80) + if (kirtan.chorus.length > 80) "..." else "",
                style = MaterialTheme.typography.bodySmall,
                color = MaterialTheme.colorScheme.onSurface.copy(alpha = 0.85f),
                fontFamily = FontFamily.Serif
            )

            Spacer(modifier = Modifier.height(10.dp))

            // Actions
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.End,
                verticalAlignment = Alignment.CenterVertically
            ) {
                TextButton(onClick = onSelect) {
                    Icon(Icons.Default.Visibility, null, modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("দেখুন ও সুর শুনুন", fontSize = 11.sp)
                }

                if (kirtan.verificationStatus != "PUBLISHED") {
                    TextButton(onClick = onVerify) {
                        Icon(Icons.Default.Verified, null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("যাচাই", fontSize = 11.sp)
                    }

                    TextButton(onClick = onPublish) {
                        Icon(Icons.Default.CloudUpload, null, modifier = Modifier.size(16.dp), tint = Color(0xFF2E7D32))
                        Spacer(modifier = Modifier.width(4.dp))
                        Text("প্রকাশ", fontSize = 11.sp, color = Color(0xFF2E7D32))
                    }
                }

                IconButton(onClick = onDelete, modifier = Modifier.size(32.dp)) {
                    Icon(Icons.Default.DeleteOutline, null, modifier = Modifier.size(16.dp), tint = Color(0xFFC62828))
                }
            }
        }
    }
}

// =======================================================================
// TAB 3: PERFORMANCE & INSTRUMENTS GUIDE
// =======================================================================

@Composable
fun KirtanPerformanceGuideTab(state: com.example.ui.viewmodel.KirtanUiState) {
    val kirtan = state.selectedKirtanForDetails ?: state.currentGeneratedKirtan

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "🪘 বাদ্যযন্ত্র ও বাদন নির্দেশিকা (Instrument Guide)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SaffronPrimary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = kirtan?.instrumentGuide ?: "খোল/মৃদঙ্গ: প্রারম্ভে বিলম্বিত খেমটা তাল, মধ্যভাগে দ্রুত কাহারবা ও তিহাই।\nকরতাল: বিলম্বিত পর্বে একক আঘাত, ক্লাইম্যাক্সে অবিরাম দ্রুত রণন।\nহারমোনিয়াম: কোমল সুরলহরী ও মধ্যম বিস্তার।\nবংশী: প্রারম্ভিক আলাপ ও সমাপ্তিতে শান্ত সুর।",
                        style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 22.sp),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "🎼 পরিবেশন ও লয় ত্বরণ নির্দেশিকা (Performance & Vocal Guide)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SaffronPrimary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = kirtan?.performanceGuide ?: "১. মূল গায়েন প্রথম কল করবেন, সমবেত ভক্তগণ রেসপন্সে দ্বিগুণ উৎসাহে উত্তর দেবেন।\n২. ক্লাইম্যাক্সে সমস্বরে জয়ধ্বনি দিয়ে সংকীর্তন উচ্চ মার্গে পৌঁছে দিতে হবে।\n৩. সমাপনীতে ক্রমশ ধীর লয়ে শান্তিপাঠের সাথে সমাপ্তি ঘটবে।",
                        style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 22.sp),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "📖 শাস্ত্রীয় শ্লোক ও ভিত্তি (Canonical Scripture Citation)",
                        style = MaterialTheme.typography.titleMedium,
                        fontWeight = FontWeight.Bold,
                        color = SaffronPrimary
                    )
                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = kirtan?.scripturalQuotesUsed ?: "শ্রীমদ্ভাগবত পুরাণ ৭.৫.২৩ (শ্রবণং কীর্তনং বিষ্ণোঃ স্মরণে পাদসেবনম্) এবং বৃহন্নারদীয় পুরাণ (হরের্নামৈব কেবলম্)।",
                        style = MaterialTheme.typography.bodyMedium.copy(lineHeight = 22.sp),
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }
    }
}

// =======================================================================
// TAB 4: KIRTAN AUDIO & DEVOTIONAL MUSIC STUDIO
// =======================================================================

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun KirtanAudioStudioTab(
    viewModel: VedaNovaViewModel,
    state: com.example.ui.viewmodel.KirtanUiState
) {
    val playerState by viewModel.audioPlayerState.collectAsStateWithLifecycle()
    val allAudio by viewModel.allKirtanAudio.collectAsStateWithLifecycle()
    val kirtan = state.selectedKirtanForDetails ?: state.currentGeneratedKirtan
    val activeAudio = state.currentGeneratedAudio ?: playerState.currentAudio ?: allAudio.firstOrNull { it.kirtanId == kirtan?.id }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp)
            .testTag("kirtan_audio_studio_tab"),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Banner Header Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, SaffronPrimary.copy(alpha = 0.35f)),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(44.dp)
                                .clip(RoundedCornerShape(12.dp))
                                .background(SaffronPrimary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text("🪕", fontSize = 22.sp)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column(modifier = Modifier.weight(1f)) {
                            Text(
                                text = "সংকীর্তন অডিও ও ভক্তিগীতি স্টুডিও",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "বাস্তব অ্যাকোস্টিক সিন্থেসিস • তানপুরা, খোল ও করতাল • জিরো-কপিরাইট",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        // Verification Tag
                        Surface(
                            color = Color(0xFF1B5E20).copy(alpha = 0.12f),
                            shape = RoundedCornerShape(16.dp),
                            border = BorderStroke(1.dp, Color(0xFF2E7D32))
                        ) {
                            Text(
                                text = "100% Real Audio",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFF2E7D32),
                                modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                            )
                        }
                    }

                    if (kirtan != null) {
                        Spacer(modifier = Modifier.height(12.dp))
                        Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.5f))
                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "পদাবলী: ${kirtan.title}",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = SaffronPrimary
                            )
                            Text(
                                text = "দেবতা: ${kirtan.deity} • ${kirtan.tempo}",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // Audio Generation Controller Card
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "🎛️ অডিও সিন্থেসিস কন্ট্রোল প্যানেল",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                    Spacer(modifier = Modifier.height(10.dp))

                    // Duration Selection Chips
                    Text(
                        text = "অডিও সময়কাল (Target Duration):",
                        style = MaterialTheme.typography.labelSmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        listOf(
                            15 to "১৫ সে. (নমুনা)",
                            30 to "৩০ সে. (স্ট্যান্ডার্ড)",
                            60 to "৬০ সে. (বিস্তৃত)",
                            90 to "৯০ সে. (পূর্ণ চক্র)"
                        ).forEach { (sec, label) ->
                            FilterChip(
                                selected = state.audioTargetDurationSeconds == sec,
                                onClick = { viewModel.updateAudioTargetDuration(sec) },
                                label = { Text(label, fontSize = 11.sp) },
                                colors = FilterChipDefaults.filterChipColors(
                                    selectedContainerColor = SaffronPrimary.copy(alpha = 0.2f),
                                    selectedLabelColor = SaffronPrimary
                                )
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))

                    // Generation CTA Button
                    Button(
                        onClick = {
                            if (kirtan != null) {
                                viewModel.generateAudioForCurrentKirtan(kirtan.id)
                            }
                        },
                        enabled = !state.isGeneratingAudio && kirtan != null,
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(50.dp)
                            .testTag("synthesize_kirtan_audio_button"),
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
                    ) {
                        if (state.isGeneratingAudio) {
                            CircularProgressIndicator(
                                modifier = Modifier.size(20.dp),
                                color = Color.White,
                                strokeWidth = 2.dp
                            )
                            Spacer(modifier = Modifier.width(10.dp))
                            Text(
                                text = "অডিও সিন্থেসিস হচ্ছে...",
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        } else {
                            Icon(Icons.Default.GraphicEq, null, tint = Color.White)
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "আসল সংকীর্তন অডিও তৈরি করুন (${state.audioTargetDurationSeconds} সেকেন্ড)",
                                color = Color.White,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    // Generation Progress Display
                    if (state.isGeneratingAudio) {
                        Spacer(modifier = Modifier.height(14.dp))
                        Column {
                            val stageText = when (state.audioGenerationStage) {
                                AudioGenerationStage.IDLE -> "প্রস্তুত"
                                AudioGenerationStage.QUEUED -> "১/৭ অপেক্ষমান..."
                                AudioGenerationStage.ANALYZING -> "২/৭ কীর্তনের পদাবলী ও ছন্দ কাঠামো বিশ্লেষণ..."
                                AudioGenerationStage.GENERATING_MUSIC -> "৩/৭ তানপুরা, খোল ও করতাল ফিজিক্যাল মডেলিং সিন্থেসিস..."
                                AudioGenerationStage.GENERATING_VOCAL -> "৪/৭ ভক্তকণ্ঠ ফর্ম্যান্ট ও সুরলহরী মেলবন্ধন..."
                                AudioGenerationStage.MIXING -> "৫/৭ মাল্টি-ট্র্যাক মিক্সিং ও অ্যাকোস্টিক ব্যালেন্স..."
                                AudioGenerationStage.MASTERING -> "৬/৭ EBU R128 (-14 LUFS) স্ট্যান্ডার্ডে মাস্টারিং..."
                                AudioGenerationStage.VERIFYING -> "৭/৭ শাস্ত্রীয় শুদ্ধতা ও কপিরাইট সুরক্ষা যাচাই..."
                                AudioGenerationStage.COMPLETED -> "অডিও সিন্থেসিস ও WAV এনকোডিং সম্পন্ন!"
                                AudioGenerationStage.FAILED -> "অডিও তৈরিতে ত্রুটি হয়েছে।"
                                AudioGenerationStage.CANCELLED -> "বাতিল করা হয়েছে।"
                            }

                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = stageText,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.SemiBold,
                                    color = SaffronPrimary
                                )
                                Text(
                                    text = "${(state.audioGenerationProgress * 100).toInt()}%",
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = SaffronPrimary
                                )
                            }
                            Spacer(modifier = Modifier.height(6.dp))
                            LinearProgressIndicator(
                                progress = state.audioGenerationProgress,
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .height(6.dp)
                                    .clip(RoundedCornerShape(3.dp)),
                                color = SaffronPrimary,
                                trackColor = SaffronPrimary.copy(alpha = 0.2f)
                            )
                        }
                    }
                }
            }
        }

        // Live Audio Player Card
        if (activeAudio != null) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, SaffronPrimary.copy(alpha = 0.4f)),
                    elevation = CardDefaults.cardElevation(defaultElevation = 4.dp)
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        // Raga & Tala Header Bar
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                Text(
                                    text = "রাগ: ${activeAudio.ragaName} • তাল: ${activeAudio.talaName}",
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = SaffronPrimary
                                )
                                Text(
                                    text = "${activeAudio.bpm} BPM • 16-bit PCM Stereo (${activeAudio.sampleRate} Hz)",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            // Status Pill
                            Surface(
                                color = when (activeAudio.status) {
                                    "AUDIO_PUBLISHED" -> Color(0xFF2E7D32).copy(alpha = 0.15f)
                                    "AUDIO_VERIFIED" -> SaffronPrimary.copy(alpha = 0.15f)
                                    else -> Color(0xFF757575).copy(alpha = 0.15f)
                                },
                                shape = RoundedCornerShape(12.dp)
                            ) {
                                Text(
                                    text = activeAudio.status,
                                    fontSize = 11.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = when (activeAudio.status) {
                                        "AUDIO_PUBLISHED" -> Color(0xFF2E7D32)
                                        "AUDIO_VERIFIED" -> SaffronPrimary
                                        else -> Color(0xFF757575)
                                    },
                                    modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Dynamic Section Indicator (Synced with Playback)
                        val activeSectionName = if (playerState.durationMs > 0) {
                            val ratio = playerState.currentPositionMs.toFloat() / playerState.durationMs.toFloat()
                            when {
                                ratio < 0.15f -> "১. বন্দনা (Opening Invocation)"
                                ratio < 0.35f -> "২. ধ্রুবপদ (Main Chorus)"
                                ratio < 0.55f -> "৩. প্রশ্নোত্তর সংকীর্তন (Call & Response)"
                                ratio < 0.72f -> "৪. অন্তরা পদাবলী (Verses / Antara)"
                                ratio < 0.85f -> "৫. দ্রুত ক্লাইম্যাক্স (Climax Acceleration)"
                                ratio < 0.94f -> "৬. সমাপনী সঞ্চারণ (Ending Transition)"
                                else -> "৭. শান্তিপাঠ ও বিশ্রাম (Closing Prayer)"
                            }
                        } else {
                            "১. বন্দনা (Opening Invocation)"
                        }

                        Surface(
                            color = SaffronPrimary.copy(alpha = 0.1f),
                            shape = RoundedCornerShape(10.dp),
                            border = BorderStroke(1.dp, SaffronPrimary.copy(alpha = 0.3f)),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                modifier = Modifier.padding(horizontal = 12.dp, vertical = 8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    Icons.Default.GraphicEq,
                                    null,
                                    tint = SaffronPrimary,
                                    modifier = Modifier.size(18.dp)
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Column {
                                    Text(
                                        text = "বর্তমান গতিশীল স্তর (Active Section):",
                                        fontSize = 10.sp,
                                        color = MaterialTheme.colorScheme.onSurfaceVariant
                                    )
                                    Text(
                                        text = activeSectionName,
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = SaffronPrimary
                                    )
                                }
                            }
                        }

                        Spacer(modifier = Modifier.height(12.dp))

                        // Stem Selection Controls
                        Text(
                            text = "অডিও স্টেম নির্বাচন (Audio Stem):",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf(
                                "MASTER" to "🎧 মাস্টার মিক্স",
                                "MUSIC_ONLY" to "🪕 বাদ্যযন্ত্র একক",
                                "VOCAL_ONLY" to "🎤 ভক্তকণ্ঠ একক"
                            ).forEach { (stem, label) ->
                                FilterChip(
                                    selected = playerState.activeStem == stem,
                                    onClick = { viewModel.switchKirtanStem(stem) },
                                    label = { Text(label, fontSize = 11.sp) },
                                    colors = FilterChipDefaults.filterChipColors(
                                        selectedContainerColor = SaffronPrimary.copy(alpha = 0.2f),
                                        selectedLabelColor = SaffronPrimary
                                    )
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(14.dp))

                        // Seek Slider & Time Counters
                        val progressFraction = if (playerState.durationMs > 0) {
                            (playerState.currentPositionMs.toFloat() / playerState.durationMs.toFloat()).coerceIn(0f, 1f)
                        } else 0f

                        Slider(
                            value = progressFraction,
                            onValueChange = { viewModel.seekKirtanAudio(it) },
                            colors = SliderDefaults.colors(
                                thumbColor = SaffronPrimary,
                                activeTrackColor = SaffronPrimary,
                                inactiveTrackColor = SaffronPrimary.copy(alpha = 0.2f)
                            ),
                            modifier = Modifier.fillMaxWidth()
                        )

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            val curSec = playerState.currentPositionMs / 1000
                            val totSec = if (playerState.durationMs > 0) playerState.durationMs / 1000 else activeAudio.durationSeconds
                            Text(
                                text = String.format(Locale.US, "%02d:%02d", curSec / 60, curSec % 60),
                                style = MaterialTheme.typography.labelMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = String.format(Locale.US, "%02d:%02d", totSec / 60, totSec % 60),
                                style = MaterialTheme.typography.labelMedium,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Play / Pause & Speed Controls
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Speed chips
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                listOf(0.75f, 1.0f, 1.25f).forEach { speed ->
                                    FilterChip(
                                        selected = playerState.playbackSpeed == speed,
                                        onClick = { viewModel.setKirtanPlaybackSpeed(speed) },
                                        label = { Text("${speed}x", fontSize = 10.sp) }
                                    )
                                }
                            }

                            // Main Play / Pause Button
                            Button(
                                onClick = {
                                    if (playerState.isPlaying) {
                                        viewModel.pauseKirtanAudio()
                                    } else {
                                        viewModel.playKirtanAudio(activeAudio)
                                    }
                                },
                                shape = CircleShape,
                                colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                                modifier = Modifier
                                    .size(52.dp)
                                    .testTag("play_pause_audio_button"),
                                contentPadding = PaddingValues(0.dp)
                            ) {
                                Icon(
                                    imageVector = if (playerState.isPlaying) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = if (playerState.isPlaying) "Pause" else "Play",
                                    tint = Color.White,
                                    modifier = Modifier.size(28.dp)
                                )
                            }

                            // File Size Tag
                            Text(
                                text = "${activeAudio.fileSizeBytes / 1024} KB",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }

            // Originality & Copyright Safety Card
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.45f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "🛡️ কপিরাইট ও শাস্ত্রীয় সুরক্ষা পরীক্ষণ (Copyright & Dharma Safety)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(8.dp))

                        val safetyItems = listOf(
                            "✅ জিরো-কপিরাইট সুর গ্যারান্টি: শাস্ত্রীয় রাগভিত্তিক মৌলিক স্বরবিন্যাস; কোনো মানবশিল্পীর গান ক্লোন নয়।",
                            "✅ জিরো-আর্টিস্ট ক্লোনিং: ভক্তিভাব সমন্বিত হারমোনিক অ্যাকোস্টিক মডেলিং, কৃত্রিম মানুষের স্বর নকল সম্পূর্ণ নিষিদ্ধ।",
                            "✅ EBU R128 মাস্টারিং: সম্প্রচার মানের -14 LUFS নরম্যালাইজেশন ও সফট স্যাচুরেশন লিমাইটার।",
                            "✅ লসলেস WAV মাস্টার: 16-bit Linear PCM, 44,100 Hz স্টেরিও হাই-ফিডেলিটি অডিও।"
                        )
                        safetyItems.forEach { item ->
                            Text(
                                text = item,
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.padding(vertical = 2.dp)
                            )
                        }
                    }
                }
            }

            // Verification & Publishing Actions Card
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Text(
                            text = "🏛️ শাসন ও প্রকাশনা (Governance & Publication)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { viewModel.verifyCurrentKirtanAudio(activeAudio.id) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.secondary)
                            ) {
                                Icon(Icons.Default.Verified, null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("অডিও যাচাই", fontSize = 12.sp)
                            }

                            Button(
                                onClick = { viewModel.publishCurrentKirtanAudio(activeAudio.id) },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                            ) {
                                Icon(Icons.Default.CloudUpload, null, modifier = Modifier.size(16.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("ক্যাটালগে প্রকাশ", fontSize = 12.sp)
                            }

                            OutlinedButton(
                                onClick = { viewModel.deleteCurrentKirtanAudio(activeAudio.id) },
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Delete, null, modifier = Modifier.size(16.dp), tint = Color(0xFFC62828))
                            }
                        }
                    }
                }
            }

            // Stems & Multi-Track Inspector
            if (state.currentAudioTracks.isNotEmpty()) {
                item {
                    Card(
                        shape = RoundedCornerShape(14.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
                    ) {
                        Column(modifier = Modifier.padding(14.dp)) {
                            Text(
                                text = "🎚️ মাল্টি-ট্র্যাক লেয়ার ও বাদ্যযন্ত্র রূপরেখা (${state.currentAudioTracks.size} টি ট্র্যাক)",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = SaffronPrimary
                            )
                            Spacer(modifier = Modifier.height(8.dp))
                            state.currentAudioTracks.forEach { track ->
                                Row(
                                    modifier = Modifier
                                        .fillMaxWidth()
                                        .padding(vertical = 4.dp),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Text(
                                            text = when (track.trackType) {
                                                "TANPURA" -> "🪕"
                                                "HARMONIUM" -> "🎹"
                                                "KHOL" -> "🥁"
                                                "KARTAL" -> "🔔"
                                                "VOCAL" -> "🎤"
                                                else -> "🎵"
                                            },
                                            fontSize = 16.sp
                                        )
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Column {
                                            Text(
                                                text = track.trackName,
                                                fontSize = 12.sp,
                                                fontWeight = FontWeight.SemiBold,
                                                color = MaterialTheme.colorScheme.onSurface
                                            )
                                            Text(
                                                text = "${track.instrument} • ${track.startTime}s - ${track.endTime}s",
                                                fontSize = 10.sp,
                                                color = MaterialTheme.colorScheme.onSurfaceVariant
                                            )
                                        }
                                    }
                                    Text(
                                        text = "${(track.volumeLevel * 100).toInt()}% Vol",
                                        fontSize = 11.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = SaffronPrimary
                                    )
                                }
                                Divider(color = MaterialTheme.colorScheme.outlineVariant.copy(alpha = 0.3f))
                            }
                        }
                    }
                }
            }
        }

        // All Generated Kirtan Audio Catalog List
        if (allAudio.isNotEmpty()) {
            item {
                Text(
                    text = "📚 সংরক্ষিত কীর্তন অডিও তালিকা (${allAudio.size} টি)",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onSurface
                )
            }

            items(allAudio) { audioItem ->
                Card(
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable { viewModel.playKirtanAudio(audioItem) }
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            IconButton(
                                onClick = { viewModel.playKirtanAudio(audioItem) },
                                modifier = Modifier
                                    .size(36.dp)
                                    .background(SaffronPrimary.copy(alpha = 0.15f), CircleShape)
                            ) {
                                Icon(
                                    imageVector = if (playerState.isPlaying && playerState.currentAudio?.id == audioItem.id) Icons.Default.Pause else Icons.Default.PlayArrow,
                                    contentDescription = "Play",
                                    tint = SaffronPrimary,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "রাগ ${audioItem.ragaName} • ${audioItem.talaName}",
                                    fontSize = 13.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Text(
                                    text = "${audioItem.durationSeconds}s • ${audioItem.format} • ${audioItem.status}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }

                        Surface(
                            color = if (audioItem.status == "AUDIO_PUBLISHED") Color(0xFF2E7D32).copy(alpha = 0.15f) else SaffronPrimary.copy(alpha = 0.15f),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Text(
                                text = audioItem.status,
                                fontSize = 10.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (audioItem.status == "AUDIO_PUBLISHED") Color(0xFF2E7D32) else SaffronPrimary,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                            )
                        }
                    }
                }
            }
        }
    }
}
