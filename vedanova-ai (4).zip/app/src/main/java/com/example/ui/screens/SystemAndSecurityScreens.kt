package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.HealthBadge
import com.example.ui.components.SectionHeader
import com.example.ui.components.StatusPill
import com.example.ui.theme.*
import com.example.ui.viewmodel.VedaNovaViewModel

@Composable
fun SystemHealthScreen(viewModel: VedaNovaViewModel) {
    val health by viewModel.healthStatus.collectAsStateWithLifecycle()
    val featureList by viewModel.featureHealthList.collectAsStateWithLifecycle()
    val isAuditing by viewModel.isAuditingHealth.collectAsStateWithLifecycle()
    val lastAuditTimestamp by viewModel.lastAuditTimestamp.collectAsStateWithLifecycle()

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Feature Health Map Component
        item {
            com.example.ui.components.FeatureHealthMapSection(viewModel = viewModel)
        }

        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.MonitorHeart, contentDescription = null, tint = StatusGreen)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "System Infrastructure Matrix",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Underlying component runtime status (synchronized with Live Feature Health Auditor).",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        item {
            val subsystems = listOf(
                "Core Backend Gateway" to (health.backendStatus to "All REST and RPC handlers nominal (Operational)"),
                "Room SQLite Database" to (health.databaseStatus to "Indexed, 12 tables synchronized, zero disk corruption"),
                "AI Orchestrator Engine" to (health.aiProviderStatus to "Multi-tier language, intent & canonical heuristics operational"),
                "API Gateway Platform" to (health.apiGatewayStatus to "Rate limiter & HMAC authentication filters active"),
                "Knowledge Base Engine" to (health.knowledgeEngineStatus to "Canonical scripture grounding nodes connected"),
                "Research Engine" to (health.researchEngineStatus to "Multi-source scriptural synthesis pipeline active"),
                "Verification Engine" to (health.verificationEngineStatus to "Shruti & Smriti authority validator online"),
                "Authentication & RBAC" to (health.authStatus to "Session enforcement & audit logging active"),
                "Local Storage Engine" to (health.storageStatus to "Encrypted shared storage nominal"),
                "Backup & Snapshot Service" to (health.backupStatus to "Automated snapshots verified with SHA-256 checksums")
            )

            Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                subsystems.forEach { (name, pair) ->
                    val (status, desc) = pair
                    Card(
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                        shape = RoundedCornerShape(14.dp),
                        border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(14.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = name,
                                    style = MaterialTheme.typography.titleMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onSurface
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = desc,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                            HealthBadge(status = status, label = "Status")
                        }
                    }
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

@Composable
fun SecurityCenterScreen(viewModel: VedaNovaViewModel) {
    val securityProtocols = listOf(
        "Zero Hardcoded Secrets" to "API keys & credentials are dynamically injected via BuildConfig & Secrets plugin. No hardcoded tokens in APK binaries.",
        "HMAC SHA-256 Client Hashing" to "All external client keys are validated against hashed values with masked previews in UI.",
        "Role-Based Access Control (RBAC)" to "Fine-grained permissions strictly enforced for Super Admin, Knowledge Manager, Reviewer, and Developer roles.",
        "Strict Scripture Guardrails" to "AI synthesis requires positive canonical grounding to prevent fabricated shlokas or false traditions.",
        "Dynamic Rate Limiting" to "Leaky bucket rate limiters protect the Gateway from abusive client traffic per minute & daily quotas.",
        "Immutable Audit Trails" to "Every administrative modification is signed with timestamp, admin username, and target entity ID."
    )

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Shield, contentDescription = null, tint = SaffronPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Security & Governance Center",
                            style = MaterialTheme.typography.titleLarge,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                    }
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(
                        text = "Security policies, credential management safeguards, and canonical verification compliance.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            }
        }

        items(securityProtocols) { (title, desc) ->
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(14.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = SaffronLight
                        )
                        StatusPill(text = "ENFORCED", color = StatusGreen)
                    }
                    Spacer(modifier = Modifier.height(6.dp))
                    Text(
                        text = desc,
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurface
                    )
                }
            }
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
        }
    }
}

