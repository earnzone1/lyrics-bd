package com.example.ui.screens

import android.widget.Toast
import androidx.compose.animation.*
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.lazy.rememberLazyListState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowBack
import androidx.compose.material.icons.automirrored.filled.HelpOutline
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.automirrored.filled.VolumeUp
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalClipboardManager
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.AnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import coil.compose.AsyncImage
import com.example.ui.components.StatusPill
import com.example.ui.theme.*
import com.example.ui.viewmodel.ScreenDestination
import com.example.ui.viewmodel.VedaNovaViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun PublicChatScreen(viewModel: VedaNovaViewModel) {
    val context = LocalContext.current
    val clipboardManager = LocalClipboardManager.current
    val messages by viewModel.publicChatMessages.collectAsStateWithLifecycle()
    val query by viewModel.publicChatQuery.collectAsStateWithLifecycle()
    val isLoading by viewModel.publicIsLoading.collectAsStateWithLifecycle()
    val clarificationOptions by viewModel.publicClarificationOptions.collectAsStateWithLifecycle()
    val lastResponse by viewModel.lastPublicResponse.collectAsStateWithLifecycle()
    val currentlySpeaking by viewModel.currentlySpeakingText.collectAsStateWithLifecycle()
    val liveVoiceState by viewModel.liveVoiceState.collectAsStateWithLifecycle()

    val listState = rememberLazyListState()

    var reportingMessageText by remember { mutableStateOf<String?>(null) }
    var reportReason by remember { mutableStateOf("") }
    var showReportDialog by remember { mutableStateOf(false) }

    // Message reaction tracking: index to liked/disliked state (1 = liked, -1 = disliked)
    val reactionMap = remember { mutableStateMapOf<Int, Int>() }

    // Auto-scroll when new messages arrive
    LaunchedEffect(messages.size, isLoading) {
        if (messages.isNotEmpty()) {
            listState.animateScrollToItem(messages.size)
        }
    }

    val quickSuggestions = listOf(
        "শ্রীমদ্ভগবদ্গীতার মূল বার্তা কী?",
        "গায়ত্রী মন্ত্রের অর্থ ও গুরুত্ব",
        "কর্মযোগ ও জ্ঞানযোগের পার্থক্য",
        "অদ্বৈত বেদান্ত দর্শন কী?",
        "আজকের তিথি ও পূজার বিধি",
        "ওঁ নমঃ শিবায় মন্ত্রের তাৎপর্য"
    )

    Scaffold(
        modifier = Modifier
            .fillMaxSize()
            .imePadding(),
        topBar = {
            TopAppBar(
                title = {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Surface(
                            shape = CircleShape,
                            color = SaffronPrimary.copy(alpha = 0.2f),
                            modifier = Modifier.size(38.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Text("🕉️", fontSize = 20.sp)
                            }
                        }
                        Spacer(modifier = Modifier.width(10.dp))
                        Column {
                            Text(
                                text = "VedaNova Dharma AI",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Box(
                                    modifier = Modifier
                                        .size(7.dp)
                                        .clip(CircleShape)
                                        .background(StatusGreen)
                                )
                                Spacer(modifier = Modifier.width(5.dp))
                                Text(
                                    text = "অনলাইন • প্রামাণ্য শাস্ত্রীয় জ্ঞান",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = SaffronLight,
                                    fontSize = 11.sp
                                )
                            }
                        }
                    }
                },
                navigationIcon = {
                    IconButton(
                        onClick = { viewModel.navigateTo(ScreenDestination.DASHBOARD) },
                        modifier = Modifier.testTag("public_chat_back_button")
                    ) {
                        Icon(
                            imageVector = Icons.AutoMirrored.Filled.ArrowBack,
                            contentDescription = "Back to Control Center",
                            tint = SaffronPrimary
                        )
                    }
                },
                actions = {
                    // Reset / Clear Conversation
                    IconButton(
                        onClick = {
                            viewModel.resetPublicChat()
                            Toast.makeText(context, "নতুন কথোপকথন শুরু হয়েছে", Toast.LENGTH_SHORT).show()
                        },
                        modifier = Modifier.testTag("public_chat_reset_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "নতুন কথোপকথন শুরু করুন",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = MaterialTheme.colorScheme.surface,
                    titleContentColor = MaterialTheme.colorScheme.onSurface
                )
            )
        },
        bottomBar = {
            // Pinned Bottom Composer with Inset and Keyboard Handling
            Surface(
                color = MaterialTheme.colorScheme.surface,
                tonalElevation = 6.dp,
                shadowElevation = 8.dp,
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.25f)),
                modifier = Modifier
                    .fillMaxWidth()
                    .navigationBarsPadding()
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 12.dp, vertical = 8.dp)
                ) {
                    // Clarification suggestions from AI (if any)
                    if (clarificationOptions.isNotEmpty()) {
                        Text(
                            text = "স্পষ্টীকরণের জন্য নির্বাচন করুন:",
                            style = MaterialTheme.typography.labelSmall,
                            color = SaffronPrimary,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(bottom = 4.dp, start = 4.dp)
                        )
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(bottom = 6.dp)
                        ) {
                            items(clarificationOptions) { option ->
                                SuggestionChip(
                                    onClick = { viewModel.selectClarificationOption(option) },
                                    label = { Text(option, fontSize = 12.sp, maxLines = 1) },
                                    colors = SuggestionChipDefaults.suggestionChipColors(
                                        containerColor = SaffronPrimary.copy(alpha = 0.15f),
                                        labelColor = MaterialTheme.colorScheme.onSurface
                                    ),
                                    border = BorderStroke(1.dp, SaffronPrimary.copy(alpha = 0.4f)),
                                    shape = RoundedCornerShape(16.dp)
                                )
                            }
                        }
                    }

                    // Input Composer Row
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        // Microphone button for voice input
                        IconButton(
                            onClick = {
                                viewModel.triggerSingleVoiceInput()
                                Toast.makeText(context, "বলুন, শুনছি...", Toast.LENGTH_SHORT).show()
                            },
                            modifier = Modifier
                                .size(44.dp)
                                .testTag("public_chat_mic_button")
                        ) {
                            Icon(
                                imageVector = Icons.Default.Mic,
                                contentDescription = "ভয়েস ইনপুট",
                                tint = if (liveVoiceState == com.example.domain.voice.LiveVoiceState.LISTENING) SaffronPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                modifier = Modifier.size(24.dp)
                            )
                        }

                        Spacer(modifier = Modifier.width(4.dp))

                        // Text Input
                        OutlinedTextField(
                            value = query,
                            onValueChange = { viewModel.setPublicChatQuery(it) },
                            placeholder = {
                                Text(
                                    text = "সনাতন ধর্ম, গীতা, বেদ বা দর্শন সম্পর্কে জিজ্ঞাসা করুন...",
                                    style = MaterialTheme.typography.bodyMedium,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f),
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("public_chat_input_field"),
                            shape = RoundedCornerShape(24.dp),
                            maxLines = 4,
                            minLines = 1,
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = SaffronPrimary,
                                unfocusedBorderColor = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f),
                                focusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f),
                                unfocusedContainerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.2f)
                            )
                        )

                        Spacer(modifier = Modifier.width(6.dp))

                        // Send Button
                        IconButton(
                            onClick = {
                                if (query.isNotBlank() && !isLoading) {
                                    viewModel.sendPublicChatMessage()
                                }
                            },
                            enabled = query.isNotBlank() && !isLoading,
                            modifier = Modifier
                                .size(44.dp)
                                .clip(CircleShape)
                                .background(
                                    if (query.isNotBlank() && !isLoading) SaffronPrimary else MaterialTheme.colorScheme.surfaceVariant
                                )
                                .testTag("public_chat_send_button")
                        ) {
                            if (isLoading) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    color = Color.White,
                                    strokeWidth = 2.dp
                                )
                            } else {
                                Icon(
                                    imageVector = Icons.AutoMirrored.Filled.Send,
                                    contentDescription = "পাঠান",
                                    tint = if (query.isNotBlank()) Color.White else MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.5f),
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }
        }
    ) { paddingValues ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
                .background(MaterialTheme.colorScheme.background)
        ) {
            // Quick Topic Suggestion Carousel when conversation is short
            if (messages.size <= 2) {
                Surface(
                    color = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.4f),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(horizontal = 14.dp, vertical = 8.dp)) {
                        Text(
                            text = "💡 জনপ্রিয় শাস্ত্রীয় জিজ্ঞাসা:",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.SemiBold,
                            color = VedicGold
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        LazyRow(
                            horizontalArrangement = Arrangement.spacedBy(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            items(quickSuggestions) { prompt ->
                                SuggestionChip(
                                    onClick = {
                                        viewModel.setPublicChatQuery(prompt)
                                        viewModel.sendPublicChatMessage(prompt)
                                    },
                                    label = {
                                        Text(
                                            text = prompt,
                                            style = MaterialTheme.typography.bodySmall,
                                            maxLines = 1
                                        )
                                    },
                                    shape = RoundedCornerShape(14.dp),
                                    colors = SuggestionChipDefaults.suggestionChipColors(
                                        containerColor = MaterialTheme.colorScheme.surface,
                                        labelColor = MaterialTheme.colorScheme.onSurface
                                    ),
                                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.4f))
                                )
                            }
                        }
                    }
                }
            }

            // Message History
            LazyColumn(
                state = listState,
                modifier = Modifier
                    .fillMaxWidth()
                    .weight(1f),
                contentPadding = PaddingValues(horizontal = 14.dp, vertical = 12.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                itemsIndexed(messages) { index, (sender, text) ->
                    val isUser = sender == "USER"
                    val isImage = sender == "AI_IMAGE"

                    PublicChatMessageBubble(
                        isUser = isUser,
                        isImage = isImage,
                        text = text,
                        isCurrentlySpeaking = currentlySpeaking == text,
                        reaction = reactionMap[index] ?: 0,
                        onCopy = {
                            clipboardManager.setText(AnnotatedString(text))
                            Toast.makeText(context, "টেক্সট কপি করা হয়েছে", Toast.LENGTH_SHORT).show()
                        },
                        onToggleVoice = {
                            viewModel.toggleSpeakMessage(text)
                        },
                        onLike = {
                            reactionMap[index] = if (reactionMap[index] == 1) 0 else 1
                            Toast.makeText(context, "ধন্যবাদ! আপনার ইতিবাচক প্রতিক্রিয়া গৃহীত হয়েছে।", Toast.LENGTH_SHORT).show()
                        },
                        onDislike = {
                            reactionMap[index] = if (reactionMap[index] == -1) 0 else -1
                            Toast.makeText(context, "মতামত গৃহীত হয়েছে। আমরা শাস্ত্রীয় নির্ভুলতা আরও উন্নত করব।", Toast.LENGTH_SHORT).show()
                        },
                        onReport = {
                            reportingMessageText = text
                            reportReason = ""
                            showReportDialog = true
                        }
                    )
                }

                // AI Processing Indicator
                if (isLoading) {
                    item {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 8.dp, horizontal = 4.dp)
                        ) {
                            Surface(
                                shape = CircleShape,
                                color = SaffronPrimary.copy(alpha = 0.15f),
                                modifier = Modifier.size(32.dp)
                            ) {
                                Box(contentAlignment = Alignment.Center) {
                                    Text("🕉️", fontSize = 16.sp)
                                }
                            }
                            Spacer(modifier = Modifier.width(10.dp))
                            Surface(
                                color = MaterialTheme.colorScheme.surfaceVariant,
                                shape = RoundedCornerShape(14.dp),
                                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))
                            ) {
                                Row(
                                    modifier = Modifier.padding(horizontal = 14.dp, vertical = 10.dp),
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    CircularProgressIndicator(
                                        modifier = Modifier.size(16.dp),
                                        color = SaffronPrimary,
                                        strokeWidth = 2.dp
                                    )
                                    Spacer(modifier = Modifier.width(10.dp))
                                    Text(
                                        text = "বেদ, উপনিষদ ও শাস্ত্রীয় তথ্য অনুসন্ধান চলছে...",
                                        style = MaterialTheme.typography.bodySmall,
                                        color = SaffronLight
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }

    // Devotee Correction & Report Dialog
    if (showReportDialog && reportingMessageText != null) {
        AlertDialog(
            onDismissRequest = { showReportDialog = false },
            icon = {
                Icon(
                    imageVector = Icons.Default.Flag,
                    contentDescription = null,
                    tint = SaffronPrimary,
                    modifier = Modifier.size(28.dp)
                )
            },
            title = {
                Text(
                    text = "শাস্ত্রীয় তথ্যের সংশোধন বা রিপোর্ট",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
            },
            text = {
                Column(verticalArrangement = Arrangement.spacedBy(10.dp)) {
                    Text(
                        text = "যদি এই উত্তরে কোনো তথ্যের ভুল বা অসঙ্গতি থাকে, অনুগ্রহ করে সঠিক রেফারেন্স সহ উল্লেখ করুন। আমাদের শাস্ত্রীয় পরিষদ এটি পর্যালোচনা করবে।",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    OutlinedTextField(
                        value = reportReason,
                        onValueChange = { reportReason = it },
                        label = { Text("আপনার পর্যবেক্ষণ বা শাস্ত্রীয় প্রমাণ") },
                        placeholder = { Text("যেমন: গীতার এই শ্লোকের সঠিক অর্থ শঙ্কর ভাষ্য অনুযায়ী...") },
                        modifier = Modifier.fillMaxWidth(),
                        minLines = 3,
                        maxLines = 5,
                        shape = RoundedCornerShape(12.dp)
                    )
                }
            },
            confirmButton = {
                Button(
                    onClick = {
                        val snippet = reportingMessageText?.take(150) ?: ""
                        viewModel.submitPublicFeedback(reportReason, snippet) {
                            Toast.makeText(context, "আপনার রিপোর্ট ও পরামর্শ সফলভাবে জমা হয়েছে।", Toast.LENGTH_LONG).show()
                        }
                        showReportDialog = false
                    },
                    colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                    enabled = reportReason.isNotBlank()
                ) {
                    Text("জমা দিন", color = Color.White)
                }
            },
            dismissButton = {
                OutlinedButton(onClick = { showReportDialog = false }) {
                    Text("বাতিল")
                }
            }
        )
    }
}

@Composable
private fun PublicChatMessageBubble(
    isUser: Boolean,
    isImage: Boolean,
    text: String,
    isCurrentlySpeaking: Boolean,
    reaction: Int,
    onCopy: () -> Unit,
    onToggleVoice: () -> Unit,
    onLike: () -> Unit,
    onDislike: () -> Unit,
    onReport: () -> Unit
) {
    Row(
        modifier = Modifier.fillMaxWidth(),
        horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
    ) {
        if (!isUser) {
            Surface(
                shape = CircleShape,
                color = SaffronPrimary.copy(alpha = 0.15f),
                modifier = Modifier
                    .size(34.dp)
                    .align(Alignment.Top)
            ) {
                Box(contentAlignment = Alignment.Center) {
                    Text("🕉️", fontSize = 16.sp)
                }
            }
            Spacer(modifier = Modifier.width(8.dp))
        }

        Column(
            modifier = Modifier.fillMaxWidth(if (isUser) 0.85f else 0.92f),
            horizontalAlignment = if (isUser) Alignment.End else Alignment.Start
        ) {
            Surface(
                shape = RoundedCornerShape(
                    topStart = 16.dp,
                    topEnd = 16.dp,
                    bottomStart = if (isUser) 16.dp else 4.dp,
                    bottomEnd = if (isUser) 4.dp else 16.dp
                ),
                color = if (isUser) SaffronPrimary.copy(alpha = 0.18f) else MaterialTheme.colorScheme.surfaceVariant,
                border = BorderStroke(
                    1.dp,
                    if (isUser) SaffronPrimary.copy(alpha = 0.45f) else MaterialTheme.colorScheme.outline.copy(alpha = 0.35f)
                ),
                shadowElevation = if (isUser) 1.dp else 2.dp,
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    // Header label
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = if (isUser) "আপনি (জিজ্ঞাসু)" else "VedaNova AI",
                            style = MaterialTheme.typography.labelSmall,
                            fontWeight = FontWeight.Bold,
                            color = if (isUser) SaffronPrimary else VedicGold,
                            fontSize = 11.sp
                        )

                        if (!isUser && !isImage) {
                            Surface(
                                shape = RoundedCornerShape(4.dp),
                                color = StatusGreen.copy(alpha = 0.15f)
                            ) {
                                Text(
                                    text = "শাস্ত্রীয় যাচাইকৃত",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = StatusGreen,
                                    fontSize = 10.sp,
                                    modifier = Modifier.padding(horizontal = 5.dp, vertical = 2.dp)
                                )
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(6.dp))

                    // Content
                    if (isImage) {
                        AsyncImage(
                            model = text,
                            contentDescription = "উৎপন্ন ধর্মীয় চিত্র",
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 280.dp)
                                .clip(RoundedCornerShape(8.dp))
                                .background(MaterialTheme.colorScheme.surface)
                        )
                    } else {
                        Text(
                            text = text,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurface,
                            lineHeight = 22.sp,
                            fontSize = 14.sp
                        )
                    }

                    // Action buttons for AI responses
                    if (!isUser && !isImage) {
                        Spacer(modifier = Modifier.height(10.dp))
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.2f))
                        Spacer(modifier = Modifier.height(6.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            // Left side: Listen and Copy
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                // Listen / Stop TTS button
                                IconButton(
                                    onClick = onToggleVoice,
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = if (isCurrentlySpeaking) Icons.Default.Stop else Icons.AutoMirrored.Filled.VolumeUp,
                                        contentDescription = if (isCurrentlySpeaking) "ভয়েস থামান" else "শুনুন",
                                        tint = if (isCurrentlySpeaking) StatusRed else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(17.dp)
                                    )
                                }

                                // Copy button
                                IconButton(
                                    onClick = onCopy,
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.ContentCopy,
                                        contentDescription = "কপি করুন",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }

                            // Right side: Like, Dislike, Report
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                // Like
                                IconButton(
                                    onClick = onLike,
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = if (reaction == 1) Icons.Default.ThumbUp else Icons.Default.ThumbUpOffAlt,
                                        contentDescription = "পছন্দ",
                                        tint = if (reaction == 1) SaffronPrimary else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }

                                // Dislike
                                IconButton(
                                    onClick = onDislike,
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = if (reaction == -1) Icons.Default.ThumbDown else Icons.Default.ThumbDownOffAlt,
                                        contentDescription = "অপছন্দ",
                                        tint = if (reaction == -1) StatusRed else MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }

                                // Report / Correction
                                IconButton(
                                    onClick = onReport,
                                    modifier = Modifier.size(32.dp)
                                ) {
                                    Icon(
                                        imageVector = Icons.Default.OutlinedFlag,
                                        contentDescription = "সংশোধন পাঠান",
                                        tint = MaterialTheme.colorScheme.onSurfaceVariant,
                                        modifier = Modifier.size(16.dp)
                                    )
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
