package com.example.ui.screens

import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardActions
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.ImeAction
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.domain.ai.CalendarRegion
import com.example.domain.ai.ExternalAppCapabilityEngine
import com.example.ui.theme.*
import com.example.ui.viewmodel.ScreenDestination
import com.example.ui.viewmodel.VedaNovaViewModel

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun ExternalAppSimulatorScreen(viewModel: VedaNovaViewModel) {
    val externalApps by viewModel.allExternalApps.collectAsStateWithLifecycle()
    val selectedAppId by viewModel.simulatorAppId.collectAsStateWithLifecycle()
    val selectedRegion by viewModel.simulatorRegion.collectAsStateWithLifecycle()
    val activeTab by viewModel.simulatorActiveTab.collectAsStateWithLifecycle()
    val chatQuery by viewModel.simulatorChatQuery.collectAsStateWithLifecycle()
    val chatMessages by viewModel.simulatorChatMessages.collectAsStateWithLifecycle()
    val isLoading by viewModel.simulatorIsLoading.collectAsStateWithLifecycle()
    val lastResponse by viewModel.simulatorLastResponse.collectAsStateWithLifecycle()
    val dailyData by viewModel.dailyData.collectAsStateWithLifecycle()

    val currentApp = externalApps.find { it.appId == selectedAppId } ?: externalApps.firstOrNull()
    var appMenuExpanded by remember { mutableStateOf(false) }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(horizontal = 12.dp, vertical = 8.dp)
            .testTag("external_app_simulator_screen"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Sub-Navigation Tabs for External App Subsystems
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            shape = RoundedCornerShape(10.dp),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(4.dp),
                horizontalArrangement = Arrangement.spacedBy(4.dp)
            ) {
                OutlinedButton(
                    onClick = { viewModel.navigateTo(ScreenDestination.EXTERNAL_APPS_MONITOR) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Apps, contentDescription = null, modifier = Modifier.size(14.dp), tint = SaffronPrimary)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Apps", fontSize = 11.sp)
                }

                OutlinedButton(
                    onClick = { viewModel.navigateTo(ScreenDestination.CAPABILITY_APPROVAL) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.VerifiedUser, contentDescription = null, modifier = Modifier.size(14.dp), tint = VedicGold)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Capabilities", fontSize = 11.sp)
                }

                OutlinedButton(
                    onClick = { viewModel.navigateTo(ScreenDestination.DAILY_DATA_MONITOR) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.CalendarMonth, contentDescription = null, modifier = Modifier.size(14.dp), tint = SpiritualTeal)
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Daily Data", fontSize = 11.sp)
                }

                FilledTonalButton(
                    onClick = { viewModel.navigateTo(ScreenDestination.EXTERNAL_APP_SIMULATOR) },
                    modifier = Modifier.weight(1f),
                    shape = RoundedCornerShape(8.dp),
                    colors = ButtonDefaults.filledTonalButtonColors(
                        containerColor = SaffronPrimary,
                        contentColor = Color.White
                    ),
                    contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.Science, contentDescription = null, modifier = Modifier.size(14.dp))
                    Spacer(modifier = Modifier.width(4.dp))
                    Text("Sandbox", fontSize = 11.sp, fontWeight = FontWeight.Bold)
                }
            }
        }

        // 1. App Switcher & Context Banner
        Card(
            modifier = Modifier.fillMaxWidth(),
            shape = RoundedCornerShape(10.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
            border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text("Simulated External Application:", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant))
                    Box {
                        TextButton(
                            onClick = { appMenuExpanded = true },
                            contentPadding = PaddingValues(0.dp)
                        ) {
                            Text(
                                currentApp?.let { "${it.appName} (${it.appId})" } ?: "Select App",
                                style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold, color = SaffronPrimary)
                            )
                            Icon(Icons.Default.ArrowDropDown, contentDescription = null, tint = SaffronPrimary)
                        }
                        DropdownMenu(
                            expanded = appMenuExpanded,
                            onDismissRequest = { appMenuExpanded = false }
                        ) {
                            externalApps.forEach { app ->
                                DropdownMenuItem(
                                    text = {
                                        Column {
                                            Text(app.appName, fontWeight = FontWeight.Bold)
                                            Text("ID: ${app.appId} • Scopes: ${app.allowedScopes}", fontSize = 11.sp, color = Color.Gray)
                                        }
                                    },
                                    onClick = {
                                        viewModel.setSimulatorApp(app.appId)
                                        appMenuExpanded = false
                                    }
                                )
                            }
                        }
                    }
                }

                Column(horizontalAlignment = Alignment.End) {
                    Text("Active Scopes", style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = MaterialTheme.colorScheme.onSurfaceVariant))
                    Text(
                        currentApp?.allowedScopes ?: "None",
                        style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.SemiBold, color = SpiritualTeal, fontSize = 11.sp),
                        maxLines = 1
                    )
                }
            }
        }

        // 2. Navigation Tabs
        val tabs = listOf("Daily Feed", "Live Countdown", "Capabilities", "Simulated Chat", "Raw Gateway")
        ScrollableTabRow(
            selectedTabIndex = activeTab,
            edgePadding = 0.dp,
            modifier = Modifier.fillMaxWidth()
        ) {
            tabs.forEachIndexed { index, title ->
                Tab(
                    selected = activeTab == index,
                    onClick = {
                        viewModel.setSimulatorActiveTab(index)
                        if (index == 0) {
                            viewModel.executeSimulatorRawRequest("/api/v1/daily/today", "GET")
                        } else if (index == 1) {
                            viewModel.executeSimulatorRawRequest("/api/v1/daily/festivals/upcoming", "GET")
                        } else if (index == 2) {
                            viewModel.executeSimulatorRawRequest("/api/v1/capabilities", "GET")
                        }
                    },
                    text = { Text(title, fontWeight = if (activeTab == index) FontWeight.Bold else FontWeight.Normal, fontSize = 12.sp) }
                )
            }
        }

        // 3. Tab Contents
        Box(modifier = Modifier.weight(1f)) {
            when (activeTab) {
                0 -> SimulatorDailyFeedTab(dailyData = dailyData)
                1 -> SimulatorCountdownTab(dailyData = dailyData)
                2 -> SimulatorCapabilitiesTab(currentApp = currentApp)
                3 -> SimulatorChatTab(
                    chatMessages = chatMessages,
                    chatQuery = chatQuery,
                    isLoading = isLoading,
                    onQueryChange = { viewModel.setSimulatorChatQuery(it) },
                    onSend = { viewModel.sendSimulatorChatMessage() }
                )
                4 -> SimulatorRawInspectorTab(lastResponse = lastResponse, viewModel = viewModel)
            }
        }
    }
}

@Composable
fun SimulatorDailyFeedTab(dailyData: com.example.domain.ai.DailyDataResolution) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        "Resolved for: ${dailyData.region.displayName}",
                        style = MaterialTheme.typography.labelSmall.copy(color = SaffronPrimary, fontWeight = FontWeight.Bold, fontSize = 10.sp)
                    )
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(
                        "${dailyData.bengaliDate.dayBangla} ${dailyData.bengaliDate.monthBangla} ${dailyData.bengaliDate.yearBangla} (${dailyData.bengaliDate.dayOfWeekBangla})",
                        style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold)
                    )
                    Text(
                        "গ্রেগরিয়ান: ${dailyData.gregorianDateFormatted} • ${dailyData.bengaliDate.fullTithiTitle}",
                        style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline)
                    Spacer(modifier = Modifier.height(10.dp))

                    Text("Muhurta Timings:", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 11.sp))
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        TimingChip(label = "Sunrise", value = dailyData.bengaliDate.sunriseTime, modifier = Modifier.weight(1f))
                        TimingChip(label = "Sunset", value = dailyData.bengaliDate.sunsetTime, modifier = Modifier.weight(1f))
                        TimingChip(label = "Brahma", value = dailyData.bengaliDate.brahmaMuhurta, modifier = Modifier.weight(1.2f))
                        TimingChip(label = "Rahu Kala", value = dailyData.bengaliDate.rahuKala, modifier = Modifier.weight(1.1f))
                    }
                }
            }
        }

        item {
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text("Daily Gita Exegesis (${dailyData.spiritualFeed.dailyGitaChapterVerse}):", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = SaffronPrimary, fontSize = 10.sp))
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(dailyData.spiritualFeed.dailyGitaSanskrit, style = MaterialTheme.typography.bodySmall.copy(fontWeight = FontWeight.Bold, fontFamily = FontFamily.Serif))
                    Spacer(modifier = Modifier.height(2.dp))
                    Text(dailyData.spiritualFeed.dailyGitaBn, style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant))
                }
            }
        }
    }
}

@Composable
fun SimulatorCountdownTab(dailyData: com.example.domain.ai.DailyDataResolution) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        items(dailyData.upcomingFestivals) { fest ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier.padding(12.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(fest.nameBn, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                        Text(
                            "${fest.nameEn} • ${fest.targetGregorianDate}",
                            style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                        )
                        Text(
                            "উপাস্য দেব/দেবী: ${fest.primaryDeity}",
                            style = MaterialTheme.typography.labelSmall.copy(fontSize = 10.sp, color = SpiritualTeal, fontWeight = FontWeight.SemiBold)
                        )
                    }

                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = SaffronPrimary
                    ) {
                        Column(
                            modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                            horizontalAlignment = Alignment.CenterHorizontally
                        ) {
                            Text("${fest.daysRemaining}", style = MaterialTheme.typography.titleMedium.copy(fontWeight = FontWeight.Bold, color = Color.White))
                            Text("দিন বাকি", style = MaterialTheme.typography.labelSmall.copy(color = Color.White, fontSize = 9.sp))
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SimulatorCapabilitiesTab(currentApp: com.example.data.model.ExternalAppEntity?) {
    val scopes = currentApp?.allowedScopes ?: "ALL"
    val capabilities = ExternalAppCapabilityEngine.getCapabilitiesForScopes(scopes)

    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        item {
            Text(
                "Authorized Capabilities for Scopes: [${scopes}] (${capabilities.size} Active)",
                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold)
            )
        }

        items(capabilities) { cap ->
            Card(
                modifier = Modifier.fillMaxWidth(),
                shape = RoundedCornerShape(10.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(12.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(cap.nameBn, style = MaterialTheme.typography.bodyMedium.copy(fontWeight = FontWeight.Bold))
                        Surface(
                            shape = RoundedCornerShape(4.dp),
                            color = SaffronPrimary.copy(alpha = 0.15f)
                        ) {
                            Text(
                                cap.code,
                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp),
                                style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = SaffronPrimary, fontSize = 10.sp)
                            )
                        }
                    }
                    Text(cap.nameEn, style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text(cap.description, style = MaterialTheme.typography.bodySmall.copy(fontSize = 11.sp))
                    Spacer(modifier = Modifier.height(4.dp))
                    Text("Endpoint: ${cap.endpoint} • Scope: ${cap.requiredScope}", style = MaterialTheme.typography.labelSmall.copy(fontFamily = FontFamily.Monospace, color = SpiritualTeal, fontSize = 10.sp))
                }
            }
        }
    }
}

@Composable
fun SimulatorChatTab(
    chatMessages: List<Pair<String, String>>,
    chatQuery: String,
    isLoading: Boolean,
    onQueryChange: (String) -> Unit,
    onSend: () -> Unit
) {
    Column(modifier = Modifier.fillMaxSize()) {
        // Quick Scenario Presets
        Row(
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 4.dp),
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            AssistChip(
                onClick = { onQueryChange("শিব কে?") },
                label = { Text("১. শিব কে?", fontSize = 11.sp) }
            )
            AssistChip(
                onClick = { onQueryChange("তার প্রণাম ও ধ্যান মন্ত্র বলো") },
                label = { Text("২. তার প্রণাম মন্ত্র", fontSize = 11.sp) }
            )
            AssistChip(
                onClick = { onQueryChange("আমাকে একটি মন্ত্র দাও") },
                label = { Text("৩. Disambiguation", fontSize = 11.sp) }
            )
        }

        LazyColumn(
            modifier = Modifier
                .weight(1f)
                .fillMaxWidth(),
            verticalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            items(chatMessages) { (sender, msg) ->
                val isUser = sender == "USER"
                val isSystem = sender == "APP_SYSTEM"

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = if (isUser) Arrangement.End else Arrangement.Start
                ) {
                    Surface(
                        shape = RoundedCornerShape(10.dp),
                        color = when {
                            isUser -> SaffronPrimary
                            isSystem -> SpiritualTeal.copy(alpha = 0.15f)
                            else -> MaterialTheme.colorScheme.surfaceVariant
                        },
                        modifier = Modifier.widthIn(max = 280.dp)
                    ) {
                        Column(modifier = Modifier.padding(8.dp)) {
                            Text(
                                if (isUser) "Simulated User" else if (isSystem) "System Event" else "VedaNova AI Central Brain",
                                style = MaterialTheme.typography.labelSmall.copy(
                                    fontWeight = FontWeight.Bold,
                                    color = if (isUser) Color.White.copy(alpha = 0.8f) else MaterialTheme.colorScheme.onSurfaceVariant,
                                    fontSize = 10.sp
                                )
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                msg,
                                style = MaterialTheme.typography.bodySmall.copy(
                                    color = if (isUser) Color.White else MaterialTheme.colorScheme.onSurface,
                                    fontSize = 11.sp
                                )
                            )
                        }
                    }
                }
            }

            if (isLoading) {
                item {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        CircularProgressIndicator(modifier = Modifier.size(14.dp), strokeWidth = 2.dp)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text("VedaNova Central AI Brain Processing...", style = MaterialTheme.typography.bodySmall.copy(color = Color.Gray, fontSize = 11.sp))
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(6.dp))

        Row(
            modifier = Modifier.fillMaxWidth(),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(6.dp)
        ) {
            OutlinedTextField(
                value = chatQuery,
                onValueChange = onQueryChange,
                modifier = Modifier.weight(1f).testTag("simulator_chat_input"),
                placeholder = { Text("Ask simulated app query...", fontSize = 11.sp) },
                singleLine = true,
                shape = RoundedCornerShape(8.dp),
                keyboardOptions = KeyboardOptions(imeAction = ImeAction.Send),
                keyboardActions = KeyboardActions(onSend = { onSend() })
            )
            IconButton(
                onClick = onSend,
                enabled = !isLoading && chatQuery.isNotBlank(),
                modifier = Modifier
                    .clip(CircleShape)
                    .background(if (!isLoading && chatQuery.isNotBlank()) SaffronPrimary else Color.Gray.copy(alpha = 0.3f))
                    .testTag("simulator_send_button")
            ) {
                Icon(Icons.AutoMirrored.Filled.Send, contentDescription = "Send", tint = Color.White, modifier = Modifier.size(18.dp))
            }
        }
        Spacer(modifier = Modifier.height(4.dp))
    }
}

@Composable
fun SimulatorRawInspectorTab(
    lastResponse: com.example.domain.api.ApiGatewayResponse?,
    viewModel: VedaNovaViewModel? = null
) {
    LazyColumn(
        modifier = Modifier.fillMaxSize(),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // HTTP Error & Edge Case Simulation Controls
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(10.dp),
                border = androidx.compose.foundation.BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(10.dp)) {
                    Text("Gateway Edge-Case & Error Code Simulator:", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, color = SaffronPrimary, fontSize = 10.sp))
                    Spacer(modifier = Modifier.height(4.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        OutlinedButton(
                            onClick = {
                                viewModel?.executeSimulatorRawRequest("/api/v1/chat", "POST", "{\"query\":\"test\"}")
                            },
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("Normal 200", fontSize = 11.sp)
                        }
                        OutlinedButton(
                            onClick = {
                                viewModel?.executeSimulatorRawRequest("/api/v1/unknown_endpoint", "GET")
                            },
                            shape = RoundedCornerShape(6.dp),
                            contentPadding = PaddingValues(horizontal = 8.dp, vertical = 4.dp)
                        ) {
                            Text("Test 404", fontSize = 11.sp)
                        }
                    }
                }
            }
        }

        if (lastResponse == null) {
            item {
                Box(
                    modifier = Modifier.fillMaxWidth().height(160.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("No API Gateway response captured yet.", color = Color.Gray, fontSize = 11.sp)
                }
            }
        } else {
            item {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Text("HTTP Status: ${lastResponse.statusCode} ${lastResponse.statusText}", fontWeight = FontWeight.Bold, fontSize = 12.sp)
                    Text("Latency: ${lastResponse.responseTimeMs}ms", style = MaterialTheme.typography.bodySmall.copy(color = SpiritualTeal, fontWeight = FontWeight.Bold, fontSize = 11.sp))
                }
            }

            item {
                Text("Response Headers:", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 10.sp))
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = MaterialTheme.colorScheme.surfaceVariant,
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Column(modifier = Modifier.padding(8.dp)) {
                        lastResponse.responseHeaders.forEach { (k, v) ->
                            Text("$k: $v", style = MaterialTheme.typography.bodySmall.copy(fontFamily = FontFamily.Monospace, fontSize = 10.sp))
                        }
                    }
                }
            }

            item {
                Text("JSON Payload:", style = MaterialTheme.typography.labelSmall.copy(fontWeight = FontWeight.Bold, fontSize = 10.sp))
                Surface(
                    shape = RoundedCornerShape(6.dp),
                    color = Color(0xFF1E1E1E),
                    modifier = Modifier.fillMaxWidth()
                ) {
                    Text(
                        lastResponse.jsonBody,
                        modifier = Modifier.padding(8.dp),
                        style = MaterialTheme.typography.bodySmall.copy(color = Color(0xFFE0E0E0), fontFamily = FontFamily.Monospace, fontSize = 10.sp)
                    )
                }
            }
        }
    }
}

@Composable
private fun TimingChip(label: String, value: String, modifier: Modifier = Modifier) {
    Surface(
        shape = RoundedCornerShape(6.dp),
        color = MaterialTheme.colorScheme.surfaceVariant,
        modifier = modifier
    ) {
        Column(modifier = Modifier.padding(horizontal = 6.dp, vertical = 4.dp)) {
            Text(label, fontSize = 9.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
            Text(value, fontSize = 10.sp, fontWeight = FontWeight.Bold)
        }
    }
}

