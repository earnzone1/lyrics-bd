package com.example.ui.screens

import android.widget.Toast
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.StatusPill
import com.example.ui.theme.*
import com.example.ui.viewmodel.ScreenDestination
import com.example.ui.viewmodel.VedaNovaViewModel
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SettingsScreen(viewModel: VedaNovaViewModel) {
    val context = LocalContext.current
    val settings by viewModel.allSettings.collectAsStateWithLifecycle()
    val voiceSettings by viewModel.voiceSettings.collectAsStateWithLifecycle()
    val session by viewModel.currentSession.collectAsStateWithLifecycle()

    var modelName by remember { mutableStateOf("gemini-2.5-flash") }
    var temperature by remember { mutableFloatStateOf(0.2f) }
    var verificationThreshold by remember { mutableFloatStateOf(0.85f) }
    var ambiguityEnabled by remember { mutableStateOf(true) }
    var strictGuardrails by remember { mutableStateOf(true) }
    var selfCorrectionEnabled by remember { mutableStateOf(true) }
    var rateLimit by remember { mutableStateOf("60") }
    var requireAdminApproval by remember { mutableStateOf(true) }
    var highContrastMode by remember { mutableStateOf(true) }

    var saveStatusMessage by remember { mutableStateOf<String?>(null) }
    var lastSavedTime by remember { mutableStateOf<String?>(null) }

    // Synchronize initial values from database settings once available
    LaunchedEffect(settings) {
        if (settings.isNotEmpty()) {
            val settingsMap = settings.associate { it.key to it.value }
            settingsMap["ai_model_name"]?.let { modelName = it }
            settingsMap["ai_temperature"]?.toFloatOrNull()?.let { temperature = it }
            settingsMap["verification_threshold"]?.toFloatOrNull()?.let { verificationThreshold = it }
            settingsMap["ambiguity_detection"]?.toBooleanStrictOrNull()?.let { ambiguityEnabled = it }
            settingsMap["strict_source_guardrails"]?.toBooleanStrictOrNull()?.let { strictGuardrails = it }
            settingsMap["self_correction_enabled"]?.toBooleanStrictOrNull()?.let { selfCorrectionEnabled = it }
            settingsMap["api_rate_limit"]?.let { rateLimit = it }
            settingsMap["require_admin_approval"]?.toBooleanStrictOrNull()?.let { requireAdminApproval = it }
            settingsMap["high_contrast_mode"]?.toBooleanStrictOrNull()?.let { highContrastMode = it }
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background),
        contentPadding = PaddingValues(
            start = 16.dp,
            end = 16.dp,
            top = 16.dp,
            bottom = 120.dp // Generous bottom padding to ensure zero clipping with navigation bar
        ),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Top Breadcrumb / Quick Navigation Bar
        item {
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                OutlinedButton(
                    onClick = { viewModel.navigateTo(ScreenDestination.DASHBOARD) },
                    shape = RoundedCornerShape(8.dp),
                    contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                ) {
                    Icon(Icons.Default.ArrowBack, contentDescription = "Back", modifier = Modifier.size(16.dp))
                    Spacer(modifier = Modifier.width(6.dp))
                    Text("Control Center", style = MaterialTheme.typography.labelMedium)
                }

                StatusPill(
                    text = "Role: ${session.currentUser.role}",
                    color = SaffronPrimary
                )
            }
        }

        // Header Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp)
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Surface(
                            shape = RoundedCornerShape(10.dp),
                            color = SaffronPrimary.copy(alpha = 0.2f),
                            modifier = Modifier.size(44.dp)
                        ) {
                            Box(contentAlignment = Alignment.Center) {
                                Icon(
                                    imageVector = Icons.Default.Tune,
                                    contentDescription = "Settings",
                                    tint = SaffronPrimary,
                                    modifier = Modifier.size(24.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "System & AI Brain Settings",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Independent platform governance & configuration",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f))
                    Spacer(modifier = Modifier.height(10.dp))

                    Text(
                        text = "Fine-tune AI model temperature, scriptural verification thresholds, live voice audio narration, API rate limits, and canonical safety guardrails.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 20.sp
                    )
                }
            }
        }

        // SECTION 1: AI Brain & Reasoning Parameters
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Psychology, contentDescription = null, tint = SaffronPrimary, modifier = Modifier.size(22.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "1. AI Brain & Reasoning Parameters",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = SaffronPrimary
                        )
                    }

                    // Model Name Field & Presets
                    Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(
                            text = "Primary Gemini Model Identifier:",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        OutlinedTextField(
                            value = modelName,
                            onValueChange = { modelName = it },
                            label = { Text("Model Name") },
                            leadingIcon = { Icon(Icons.Default.SmartToy, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth(),
                            colors = OutlinedTextFieldDefaults.colors(
                                focusedBorderColor = SaffronPrimary,
                                focusedLabelColor = SaffronPrimary
                            )
                        )
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            listOf("gemini-2.5-flash", "gemini-1.5-pro", "gemini-2.0-flash").forEach { preset ->
                                FilterChip(
                                    selected = modelName == preset,
                                    onClick = { modelName = preset },
                                    label = { Text(preset, style = MaterialTheme.typography.labelSmall) }
                                )
                            }
                        }
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))

                    // Temperature Slider
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Temperature (Scriptural Rigor vs Creativity):",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            StatusPill(
                                text = String.format(Locale.US, "%.2f (%s)", temperature, if (temperature <= 0.3f) "Strict" else "Creative"),
                                color = VedicGold
                            )
                        }
                        Slider(
                            value = temperature,
                            onValueChange = { temperature = it },
                            valueRange = 0.0f..1.0f,
                            colors = SliderDefaults.colors(
                                thumbColor = SaffronPrimary,
                                activeTrackColor = SaffronPrimary,
                                inactiveTrackColor = MaterialTheme.colorScheme.outline
                            )
                        )
                        Text(
                            text = "Lower values (0.1 - 0.3) provide strict adherence to canonical texts and authentic Sanskrit shlokas.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))

                    // Verification Threshold Slider
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Verification Confidence Threshold:",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            StatusPill(
                                text = String.format(Locale.US, "%d%% (Pass)", (verificationThreshold * 100).toInt()),
                                color = StatusGreen
                            )
                        }
                        Slider(
                            value = verificationThreshold,
                            onValueChange = { verificationThreshold = it },
                            valueRange = 0.5f..1.0f,
                            colors = SliderDefaults.colors(
                                thumbColor = StatusGreen,
                                activeTrackColor = StatusGreen,
                                inactiveTrackColor = MaterialTheme.colorScheme.outline
                            )
                        )
                        Text(
                            text = "Minimum confidence required to publish research or accept candidate knowledge into production.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))

                    // Ambiguity Detection Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .padding(end = 12.dp)
                        ) {
                            Text(
                                text = "Ambiguity Detection & Disambiguation",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Prompts users with contextual scripture branches when queries are brief or have multiple interpretations.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = ambiguityEnabled,
                            onCheckedChange = { ambiguityEnabled = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = SaffronPrimary,
                                checkedTrackColor = SaffronPrimary.copy(alpha = 0.5f)
                            )
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))

                    // Strict Guardrails Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .padding(end = 12.dp)
                        ) {
                            Text(
                                text = "Strict Canonical Scripture Guardrails",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Prevents speculative answers and hallucinated verses by enforcing Shruti/Smriti verification.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = strictGuardrails,
                            onCheckedChange = { strictGuardrails = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = StatusGreen,
                                checkedTrackColor = StatusGreen.copy(alpha = 0.5f)
                            )
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))

                    // Self-Correction Loop Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .padding(end = 12.dp)
                        ) {
                            Text(
                                text = "Automated Self-Correction & Refinement",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Applies surgical refinement against tone rules, clarity standards, and anaphoric pronoun resolution.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = selfCorrectionEnabled,
                            onCheckedChange = { selfCorrectionEnabled = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = SaffronPrimary,
                                checkedTrackColor = SaffronPrimary.copy(alpha = 0.5f)
                            )
                        )
                    }
                }
            }
        }

        // SECTION 2: Voice Guide & Audio Announcer
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            modifier = Modifier.weight(1f).padding(end = 12.dp)
                        ) {
                            Icon(Icons.Default.RecordVoiceOver, contentDescription = null, tint = SaffronPrimary, modifier = Modifier.size(22.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "2. Voice Guide & Audio Announcer",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = SaffronPrimary
                            )
                        }
                        Switch(
                            checked = voiceSettings.isEnabled,
                            onCheckedChange = { viewModel.setVoiceGuideEnabled(it) },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = SaffronPrimary,
                                checkedTrackColor = SaffronPrimary.copy(alpha = 0.5f)
                            )
                        )
                    }

                    Text(
                        text = "Real-time Text-To-Speech (TTS) narration for system sections, navigation events, and answer audio playback.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    if (voiceSettings.isEnabled) {
                        HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))

                        // Language Selection
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = "Announcer Language:",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(10.dp)
                            ) {
                                FilterChip(
                                    selected = voiceSettings.language == "BENGALI",
                                    onClick = { viewModel.setVoiceLanguage("BENGALI") },
                                    label = { Text("বাংলা (Bengali - Default)") },
                                    leadingIcon = if (voiceSettings.language == "BENGALI") {
                                        { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                    } else null
                                )
                                FilterChip(
                                    selected = voiceSettings.language == "ENGLISH",
                                    onClick = { viewModel.setVoiceLanguage("ENGLISH") },
                                    label = { Text("English") },
                                    leadingIcon = if (voiceSettings.language == "ENGLISH") {
                                        { Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp)) }
                                    } else null
                                )
                            }
                        }

                        // Speech Rate Selection
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = "Speech Rate (গতি):",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf("SLOW" to "ধীর (Slow)", "NORMAL" to "স্বাভাবিক (Normal)", "FAST" to "দ্রুত (Fast)").forEach { (speed, label) ->
                                    FilterChip(
                                        selected = voiceSettings.speechSpeed == speed,
                                        onClick = { viewModel.setVoiceSpeed(speed) },
                                        label = { Text(label) }
                                    )
                                }
                            }
                        }

                        // Announcement Scope Mode
                        Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                            Text(
                                text = "Announcement Scope Mode:",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.SemiBold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                listOf(
                                    "ALL" to "All Actions",
                                    "MAJOR_ONLY" to "Major Only",
                                    "NAVIGATION_ONLY" to "Nav Only"
                                ).forEach { (mode, label) ->
                                    FilterChip(
                                        selected = voiceSettings.announcementMode == mode,
                                        onClick = { viewModel.setAnnouncementMode(mode) },
                                        label = { Text(label, style = MaterialTheme.typography.labelSmall) }
                                    )
                                }
                            }
                        }

                        // Test Announcement Button
                        FilledTonalButton(
                            onClick = {
                                viewModel.testVoiceAnnouncement(
                                    textBn = "নমস্কার! VedaNova AI ভয়েস গাইড ও সিস্টেম সেটিংস সঠিকভাবে কাজ করছে।",
                                    textEn = "Greetings! VedaNova AI voice guide and system settings are fully operational."
                                )
                                Toast.makeText(context, "Voice test initiated", Toast.LENGTH_SHORT).show()
                            },
                            shape = RoundedCornerShape(10.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(48.dp)
                        ) {
                            Icon(Icons.Default.VolumeUp, contentDescription = null, modifier = Modifier.size(20.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("Test Voice Audio (পরীক্ষা শুনুন)", fontWeight = FontWeight.SemiBold)
                        }
                    }
                }
            }
        }

        // SECTION 3: API Gateway & Security Governance
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Security, contentDescription = null, tint = SpiritualTeal, modifier = Modifier.size(22.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "3. Security & Gateway Governance",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = SpiritualTeal
                        )
                    }

                    // Rate Limit Text Field
                    Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                        Text(
                            text = "Default Gateway Rate Limit (Requests per Minute):",
                            style = MaterialTheme.typography.bodyMedium,
                            fontWeight = FontWeight.SemiBold,
                            color = MaterialTheme.colorScheme.onSurface
                        )
                        OutlinedTextField(
                            value = rateLimit,
                            onValueChange = { rateLimit = it },
                            label = { Text("RPM Limit") },
                            leadingIcon = { Icon(Icons.Default.Speed, contentDescription = null) },
                            singleLine = true,
                            modifier = Modifier.fillMaxWidth()
                        )
                        Text(
                            text = "Throttles external consumer client applications to prevent server overloading and API quota exhaustion.",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    HorizontalDivider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.3f))

                    // Require Admin Approval Switch
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .padding(end = 12.dp)
                        ) {
                            Text(
                                text = "Require Admin Approval for Knowledge",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "All user-taught or harvested knowledge candidates must be approved before publication into production.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = requireAdminApproval,
                            onCheckedChange = { requireAdminApproval = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = StatusGreen,
                                checkedTrackColor = StatusGreen.copy(alpha = 0.5f)
                            )
                        )
                    }
                }
            }
        }

        // SECTION 4: High Contrast & UI Display
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(16.dp)
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Visibility, contentDescription = null, tint = VedicGold, modifier = Modifier.size(22.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "4. Visual Display & Contrast",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = VedicGold
                        )
                    }

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(
                            modifier = Modifier
                                .weight(1f)
                                .padding(end = 12.dp)
                        ) {
                            Text(
                                text = "High Visibility Text & Contrast Mode",
                                style = MaterialTheme.typography.bodyMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Spacer(modifier = Modifier.height(2.dp))
                            Text(
                                text = "Ensures all labels, toggles, and status text render with prominent contrast across all screens.",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                        Switch(
                            checked = highContrastMode,
                            onCheckedChange = { highContrastMode = it },
                            colors = SwitchDefaults.colors(
                                checkedThumbColor = SaffronPrimary,
                                checkedTrackColor = SaffronPrimary.copy(alpha = 0.5f)
                            )
                        )
                    }
                }
            }
        }

        // SECTION 5: Save & Synchronize Actions
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, SaffronPrimary.copy(alpha = 0.6f))
            ) {
                Column(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(20.dp),
                    verticalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Button(
                        onClick = {
                            viewModel.updateSetting("ai_model_name", modelName)
                            viewModel.updateSetting("ai_temperature", temperature.toString())
                            viewModel.updateSetting("verification_threshold", verificationThreshold.toString())
                            viewModel.updateSetting("ambiguity_detection", ambiguityEnabled.toString())
                            viewModel.updateSetting("strict_source_guardrails", strictGuardrails.toString())
                            viewModel.updateSetting("self_correction_enabled", selfCorrectionEnabled.toString())
                            viewModel.updateSetting("api_rate_limit", rateLimit)
                            viewModel.updateSetting("require_admin_approval", requireAdminApproval.toString())
                            viewModel.updateSetting("high_contrast_mode", highContrastMode.toString())

                            val now = SimpleDateFormat("HH:mm:ss yyyy-MM-dd", Locale.getDefault()).format(Date())
                            lastSavedTime = now
                            saveStatusMessage = "All system settings saved and synchronized with database at $now."
                            Toast.makeText(context, "Settings saved successfully", Toast.LENGTH_SHORT).show()
                        },
                        colors = ButtonDefaults.buttonColors(
                            containerColor = SaffronPrimary,
                            contentColor = Color.Black
                        ),
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(52.dp)
                    ) {
                        Icon(Icons.Default.Save, contentDescription = null, tint = Color.Black)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "Save All System Settings",
                            fontWeight = FontWeight.Bold,
                            fontSize = 16.sp
                        )
                    }

                    OutlinedButton(
                        onClick = {
                            modelName = "gemini-2.5-flash"
                            temperature = 0.2f
                            verificationThreshold = 0.85f
                            ambiguityEnabled = true
                            strictGuardrails = true
                            selfCorrectionEnabled = true
                            rateLimit = "60"
                            requireAdminApproval = true
                            highContrastMode = true
                            Toast.makeText(context, "Defaults restored. Click Save to persist.", Toast.LENGTH_SHORT).show()
                        },
                        shape = RoundedCornerShape(12.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(44.dp)
                    ) {
                        Icon(Icons.Default.RestartAlt, contentDescription = null, modifier = Modifier.size(18.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("Reset to Recommended Canonical Defaults")
                    }

                    saveStatusMessage?.let { msg ->
                        StatusPill(
                            text = "✓ $msg",
                            color = StatusGreen
                        )
                    }

                    lastSavedTime?.let { time ->
                        Text(
                            text = "Last synchronized: $time • Logged in audit trail",
                            style = MaterialTheme.typography.labelSmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }
    }
}
