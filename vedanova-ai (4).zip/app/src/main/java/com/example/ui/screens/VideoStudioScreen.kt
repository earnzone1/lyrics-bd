package com.example.ui.screens

import android.content.Intent
import android.net.Uri
import android.widget.MediaController
import android.widget.VideoView
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontFamily
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.content.FileProvider
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.data.model.*
import com.example.ui.theme.*
import com.example.ui.viewmodel.VedaNovaViewModel
import com.example.ui.viewmodel.VideoStudioUiState
import java.io.File
import java.text.SimpleDateFormat
import java.util.*

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun VideoStudioScreen(viewModel: VedaNovaViewModel) {
    val state by viewModel.videoStudioState.collectAsStateWithLifecycle()
    val allVideos by viewModel.allVideos.collectAsStateWithLifecycle()
    val auditLogs by viewModel.videoAuditLogs.collectAsStateWithLifecycle()
    val context = LocalContext.current

    val snackbarHostState = remember { SnackbarHostState() }

    LaunchedEffect(state.toastMessage) {
        state.toastMessage?.let {
            snackbarHostState.showSnackbar(it)
            viewModel.clearVideoToast()
        }
    }

    Scaffold(
        snackbarHost = { SnackbarHost(snackbarHostState) },
        topBar = {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .background(MaterialTheme.colorScheme.surface)
            ) {
                // Header Banner
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 12.dp),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(42.dp)
                                .clip(CircleShape)
                                .background(SaffronPrimary.copy(alpha = 0.15f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(
                                Icons.Default.MovieCreation,
                                contentDescription = "Video Studio",
                                tint = SaffronPrimary,
                                modifier = Modifier.size(24.dp)
                            )
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "AI Video Studio",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "Centralized Dharma Video Intelligence & Muxer",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    // VIP Status Pill
                    Surface(
                        shape = RoundedCornerShape(16.dp),
                        color = if (state.isVipUser) SaffronPrimary.copy(alpha = 0.15f) else MaterialTheme.colorScheme.surfaceVariant,
                        border = BorderStroke(1.dp, if (state.isVipUser) SaffronPrimary else MaterialTheme.colorScheme.outline)
                    ) {
                        Row(
                            modifier = Modifier
                                .clickable { viewModel.setVipUserAccess(!state.isVipUser) }
                                .padding(horizontal = 10.dp, vertical = 6.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = if (state.isVipUser) "💎 VIP ACTIVE" else "🔒 FREE TIER",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (state.isVipUser) SaffronPrimary else MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }

                // Stats row
                Row(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(horizontal = 16.dp, vertical = 4.dp),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    val completedCount = allVideos.count { it.status == VideoGenerationStatus.COMPLETED.name }
                    val publishedCount = allVideos.count { it.isPublished }

                    VideoMiniBadge("মোট: ${allVideos.size}", MaterialTheme.colorScheme.surfaceVariant)
                    VideoMiniBadge("রেন্ডারড: $completedCount", Color(0xFF2E7D32).copy(alpha = 0.15f), Color(0xFF2E7D32))
                    VideoMiniBadge("প্রকাশিত: $publishedCount", SaffronPrimary.copy(alpha = 0.15f), SaffronPrimary)
                    if (state.isGenerating) {
                        VideoMiniBadge("প্রস্তুত হচ্ছে...", Color(0xFFE65100).copy(alpha = 0.2f), Color(0xFFE65100))
                    }
                }

                // Navigation Tabs
                ScrollableTabRow(
                    selectedTabIndex = state.activeTab,
                    containerColor = MaterialTheme.colorScheme.surface,
                    contentColor = SaffronPrimary,
                    edgePadding = 12.dp
                ) {
                    Tab(
                        selected = state.activeTab == 0,
                        onClick = { viewModel.setVideoActiveTab(0) },
                        text = { Text("🌟 সার্বজনীন ক্রিয়েটর", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                        icon = { Icon(Icons.Default.AutoAwesome, contentDescription = null, modifier = Modifier.size(18.dp)) },
                        modifier = Modifier.testTag("tab_universal_creator")
                    )
                    Tab(
                        selected = state.activeTab == 1,
                        onClick = { viewModel.setVideoActiveTab(1) },
                        text = { Text("স্টুডিও মোড", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                        icon = { Icon(Icons.Default.MovieCreation, contentDescription = null, modifier = Modifier.size(18.dp)) },
                        modifier = Modifier.testTag("tab_video_studio")
                    )
                    Tab(
                        selected = state.activeTab == 2,
                        onClick = { viewModel.setVideoActiveTab(2) },
                        text = { Text("প্লেয়ার ও QA", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                        icon = { Icon(Icons.Default.PlayCircle, contentDescription = null, modifier = Modifier.size(18.dp)) },
                        modifier = Modifier.testTag("tab_video_player")
                    )
                    Tab(
                        selected = state.activeTab == 3,
                        onClick = { viewModel.setVideoActiveTab(3) },
                        text = { Text("স্টোরিবোর্ড", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                        icon = { Icon(Icons.Default.ViewCarousel, contentDescription = null, modifier = Modifier.size(18.dp)) },
                        modifier = Modifier.testTag("tab_video_storyboard")
                    )
                    Tab(
                        selected = state.activeTab == 4,
                        onClick = { viewModel.setVideoActiveTab(4) },
                        text = { Text("ক্যাটালগ (${allVideos.size})", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                        icon = { Icon(Icons.Default.VideoLibrary, contentDescription = null, modifier = Modifier.size(18.dp)) },
                        modifier = Modifier.testTag("tab_video_catalog")
                    )
                    Tab(
                        selected = state.activeTab == 5,
                        onClick = { viewModel.setVideoActiveTab(5) },
                        text = { Text("অডিট ট্রেইল", fontSize = 11.sp, fontWeight = FontWeight.SemiBold) },
                        icon = { Icon(Icons.Default.Security, contentDescription = null, modifier = Modifier.size(18.dp)) },
                        modifier = Modifier.testTag("tab_video_audit")
                    )
                }
            }
        }
    ) { paddingValues ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(paddingValues)
        ) {
            when (state.activeTab) {
                0 -> UniversalCreatorTab(viewModel, state)
                1 -> VideoStudioTab(viewModel, state)
                2 -> VideoPlayerTab(viewModel, state)
                3 -> VideoStoryboardTab(viewModel, state)
                4 -> VideoCatalogTab(viewModel, state, allVideos)
                5 -> VideoAuditTab(viewModel, state, auditLogs)
                else -> UniversalCreatorTab(viewModel, state)
            }
        }
    }
}

@Composable
private fun VideoMiniBadge(text: String, bgColor: Color, textColor: Color = MaterialTheme.colorScheme.onSurface) {
    Surface(
        shape = RoundedCornerShape(8.dp),
        color = bgColor,
        modifier = Modifier.padding(vertical = 2.dp)
    ) {
        Text(
            text = text,
            fontSize = 11.sp,
            fontWeight = FontWeight.Medium,
            color = textColor,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 3.dp)
        )
    }
}

// ============================================================
// TAB 0: Universal Devotional Video + Kirtan Audio Creator
// ============================================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun UniversalCreatorTab(viewModel: VedaNovaViewModel, state: VideoStudioUiState) {
    val context = LocalContext.current

    // Trigger analysis when prompt changes
    LaunchedEffect(state.universalPrompt) {
        if (state.universalAnalysis == null) {
            viewModel.analyzeUniversalPrompt(state.universalPrompt)
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // 1. Hero Universal Banner
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.5f)),
                border = BorderStroke(1.dp, SaffronPrimary.copy(alpha = 0.3f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Box(
                            modifier = Modifier
                                .size(40.dp)
                                .clip(CircleShape)
                                .background(SaffronPrimary.copy(alpha = 0.2f)),
                            contentAlignment = Alignment.Center
                        ) {
                            Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = SaffronPrimary)
                        }
                        Spacer(modifier = Modifier.width(12.dp))
                        Column {
                            Text(
                                text = "সার্বজনীন ভক্তিমূলক ভিডিও ও কীর্তন ক্রিয়েটর",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                            Text(
                                text = "স্বাভাবিক ভাষার প্রম্পট থেকে সরাসরি এআই মাস্টার প্রোডাকশন",
                                style = MaterialTheme.typography.bodySmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text(
                        text = "শুধু আপনার ইচ্ছা লিখুন বা মুখে বলুন — সিস্টেম স্বয়ংক্রিয়ভাবে বিষয়, দেবতা, ভাব, শাস্ত্রীয় রাগ, তাল, খোল-করতালের সুর এবং সিঙ্ক্রোনাইজড ভিডিও তৈরি করবে।",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        lineHeight = 18.sp
                    )
                }
            }
        }

        // 2. VIP Entitlement Warning Card (if user is not VIP)
        if (!state.isVipUser) {
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFFFF3E0)),
                    border = BorderStroke(1.5.dp, Color(0xFFFF9800))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.WorkspacePremium, contentDescription = null, tint = Color(0xFFE65100))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text(
                                text = "💎 VIP Plan ফিচার সুরক্ষাবিধি",
                                fontWeight = FontWeight.Bold,
                                color = Color(0xFFE65100),
                                fontSize = 14.sp
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "AI ভিডিও ও অডিও জেনারেশন একটি হাই-কম্পিউট সার্ভিস। ফ্রি ব্যবহারকারীদের জন্য এটি সীমাবদ্ধ রাখা হয়েছে।",
                            fontSize = 12.sp,
                            color = Color(0xFF5D4037)
                        )
                        Spacer(modifier = Modifier.height(10.dp))
                        Button(
                            onClick = { viewModel.setVipUserAccess(true) },
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFE65100)),
                            shape = RoundedCornerShape(8.dp),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("💎 VIP Plan সক্রিয় করুন (Admin Test Access)", fontWeight = FontWeight.Bold, color = Color.White)
                        }
                    }
                }
            }
        }

        // 3. Universal Prompt Input Box
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.5.dp, SaffronPrimary.copy(alpha = 0.6f))
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "আপনি কী তৈরি করতে চান?",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold,
                            color = SaffronPrimary
                        )

                        // Quota badge
                        Text(
                            text = "আজকের অবশিষ্ট কোটা: ${state.dailyQuotaRemaining}/২০",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = state.universalPrompt,
                        onValueChange = { viewModel.updateUniversalPrompt(it) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_universal_prompt"),
                        placeholder = {
                            Text(
                                "যেমন: 'শ্রীকৃষ্ণকে নিয়ে একটি আনন্দময় বাংলা কীর্তন ভিডিও বানাও' বা 'দুর্গাপূজার উৎসব ভিডিও'...",
                                fontSize = 13.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant.copy(alpha = 0.7f)
                            )
                        },
                        minLines = 3,
                        maxLines = 5,
                        shape = RoundedCornerShape(12.dp),
                        trailingIcon = {
                            IconButton(
                                onClick = {
                                    viewModel.toggleVoiceListening(!state.isVoiceListening)
                                    if (!state.isVoiceListening) {
                                        viewModel.simulateVoiceInput("শ্রীকৃষ্ণকে নিয়ে একটি আনন্দময় বাংলা কীর্তন ভিডিও বানাও")
                                    }
                                }
                            ) {
                                Icon(
                                    Icons.Default.Mic,
                                    contentDescription = "ভয়েস ইনপুট",
                                    tint = if (state.isVoiceListening) Color.Red else SaffronPrimary
                                )
                            }
                        }
                    )

                    if (state.isVoiceListening) {
                        Spacer(modifier = Modifier.height(6.dp))
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Text(
                                text = "🎤 ভয়েস ইনপুট সক্রিয় — কথা বলুন...",
                                fontSize = 11.sp,
                                color = Color.Red,
                                fontWeight = FontWeight.Bold
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    // Quick Prompt Chips
                    Text("💡 দ্রুত প্রস্তাবিত প্রম্পট:", fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        val quickPrompts = listOf(
                            "✨ শ্রীকৃষ্ণ আনন্দময় কীর্তন",
                            "🌺 দুর্গাপূজা মহোৎসব ভিডিও",
                            "🕉️ শিব ধ্যান ভজন",
                            "🌸 রাধাকৃষ্ণ"
                        )
                        items(quickPrompts) { qp ->
                            FilterChip(
                                selected = false,
                                onClick = {
                                    val full = when (qp) {
                                        "✨ শ্রীকৃষ্ণ আনন্দময় কীর্তন" -> "শ্রীকৃষ্ণকে নিয়ে একটি আনন্দময় বাংলা কীর্তন ভিডিও বানাও"
                                        "🌺 দুর্গাপূজা মহোৎসব ভিডিও" -> "দুর্গাপূজার জন্য একটি ভক্তিমূলক উৎসব ভিডিও তৈরি করো"
                                        "🕉️ শিব ধ্যান ভজন" -> "শিবকে নিয়ে শান্ত একটি ধ্যান ভজন ভিডিও তৈরি করো"
                                        else -> "রাধাকৃষ্ণ"
                                    }
                                    viewModel.updateUniversalPrompt(full)
                                },
                                label = { Text(qp, fontSize = 11.sp) }
                            )
                        }
                    }
                }
            }
        }

        // 4. Ambiguity Helper (if prompt is short or ambiguous like "রাধাকৃষ্ণ")
        val analysis = state.universalAnalysis
        if (analysis != null && analysis.isAmbiguous && analysis.clarificationOptions.isNotEmpty()) {
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)),
                    border = BorderStroke(1.dp, SaffronPrimary.copy(alpha = 0.4f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Lightbulb, contentDescription = null, tint = SaffronPrimary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text(
                                text = "সংক্ষিপ্ত অনুরোধ বিশ্লেষণ: '${state.universalPrompt}'",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onSurface
                            )
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "আপনি কোন ধরণের প্রযোজনা পছন্দ করেন? নিচের বিকল্পটি স্পর্শ করলেই স্বয়ংক্রিয় সেটআপ হয়ে যাবে:",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(8.dp))
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            analysis.clarificationOptions.forEach { opt ->
                                OutlinedButton(
                                    onClick = { viewModel.selectUniversalClarificationOption(opt) },
                                    modifier = Modifier.fillMaxWidth(),
                                    shape = RoundedCornerShape(8.dp),
                                    contentPadding = PaddingValues(horizontal = 10.dp, vertical = 6.dp)
                                ) {
                                    Text(opt, fontSize = 12.sp, fontWeight = FontWeight.Medium)
                                }
                            }
                        }
                    }
                }
            }
        }

        // 5. Intelligent Request Analysis Card (Real-time Feedback)
        if (analysis != null && analysis.safetyPassed) {
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "🔍 এআই কন্টেন্ট বিশ্লেষণ ও শাস্ত্রীয় কাঠামো",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold
                            )
                            Text(
                                text = "স্বয়ংক্রিয় চিহ্নিত",
                                fontSize = 10.sp,
                                color = SaffronPrimary,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Chips grid
                        Column(verticalArrangement = Arrangement.spacedBy(6.dp)) {
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                VideoMiniBadge("দেবতা: ${analysis.deity}", SaffronPrimary.copy(alpha = 0.15f), SaffronPrimary)
                                VideoMiniBadge("টাইপ: ${analysis.contentType.titleBengali.take(20)}", Color(0xFF1E88E5).copy(alpha = 0.15f), Color(0xFF1E88E5))
                            }
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                VideoMiniBadge("ভাব: ${analysis.mood}", Color(0xFF43A047).copy(alpha = 0.15f), Color(0xFF43A047))
                                VideoMiniBadge("রাগ ও তাল: ${analysis.suggestedRaga} • ${analysis.suggestedTala}", Color(0xFF8E24AA).copy(alpha = 0.15f), Color(0xFF8E24AA))
                            }
                            Text(
                                text = "বাদ্যযন্ত্র: ${analysis.selectedInstruments.joinToString(", ")}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                            Text(
                                text = "দৃশ্যরূপ: ${analysis.visualStyle}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        // 6. 8-Part Classical Kirtan Structure Preview
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Text(
                        text = "🎶 ৮-অংশের মূল শাস্ত্রীয় কীর্তন ও দৃশ্য কাঠামো",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    val partsList = listOf(
                        "১. মঙ্গলাচরণ ও আবাহন" to "শান্ত যমুনা তীর ও মঙ্গল শঙ্খধ্বনি",
                        "২. মূল ধ্রুব ও সংকীর্তন" to "দেববিগ্রহ ও পদ্মফুল বিকাশ",
                        "৩. কল অ্যান্ড রেসপন্স" to "উদ্বাহু নৃত্য ও হরিনাম ধ্বনি",
                        "৪. অন্তরা ও ভক্তিপদ" to "মন্দির গম্বুজ ও বৈদিক মণ্ডল",
                        "৫. সঙ্গীত সঞ্চারী ও লয় বৃদ্ধি" to "খোল ও করতালের দ্রুত লয়",
                        "৬. কীর্তন মহোচ্ছ্বাস ও শীর্ষ লয়" to "মহাজাগতিক আলোকচ্ছটা ও পুষ্পবৃষ্টি",
                        "৭. স্নিগ্ধ সমাপন ও শান্তি লয়" to "সন্ধ্যা আরতির প্রদীপ শিখা",
                        "৮. সমর্পণ ও শুভ প্রার্থনা" to "প্রণামরত অঞ্জলি ও বিশ্বকল্যাণ প্রার্থনা"
                    )

                    Column(verticalArrangement = Arrangement.spacedBy(4.dp)) {
                        partsList.forEachIndexed { idx, p ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 2.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(p.first, fontSize = 11.sp, fontWeight = FontWeight.SemiBold, color = MaterialTheme.colorScheme.onSurface)
                                Text(p.second, fontSize = 11.sp, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }
                }
            }
        }

        // 7. Optional Customization Accordion
        item {
            Card(
                shape = RoundedCornerShape(14.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.25f))
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.setCustomizingUniversal(!state.isCustomizingUniversal) },
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.Tune, contentDescription = null, tint = SaffronPrimary, modifier = Modifier.size(18.dp))
                            Spacer(modifier = Modifier.width(8.dp))
                            Text("উন্নত পছন্দ ও কাস্টমাইজেশন (ঐচ্ছিক)", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                        }
                        Icon(
                            if (state.isCustomizingUniversal) Icons.Default.ExpandLess else Icons.Default.ExpandMore,
                            contentDescription = null,
                            tint = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }

                    if (state.isCustomizingUniversal) {
                        Spacer(modifier = Modifier.height(12.dp))

                        // Duration selector
                        Text("সময়কাল (Duration):", fontSize = 11.sp, fontWeight = FontWeight.Medium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf(15 to "১৫ সে.", 30 to "৩০ সে.", 60 to "১ মিনিট").forEach { (d, label) ->
                                FilterChip(
                                    selected = state.durationSeconds == d,
                                    onClick = { viewModel.setVideoDuration(d) },
                                    label = { Text(label, fontSize = 11.sp) }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Resolution & Ratio
                        Text("ভিডিও আকার ও রেজোলিউশন:", fontSize = 11.sp, fontWeight = FontWeight.Medium)
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            listOf("16:9" to "ল্যান্ডস্কেপ (16:9)", "9:16" to "রিলস/শর্টস (9:16)", "1:1" to "স্কয়ার (1:1)").forEach { (r, label) ->
                                FilterChip(
                                    selected = state.aspectRatio == r,
                                    onClick = { viewModel.setVideoAspectRatio(r) },
                                    label = { Text(label, fontSize = 11.sp) }
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))

                        // Subtitle toggle
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text("সিঙ্ক্রোনাইজড সাবটাইটেল টেক্সট:", fontSize = 11.sp, fontWeight = FontWeight.Medium)
                            Switch(
                                checked = state.subtitlesEnabled,
                                onCheckedChange = { viewModel.toggleSubtitles(it) }
                            )
                        }
                    }
                }
            }
        }

        // 8. One-Tap Master Creation Action Button
        item {
            Button(
                onClick = { viewModel.startUniversalCreation() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(54.dp)
                    .testTag("btn_universal_create_action"),
                shape = RoundedCornerShape(14.dp),
                colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                enabled = !state.isGenerating
            ) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null, tint = Color.White)
                Spacer(modifier = Modifier.width(10.dp))
                Text(
                    text = if (state.isGenerating) "মাস্টার প্রোডাকশন রেন্ডার হচ্ছে..." else "✨ এক ক্লিকে মাস্টার প্রোডাকশন তৈরি করুন",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = Color.White
                )
            }
        }

        // 9. Real-Time Generation Progress Tracker
        if (state.isGenerating || state.generationStage != VideoGenerationStatus.IDLE) {
            item {
                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, SaffronPrimary.copy(alpha = 0.5f))
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "প্রোডাকশন স্ট্যাটাস: ${state.generationStage.labelBengali}",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = SaffronPrimary
                            )
                            Text(
                                text = "${(state.generationProgress * 100).toInt()}%",
                                fontWeight = FontWeight.Bold,
                                color = SaffronPrimary
                            )
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        LinearProgressIndicator(
                            progress = { state.generationProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = SaffronPrimary,
                            trackColor = SaffronPrimary.copy(alpha = 0.2f)
                        )

                        if (state.generationStatusMessage.isNotBlank()) {
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = state.generationStatusMessage,
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text("পর্যায়: ${state.generationStage.stepIndex}/৯", fontSize = 10.sp, color = MaterialTheme.colorScheme.outline)
                            if (state.isGenerating) {
                                TextButton(
                                    onClick = { viewModel.cancelVideoGeneration() },
                                    contentPadding = PaddingValues(0.dp)
                                ) {
                                    Text("বাতিল করুন", color = Color.Red, fontSize = 11.sp)
                                }
                            }
                        }
                    }
                }
            }
        }

        // 10. Completed Master Result Card
        val master = state.masterResult
        if (master != null && !state.isGenerating) {
            item {
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = Color(0xFFE8F5E9)),
                    border = BorderStroke(1.5.dp, Color(0xFF2E7D32))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(verticalAlignment = Alignment.CenterVertically) {
                            Icon(Icons.Default.CheckCircle, contentDescription = null, tint = Color(0xFF2E7D32), modifier = Modifier.size(24.dp))
                            Spacer(modifier = Modifier.width(10.dp))
                            Column {
                                Text(
                                    text = "মাস্টার প্রোডাকশন প্রস্তুত!",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = Color(0xFF1B5E20)
                                )
                                Text(
                                    text = master.title,
                                    fontSize = 12.sp,
                                    color = Color(0xFF2E7D32)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        // Telemetry details
                        Text("ভিডিও আকার: ${master.videoFile.length() / 1024} KB • সময়: ${master.videoEntity.durationSeconds}s", fontSize = 11.sp, color = Color(0xFF33691E))
                        Text("চেকসাম SHA-256: ${master.qualityReport.sha256Checksum.take(16)}...", fontSize = 10.sp, fontFamily = FontFamily.Monospace, color = Color(0xFF558B2F))

                        Spacer(modifier = Modifier.height(12.dp))

                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.spacedBy(8.dp)
                        ) {
                            Button(
                                onClick = { viewModel.setVideoActiveTab(2) }, // Switch to Player tab
                                modifier = Modifier.weight(1f),
                                colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32)),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.PlayArrow, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("প্লেয়ারে চালান", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                            }

                            OutlinedButton(
                                onClick = {
                                    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", master.videoFile)
                                    val intent = Intent(Intent.ACTION_VIEW).apply {
                                        setDataAndType(uri, "video/mp4")
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(Intent.createChooser(intent, "মাস্টার ভিডিও প্লে করুন"))
                                },
                                modifier = Modifier.weight(1f),
                                shape = RoundedCornerShape(8.dp)
                            ) {
                                Icon(Icons.Default.Share, contentDescription = null, modifier = Modifier.size(18.dp))
                                Spacer(modifier = Modifier.width(4.dp))
                                Text("শেয়ার করুন", fontSize = 12.sp)
                            }
                        }
                    }
                }
            }
        }
    }
}

// ============================================================
// TAB 1: Video Studio & Scene Generator
// ============================================================
@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun VideoStudioTab(viewModel: VedaNovaViewModel, state: VideoStudioUiState) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Active Generating Progress Card
        if (state.isGenerating) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = SaffronPrimary.copy(alpha = 0.08f)),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, SaffronPrimary)
                ) {
                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(16.dp)
                    ) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                CircularProgressIndicator(
                                    modifier = Modifier.size(20.dp),
                                    strokeWidth = 2.dp,
                                    color = SaffronPrimary
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = "ভিডিও রেন্ডারিং চলছে (${(state.generationProgress * 100).toInt()}%)",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = SaffronPrimary
                                )
                            }
                            TextButton(
                                onClick = { viewModel.cancelVideoGeneration() },
                                modifier = Modifier.testTag("btn_cancel_video_gen")
                            ) {
                                Text("বাতিল করুন", color = MaterialTheme.colorScheme.error, fontSize = 12.sp)
                            }
                        }

                        Spacer(modifier = Modifier.height(10.dp))
                        LinearProgressIndicator(
                            progress = { state.generationProgress },
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(8.dp)
                                .clip(RoundedCornerShape(4.dp)),
                            color = SaffronPrimary,
                            trackColor = MaterialTheme.colorScheme.surfaceVariant
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "ধাপ: ${state.generationStage.name} • হার্ডওয়্যার মিডিয়া কোডেক এনকোডিং সক্রিয়",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                    }
                }
            }
        }

        // Prompt Input Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "ভিডিও প্রম্পট ও বিবরণ (Devotional Video Prompt)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    OutlinedTextField(
                        value = state.prompt,
                        onValueChange = { viewModel.setVideoPrompt(it) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .heightIn(min = 100.dp)
                            .testTag("input_video_prompt"),
                        placeholder = { Text("ভিডিওর দৃশ্য, ভাব ও পারিপার্শ্বিকতা লিখুন...") },
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedButton(
                            onClick = { viewModel.analyzeVideoPrompt() },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_check_video_safety"),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.VerifiedUser, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("নিরাপত্তা যাচাই", fontSize = 12.sp)
                        }

                        OutlinedButton(
                            onClick = { viewModel.generateVideoStoryboardPreview() },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_preview_storyboard"),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.ViewCarousel, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(6.dp))
                            Text("স্টোরিবোর্ড ড্রাফট", fontSize = 12.sp)
                        }
                    }

                    // Prompt Analysis Result Badge
                    state.promptAnalysis?.let { analysis ->
                        Spacer(modifier = Modifier.height(10.dp))
                        Surface(
                            shape = RoundedCornerShape(8.dp),
                            color = if (analysis.safetyPassed) Color(0xFF2E7D32).copy(alpha = 0.1f) else MaterialTheme.colorScheme.errorContainer,
                            border = BorderStroke(1.dp, if (analysis.safetyPassed) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error)
                        ) {
                            Column(modifier = Modifier.padding(10.dp)) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Icon(
                                        if (analysis.safetyPassed) Icons.Default.CheckCircle else Icons.Default.Warning,
                                        contentDescription = null,
                                        tint = if (analysis.safetyPassed) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error,
                                        modifier = Modifier.size(16.dp)
                                    )
                                    Spacer(modifier = Modifier.width(6.dp))
                                    Text(
                                        text = if (analysis.safetyPassed) "শাস্ত্রীয় সুরক্ষা অনুমোদিত (Passed)" else "সুরক্ষা সতর্কতা (Safety Issue)",
                                        fontWeight = FontWeight.Bold,
                                        fontSize = 12.sp,
                                        color = if (analysis.safetyPassed) Color(0xFF2E7D32) else MaterialTheme.colorScheme.error
                                    )
                                }
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = "ধরন: ${analysis.suggestedVideoType} • মেজাজ: ${analysis.mood} • মূল বিষয়: ${analysis.subject}",
                                    fontSize = 11.sp,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        // Configuration Options Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "প্রযুক্তিগত কনফিগারেশন ও শৈলী",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Text("ভিডিও টাইপ (Video Type):", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        val types = listOf("Dharma Video", "Festival Special", "Temple History", "Scripture Scene", "Meditation")
                        items(types) { type ->
                            FilterChip(
                                selected = state.videoType == type,
                                onClick = { viewModel.setVideoType(type) },
                                label = { Text(type, fontSize = 11.sp) },
                                modifier = Modifier.testTag("chip_type_$type")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text("ভিডিওর স্থায়িত্ব (Duration):", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        val durations = listOf(5, 10, 15, 30, 60)
                        durations.forEach { d ->
                            FilterChip(
                                selected = state.durationSeconds == d,
                                onClick = { viewModel.setVideoDuration(d) },
                                label = { Text("${d}s", fontSize = 11.sp) },
                                modifier = Modifier.testTag("chip_duration_${d}s")
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(12.dp)
                    ) {
                        Column(modifier = Modifier.weight(1f)) {
                            Text("অনুপাত (Aspect Ratio):", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf("16:9", "9:16", "1:1").forEach { ratio ->
                                    FilterChip(
                                        selected = state.aspectRatio == ratio,
                                        onClick = { viewModel.setVideoAspectRatio(ratio) },
                                        label = { Text(ratio, fontSize = 11.sp) }
                                    )
                                }
                            }
                        }

                        Column(modifier = Modifier.weight(1f)) {
                            Text("রেজোলিউশন (Resolution):", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                            Spacer(modifier = Modifier.height(6.dp))
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                listOf("720p", "1080p").forEach { res ->
                                    FilterChip(
                                        selected = state.resolution == res,
                                        onClick = { viewModel.setVideoResolution(res) },
                                        label = { Text(res, fontSize = 11.sp) }
                                    )
                                }
                            }
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text("কণ্ঠ ও পাঠের ধরন (Voice/Chant):", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        val voices = listOf("Narration", "Chanting", "Katha", "None")
                        items(voices) { voice ->
                            FilterChip(
                                selected = state.voiceType == voice,
                                onClick = { viewModel.setVideoVoice(voice) },
                                label = { Text(voice, fontSize = 11.sp) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text("পটভূমি সুর (Background Devotional Music):", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        val musics = listOf("Devotional Flute", "Temple Bells", "Veena & Tanpura", "Sitar", "None")
                        items(musics) { music ->
                            FilterChip(
                                selected = state.bgMusic == music,
                                onClick = { viewModel.setVideoBgMusic(music) },
                                label = { Text(music, fontSize = 11.sp) }
                            )
                        }
                    }

                    Spacer(modifier = Modifier.height(12.dp))
                    Text("ভিজ্যুয়াল স্টাইল (Visual Art Style):", fontSize = 12.sp, fontWeight = FontWeight.SemiBold)
                    Spacer(modifier = Modifier.height(6.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        val styles = listOf("Spiritual Art", "Cinematic", "Temple Painting", "Minimalist")
                        items(styles) { st ->
                            FilterChip(
                                selected = state.style == st,
                                onClick = { viewModel.setVideoStyle(st) },
                                label = { Text(st, fontSize = 11.sp) }
                            )
                        }
                    }
                }
            }
        }

        // Primary Action Button
        item {
            Button(
                onClick = { viewModel.startVideoGeneration() },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("btn_generate_video_action"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary),
                enabled = !state.isGenerating
            ) {
                Icon(Icons.Default.AutoAwesome, contentDescription = null)
                Spacer(modifier = Modifier.width(8.dp))
                Text(
                    text = if (state.isGenerating) "রেন্ডারিং হচ্ছে..." else "ভিডিও জেনারেট করুন (Generate Real Video)",
                    fontWeight = FontWeight.Bold,
                    fontSize = 15.sp,
                    color = Color.White
                )
            }
        }
    }
}

// ============================================================
// TAB 1: Real Player & QA Verification
// ============================================================
@Composable
private fun VideoPlayerTab(viewModel: VedaNovaViewModel, state: VideoStudioUiState) {
    val activeVideo = state.selectedVideo ?: state.currentGeneratedVideo
    val context = LocalContext.current

    if (activeVideo == null) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(32.dp),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.Movie, contentDescription = null, tint = MaterialTheme.colorScheme.outline, modifier = Modifier.size(64.dp))
                Spacer(modifier = Modifier.height(16.dp))
                Text(
                    text = "কোনো ভিডিও নির্বাচিত নেই",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold
                )
                Spacer(modifier = Modifier.height(8.dp))
                Text(
                    text = "স্টুডিও ট্যাব থেকে একটি নতুন ভিডিও জেনারেট করুন অথবা ক্যাটালগ থেকে নির্বাচন করুন।",
                    style = MaterialTheme.typography.bodySmall,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        }
        return
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Real Video Player Viewport
        item {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = Color.Black),
                modifier = Modifier
                    .fillMaxWidth()
                    .height(240.dp)
                    .clip(RoundedCornerShape(16.dp))
            ) {
                Box(modifier = Modifier.fillMaxSize()) {
                    RealVideoPlayerView(activeVideo.videoUrl)

                    // Overlay watermark / badge
                    Surface(
                        shape = RoundedCornerShape(8.dp),
                        color = Color.Black.copy(alpha = 0.6f),
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(8.dp)
                    ) {
                        Text(
                            text = "${activeVideo.resolution} • ${activeVideo.aspectRatio}",
                            color = Color.White,
                            fontSize = 10.sp,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.padding(horizontal = 6.dp, vertical = 3.dp)
                        )
                    }
                }
            }
        }

        // Title and Status
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = activeVideo.title,
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            modifier = Modifier.weight(1f)
                        )
                        Spacer(modifier = Modifier.width(8.dp))
                        VideoStatusBadge(activeVideo.verificationStatus)
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "প্রম্পট: ${activeVideo.prompt}",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    HorizontalDivider()
                    Spacer(modifier = Modifier.height(12.dp))

                    // Technical Telemetry
                    Text("কারিগরি স্পেসিফিকেশন (Technical Specs):", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    Spacer(modifier = Modifier.height(6.dp))
                    Text("• ইঞ্জিন: ${activeVideo.engine}", fontSize = 11.sp)
                    Text("• ফাইল আকার: ${activeVideo.fileSizeBytes} bytes (${activeVideo.fileSizeBytes / 1024} KB)", fontSize = 11.sp)
                    Text("• সময়সীমা: ${activeVideo.durationSeconds} সেকেন্ড", fontSize = 11.sp)
                    Text("• সংস্করণ: v${activeVideo.version}", fontSize = 11.sp)
                    Text("• এসএইচএ-২৫৬ চেকসাম: ${activeVideo.sha256Checksum}", fontSize = 11.sp, fontFamily = FontFamily.Monospace)
                    Text("• ফাইল লোকেশন: ${activeVideo.videoUrl}", fontSize = 10.sp, color = MaterialTheme.colorScheme.outline)
                }
            }
        }

        // Synchronized Subtitles & Devotional Lyrics Card
        val master = state.masterResult
        if (master != null && (master.videoEntity.id == activeVideo.id || master.title == activeVideo.title)) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant.copy(alpha = 0.35f)),
                    shape = RoundedCornerShape(16.dp),
                    border = BorderStroke(1.dp, SaffronPrimary.copy(alpha = 0.3f))
                ) {
                    Column(modifier = Modifier.padding(16.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "📜 সিঙ্ক্রোনাইজড সাবটাইটেল ও কীর্তন পদাবলী",
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                color = SaffronPrimary
                            )
                            VideoMiniBadge("৮-অংশ সিঙ্ক", SaffronPrimary.copy(alpha = 0.15f), SaffronPrimary)
                        }

                        Spacer(modifier = Modifier.height(10.dp))

                        master.subtitles.forEach { sub ->
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .padding(vertical = 3.dp),
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Text(
                                    text = "[${sub.startTimeSeconds}s - ${sub.endTimeSeconds}s]",
                                    fontSize = 11.sp,
                                    fontFamily = FontFamily.Monospace,
                                    color = MaterialTheme.colorScheme.outline
                                )
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = sub.textBengali,
                                    fontSize = 12.sp,
                                    fontWeight = FontWeight.Medium,
                                    color = MaterialTheme.colorScheme.onSurface,
                                    modifier = Modifier.weight(1f)
                                )
                            }
                        }
                    }
                }
            }
        }

        // Admin QA Action Buttons
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "এডমিন যাচাইকরণ ও প্রকাশনা নিয়ন্ত্রণ",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = { viewModel.verifyVideo(activeVideo.id, true, "এডমিন দ্বারা শাস্ত্রীয় গুণমান যাচাই সম্পন্ন") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_approve_video"),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = Color(0xFF2E7D32))
                        ) {
                            Icon(Icons.Default.Check, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("অনুমোদন (Verify)", fontSize = 11.sp, color = Color.White)
                        }

                        OutlinedButton(
                            onClick = { viewModel.verifyVideo(activeVideo.id, false, "এডমিন দ্বারা সংশোধন প্রয়োজন হিসেবে চিহ্নিত") },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_reject_video"),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Close, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("প্রত্যাখ্যান", fontSize = 11.sp, color = MaterialTheme.colorScheme.error)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        Button(
                            onClick = {
                                if (activeVideo.isPublished) {
                                    viewModel.unpublishVideo(activeVideo.id)
                                } else {
                                    viewModel.publishVideo(activeVideo.id)
                                }
                            },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_publish_video"),
                            shape = RoundedCornerShape(8.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = if (activeVideo.isPublished) MaterialTheme.colorScheme.secondary else SaffronPrimary
                            )
                        ) {
                            Icon(if (activeVideo.isPublished) Icons.Default.VisibilityOff else Icons.Default.Publish, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text(if (activeVideo.isPublished) "অপ্রকাশিত করুন" else "সর্বজনীন প্রকাশ (Publish)", fontSize = 11.sp, color = Color.White)
                        }

                        OutlinedButton(
                            onClick = { viewModel.regenerateVideo(activeVideo.id) },
                            modifier = Modifier
                                .weight(1f)
                                .testTag("btn_regen_video"),
                            shape = RoundedCornerShape(8.dp)
                        ) {
                            Icon(Icons.Default.Refresh, contentDescription = null, modifier = Modifier.size(16.dp))
                            Spacer(modifier = Modifier.width(4.dp))
                            Text("পুনরায় তৈরি", fontSize = 11.sp)
                        }
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    OutlinedButton(
                        onClick = {
                            val cleanPath = activeVideo.videoUrl.removePrefix("file://")
                            val file = File(cleanPath)
                            if (file.exists()) {
                                try {
                                    val uri = FileProvider.getUriForFile(context, "${context.packageName}.fileprovider", file)
                                    val shareIntent = Intent(Intent.ACTION_SEND).apply {
                                        type = "video/mp4"
                                        putExtra(Intent.EXTRA_STREAM, uri)
                                        addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
                                    }
                                    context.startActivity(Intent.createChooser(shareIntent, "শেয়ার বা ডাউনলোড করুন"))
                                } catch (e: Exception) {
                                    val intent = Intent(Intent.ACTION_VIEW).apply {
                                        setDataAndType(Uri.fromFile(file), "video/mp4")
                                        addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                                    }
                                    context.startActivity(intent)
                                }
                            }
                        },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("btn_export_video"),
                        shape = RoundedCornerShape(8.dp)
                    ) {
                        Icon(Icons.Default.Download, contentDescription = null, modifier = Modifier.size(16.dp))
                        Spacer(modifier = Modifier.width(6.dp))
                        Text("ভিডিও ডাউনলোড / শেয়ার করুন (Real File Export)", fontSize = 12.sp)
                    }
                }
            }
        }
    }
}

@Composable
private fun RealVideoPlayerView(videoPath: String) {
    val clean = videoPath.removePrefix("file://")
    val file = remember(videoPath) { File(clean) }

    if (!file.exists()) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black),
            contentAlignment = Alignment.Center
        ) {
            Column(horizontalAlignment = Alignment.CenterHorizontally) {
                Icon(Icons.Default.VideocamOff, contentDescription = null, tint = Color.Gray, modifier = Modifier.size(36.dp))
                Spacer(modifier = Modifier.height(6.dp))
                Text("ভিডিও ফাইলটি খুঁজে পাওয়া যায়নি", color = Color.White, fontSize = 12.sp)
            }
        }
    } else {
        AndroidView(
            modifier = Modifier.fillMaxSize(),
            factory = { ctx ->
                VideoView(ctx).apply {
                    val mediaController = MediaController(ctx)
                    mediaController.setAnchorView(this)
                    setMediaController(mediaController)
                    setVideoPath(file.absolutePath)
                    setOnPreparedListener { mp ->
                        mp.isLooping = true
                        start()
                    }
                }
            },
            update = { view ->
                if (file.exists()) {
                    view.setVideoPath(file.absolutePath)
                    view.start()
                }
            }
        )
    }
}

@Composable
private fun VideoStatusBadge(status: String) {
    val (bgColor, textColor, label) = when (status) {
        VideoVerificationStatus.PUBLISHED.name -> Triple(SaffronPrimary.copy(alpha = 0.15f), SaffronPrimary, "প্রকাশিত (PUBLISHED)")
        VideoVerificationStatus.VERIFIED.name -> Triple(Color(0xFF2E7D32).copy(alpha = 0.15f), Color(0xFF2E7D32), "অনুমোদিত (VERIFIED)")
        VideoVerificationStatus.REJECTED.name -> Triple(MaterialTheme.colorScheme.errorContainer, MaterialTheme.colorScheme.error, "প্রত্যাখ্যাত (REJECTED)")
        else -> Triple(MaterialTheme.colorScheme.surfaceVariant, MaterialTheme.colorScheme.onSurfaceVariant, "অপেক্ষমান (PENDING)")
    }

    Surface(
        shape = RoundedCornerShape(8.dp),
        color = bgColor
    ) {
        Text(
            text = label,
            fontSize = 11.sp,
            fontWeight = FontWeight.Bold,
            color = textColor,
            modifier = Modifier.padding(horizontal = 8.dp, vertical = 4.dp)
        )
    }
}

// ============================================================
// TAB 2: Storyboard & Scene Planning
// ============================================================
@Composable
private fun VideoStoryboardTab(viewModel: VedaNovaViewModel, state: VideoStudioUiState) {
    val storyboard = state.previewStoryboard

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(
                            text = "দৃশ্যাবলীর পরিকল্পনা ও স্টোরিবোর্ড (Scene Blueprint)",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold
                        )
                        Icon(Icons.Default.AutoStories, contentDescription = null, tint = SaffronPrimary)
                    }

                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "ভিডিও নির্মাণের পূর্বে প্রতিটি দৃশ্যের ভিজ্যুয়াল ক্যামেরা মোশন, আখ্যান ও শাস্ত্রীয় ব্যাখ্যা এখানে সংকলিত হয়।",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    if (storyboard != null) {
                        Spacer(modifier = Modifier.height(12.dp))
                        HorizontalDivider()
                        Spacer(modifier = Modifier.height(12.dp))
                        Text("মূল ভাব ও চরিত্র: ${storyboard.primaryDeityOrTheme}", fontWeight = FontWeight.Bold, fontSize = 13.sp)
                        Text("মোট সময়: ${storyboard.totalDurationSeconds} সেকেন্ড (${storyboard.scenes.size} টি দৃশ্য)", fontSize = 11.sp)
                        Text("অনুপাত: ${storyboard.aspectRatio} • রেজোলিউশন: ${storyboard.resolution}", fontSize = 11.sp)
                        Text("ভিজ্যুয়াল স্টাইল: ${storyboard.visualStyle}", fontSize = 11.sp)
                    }
                }
            }
        }

        if (storyboard == null || storyboard.scenes.isEmpty()) {
            item {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surfaceVariant),
                    shape = RoundedCornerShape(16.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text("বর্তমানে কোনো স্টোরিবোর্ড সক্রিয় নেই", fontWeight = FontWeight.Bold)
                            Spacer(modifier = Modifier.height(6.dp))
                            Text(
                                text = "স্টুডিও ট্যাব থেকে \"স্টোরিবোর্ড ড্রাফট\" বোতামে ক্লিক করে তাৎক্ষণিক সিন প্ল্যান তৈরি করুন।",
                                fontSize = 12.sp,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        } else {
            items(storyboard.scenes) { scene ->
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Row(verticalAlignment = Alignment.CenterVertically) {
                                Surface(
                                    shape = CircleShape,
                                    color = SaffronPrimary,
                                    modifier = Modifier.size(24.dp)
                                ) {
                                    Box(contentAlignment = Alignment.Center) {
                                        Text(
                                            text = "${scene.sceneNumber}",
                                            color = Color.White,
                                            fontWeight = FontWeight.Bold,
                                            fontSize = 11.sp
                                        )
                                    }
                                }
                                Spacer(modifier = Modifier.width(8.dp))
                                Text(
                                    text = scene.title,
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold
                                )
                            }
                            Surface(
                                shape = RoundedCornerShape(6.dp),
                                color = MaterialTheme.colorScheme.surfaceVariant
                            ) {
                                Text(
                                    text = "${scene.durationSeconds}s",
                                    fontSize = 10.sp,
                                    fontWeight = FontWeight.Bold,
                                    modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                )
                            }
                        }

                        Spacer(modifier = Modifier.height(8.dp))
                        Text(
                            text = "চিত্ররূপ: ${scene.description}",
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurface
                        )

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = "ক্যামেরা মোশন: ${scene.cameraMovement}",
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        if (scene.voiceScript.isNotBlank()) {
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = "কণ্ঠ আখ্যান: \"${scene.voiceScript}\"",
                                fontSize = 11.sp,
                                fontWeight = FontWeight.Medium,
                                color = SaffronPrimary
                            )
                        }

                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = "মোটিফ ও সুর: ${scene.visualMotif} • ${scene.musicMood}",
                            fontSize = 10.sp,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                }
            }
        }
    }
}

// ============================================================
// TAB 3: Video Catalog & Versions
// ============================================================
@Composable
private fun VideoCatalogTab(
    viewModel: VedaNovaViewModel,
    state: VideoStudioUiState,
    allVideos: List<VideoGenerationEntity>
) {
    val filteredVideos = remember(allVideos, state.searchQuery, state.filterStatus, state.filterType) {
        allVideos.filter { video ->
            val matchQuery = state.searchQuery.isBlank() ||
                    video.title.contains(state.searchQuery, ignoreCase = true) ||
                    video.prompt.contains(state.searchQuery, ignoreCase = true)

            val matchStatus = state.filterStatus == "ALL" || video.verificationStatus == state.filterStatus
            val matchType = state.filterType == "ALL" || video.videoType.equals(state.filterType, ignoreCase = true)

            matchQuery && matchStatus && matchType
        }
    }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(14.dp)
    ) {
        // Search & Filter
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(14.dp)) {
                    OutlinedTextField(
                        value = state.searchQuery,
                        onValueChange = { viewModel.setVideoSearchQuery(it) },
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("input_search_videos"),
                        placeholder = { Text("ভিডিও খুঁজুন (নাম বা প্রম্পট)...", fontSize = 12.sp) },
                        leadingIcon = { Icon(Icons.Default.Search, contentDescription = null, modifier = Modifier.size(18.dp)) },
                        shape = RoundedCornerShape(12.dp)
                    )

                    Spacer(modifier = Modifier.height(10.dp))
                    LazyRow(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                        val filters = listOf("ALL", VideoVerificationStatus.PUBLISHED.name, VideoVerificationStatus.VERIFIED.name, VideoVerificationStatus.PENDING_VERIFICATION.name, VideoVerificationStatus.UNVERIFIED.name)
                        items(filters) { f ->
                            FilterChip(
                                selected = state.filterStatus == f,
                                onClick = { viewModel.setVideoFilterStatus(f) },
                                label = { Text(f, fontSize = 10.sp) }
                            )
                        }
                    }
                }
            }
        }

        if (filteredVideos.isEmpty()) {
            item {
                Box(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(32.dp),
                    contentAlignment = Alignment.Center
                ) {
                    Text("কোনো ভিডিও পাওয়া যায়নি", color = MaterialTheme.colorScheme.outline)
                }
            }
        } else {
            items(filteredVideos) { video ->
                val isSelected = state.selectedVideo?.id == video.id
                Card(
                    colors = CardDefaults.cardColors(
                        containerColor = if (isSelected) SaffronPrimary.copy(alpha = 0.08f) else MaterialTheme.colorScheme.surface
                    ),
                    shape = RoundedCornerShape(14.dp),
                    border = BorderStroke(1.dp, if (isSelected) SaffronPrimary else MaterialTheme.colorScheme.outline),
                    modifier = Modifier
                        .fillMaxWidth()
                        .clickable {
                            viewModel.selectVideo(video)
                            viewModel.setVideoActiveTab(1) // Jump to player
                        }
                ) {
                    Column(modifier = Modifier.padding(14.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = video.title,
                                style = MaterialTheme.typography.titleSmall,
                                fontWeight = FontWeight.Bold,
                                modifier = Modifier.weight(1f)
                            )
                            VideoStatusBadge(video.verificationStatus)
                        }

                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = video.prompt,
                            style = MaterialTheme.typography.bodySmall,
                            maxLines = 2,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )

                        Spacer(modifier = Modifier.height(8.dp))
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "${video.durationSeconds}s • ${video.resolution} • ${video.aspectRatio} • v${video.version}",
                                fontSize = 11.sp,
                                color = MaterialTheme.colorScheme.outline
                            )
                            Row(horizontalArrangement = Arrangement.spacedBy(6.dp)) {
                                IconButton(
                                    onClick = {
                                        viewModel.selectVideo(video)
                                        viewModel.setVideoActiveTab(1)
                                    },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.PlayCircle, contentDescription = "Play", tint = SaffronPrimary, modifier = Modifier.size(20.dp))
                                }
                                IconButton(
                                    onClick = { viewModel.deleteVideo(video.id) },
                                    modifier = Modifier.size(28.dp)
                                ) {
                                    Icon(Icons.Default.Delete, contentDescription = "Delete", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(18.dp))
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

// ============================================================
// TAB 4: Safety & Audit Trail
// ============================================================
@Composable
private fun VideoAuditTab(
    viewModel: VedaNovaViewModel,
    state: VideoStudioUiState,
    auditLogs: List<VideoAuditLogEntity>
) {
    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .padding(16.dp),
        verticalArrangement = Arrangement.spacedBy(16.dp)
    ) {
        // Safety Policy Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.Shield, contentDescription = null, tint = SaffronPrimary)
                        Spacer(modifier = Modifier.width(8.dp))
                        Text(
                            text = "বেদিক ভিডিও নিরাপত্তা ও নীতিবিধি (Safety Policy)",
                            style = MaterialTheme.typography.titleSmall,
                            fontWeight = FontWeight.Bold
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))
                    Text("✓ কোনো জীবিত ব্যক্তির কৃত্রিম মুখাবয়ব (Deepfake/Face Swap) নিষিদ্ধ।", fontSize = 12.sp)
                    Text("✓ শাস্ত্রীয় পবিত্রতা ও বেদিক মন্ত্রের বিকৃতি কঠোরভাবে ফিল্টার করা হয়।", fontSize = 12.sp)
                    Text("✓ প্রতিটি ভিডিওর হ্যাশ কোড (SHA-256) অডিট ট্রেইলে অপরিবর্তনীয়ভাবে সংরক্ষিত।", fontSize = 12.sp)
                    Text("✓ কপিরাইট ও ভয়েস ক্লোনিং প্রতিরোধে নিজস্ব সিন্থেসাইজার ইঞ্জিন ব্যবহৃত।", fontSize = 12.sp)
                }
            }
        }

        // Entitlement Settings Card
        item {
            Card(
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = "ভিআইপি এনটাইটেলমেন্ট নিয়ন্ত্রণ (Server-Side Entitlement)",
                        style = MaterialTheme.typography.titleSmall,
                        fontWeight = FontWeight.Bold
                    )
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = "ভিডিও জেনারেশন কেবল ভেরিফাইড ভিআইপি ইউজার ও এডমিনদের জন্য কার্যকর থাকে।",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )

                    Spacer(modifier = Modifier.height(12.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column {
                            Text("সাধারণ ব্যবহারকারীর VIP ভিডিও অ্যাক্সেস", fontWeight = FontWeight.SemiBold, fontSize = 13.sp)
                            Text(if (state.isVipUser) "সক্রিয় (Active)" else "নিষ্ক্রিয় (Free Only)", fontSize = 11.sp, color = SaffronPrimary)
                        }
                        Switch(
                            checked = state.isVipUser,
                            onCheckedChange = { viewModel.setVipUserAccess(it) }
                        )
                    }
                }
            }
        }

        // Audit Trail Logs
        item {
            Text(
                text = "অডিট লগ স্ট্রিম (${auditLogs.size} টি ইভেন্ট):",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold
            )
        }

        if (auditLogs.isEmpty()) {
            item {
                Text("বর্তমানে কোনো অডিট লগ নেই", color = MaterialTheme.colorScheme.outline, fontSize = 12.sp)
            }
        } else {
            items(auditLogs) { log ->
                val timeStr = SimpleDateFormat("dd MMM, HH:mm:ss", Locale.getDefault()).format(Date(log.timestamp))
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Column(modifier = Modifier.padding(12.dp)) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween
                        ) {
                            Text(
                                text = "${log.action} • ${log.result}",
                                fontWeight = FontWeight.Bold,
                                fontSize = 12.sp,
                                color = if (log.result == "SUCCESS") Color(0xFF2E7D32) else MaterialTheme.colorScheme.primary
                            )
                            Text(timeStr, fontSize = 10.sp, color = MaterialTheme.colorScheme.outline)
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = log.details,
                            fontSize = 11.sp,
                            color = MaterialTheme.colorScheme.onSurfaceVariant
                        )
                        Spacer(modifier = Modifier.height(2.dp))
                        Text(
                            text = "ব্যবহারকারী: ${log.adminUsername} • আইডি: ${log.videoId}",
                            fontSize = 9.sp,
                            color = MaterialTheme.colorScheme.outline
                        )
                    }
                }
            }
        }
    }
}
