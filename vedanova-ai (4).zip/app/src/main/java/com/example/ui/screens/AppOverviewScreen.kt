package com.example.ui.screens

import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.example.ui.components.StatusPill
import com.example.ui.theme.*
import com.example.ui.viewmodel.ScreenDestination
import com.example.ui.viewmodel.VedaNovaViewModel

enum class FeatureHealthStatus(val label: String, val color: Color, val icon: ImageVector) {
    WORKING("Working (Operational)", StatusGreen, Icons.Default.CheckCircle),
    ACTIVE("Active / Online", SpiritualTeal, Icons.Default.CloudDone),
    NEEDS_REVIEW("Needs Admin Review", StatusYellow, Icons.Default.Warning),
    ERROR("Degraded / Issue", StatusRed, Icons.Default.Error)
}

data class AppFeatureInfo(
    val id: String,
    val nameBengali: String,
    val nameEnglish: String,
    val screenDestination: ScreenDestination,
    val screenName: String,
    val backendService: String,
    val linkedDatabaseTable: String,
    val status: FeatureHealthStatus,
    val description: String,
    val navigationPath: String
)

data class AppScreenInfo(
    val destination: ScreenDestination,
    val name: String,
    val bengaliTitle: String,
    val category: String,
    val icon: ImageVector,
    val features: List<String>,
    val linkedDaos: List<String>,
    val linkedServices: List<String>,
    val navigationTrigger: String,
    val previewSummary: String
)

@Composable
fun AppOverviewScreen(viewModel: VedaNovaViewModel) {
    var selectedTab by remember { mutableStateOf(0) } // 0: Screen Architecture, 1: Real Feature Map, 2: Navigation Graph
    var selectedScreen by remember { mutableStateOf<ScreenDestination?>(null) }
    var featureSearchQuery by remember { mutableStateOf("") }
    var selectedStatusFilter by remember { mutableStateOf<FeatureHealthStatus?>(null) }

    val health by viewModel.healthStatus.collectAsStateWithLifecycle()
    val totalKnowledge by viewModel.knowledgeCount.collectAsStateWithLifecycle()
    val apiKeys by viewModel.allApiKeys.collectAsStateWithLifecycle()
    val totalLogs by viewModel.totalLogsCount.collectAsStateWithLifecycle()
    val pendingTasks by viewModel.allDevelopmentTasks.collectAsStateWithLifecycle()

    val screensList = remember {
        listOf(
            AppScreenInfo(
                destination = ScreenDestination.SETTINGS,
                name = "System & AI Brain Settings",
                bengaliTitle = "সিস্টেম ও এআই ব্রেন সেটিংস",
                category = "Configuration",
                icon = Icons.Default.Tune,
                features = listOf(
                    "AI Brain Model Selection & Scriptural Temperature Rigor",
                    "Verification Confidence Threshold & Guardrails",
                    "Voice Guide & Real-Time TTS Announcer Settings",
                    "Security, API Gateway RPM & Rate Limiting",
                    "High Contrast Visibility Mode & Audit Trail Sync"
                ),
                linkedDaos = listOf("SystemLogDao", "AuditLogDao"),
                linkedServices = listOf("AiOrchestrator", "LiveVoiceAiManager", "VedaNovaRepository"),
                navigationTrigger = "Top Bar Tune Icon / Bottom Bar 'Settings' / Drawer -> 'System Settings'",
                previewSummary = "স্বতন্ত্র সেটিংস স্ক্রিন যেখান থেকে এআই মডেল প্যারামিটার, ভয়েস গাইড ও সিস্টেম কনফিগারেশন নিয়ন্ত্রণ করা যায়।"
            ),
            AppScreenInfo(
                destination = ScreenDestination.DASHBOARD,
                name = "Admin Control Center",
                bengaliTitle = "অ্যাডমিন সেন্ট্রাল ড্যাশবোর্ড",
                category = "Admin Core",
                icon = Icons.Default.Dashboard,
                features = listOf(
                    "Live System Health Diagnostics (Backend, Room DB, AI, Gateway)",
                    "Quick Access Navigation to all 6 Core Modules",
                    "Real-Time API Traffic & Token Metrics Counter",
                    "Pending AI Tasks & Review Counter",
                    "Recent Audit Trail & Operational Log Stream"
                ),
                linkedDaos = listOf("AuditLogDao", "SystemLogDao", "ApiKeyDao"),
                linkedServices = listOf("SystemHealthManager", "AuditLoggingService"),
                navigationTrigger = "Default Home / Drawer -> '1. CONTROL CENTER'",
                previewSummary = "সিস্টেমের সমস্ত সার্ভিস, ডাটাবেস এবং এআই গেটওয়ের সার্বিক অবস্থা পর্যবেক্ষণ করার মূল ড্যাশবোর্ড।"
            ),
            AppScreenInfo(
                destination = ScreenDestination.API_CENTER,
                name = "API Gateway & Token Manager",
                bengaliTitle = "এপিআই ম্যানেজার ও এক্সেস কন্ট্রোল",
                category = "API Platform",
                icon = Icons.Default.Key,
                features = listOf(
                    "Create New API Key with SHA-256 Token & Custom Expiry",
                    "Copy API Key to Clipboard securely",
                    "Extend Expiry (1M, 3M, 6M, 1Y, Custom Date)",
                    "Instant Pause / Revoke / Activate API Key in Room DB",
                    "Detailed Endpoint Permissions & Capability Assignment",
                    "Live Request Usage & Quota Monitor"
                ),
                linkedDaos = listOf("ApiKeyDao", "ApiUsageLogDao"),
                linkedServices = listOf("VedaNovaApiGateway", "ApiKeyManager", "CryptoHashService"),
                navigationTrigger = "Drawer -> '2. API MANAGER' / Bottom Bar 'API'",
                previewSummary = "বাহ্যিক অ্যাপ্লিকেশনের জন্য সিকিউর এপিআই তৈরি, মেয়াদ বৃদ্ধি, নিয়ন্ত্রণ ও ব্যবহার নিরীক্ষণ।"
            ),
            AppScreenInfo(
                destination = ScreenDestination.TEACH_AI,
                name = "AI Command & Pipeline Center",
                bengaliTitle = "এআই কমান্ড ও আর্কিটেকচার জেনারেটর",
                category = "Admin Core",
                icon = Icons.Default.School,
                features = listOf(
                    "Natural Language Admin Voice/Text Instruction",
                    "Multi-Media Screenshot / Logo Asset Attachment",
                    "AI Architectural Analysis & Proposed Code Generation",
                    "Development Task Pipeline with Approve/Reject in DB",
                    "Authoritative Knowledge Teaching with Sampradaya Tagging",
                    "Knowledge Version Control & Diff History"
                ),
                linkedDaos = listOf("DevelopmentTaskDao", "KnowledgeDao", "KnowledgeVersionDao", "UnknownKnowledgeDao"),
                linkedServices = listOf("AiOrchestrator", "KnowledgeMatchingEngine"),
                navigationTrigger = "Drawer -> '3. TEACH / COMMAND' / Bottom Bar 'Teach'",
                previewSummary = "অ্যাডমিনের নির্দেশে এআই স্বয়ংক্রিয়ভাবে আর্কিটেকচার বিশ্লেষণ ও কোড পরিবর্তন প্রস্তুত করে।"
            ),
            AppScreenInfo(
                destination = ScreenDestination.AI_TESTING_LAB,
                name = "AI Testing Lab & Simulator",
                bengaliTitle = "এআই টেস্ট চ্যাট ও ডায়াগনস্টিক ল্যাব",
                category = "AI & Testing",
                icon = Icons.Default.Forum,
                features = listOf(
                    "Real Admin AI Test Chat Console",
                    "Side-by-Side Dual Brain Comparison (Gemini vs Canonical DB)",
                    "Live Intent Classification Inspector",
                    "Response Latency & Quality Confidence Scores",
                    "Context Memory & Entity Tracker Inspector"
                ),
                linkedDaos = listOf("SystemLogDao", "KnowledgeDao"),
                linkedServices = listOf("AiOrchestrator", "GeminiNetworkClient", "DiagnosticEngine"),
                navigationTrigger = "Drawer -> '4. AI TEST CHAT' / Bottom Bar 'Test Chat'",
                previewSummary = "এআইয়ের বুদ্ধিমত্তা, ডায়াগনস্টিক তথ্য ও রেসপন্স কোয়ালিটি লাইভ পরীক্ষা করার কনসোল।"
            ),
            AppScreenInfo(
                destination = ScreenDestination.EXTERNAL_APPS_MONITOR,
                name = "External Apps & RBAC Monitor",
                bengaliTitle = "বাহ্যিক অ্যাপস ও আরবিক নজরদারি",
                category = "External Apps",
                icon = Icons.Default.Apps,
                features = listOf(
                    "Registered External Consumer Applications List",
                    "Permission & Role Based Access Control Matrix",
                    "Real-Time Gateway Traffic and Failure Rate Tracking",
                    "Capability Approval Queue"
                ),
                linkedDaos = listOf("ApiKeyDao", "ApiUsageLogDao", "UserDao"),
                linkedServices = listOf("VedaNovaApiGateway", "RbacAuthorizationService"),
                navigationTrigger = "Drawer -> '5. APPS & USAGE' / Bottom Bar 'Apps'",
                previewSummary = "ধর্ম এআই এপিআই ব্যবহারকারী সমস্ত ক্লায়েন্ট অ্যাপের স্বাস্থ্য ও অ্যাক্সেস কন্ট্রোল।"
            ),
            AppScreenInfo(
                destination = ScreenDestination.PROJECT_MONITOR,
                name = "Project Pipeline Monitor",
                bengaliTitle = "প্রজেক্ট টাস্ক ও এক্সিকিউশন মনিটর",
                category = "Operations",
                icon = Icons.Default.Engineering,
                features = listOf(
                    "All Generated Development Tasks Queue",
                    "Task Execution Status (APPROVED, EXECUTED, REJECTED)",
                    "Proposed Code Diff & Target Location Inspector",
                    "Direct Rollback & Re-verification Trigger"
                ),
                linkedDaos = listOf("DevelopmentTaskDao"),
                linkedServices = listOf("TaskExecutionPipeline"),
                navigationTrigger = "Drawer -> '6. PROJECT MONITOR' / Bottom Bar 'Monitor'",
                previewSummary = "অ্যাডমিন কমান্ড থেকে তৈরি সমস্ত ডেভেলপমেন্ট টাস্কের ডাটাবেস হিস্ট্রি ও স্ট্যাটাস।"
            ),
            AppScreenInfo(
                destination = ScreenDestination.KNOWLEDGE_CENTER,
                name = "Knowledge Center",
                bengaliTitle = "শাস্ত্রীয় জ্ঞানভাণ্ডার ও সংস্করণ নিয়ন্ত্রণ",
                category = "Knowledge",
                icon = Icons.Default.AutoStories,
                features = listOf(
                    "Authoritative Shloka & Scripture CRUD",
                    "Full Text Bengali/Sanskrit Search",
                    "Sampradaya & Source Category Hierarchy",
                    "Version Diff and Rollback System"
                ),
                linkedDaos = listOf("KnowledgeDao", "KnowledgeVersionDao"),
                linkedServices = listOf("KnowledgeMatchingEngine"),
                navigationTrigger = "Drawer -> 'Knowledge Center'",
                previewSummary = "বেদ, উপনিষদ ও গীতার সমস্ত প্রামাণিক শ্লোক ও অর্থ পরিচালনার কেন্দ্র।"
            ),
            AppScreenInfo(
                destination = ScreenDestination.RESEARCH_CENTER,
                name = "Web Research & Harvesting Lab",
                bengaliTitle = "ওয়েব গবেষণা ও উৎস যাচাই ল্যাব",
                category = "Knowledge",
                icon = Icons.Default.TravelExplore,
                features = listOf(
                    "Automated Canonical Web Harvesting",
                    "YouTube Sanskrit Chanting Cross-Verification",
                    "Mantra Authenticity Shield (Anti-hallucination)",
                    "Candidate Knowledge Approval Pipeline"
                ),
                linkedDaos = listOf("ResearchSourceDao", "ResearchIssueDao", "KnowledgeCandidateDao"),
                linkedServices = listOf("WebResearchProvider", "YouTubeResearchProvider", "CrossSourceVerificationEngine"),
                navigationTrigger = "Drawer -> 'Web Research & Harvesting Center'",
                previewSummary = "অজ্ঞাত প্রশ্নের জন্য ডিজিটাল শাস্ত্রীয় আর্কাইভ থেকে স্বয়ংক্রিয় তথ্য সংগ্রহ ও যাচাই।"
            ),
            AppScreenInfo(
                destination = ScreenDestination.DAILY_DATA_MONITOR,
                name = "Daily Wisdom & Festival Engine",
                bengaliTitle = "দৈনিক বাণী ও তিথি-উৎসব ক্যালেন্ডার",
                category = "External Apps",
                icon = Icons.Default.Today,
                features = listOf(
                    "Daily Shloka Rotation Engine",
                    "Hindu Panchang & Tithi Calculator",
                    "Ekadashi & Festival Push Notification Dispatcher",
                    "Auspicious Muhurat Data Provider"
                ),
                linkedDaos = listOf("KnowledgeDao"),
                linkedServices = listOf("DailyDataEngine", "CalendarService"),
                navigationTrigger = "Drawer -> 'Daily Data & Festivals'",
                previewSummary = "দৈনিক শ্লোক ও সনাতন ক্যালেন্ডার ডাটা বাহ্যিক অ্যাপে পাঠানোর সার্ভিস।"
            )
        )
    }

    val allFeatures = remember(screensList) {
        listOf(
            AppFeatureInfo(
                id = "F-01",
                nameBengali = "লাইভ চ্যাট ও শাস্ত্রীয় উত্তর",
                nameEnglish = "Dharma AI Live Chat Engine",
                screenDestination = ScreenDestination.AI_TESTING_LAB,
                screenName = "AI Testing Lab & Chat",
                backendService = "AiOrchestrator + Gemini 2.5 Flash",
                linkedDatabaseTable = "knowledge_base",
                status = FeatureHealthStatus.WORKING,
                description = "ব্যবহারকারীর প্রশ্নের নিখুঁত অর্থ ও শাস্ত্রীয় সমাধান তৈরি করে অপ্রাসঙ্গিক বিষয় বাদ দিয়ে উত্তর দেয়।",
                navigationPath = "Bottom Bar -> Test Chat / Drawer -> AI TEST CHAT"
            ),
            AppFeatureInfo(
                id = "F-02",
                nameBengali = "ভয়েস ইনপুট ও টিটিএস অডিও প্লেব্যাক",
                nameEnglish = "Live Voice AI & Speech Synthesis",
                screenDestination = ScreenDestination.SETTINGS,
                screenName = "System Settings & Voice Guide",
                backendService = "LiveVoiceAiManager (Android TTS & SpeechRecognizer)",
                linkedDatabaseTable = "None (Runtime Audio)",
                status = FeatureHealthStatus.WORKING,
                description = "ভয়েস গাইড সক্রিয় করা, ভাষা নির্বাচন এবং সিস্টেম নোটিফিকেশন অডিওতে শোনা।",
                navigationPath = "Bottom Bar -> Settings -> Voice Guide"
            ),
            AppFeatureInfo(
                id = "F-03",
                nameBengali = "মেসেজ অ্যাকশন টুলবার (কপি, লাইক, ডিসলাইক, রিপোর্ট)",
                nameEnglish = "Message Feedback & Copy Actions",
                screenDestination = ScreenDestination.AI_TESTING_LAB,
                screenName = "AI Testing Lab & Chat",
                backendService = "VedaNovaRepository (Usage Feedback & Report System)",
                linkedDatabaseTable = "knowledge_usage_logs, user_reports",
                status = FeatureHealthStatus.WORKING,
                description = "মেসেজ টেক্সট কপি করা, রেটিং দেওয়া এবং ভুল উত্তরের জন্য রিপোর্ট জমা দেওয়ার বাস্তব ব্যবস্থা।",
                navigationPath = "AI Test Chat -> Chat Cards Action Bar"
            ),
            AppFeatureInfo(
                id = "F-04",
                nameBengali = "এপিআই কি জেনারেশন ও মেয়াদ নিয়ন্ত্রণ",
                nameEnglish = "External API Key Generator & Lifecycle",
                screenDestination = ScreenDestination.API_CENTER,
                screenName = "API Manager",
                backendService = "VedaNovaApiGateway + CryptoHashService",
                linkedDatabaseTable = "api_keys",
                status = FeatureHealthStatus.WORKING,
                description = "সিকিউর টোকেন তৈরি, মেয়াদ বৃদ্ধি (Extend Expiry), সাময়িক স্থগিত ও ডিলিট করার সম্পূর্ণ কার্যকারিতা।",
                navigationPath = "Drawer -> 2. API MANAGER"
            ),
            AppFeatureInfo(
                id = "F-05",
                nameBengali = "অ্যাডমিন এআই কমান্ড ও ডেভেলপমেন্ট পাইপলাইন",
                nameEnglish = "Admin AI Command & Architecture Generator",
                screenDestination = ScreenDestination.TEACH_AI,
                screenName = "Teach / Command",
                backendService = "AiOrchestrator + TaskExecutionPipeline",
                linkedDatabaseTable = "development_tasks",
                status = FeatureHealthStatus.WORKING,
                description = "ন্যাচারাল ল্যাঙ্গুয়েজ ও ইমেজ নির্দেশে এআই কোড আর্কিটেকচার বিশ্লেষণ করে ডাটাবেসে সেভ করে।",
                navigationPath = "Drawer -> 3. TEACH / COMMAND"
            ),
            AppFeatureInfo(
                id = "F-06",
                nameBengali = "শাস্ত্রীয় জ্ঞানভাণ্ডার সংরক্ষণ ও সংস্করণ",
                nameEnglish = "Scripture Knowledge Repository & Versioning",
                screenDestination = ScreenDestination.KNOWLEDGE_CENTER,
                screenName = "Knowledge Center",
                backendService = "KnowledgeMatchingEngine",
                linkedDatabaseTable = "knowledge_base, knowledge_versions",
                status = FeatureHealthStatus.WORKING,
                description = "প্রামাণিক শ্লোক সংরক্ষণ, সংস্করণ ইতিহাস এবং রোলব্যাক সুবিধা।",
                navigationPath = "Drawer -> Knowledge Center"
            ),
            AppFeatureInfo(
                id = "F-07",
                nameBengali = "ওয়েব ও ইউটিউব গবেষণা ল্যাব",
                nameEnglish = "Web Research & Canonical Harvesting",
                screenDestination = ScreenDestination.RESEARCH_CENTER,
                screenName = "Research Center",
                backendService = "WebResearchProvider + CrossSourceVerificationEngine",
                linkedDatabaseTable = "research_sources, research_issues",
                status = FeatureHealthStatus.WORKING,
                description = "অনলাইনে শাস্ত্রীয় প্রামাণিক ডিজিটাল সংগ্রহশালা থেকে তথ্য সংগ্রহ ও মন্ত্র শিল্ড যাচাই।",
                navigationPath = "Drawer -> Web Research Center"
            ),
            AppFeatureInfo(
                id = "F-08",
                nameBengali = "সিস্টেম স্বাস্থ্য ও ডায়াগনস্টিক সেন্টার",
                nameEnglish = "System Health & Real-time Diagnostic Matrix",
                screenDestination = ScreenDestination.SYSTEM_HEALTH,
                screenName = "System Health",
                backendService = "SystemHealthManager + CrashReportingManager",
                linkedDatabaseTable = "crash_reports, system_logs",
                status = FeatureHealthStatus.WORKING,
                description = "ডাটাবেস, ব্যাকএন্ড ও এআই মডিউলের লাইভ কানেক্টিভিটি চেক।",
                navigationPath = "Drawer -> System Health"
            )
        )
    }

    val filteredFeatures = remember(featureSearchQuery, selectedStatusFilter, allFeatures) {
        allFeatures.filter { feat ->
            (featureSearchQuery.isBlank() ||
                feat.nameBengali.contains(featureSearchQuery, ignoreCase = true) ||
                feat.nameEnglish.contains(featureSearchQuery, ignoreCase = true) ||
                feat.screenName.contains(featureSearchQuery, ignoreCase = true) ||
                feat.backendService.contains(featureSearchQuery, ignoreCase = true) ||
                feat.linkedDatabaseTable.contains(featureSearchQuery, ignoreCase = true)) &&
            (selectedStatusFilter == null || feat.status == selectedStatusFilter)
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .padding(12.dp)
            .testTag("app_overview_screen"),
        verticalArrangement = Arrangement.spacedBy(10.dp)
    ) {
        // Screen Header
        Card(
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.primaryContainer),
            shape = RoundedCornerShape(12.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Column(modifier = Modifier.padding(14.dp)) {
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween,
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        Icon(Icons.Default.AccountTree, contentDescription = null, tint = SaffronPrimary, modifier = Modifier.size(24.dp))
                        Spacer(modifier = Modifier.width(8.dp))
                        Column {
                            Text(
                                text = "Dharma AI App Overview & Architecture",
                                style = MaterialTheme.typography.titleMedium,
                                fontWeight = FontWeight.Bold,
                                color = MaterialTheme.colorScheme.onPrimaryContainer
                            )
                            Text(
                                text = "Complete interactive screen map, feature directory & live connections",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onPrimaryContainer.copy(alpha = 0.8f)
                            )
                        }
                    }
                    Badge(containerColor = SaffronPrimary) {
                        Text("${screensList.size} Screens Active", color = Color.Black, fontWeight = FontWeight.Bold, modifier = Modifier.padding(4.dp))
                    }
                }

                Spacer(modifier = Modifier.height(10.dp))

                // Stats row
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Text(text = "Total Verified Features: ${allFeatures.size}", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text(text = "DB Tables Linked: 12", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onPrimaryContainer)
                    Text(text = "Gateway Status: ONLINE", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = StatusGreen)
                }
            }
        }

        // Tab Navigation
        TabRow(
            selectedTabIndex = selectedTab,
            containerColor = MaterialTheme.colorScheme.surface,
            contentColor = SaffronPrimary
        ) {
            Tab(
                selected = selectedTab == 0,
                onClick = { selectedTab = 0 },
                text = { Text("1. Screen Architecture (${screensList.size})", fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.GridView, contentDescription = null, modifier = Modifier.size(16.dp)) }
            )
            Tab(
                selected = selectedTab == 1,
                onClick = { selectedTab = 1 },
                text = { Text("2. Feature Map (${allFeatures.size})", fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.FactCheck, contentDescription = null, modifier = Modifier.size(16.dp)) }
            )
            Tab(
                selected = selectedTab == 2,
                onClick = { selectedTab = 2 },
                text = { Text("3. Navigation Graph", fontWeight = FontWeight.Bold) },
                icon = { Icon(Icons.Default.Route, contentDescription = null, modifier = Modifier.size(16.dp)) }
            )
        }

        when (selectedTab) {
            0 -> {
                // Screen Architecture View
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    item {
                        Text(
                            text = "অ্যাপ্লিকেশনের সমস্ত সক্রিয় স্ক্রিন ও এদের লাইভ সংযোগসমূহ:",
                            style = MaterialTheme.typography.labelMedium,
                            fontWeight = FontWeight.Bold,
                            color = VedicGold
                        )
                    }

                    items(screensList) { screen ->
                        val isExpanded = selectedScreen == screen.destination
                        Card(
                            colors = CardDefaults.cardColors(containerColor = CosmicNavySurface),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, if (isExpanded) SaffronPrimary else CosmicCardBorder),
                            modifier = Modifier
                                .fillMaxWidth()
                                .clickable { selectedScreen = if (isExpanded) null else screen.destination }
                        ) {
                            Column(modifier = Modifier.padding(12.dp)) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Row(verticalAlignment = Alignment.CenterVertically, modifier = Modifier.weight(1f)) {
                                        Box(
                                            modifier = Modifier
                                                .size(36.dp)
                                                .clip(CircleShape)
                                                .background(SaffronPrimary.copy(alpha = 0.15f)),
                                            contentAlignment = Alignment.Center
                                        ) {
                                            Icon(screen.icon, contentDescription = null, tint = SaffronPrimary, modifier = Modifier.size(20.dp))
                                        }
                                        Spacer(modifier = Modifier.width(10.dp))
                                        Column {
                                            Text(
                                                text = screen.name,
                                                style = MaterialTheme.typography.titleSmall,
                                                fontWeight = FontWeight.Bold,
                                                color = Color.White
                                            )
                                            Text(
                                                text = screen.bengaliTitle,
                                                style = MaterialTheme.typography.bodySmall,
                                                color = SaffronLight
                                            )
                                        }
                                    }

                                    StatusPill(text = screen.category, color = VedicGold)
                                }

                                Spacer(modifier = Modifier.height(8.dp))
                                Text(
                                    text = screen.previewSummary,
                                    style = MaterialTheme.typography.bodySmall,
                                    color = TextSecondaryDark
                                )

                                Spacer(modifier = Modifier.height(8.dp))
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceBetween,
                                    verticalAlignment = Alignment.CenterVertically
                                ) {
                                    Text(
                                        text = "📍 Navigation: ${screen.navigationTrigger}",
                                        style = MaterialTheme.typography.labelSmall,
                                        color = TextSecondaryDark,
                                        fontSize = 10.sp
                                    )

                                    Button(
                                        onClick = { viewModel.navigateTo(screen.destination) },
                                        shape = RoundedCornerShape(6.dp),
                                        contentPadding = PaddingValues(horizontal = 8.dp, vertical = 2.dp),
                                        colors = ButtonDefaults.buttonColors(containerColor = SaffronPrimary)
                                    ) {
                                        Icon(Icons.Default.Launch, contentDescription = null, tint = Color.Black, modifier = Modifier.size(12.dp))
                                        Spacer(modifier = Modifier.width(4.dp))
                                        Text("Launch Screen", color = Color.Black, style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold)
                                    }
                                }

                                AnimatedVisibility(visible = isExpanded) {
                                    Column(modifier = Modifier.padding(top = 10.dp)) {
                                        Divider(color = CosmicCardBorder, thickness = 0.8.dp)
                                        Spacer(modifier = Modifier.height(8.dp))

                                        Text(text = "✨ Included Features:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = VedicGold)
                                        Spacer(modifier = Modifier.height(4.dp))
                                        screen.features.forEach { feat ->
                                            Text(text = "  • $feat", style = MaterialTheme.typography.bodySmall, color = Color.LightGray)
                                        }

                                        Spacer(modifier = Modifier.height(8.dp))
                                        Row(
                                            modifier = Modifier.fillMaxWidth(),
                                            horizontalArrangement = Arrangement.SpaceBetween
                                        ) {
                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(text = "🗄️ Linked Database DAOs:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = SpiritualTeal)
                                                screen.linkedDaos.forEach { dao ->
                                                    Text(text = "  → $dao", style = MaterialTheme.typography.bodySmall, color = TextPrimaryDark)
                                                }
                                            }

                                            Column(modifier = Modifier.weight(1f)) {
                                                Text(text = "⚙️ Linked Services:", style = MaterialTheme.typography.labelSmall, fontWeight = FontWeight.Bold, color = SaffronLight)
                                                screen.linkedServices.forEach { srv ->
                                                    Text(text = "  → $srv", style = MaterialTheme.typography.bodySmall, color = TextPrimaryDark)
                                                }
                                            }
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
            }

            1 -> {
                // Real Feature Health Map View
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        com.example.ui.components.FeatureHealthMapSection(viewModel = viewModel)
                    }
                }
            }

            2 -> {
                // Navigation Graph & Flow Map
                LazyColumn(
                    modifier = Modifier.fillMaxSize(),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Card(
                            colors = CardDefaults.cardColors(containerColor = CosmicNavySurface),
                            shape = RoundedCornerShape(12.dp),
                            border = BorderStroke(1.dp, CosmicCardBorder)
                        ) {
                            Column(modifier = Modifier.padding(14.dp)) {
                                Text(
                                    text = "🗺️ Dharma AI Core Navigation Structure:",
                                    style = MaterialTheme.typography.titleSmall,
                                    fontWeight = FontWeight.Bold,
                                    color = VedicGold
                                )
                                Spacer(modifier = Modifier.height(10.dp))

                                val navPaths = listOf(
                                    "App Launch" to "→ Public Dharma App (Client Q&A & Voice)",
                                    "Public App Top Bar" to "→ Admin Center / Live Voice Call Overlay",
                                    "Admin Drawer (Top Level)" to "→ 1. Control Center, 2. API Manager, 3. Teach AI, 4. AI Test Chat, 5. Apps & Usage, 6. Project Monitor",
                                    "Control Center (Dashboard)" to "→ System Health, API Center, Knowledge Center, Teach AI, Diagnostics",
                                    "API Manager" to "→ Create API Dialog, Extend Expiry Dialog, Copy Key, Revoke/Pause Key",
                                    "Teach / Command AI" to "→ Natural Language Command -> Architecture Analysis -> Approve/Reject -> Project Monitor",
                                    "Knowledge Center" to "→ Add Shloka, Edit Verse, Version History Diff, Candidate Approval",
                                    "Research Center" to "→ Web Harvesting, YouTube Sanskrit Audio Verification, Mantra Shield"
                                )

                                navPaths.forEach { (source, target) ->
                                    Row(
                                        modifier = Modifier
                                            .fillMaxWidth()
                                            .padding(vertical = 4.dp),
                                        verticalAlignment = Alignment.CenterVertically
                                    ) {
                                        Surface(color = SaffronPrimary.copy(alpha = 0.15f), shape = RoundedCornerShape(4.dp)) {
                                            Text(
                                                text = source,
                                                color = SaffronPrimary,
                                                fontWeight = FontWeight.Bold,
                                                fontSize = 11.sp,
                                                modifier = Modifier.padding(horizontal = 6.dp, vertical = 2.dp)
                                            )
                                        }
                                        Spacer(modifier = Modifier.width(8.dp))
                                        Text(text = target, style = MaterialTheme.typography.bodySmall, color = TextPrimaryDark)
                                    }
                                    Divider(color = CosmicCardBorder.copy(alpha = 0.5f), thickness = 0.5.dp)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}
