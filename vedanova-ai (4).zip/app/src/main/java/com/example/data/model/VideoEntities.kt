package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Real Video Generation Status Lifecycle
 */
enum class VideoGenerationStatus(val labelBengali: String, val stepIndex: Int) {
    IDLE("প্রস্তুত (Idle)", 0),
    QUEUED("সারিবদ্ধ অপেক্ষমান (Queued)", 1),
    ANALYZING("প্রম্পট ও ভাব বিশ্লেষণ (Analyzing)", 2),
    PLANNING("স্টোরিবোর্ড ও দৃশ্য পরিকল্পনা (Planning)", 3),
    GENERATING("ভিজ্যুয়াল ফ্রেম জেনারেশন (Generating)", 4),
    RENDERING("এইচ.২৬৪ হার্ডওয়্যার রেন্ডারিং (Rendering)", 5),
    PROCESSING_AUDIO("ভক্তিমূলক সাউন্ডট্র্যাক মার্জিং (Processing Audio)", 6),
    VERIFYING("শাস্ত্রীয় শুদ্ধতা ও কোয়ালিটি যাচাই (Verifying)", 7),
    COMPLETED("ভিডিও জেনারেশন সফল (Completed)", 8),
    FAILED("জেনারেশন ব্যর্থ (Failed)", -1),
    CANCELLED("বাতিল করা হয়েছে (Cancelled)", -2)
}

/**
 * Video Verification & Publishing Lifecycle
 */
enum class VideoVerificationStatus(val labelBengali: String) {
    UNVERIFIED("অযাচাইকৃত (Unverified)"),
    PENDING_VERIFICATION("যাচাই অপেক্ষমান (Pending Verification)"),
    VERIFIED("শাস্ত্রীয়ভাবে অনুমোদিত (Verified)"),
    REJECTED("প্রত্যাখ্যাত (Rejected)"),
    PUBLISHED("প্রকাশিত (Published)")
}

/**
 * Database Entity for Video Generation
 */
@Entity(tableName = "video_generations")
data class VideoGenerationEntity(
    @PrimaryKey val id: String,
    val userId: String = "admin",
    val prompt: String,
    val title: String,
    val videoType: String, // Dharma Video, Festival Video, Puja Video, Mantra Video, Kirtan Video, Educational Dharma Video, Panchang Video, General AI Video
    val language: String = "Bengali",
    val durationSeconds: Int = 10,
    val resolution: String = "720p", // 720p, 1080p
    val aspectRatio: String = "16:9", // 16:9, 9:16, 1:1
    val status: String = VideoGenerationStatus.IDLE.name,
    val progress: Float = 0.0f,
    val engine: String = "VedaNova-V1-HardwareSynth",
    val videoUrl: String = "",
    val thumbnailUrl: String = "",
    val fileSizeBytes: Long = 0L,
    val createdAt: Long = System.currentTimeMillis(),
    val completedAt: Long? = null,
    val errorCode: String? = null,
    val errorMessage: String? = null,
    val version: Int = 1,
    val verificationStatus: String = VideoVerificationStatus.PENDING_VERIFICATION.name,
    val isPublished: Boolean = false,
    val publishedAt: Long? = null,
    val isArchived: Boolean = false,
    val storyboardJson: String = "",
    val voiceType: String = "Narration",
    val bgMusic: String = "Devotional Flute",
    val style: String = "Spiritual Art",
    val adminUser: String = "admin",
    val sha256Checksum: String = ""
)

/**
 * Version History Entity for Video Generation
 */
@Entity(tableName = "video_generation_versions")
data class VideoGenerationVersionEntity(
    @PrimaryKey val id: String,
    val videoId: String,
    val versionNumber: Int,
    val prompt: String,
    val videoUrl: String,
    val thumbnailUrl: String,
    val changeNotes: String,
    val createdAt: Long = System.currentTimeMillis(),
    val createdBy: String = "admin"
)

/**
 * Audit Log Entity for Video Generation
 */
@Entity(tableName = "video_audit_logs")
data class VideoAuditLogEntity(
    @PrimaryKey(autoGenerate = true) val id: Long = 0,
    val videoId: String,
    val adminUsername: String,
    val action: String, // CREATE, GENERATE, VERIFY, PUBLISH, UNPUBLISH, REGENERATE, CANCEL, ARCHIVE, DELETE, ROLLBACK, SAFETY_REJECT
    val result: String, // SUCCESS, FAILED, BLOCKED
    val details: String,
    val timestamp: Long = System.currentTimeMillis()
)

/**
 * Individual Scene in a Storyboard
 */
data class VideoScene(
    val sceneNumber: Int,
    val title: String,
    val description: String,
    val durationSeconds: Int,
    val visualMotif: String,
    val cameraMovement: String, // Slow Zoom In, Pan Right, Static Divine Focus, Gentle Tilt Up
    val onScreenText: String,
    val voiceScript: String,
    val musicMood: String
)

/**
 * Complete Storyboard Plan
 */
data class VideoStoryboard(
    val scenes: List<VideoScene>,
    val totalDurationSeconds: Int,
    val aspectRatio: String,
    val resolution: String,
    val primaryDeityOrTheme: String,
    val visualStyle: String
)

/**
 * Natural Language Prompt Analysis
 */
data class VideoPromptAnalysis(
    val subject: String,
    val theme: String,
    val mood: String,
    val language: String,
    val style: String,
    val suggestedVideoType: String,
    val safetyPassed: Boolean = true,
    val safetyReason: String? = null
)
