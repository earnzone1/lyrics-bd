package com.example.data.dao

import androidx.room.*
import com.example.data.model.VideoAuditLogEntity
import com.example.data.model.VideoGenerationEntity
import com.example.data.model.VideoGenerationVersionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface VideoDao {
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVideo(video: VideoGenerationEntity)

    @Update
    suspend fun updateVideo(video: VideoGenerationEntity)

    @Query("SELECT * FROM video_generations WHERE id = :id")
    suspend fun getVideoById(id: String): VideoGenerationEntity?

    @Query("SELECT * FROM video_generations ORDER BY createdAt DESC")
    fun getAllVideos(): Flow<List<VideoGenerationEntity>>

    @Query("SELECT * FROM video_generations ORDER BY createdAt DESC")
    suspend fun getAllVideosSync(): List<VideoGenerationEntity>

    @Query("SELECT * FROM video_generations WHERE isArchived = 0 ORDER BY createdAt DESC")
    fun getActiveVideos(): Flow<List<VideoGenerationEntity>>

    @Query("SELECT * FROM video_generations WHERE isArchived = 1 ORDER BY createdAt DESC")
    fun getArchivedVideos(): Flow<List<VideoGenerationEntity>>

    @Query("DELETE FROM video_generations WHERE id = :id")
    suspend fun deleteVideo(id: String)

    @Query("UPDATE video_generations SET status = :status, progress = :progress WHERE id = :id")
    suspend fun updateStatus(id: String, status: String, progress: Float)

    @Query("UPDATE video_generations SET verificationStatus = :verStatus, isPublished = :isPublished, publishedAt = :publishedAt WHERE id = :id")
    suspend fun updateVerification(id: String, verStatus: String, isPublished: Boolean, publishedAt: Long?)

    @Query("UPDATE video_generations SET isArchived = :isArchived WHERE id = :id")
    suspend fun updateArchived(id: String, isArchived: Boolean)

    // Version History
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVersion(version: VideoGenerationVersionEntity)

    @Query("SELECT * FROM video_generation_versions WHERE videoId = :videoId ORDER BY versionNumber DESC")
    suspend fun getVersionsForVideo(videoId: String): List<VideoGenerationVersionEntity>

    // Audit Logs
    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: VideoAuditLogEntity)

    @Query("SELECT * FROM video_audit_logs WHERE videoId = :videoId ORDER BY timestamp DESC")
    suspend fun getAuditLogsForVideo(videoId: String): List<VideoAuditLogEntity>

    @Query("SELECT * FROM video_audit_logs ORDER BY timestamp DESC LIMIT 200")
    fun getAllAuditLogs(): Flow<List<VideoAuditLogEntity>>

    // Real Statistics
    @Query("SELECT COUNT(*) FROM video_generations")
    suspend fun countTotal(): Int

    @Query("SELECT COUNT(*) FROM video_generations WHERE status IN ('QUEUED', 'ANALYZING', 'PLANNING', 'GENERATING', 'RENDERING', 'PROCESSING_AUDIO', 'VERIFYING')")
    suspend fun countProcessing(): Int

    @Query("SELECT COUNT(*) FROM video_generations WHERE status = 'COMPLETED'")
    suspend fun countCompleted(): Int

    @Query("SELECT COUNT(*) FROM video_generations WHERE isPublished = 1")
    suspend fun countPublished(): Int

    @Query("SELECT COUNT(*) FROM video_generations WHERE status = 'FAILED'")
    suspend fun countFailed(): Int

    @Query("SELECT COUNT(*) FROM video_generations WHERE status = 'CANCELLED'")
    suspend fun countCancelled(): Int
}
