package com.example.data.local

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import androidx.sqlite.db.SupportSQLiteDatabase
import com.example.data.dao.*
import com.example.data.model.*
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch

@Database(
    entities = [
        KnowledgeEntity::class,
        ApiKeyEntity::class,
        ApiLogEntity::class,
        IssueEntity::class,
        ReportEntity::class,
        AuditLogEntity::class,
        SystemLogEntity::class,
        AdminUserEntity::class,
        SystemSettingEntity::class,
        BackupEntity::class,
        CapabilityProposalEntity::class,
        DailyJobLogEntity::class,
        ExternalAppEntity::class,
        UnknownKnowledgeEntity::class,
        KnowledgeVersionEntity::class,
        KnowledgeUsageLogEntity::class,
        CrashReportEntity::class,
        FunctionActivityLogEntity::class,
        ResearchSourceEntity::class,
        ResearchIssueEntity::class,
        KnowledgeCandidateEntity::class,
        ResearchCacheEntity::class,
        ResearchActivityLogEntity::class,
        DevelopmentTaskEntity::class,
        GeneratedImageEntity::class,
        CalendarDayEntity::class,
        CalendarEventEntity::class,
        CalendarVersionEntity::class,
        CalendarAuditLogEntity::class,
        ClientCalendarCacheEntity::class,
        KirtanEntity::class,
        KirtanVersionEntity::class,
        KirtanAuditLogEntity::class,
        KirtanAudioEntity::class,
        KirtanAudioTrackEntity::class,
        VideoGenerationEntity::class,
        VideoGenerationVersionEntity::class,
        VideoAuditLogEntity::class
    ],
    version = 7,
    exportSchema = false
)
abstract class VedaNovaDatabase : RoomDatabase() {
    abstract fun knowledgeDao(): KnowledgeDao
    abstract fun apiKeyDao(): ApiKeyDao
    abstract fun apiLogDao(): ApiLogDao
    abstract fun issueDao(): IssueDao
    abstract fun reportDao(): ReportDao
    abstract fun auditLogDao(): AuditLogDao
    abstract fun systemLogDao(): SystemLogDao
    abstract fun adminUserDao(): AdminUserDao
    abstract fun systemSettingDao(): SystemSettingDao
    abstract fun backupDao(): BackupDao
    abstract fun capabilityProposalDao(): CapabilityProposalDao
    abstract fun dailyJobLogDao(): DailyJobLogDao
    abstract fun externalAppDao(): ExternalAppDao
    abstract fun unknownKnowledgeDao(): UnknownKnowledgeDao
    abstract fun knowledgeVersionDao(): KnowledgeVersionDao
    abstract fun knowledgeUsageLogDao(): KnowledgeUsageLogDao
    abstract fun crashReportDao(): CrashReportDao
    abstract fun functionActivityLogDao(): FunctionActivityLogDao
    abstract fun researchSourceDao(): ResearchSourceDao
    abstract fun researchIssueDao(): ResearchIssueDao
    abstract fun knowledgeCandidateDao(): KnowledgeCandidateDao
    abstract fun researchCacheDao(): ResearchCacheDao
    abstract fun researchActivityLogDao(): ResearchActivityLogDao
    abstract fun developmentTaskDao(): DevelopmentTaskDao
    abstract fun generatedImageDao(): GeneratedImageDao
    abstract fun calendarDayDao(): CalendarDayDao
    abstract fun calendarEventDao(): CalendarEventDao
    abstract fun calendarVersionDao(): CalendarVersionDao
    abstract fun calendarAuditLogDao(): CalendarAuditLogDao
    abstract fun clientCalendarCacheDao(): ClientCalendarCacheDao
    abstract fun kirtanDao(): KirtanDao
    abstract fun kirtanAudioDao(): KirtanAudioDao
    abstract fun videoDao(): VideoDao

    companion object {
        @Volatile
        private var INSTANCE: VedaNovaDatabase? = null

        fun getInstance(context: Context): VedaNovaDatabase {
            return INSTANCE ?: synchronized(this) {
                val instance = Room.databaseBuilder(
                    context.applicationContext,
                    VedaNovaDatabase::class.java,
                    "vedanova_ai.db"
                )
                .addCallback(object : Callback() {
                    override fun onCreate(db: SupportSQLiteDatabase) {
                        super.onCreate(db)
                        CoroutineScope(Dispatchers.IO).launch {
                            try {
                                val database = getInstance(context)
                                database.knowledgeDao().insertAllKnowledge(InitialKnowledgeData.initialKnowledge)
                                database.apiKeyDao().insertAllApiKeys(InitialKnowledgeData.initialApiKeys)
                                database.adminUserDao().insertAllUsers(InitialKnowledgeData.initialAdminUsers)
                                database.issueDao().insertAllIssues(InitialKnowledgeData.initialIssues)
                                database.reportDao().insertAllReports(InitialKnowledgeData.initialReports)
                                database.systemSettingDao().insertAllSettings(InitialKnowledgeData.initialSettings)
                                if (InitialKnowledgeData.initialBackups.isNotEmpty()) {
                                    database.backupDao().insertBackup(InitialKnowledgeData.initialBackups[0])
                                }
                                database.externalAppDao().insertAllApps(InitialKnowledgeData.initialExternalApps)
                                database.capabilityProposalDao().insertAllProposals(InitialKnowledgeData.initialCapabilityProposals)
                                if (InitialKnowledgeData.initialDailyJobLogs.isNotEmpty()) {
                                    database.dailyJobLogDao().insertJobLog(InitialKnowledgeData.initialDailyJobLogs[0])
                                }
                                database.unknownKnowledgeDao().insertAllUnknown(InitialKnowledgeData.initialUnknownKnowledge)
                                database.knowledgeVersionDao().insertAllVersions(InitialKnowledgeData.initialKnowledgeVersions)
                                database.knowledgeUsageLogDao().insertAllUsageLogs(InitialKnowledgeData.initialUsageLogs)
                                database.crashReportDao().insertAllCrashReports(InitialKnowledgeData.initialCrashReports)
                                database.functionActivityLogDao().insertAllActivityLogs(InitialKnowledgeData.initialFunctionActivityLogs)
                                database.researchSourceDao().insertAllSources(InitialKnowledgeData.initialResearchSources)
                                database.researchIssueDao().insertAllIssues(InitialKnowledgeData.initialResearchIssues)
                                database.knowledgeCandidateDao().insertAllCandidates(InitialKnowledgeData.initialKnowledgeCandidates)
                                database.researchActivityLogDao().insertAllLogs(InitialKnowledgeData.initialResearchActivityLogs)
                                for (task in InitialKnowledgeData.initialDevelopmentTasks) {
                                    database.developmentTaskDao().insertTask(task)
                                }
                                com.example.domain.ai.CalendarAdminEngine.seedDatabaseIfEmpty(database)
                                database.kirtanDao().insertAllKirtans(com.example.domain.ai.KirtanEngine.seedInitialKirtans())
                                database.auditLogDao().insertAuditLog(
                                    AuditLogEntity(
                                        adminUsername = "system",
                                        adminRole = "SYSTEM",
                                        action = "Database Seed Initialization",
                                        targetType = "DATABASE",
                                        targetId = "INIT",
                                        details = "Successfully initialized verified VedaNova core knowledge, Phase 6 research engine, and admin tables."
                                    )
                                )
                                database.systemLogDao().insertSystemLog(
                                    SystemLogEntity(
                                        category = "DATABASE",
                                        level = "INFO",
                                        message = "VedaNova Room DB Engine successfully provisioned with Phase 6 Web Research & Knowledge Harvesting Engine."
                                    )
                                )
                            } catch (e: Exception) {
                                android.util.Log.e("VedaNovaDatabase", "Database seed initialization exception: ${e.message}", e)
                            }
                        }
                    }
                })
                .fallbackToDestructiveMigration()
                .build()
                INSTANCE = instance
                instance
            }
        }
    }
}
