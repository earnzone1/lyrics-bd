package com.example.data.dao

import androidx.room.*
import com.example.data.model.KirtanAuditLogEntity
import com.example.data.model.KirtanEntity
import com.example.data.model.KirtanVersionEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface KirtanDao {

    @Query("SELECT * FROM kirtans ORDER BY updatedAt DESC")
    fun getAllKirtansFlow(): Flow<List<KirtanEntity>>

    @Query("SELECT * FROM kirtans WHERE verificationStatus = 'PUBLISHED' ORDER BY updatedAt DESC")
    fun getPublishedKirtansFlow(): Flow<List<KirtanEntity>>

    @Query("SELECT * FROM kirtans WHERE verificationStatus = 'PUBLISHED' AND deity = :deity ORDER BY updatedAt DESC")
    fun getPublishedKirtansByDeityFlow(deity: String): Flow<List<KirtanEntity>>

    @Query("SELECT * FROM kirtans WHERE isBookmarked = 1 ORDER BY updatedAt DESC")
    fun getBookmarkedKirtansFlow(): Flow<List<KirtanEntity>>

    @Query("SELECT * FROM kirtans WHERE verificationStatus = :status ORDER BY updatedAt DESC")
    fun getKirtansByStatusFlow(status: String): Flow<List<KirtanEntity>>

    @Query("SELECT * FROM kirtans WHERE id = :id LIMIT 1")
    suspend fun getKirtanById(id: String): KirtanEntity?

    @Query("SELECT * FROM kirtans WHERE title = :title LIMIT 1")
    suspend fun getKirtanByTitle(title: String): KirtanEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertKirtan(kirtan: KirtanEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllKirtans(kirtans: List<KirtanEntity>)

    @Update
    suspend fun updateKirtan(kirtan: KirtanEntity)

    @Query("UPDATE kirtans SET verificationStatus = :status, updatedAt = :updatedAt, publishedAt = :publishedAt WHERE id = :id")
    suspend fun updateKirtanStatus(id: String, status: String, updatedAt: Long, publishedAt: Long?)

    @Query("UPDATE kirtans SET isBookmarked = :isBookmarked WHERE id = :id")
    suspend fun toggleBookmark(id: String, isBookmarked: Boolean)

    @Query("DELETE FROM kirtans WHERE id = :id")
    suspend fun deleteKirtanById(id: String)

    @Query("""
        SELECT * FROM kirtans 
        WHERE title LIKE '%' || :query || '%' 
           OR deity LIKE '%' || :query || '%' 
           OR theme LIKE '%' || :query || '%' 
           OR mood LIKE '%' || :query || '%' 
           OR chorus LIKE '%' || :query || '%' 
           OR verses LIKE '%' || :query || '%'
        ORDER BY updatedAt DESC
    """)
    suspend fun searchKirtans(query: String): List<KirtanEntity>

    // Versions
    @Query("SELECT * FROM kirtan_versions WHERE kirtanId = :kirtanId ORDER BY version DESC")
    fun getVersionsForKirtanFlow(kirtanId: String): Flow<List<KirtanVersionEntity>>

    @Query("SELECT * FROM kirtan_versions WHERE kirtanId = :kirtanId ORDER BY version DESC")
    suspend fun getVersionsForKirtan(kirtanId: String): List<KirtanVersionEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVersion(version: KirtanVersionEntity)

    // Audit Logs
    @Query("SELECT * FROM kirtan_audit_logs ORDER BY timestamp DESC LIMIT 200")
    fun getAllAuditLogsFlow(): Flow<List<KirtanAuditLogEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAuditLog(log: KirtanAuditLogEntity)

    // Counts for Admin Dashboard
    @Query("SELECT COUNT(*) FROM kirtans")
    suspend fun getTotalKirtansCount(): Int

    @Query("SELECT COUNT(*) FROM kirtans WHERE verificationStatus = 'DRAFT'")
    suspend fun getDraftCount(): Int

    @Query("SELECT COUNT(*) FROM kirtans WHERE verificationStatus = 'PENDING_VERIFICATION'")
    suspend fun getPendingVerificationCount(): Int

    @Query("SELECT COUNT(*) FROM kirtans WHERE verificationStatus = 'VERIFIED'")
    suspend fun getVerifiedCount(): Int

    @Query("SELECT COUNT(*) FROM kirtans WHERE verificationStatus = 'PUBLISHED'")
    suspend fun getPublishedCount(): Int

    @Query("SELECT COUNT(*) FROM kirtans WHERE verificationStatus = 'NEEDS_REVISION'")
    suspend fun getNeedsRevisionCount(): Int

    @Query("SELECT COUNT(*) FROM kirtans WHERE verificationStatus = 'REJECTED'")
    suspend fun getRejectedCount(): Int

    @Query("SELECT COUNT(*) FROM kirtans WHERE verificationStatus = 'ARCHIVED'")
    suspend fun getArchivedCount(): Int
}
