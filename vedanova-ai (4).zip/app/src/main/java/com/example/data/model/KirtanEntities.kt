package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Authoritative Central Kirtan Entity.
 * Represents an original, devotional, structured Hindu Kirtan composition
 * with complete performance guidelines, call & response lines, verses,
 * bhakti climax, and dharma verification status.
 */
@Entity(tableName = "kirtans")
data class KirtanEntity(
    @PrimaryKey
    val id: String, // e.g. "kirtan_krishna_prem_01"
    val title: String, // Original, memorable title
    val deity: String, // e.g. "শ্রীকৃষ্ণ", "মহাদেব শিব", "শ্রীশ্রীদেবী দুর্গা", "শ্রীরামচন্দ্র", "মা কালী", "শ্রীগৌরাঙ্গ মহাপ্রভু"
    val theme: String, // e.g. "আনন্দ ও প্রেমভক্তি", "শরণাগতি ও আত্মনিবেদন", "জয়ধ্বনি ও উৎসব"
    val language: String = "Bengali", // Bengali, Sanskrit, Hindi, English
    val mood: String = "Joyful", // Peaceful, Devotional, Joyful, Energetic, Meditative, Emotional, Celebratory, Temple Style, Nama Sankirtan Style, Festival Style
    val tempo: String = "Gradual Build", // Very Slow, Slow, Medium, Medium-Fast, Fast, Gradual Build
    val durationMinutes: Int = 10, // 3, 5, 10, 15, 20, 30
    val type: String = "Nama Sankirtan", // Nama Sankirtan, Bhakti Kirtan, Festival Kirtan, Temple Style, Meditation-oriented, Call & Response, Devotional Prayer Kirtan, Celebration Kirtan
    val structure: String = "Opening -> Main Chorus -> Call & Response -> Verse 1 -> Chorus -> Verse 2 -> Bhakti Climax -> Slow Ending -> Closing Prayer",
    val opening: String, // Opening Invocation / বন্দনা
    val chorus: String, // Main Chorus / ধ্রুবপদ
    val callResponse: String, // Structured LEAD: ... / GROUP: ...
    val verses: String, // Verses / অন্তরা সমূহ
    val climax: String, // Bhakti Climax / ভক্তি পরাকাষ্ঠা ও দ্রুত ভাবতরঙ্গ
    val ending: String, // Slow Ending / ধীর লয়ের সমাপ্তি
    val closingPrayer: String, // Closing Prayer / শান্তিপাঠ ও সমর্পণ
    val performanceGuide: String, // Rhythm, tempo changes, repetition counts
    val instrumentGuide: String, // Suggested traditional instruments (Khol, Mridanga, Kartal, Harmonium, etc.)
    val sourceType: String = "ORIGINAL_AI_CREATION", // ORIGINAL_AI_CREATION, ADMIN_CREATION, COMMUNITY_VERIFIED
    val verificationStatus: String = "DRAFT", // DRAFT, PENDING_VERIFICATION, VERIFIED, PUBLISHED, NEEDS_REVISION, REJECTED
    val version: Int = 1,
    val isOriginalVerified: Boolean = true,
    val copyrightSafetyPassed: Boolean = true,
    val dharmaAccuracyPassed: Boolean = true,
    val scripturalQuotesUsed: String = "", // Clear distinction between verified scriptural shloka and original lyrics
    val festivalTag: String? = null, // e.g. "Janmashtami", "Durga Puja", "Mahashivratri", "Ram Navami"
    val isBookmarked: Boolean = false,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val publishedAt: Long? = null,
    val createdBy: String = "VedaNova AI"
)

/**
 * Historical version snapshot of a Kirtan to ensure no verified
 * version is lost and to enable 1-click administrative rollbacks.
 */
@Entity(tableName = "kirtan_versions")
data class KirtanVersionEntity(
    @PrimaryKey
    val id: String, // e.g. "kirtan_ver_01_v1"
    val kirtanId: String,
    val version: Int,
    val title: String,
    val snapshotJson: String, // Full JSON snapshot of KirtanEntity
    val changeReason: String,
    val createdBy: String,
    val createdAt: Long = System.currentTimeMillis()
)

/**
 * Immutable administrative audit log tracking every action
 * taken on a Kirtan (creation, verification, editing, publishing, rollback, etc.).
 */
@Entity(tableName = "kirtan_audit_logs")
data class KirtanAuditLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val adminUsername: String,
    val action: String, // CREATE, EDIT, VERIFY, REJECT, PUBLISH, UNPUBLISH, DELETE, ROLLBACK, VARIATION
    val kirtanId: String,
    val kirtanTitle: String,
    val version: Int,
    val timestamp: Long = System.currentTimeMillis(),
    val oldStatus: String = "",
    val newStatus: String = "",
    val notes: String = "",
    val status: String = "SUCCESS"
)
