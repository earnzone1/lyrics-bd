package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Authoritative Central Kirtan Audio Entity.
 * Represents a real, synthesized, multi-track devotional audio composition
 * directly linked to a verified Kirtan text composition.
 */
@Entity(tableName = "kirtan_audio")
data class KirtanAudioEntity(
    @PrimaryKey
    val id: String, // e.g. "kirtan_audio_krishna_01_v1"
    val kirtanId: String,
    val kirtanVersion: Int,
    val audioVersion: Int = 1,
    val status: String = "AUDIO_DRAFT", // AUDIO_DRAFT, AUDIO_PROCESSING, AUDIO_VERIFIED, AUDIO_PUBLISHED, AUDIO_REJECTED, AUDIO_FAILED
    val durationSeconds: Int,
    val format: String = "WAV", // WAV (16-bit PCM 44.1kHz Stereo)
    val sampleRate: Int = 44100,
    val channels: Int = 2,
    val fileSizeBytes: Long = 0L,
    val storageReference: String, // Full local file path to the master audio WAV file
    val musicOnlyStorageReference: String? = null, // Instrumental stem WAV
    val vocalOnlyStorageReference: String? = null, // Vocal stem WAV
    val generationMetadata: String, // JSON payload containing Music Blueprint, Raga, Tala, BPM, and section markers
    val qualityStatus: String = "VERIFIED_HIGH_QUALITY", // VERIFIED_HIGH_QUALITY, QUALITY_WARNING, REJECTED_POOR_QUALITY
    val copyrightSafetyStatus: String = "ORIGINAL_COMPOSITION_VERIFIED", // ORIGINAL_COMPOSITION_VERIFIED, REJECTED_SIMILARITY
    val vocalSynthesisType: String = "DEVOTIONAL_MELODIC_VOCAL", // DEVOTIONAL_MELODIC_VOCAL, ANDROID_TTS_SPOKEN, INSTRUMENTAL_ONLY
    val ragaName: String = "Bhairavi",
    val talaName: String = "Kaharwa",
    val bpm: Int = 92,
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val publishedAt: Long? = null,
    val createdBy: String = "VedaNova Audio Engine"
)

/**
 * Detailed track / stem entity representing each individual acoustic layer
 * (Lead Vocal, Group Response, Chorus, Tanpura Drone, Harmonium, Khol/Mridanga, Kartal).
 */
@Entity(tableName = "kirtan_audio_tracks")
data class KirtanAudioTrackEntity(
    @PrimaryKey
    val id: String, // e.g. "track_kirtan_audio_01_tanpura"
    val audioId: String,
    val trackType: String, // LEAD_VOCAL, GROUP_RESPONSE, CHORUS, TANPURA, HARMONIUM, KHOL, KARTAL, MASTER
    val trackName: String,
    val startTime: Int, // Start time in seconds
    val endTime: Int, // End time in seconds
    val instrument: String,
    val language: String = "Bengali",
    val volumeLevel: Float = 1.0f,
    val metadata: String = ""
)

/**
 * Real Audio Generation Pipeline Stage
 */
enum class AudioGenerationStage(val labelBengali: String, val progress: Float) {
    IDLE("প্রস্তুত (Idle)", 0.0f),
    QUEUED("অপেক্ষমান (Queued)", 0.05f),
    ANALYZING("কীর্তন পাঠ্য ও ভাব বিশ্লেষণ (Analyzing)", 0.15f),
    GENERATING_MUSIC("সুর ও তানপুরা-হারমোনিয়াম সৃষ্টি (Generating Music)", 0.35f),
    GENERATING_VOCAL("ভক্তিগীতি কণ্ঠস্বর ও কোরাস স্তর বিন্যাস (Generating Vocals)", 0.55f),
    MIXING("বাদ্যযন্ত্র ও কণ্ঠস্বর মেলবন্ধন (Multi-track Mixing)", 0.75f),
    MASTERING("ডাইনামিক রেঞ্জ ও লাউডনেস মাস্টারিং (Mastering)", 0.88f),
    VERIFYING("কপিরাইট ও অডিও বিশুদ্ধতা যাচাই (Verifying)", 0.95f),
    COMPLETED("সম্পন্ন ও সংরক্ষণে প্রস্তুত (Completed)", 1.0f),
    FAILED("উৎপাদন ব্যর্থ (Failed)", 0.0f),
    CANCELLED("বাতিলকৃত (Cancelled)", 0.0f)
}
