package com.example.data.model

import androidx.room.Entity
import androidx.room.PrimaryKey

/**
 * Authoritative Central Calendar Day Record.
 * Stores comprehensive dynamic Panchang, Solar, Lunar, and Muhurta timings
 * for a specific Gregorian Date and Regional Almanac Convention.
 */
@Entity(tableName = "calendar_days")
data class CalendarDayEntity(
    @PrimaryKey
    val id: String, // e.g. "2026-09-08_BANGLADESH_DHAKA"
    val gregorianDate: String, // Format: YYYY-MM-DD
    val region: String, // CalendarRegion code: BANGLADESH_DHAKA, INDIA_WEST_BENGAL, TRIPURA_AGARTALA, ASSAM_GUWAHATI, INDIA_VARANASI
    val yearBangla: String, // e.g. "১৪৩৩ বঙ্গাব্দ"
    val monthBangla: String, // e.g. "ভাদ্র"
    val dayBangla: String, // e.g. "৯"
    val dayOfWeekBangla: String, // e.g. "মঙ্গলবার"
    val tithi: String, // e.g. "দ্বাদশী"
    val paksha: String, // e.g. "শুক্লপক্ষ"
    val fullTithiTitle: String, // e.g. "শুক্লা দ্বাদশী তিথি"
    val nakshatra: String, // e.g. "শ্রবণা নক্ষত্র"
    val yoga: String = "সুকর্মা", // e.g. "অতিগণ্ড", "সুকর্মা", "ধৃতি"
    val karana: String = "বব", // e.g. "বব", "বালব", "কৌলব"
    val sunriseTime: String, // e.g. "০৫:৩৮ AM"
    val sunsetTime: String, // e.g. "০৬:২৩ PM"
    val brahmaMuhurta: String, // e.g. "০৪:০২ AM - ০৪:৫০ AM"
    val abhijitMuhurta: String, // e.g. "১১:৪৫ AM - ১২:৩৭ PM"
    val rahuKala: String, // e.g. "০৩:১৪ PM - ০৪:৪৮ PM"
    val yamaGhanta: String = "১১:০০ AM - ১২:৩০ PM",
    val gulikaKala: String = "১২:০০ PM - ০১:৩০ PM",
    val isPurnima: Boolean = false,
    val isAmavasya: Boolean = false,
    val isEkadashi: Boolean = false,
    val ekadashiName: String? = null,
    val specialDharmaDay: String? = null,
    val pujaName: String? = null,
    val festivalName: String? = null,
    val vrataName: String? = null,
    val rituals: String = "",
    val mantras: String = "",
    val status: String = "PUBLISHED", // DRAFT, PENDING_VERIFICATION, VERIFIED, PUBLISHED
    val publishedVersion: String = "Calendar 2026 v1",
    val lastUpdatedTimestamp: Long = System.currentTimeMillis(),
    val lastUpdatedBy: String = "system"
)

/**
 * Authoritative Central Calendar Event:
 * Used for Puja, Festivals, Vratas, Ekadashis, Purnimas, Amavasyas, Special Dharma Days,
 * and multi-day festival breakdown (Day 1..Day N).
 */
@Entity(tableName = "calendar_events")
data class CalendarEventEntity(
    @PrimaryKey
    val id: String, // Unique ID
    val nameEn: String,
    val nameBn: String,
    val category: String, // PUJA, FESTIVAL, VRATA, EKADASHI, PURNIMA, AMAVASYA, SPECIAL_DHARMA_DAY, MULTI_DAY_FESTIVAL
    val targetGregorianDate: String, // Primary Gregorian Date (YYYY-MM-DD)
    val startDate: String, // Start Date (YYYY-MM-DD)
    val endDate: String, // End Date (YYYY-MM-DD)
    val timeDetails: String = "", // e.g. "নিশীথকালে ১২:১৫ AM - ০১:০৫ AM"
    val tithi: String = "", // Associated Tithi
    val descriptionEn: String = "",
    val descriptionBn: String = "",
    val importance: String = "HIGH", // HIGH, MEDIUM, SPECIAL
    val rituals: String = "", // Ritual information
    val relatedMantra: String = "", // Sacred scripture / mantra
    val regionalScope: String = "ALL", // ALL, BANGLADESH_DHAKA, INDIA_WEST_BENGAL, TRIPURA_AGARTALA, ASSAM_GUWAHATI
    val isMultiDay: Boolean = false,
    val multiDayParentId: String? = null,
    val daySequence: Int = 1, // Day 1, 2, 3, 4, 5
    val status: String = "PUBLISHED", // DRAFT, PENDING_VERIFICATION, VERIFIED, PUBLISHED
    val publishedVersion: String = "Calendar 2026 v1",
    val lastUpdatedTimestamp: Long = System.currentTimeMillis(),
    val lastUpdatedBy: String = "system"
)

/**
 * Version Control Entity for Calendar Releases.
 * Captures historical versions with immutable snapshot and description of changes.
 */
@Entity(tableName = "calendar_versions")
data class CalendarVersionEntity(
    @PrimaryKey
    val versionId: String, // e.g. "cal_ver_2026_v1"
    val versionName: String, // e.g. "Calendar 2026 v1"
    val year: Int,
    val changeDescription: String,
    val totalDaysCount: Int,
    val totalEventsCount: Int,
    val createdBy: String,
    val createdAtTimestamp: Long,
    val isPublished: Boolean = true,
    val publishedAtTimestamp: Long? = null,
    val snapshotJson: String = "" // Serialized snapshot of days and events for atomic rollback
)

/**
 * Detailed Audit Log for every Admin update, validation, approval, publish, and rollback action.
 */
@Entity(tableName = "calendar_audit_logs")
data class CalendarAuditLogEntity(
    @PrimaryKey(autoGenerate = true)
    val id: Long = 0,
    val timestamp: Long = System.currentTimeMillis(),
    val adminUsername: String,
    val action: String, // CREATE_DAY, UPDATE_DAY, CREATE_EVENT, UPDATE_EVENT, VERIFY, APPROVE, PUBLISH, ROLLBACK, BULK_MONTH_UPDATE, BULK_YEAR_UPDATE, API_CONTROL
    val targetType: String, // DAY, EVENT, MONTH, YEAR, VERSION, API_GATEWAY
    val targetKey: String,
    val oldValue: String = "",
    val newValue: String = "",
    val status: String = "SUCCESS",
    val notes: String = ""
)

/**
 * Demonstrates Client App local cache synchronization and offline status safety.
 * Guarantees that Client Apps explicitly state LIVE / SYNCED vs OFFLINE / CACHED.
 */
@Entity(tableName = "client_calendar_cache")
data class ClientCalendarCacheEntity(
    @PrimaryKey
    val clientAppId: String, // e.g. "VedaNovaClient_Mobile_1"
    val cachedVersion: String,
    val cachedAtTimestamp: Long = System.currentTimeMillis(),
    val syncStatus: String = "LIVE_SYNCED", // LIVE_SYNCED, OFFLINE_CACHED, SERVICE_UNAVAILABLE, PENDING_RECONNECT
    val cachedPayloadJson: String = "",
    val lastServerChecksum: String = ""
)
