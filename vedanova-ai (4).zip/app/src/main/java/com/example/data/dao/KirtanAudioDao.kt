package com.example.data.dao

import androidx.room.*
import com.example.data.model.KirtanAudioEntity
import com.example.data.model.KirtanAudioTrackEntity
import kotlinx.coroutines.flow.Flow

@Dao
interface KirtanAudioDao {

    @Query("SELECT * FROM kirtan_audio ORDER BY updatedAt DESC")
    fun getAllAudioFlow(): Flow<List<KirtanAudioEntity>>

    @Query("SELECT * FROM kirtan_audio WHERE status = 'AUDIO_PUBLISHED' ORDER BY updatedAt DESC")
    fun getPublishedAudioFlow(): Flow<List<KirtanAudioEntity>>

    @Query("SELECT * FROM kirtan_audio WHERE id = :id LIMIT 1")
    suspend fun getAudioById(id: String): KirtanAudioEntity?

    @Query("SELECT * FROM kirtan_audio WHERE kirtanId = :kirtanId ORDER BY audioVersion DESC")
    suspend fun getAudioListForKirtan(kirtanId: String): List<KirtanAudioEntity>

    @Query("SELECT * FROM kirtan_audio WHERE kirtanId = :kirtanId ORDER BY audioVersion DESC LIMIT 1")
    suspend fun getLatestAudioForKirtan(kirtanId: String): KirtanAudioEntity?

    @Query("SELECT * FROM kirtan_audio WHERE kirtanId = :kirtanId AND audioVersion = :audioVersion LIMIT 1")
    suspend fun getAudioForKirtanAndVersion(kirtanId: String, audioVersion: Int): KirtanAudioEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAudio(audio: KirtanAudioEntity)

    @Update
    suspend fun updateAudio(audio: KirtanAudioEntity)

    @Query("UPDATE kirtan_audio SET status = :status, updatedAt = :updatedAt, publishedAt = :publishedAt WHERE id = :id")
    suspend fun updateAudioStatus(id: String, status: String, updatedAt: Long, publishedAt: Long?)

    @Query("DELETE FROM kirtan_audio WHERE id = :id")
    suspend fun deleteAudioById(id: String)

    @Query("DELETE FROM kirtan_audio WHERE kirtanId = :kirtanId")
    suspend fun deleteAudioForKirtan(kirtanId: String)

    // Tracks
    @Query("SELECT * FROM kirtan_audio_tracks WHERE audioId = :audioId ORDER BY startTime ASC")
    suspend fun getTracksForAudio(audioId: String): List<KirtanAudioTrackEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertTracks(tracks: List<KirtanAudioTrackEntity>)

    @Query("DELETE FROM kirtan_audio_tracks WHERE audioId = :audioId")
    suspend fun deleteTracksForAudio(audioId: String)

    // Admin Dashboard Aggregates
    @Query("SELECT COUNT(*) FROM kirtan_audio")
    suspend fun getTotalAudioCount(): Int

    @Query("SELECT COUNT(*) FROM kirtan_audio WHERE status = 'AUDIO_DRAFT'")
    suspend fun getDraftAudioCount(): Int

    @Query("SELECT COUNT(*) FROM kirtan_audio WHERE status = 'AUDIO_PROCESSING'")
    suspend fun getProcessingAudioCount(): Int

    @Query("SELECT COUNT(*) FROM kirtan_audio WHERE status = 'AUDIO_VERIFIED'")
    suspend fun getVerifiedAudioCount(): Int

    @Query("SELECT COUNT(*) FROM kirtan_audio WHERE status = 'AUDIO_PUBLISHED'")
    suspend fun getPublishedAudioCount(): Int

    @Query("SELECT COUNT(*) FROM kirtan_audio WHERE status = 'AUDIO_REJECTED'")
    suspend fun getRejectedAudioCount(): Int

    @Query("SELECT COUNT(*) FROM kirtan_audio WHERE status = 'AUDIO_FAILED'")
    suspend fun getFailedAudioCount(): Int

    @Query("SELECT SUM(fileSizeBytes) FROM kirtan_audio")
    suspend fun getTotalStorageBytes(): Long?
}
