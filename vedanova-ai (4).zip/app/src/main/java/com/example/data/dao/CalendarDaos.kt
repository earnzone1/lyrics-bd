package com.example.data.dao

import androidx.room.*
import com.example.data.model.*
import kotlinx.coroutines.flow.Flow

@Dao
interface CalendarDayDao {
    @Query("SELECT * FROM calendar_days WHERE gregorianDate = :date AND region = :region LIMIT 1")
    suspend fun getDayByDateAndRegion(date: String, region: String): CalendarDayEntity?

    @Query("SELECT * FROM calendar_days WHERE gregorianDate = :date")
    suspend fun getDaysByDate(date: String): List<CalendarDayEntity>

    @Query("SELECT * FROM calendar_days WHERE region = :region AND gregorianDate LIKE :yearMonthPrefix || '%' ORDER BY gregorianDate ASC")
    suspend fun getDaysByMonth(yearMonthPrefix: String, region: String): List<CalendarDayEntity>

    @Query("SELECT * FROM calendar_days WHERE region = :region AND gregorianDate LIKE :yearPrefix || '%' ORDER BY gregorianDate ASC")
    suspend fun getDaysByYear(yearPrefix: String, region: String): List<CalendarDayEntity>

    @Query("SELECT * FROM calendar_days ORDER BY gregorianDate ASC")
    suspend fun getAllDays(): List<CalendarDayEntity>

    @Query("SELECT * FROM calendar_days ORDER BY gregorianDate ASC")
    fun observeAllDays(): Flow<List<CalendarDayEntity>>

    @Query("SELECT * FROM calendar_days WHERE status IN ('DRAFT', 'PENDING_VERIFICATION') ORDER BY gregorianDate ASC")
    suspend fun getPendingDays(): List<CalendarDayEntity>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateDay(day: CalendarDayEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllDays(days: List<CalendarDayEntity>)

    @Delete
    suspend fun deleteDay(day: CalendarDayEntity)

    @Query("DELETE FROM calendar_days WHERE id = :id")
    suspend fun deleteDayById(id: String)

    @Query("DELETE FROM calendar_days")
    suspend fun deleteAllDays()

    @Query("SELECT COUNT(*) FROM calendar_days")
    suspend fun getDaysCount(): Int

    @Query("SELECT COUNT(*) FROM calendar_days")
    fun observeDaysCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM calendar_days WHERE status IN ('DRAFT', 'PENDING_VERIFICATION')")
    fun observePendingDaysCount(): Flow<Int>
}

@Dao
interface CalendarEventDao {
    @Query("SELECT * FROM calendar_events ORDER BY startDate ASC")
    suspend fun getAllEvents(): List<CalendarEventEntity>

    @Query("SELECT * FROM calendar_events ORDER BY startDate ASC")
    fun observeAllEvents(): Flow<List<CalendarEventEntity>>

    @Query("SELECT * FROM calendar_events WHERE targetGregorianDate = :date OR (startDate <= :date AND endDate >= :date) ORDER BY startDate ASC")
    suspend fun getEventsForDate(date: String): List<CalendarEventEntity>

    @Query("SELECT * FROM calendar_events WHERE multiDayParentId = :parentId ORDER BY daySequence ASC")
    suspend fun getMultiDayChildEvents(parentId: String): List<CalendarEventEntity>

    @Query("SELECT * FROM calendar_events WHERE isMultiDay = 1 AND multiDayParentId IS NULL ORDER BY startDate ASC")
    suspend fun getMultiDayParentEvents(): List<CalendarEventEntity>

    @Query("SELECT * FROM calendar_events WHERE status IN ('DRAFT', 'PENDING_VERIFICATION') ORDER BY startDate ASC")
    suspend fun getPendingEvents(): List<CalendarEventEntity>

    @Query("SELECT * FROM calendar_events WHERE id = :id LIMIT 1")
    suspend fun getEventById(id: String): CalendarEventEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateEvent(event: CalendarEventEntity)

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertAllEvents(events: List<CalendarEventEntity>)

    @Delete
    suspend fun deleteEvent(event: CalendarEventEntity)

    @Query("DELETE FROM calendar_events WHERE id = :id OR multiDayParentId = :id")
    suspend fun deleteEventAndChildren(id: String)

    @Query("DELETE FROM calendar_events WHERE id = :id")
    suspend fun deleteEventById(id: String)

    @Query("DELETE FROM calendar_events")
    suspend fun deleteAllEvents()

    @Query("SELECT COUNT(*) FROM calendar_events")
    suspend fun getEventsCount(): Int

    @Query("SELECT COUNT(*) FROM calendar_events")
    fun observeEventsCount(): Flow<Int>

    @Query("SELECT COUNT(*) FROM calendar_events WHERE status IN ('DRAFT', 'PENDING_VERIFICATION')")
    fun observePendingEventsCount(): Flow<Int>
}

@Dao
interface CalendarVersionDao {
    @Query("SELECT * FROM calendar_versions ORDER BY createdAtTimestamp DESC")
    suspend fun getAllVersions(): List<CalendarVersionEntity>

    @Query("SELECT * FROM calendar_versions ORDER BY createdAtTimestamp DESC")
    fun observeAllVersions(): Flow<List<CalendarVersionEntity>>

    @Query("SELECT * FROM calendar_versions WHERE isPublished = 1 ORDER BY publishedAtTimestamp DESC, createdAtTimestamp DESC LIMIT 1")
    suspend fun getLatestPublishedVersion(): CalendarVersionEntity?

    @Query("SELECT * FROM calendar_versions WHERE versionId = :versionId LIMIT 1")
    suspend fun getVersionById(versionId: String): CalendarVersionEntity?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertVersion(version: CalendarVersionEntity)

    @Update
    suspend fun updateVersion(version: CalendarVersionEntity)

    @Query("DELETE FROM calendar_versions WHERE versionId = :versionId")
    suspend fun deleteVersion(versionId: String)

    @Query("DELETE FROM calendar_versions")
    suspend fun deleteAllVersions()

    @Query("SELECT COUNT(*) FROM calendar_versions")
    suspend fun getVersionsCount(): Int
}

@Dao
interface CalendarAuditLogDao {
    @Query("SELECT * FROM calendar_audit_logs ORDER BY timestamp DESC LIMIT :limit")
    suspend fun getRecentAuditLogs(limit: Int = 100): List<CalendarAuditLogEntity>

    @Query("SELECT * FROM calendar_audit_logs ORDER BY timestamp DESC LIMIT :limit")
    fun observeRecentAuditLogs(limit: Int = 100): Flow<List<CalendarAuditLogEntity>>

    @Insert
    suspend fun insertAuditLog(log: CalendarAuditLogEntity)

    @Query("DELETE FROM calendar_audit_logs")
    suspend fun deleteAllAuditLogs()
}

@Dao
interface ClientCalendarCacheDao {
    @Query("SELECT * FROM client_calendar_cache WHERE clientAppId = :clientAppId LIMIT 1")
    suspend fun getCacheByAppId(clientAppId: String): ClientCalendarCacheEntity?

    @Query("SELECT * FROM client_calendar_cache ORDER BY cachedAtTimestamp DESC")
    suspend fun getAllClientCaches(): List<ClientCalendarCacheEntity>

    @Query("SELECT * FROM client_calendar_cache ORDER BY cachedAtTimestamp DESC")
    fun observeAllClientCaches(): Flow<List<ClientCalendarCacheEntity>>

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertOrUpdateCache(cache: ClientCalendarCacheEntity)

    @Query("DELETE FROM client_calendar_cache WHERE clientAppId = :clientAppId")
    suspend fun deleteCache(clientAppId: String)

    @Query("DELETE FROM client_calendar_cache")
    suspend fun deleteAllCaches()
}
