package com.example.domain.ai

data class DiagnosticQualityScores(
    val groundingScore: Int,   // 0-100
    val sourceScore: Int,      // 0-100
    val contextScore: Int,     // 0-100
    val confidenceScore: Int,  // 0-100
    val safetyScore: Int,      // 0-100
    val overallScore: Int      // 0-100
)

data class DiagnosticInfo(
    val languageDetected: String,
    val intentDetected: String,
    val subIntent: String,
    val detectedIntents: List<String> = emptyList(),
    val ambiguityScore: Float, // 0.0 to 1.0 (higher means more ambiguous)
    val knowledgeMatchCount: Int,
    val topKnowledgeSource: String,
    val scriptureReference: String,
    val verificationStatus: String, // "VERIFIED_CANONICAL", "PARTIAL_MATCH", "SYNTHESIS_REQUIRED", "UNKNOWN_GROUNDING"
    val confidenceScore: Float, // 0.0 to 1.0
    val researchEngineUsed: Boolean,
    val responseTimeMs: Long,
    val apiEndpointUsed: String,
    val safetyPassed: Boolean,
    val conflictsDetected: Boolean,
    val diagnosticSummary: String,
    val qualityScores: DiagnosticQualityScores = DiagnosticQualityScores(95, 95, 90, 92, 100, 94),
    val sourceTier: SourceQualityTier = SourceQualityTier.PRIMARY_SCRIPTURE,
    val contextState: ConversationContextState = ConversationContextState(),
    val evaluatedSources: List<EvaluatedSource> = emptyList(),
    val claims: List<ClaimVerificationResult> = emptyList(),
    val selfCorrectionLogs: List<SelfCorrectionLog> = emptyList(),
    val relatedNodes: List<DharmaGraphNode> = emptyList(),
    val reasoningConfidence: ReasoningConfidence = ReasoningConfidence.HIGH_CONFIDENCE,
    val isDecomposedReasoning: Boolean = false,
    val subTasksCount: Int = 1,
    val evidenceCount: Int = 1,
    val answerPlan: AnswerPlanFormat = AnswerPlanFormat.DETAILED_EXPLANATION,
    val evidenceClassification: EvidenceClassification = EvidenceClassification.CANONICAL,
    val isOriginalCreativeWriting: Boolean = false,
    val truthCategory: TruthCategory = TruthCategory.SCRIPTURAL_TEXT,
    val truthSeparation: TruthSeparationAnalysis? = null,
    val scripturalSourceTier: ScripturalSourceTier = ScripturalSourceTier.OTHER_RECOGNIZED_TEXTS,
    val selfCheckResult: SelfCheckResult? = null,
    val qualityEvaluation: AnswerQualityEvaluationResult? = null,
    val selfCorrectionPipelineResult: SelfCorrectionPipelineResult? = null,
    val universalIntent: UniversalIntent? = null,
    val subsystemRoute: SubsystemRoute? = null,
    val answerType: AnswerType? = null,
    val messageForm: MessageForm? = null,
    val conversationDecision: ConversationDecision? = null,
    val humanInterpretation: HumanInterpretation? = null,
    val questionType: QuestionType? = null,
    val answerDepth: AnswerDepth? = null,
    val answerConfidence: AnswerConfidence = AnswerConfidence.HIGH,
    val step9QualityEvaluation: Step9QualityEvaluation? = null,
    val isMultiPartQuestion: Boolean = false,
    val requiresCurrentInfo: Boolean = false,
    val hasFalsePremise: Boolean = false
)

enum class ConversationDecision {
    ANSWER,
    ASK,
    CLARIFY,
    ACKNOWLEDGE,
    EXPLAIN,
    CONTINUE_CONVERSATION,
    CORRECT,
    SUMMARIZE,
    RECOMMEND,
    RESEARCH,
    USE_TOOL,
    CREATIVE_RESPONSE,
    REFUSE_SAFE_RESPONSE
}

enum class ConversationalEmotionTone {
    HAPPY,
    SAD,
    CONFUSED,
    FRUSTRATED,
    CURIOUS,
    EXCITED,
    SERIOUS,
    PLAYFUL,
    WORRIED,
    NEUTRAL
}

enum class EpistemicClassification {
    FACT,
    TRADITION,
    INTERPRETATION,
    OPINION,
    ADVICE,
    ORIGINAL_AI_WRITING
}

data class HumanInterpretation(
    val whatWasSaid: String,
    val potentialMeaning: String,
    val hasSufficientContext: Boolean,
    val naturalResponseStyle: String,
    val isTypoOrGibberish: Boolean = false,
    val requiresClarification: Boolean = false,
    val clarifiesPreviousTurn: Boolean = false,
    val detectedTone: ConversationalEmotionTone = ConversationalEmotionTone.NEUTRAL,
    val epistemicType: EpistemicClassification = EpistemicClassification.FACT
)

data class SelfDiagnosticReport(
    val queryInterpretation: String,
    val detectedIntent: String,
    val knowledgeRetrievalStatus: String,
    val sourceIntegrity: String,
    val verificationAnalysis: String,
    val potentialErrorsOrHallucinations: List<String>,
    val recommendedFix: String,
    val overallHealthScore: Int // 0-100
)

