package com.example.domain.ai

import java.util.Locale

/**
 * Universal Intent Categories supported by VedaNova AI
 */
enum class UniversalIntent {
    GREETING,
    FAREWELL,
    CASUAL_CONVERSATION,
    GENERAL_QUESTION,
    RELIGIOUS_QUESTION,
    SCRIPTURE_QUESTION,
    MANTRA_QUESTION,
    RITUAL_QUESTION,
    PHILOSOPHICAL_QUESTION,
    HISTORICAL_QUESTION,
    SCIENTIFIC_QUESTION,
    MATHEMATICAL_QUESTION,
    TECHNOLOGY_QUESTION,
    TRANSLATION,
    SUMMARIZATION,
    WRITING_REQUEST,
    CREATIVE_REQUEST,
    IMAGE_REQUEST,
    VOICE_REQUEST,
    HOW_TO_REQUEST,
    COMPARISON,
    CALCULATION,
    FOLLOW_UP,
    CLARIFICATION,
    CORRECTION,
    OPINION_REQUEST,
    UNKNOWN_INTENT,
    // Step 8 additions:
    RELATIONSHIP_ADVICE,
    EMOTIONAL_CONVERSATION,
    CURIOSITY_PROMPT,
    META_COMMUNICATION,
    // Step 9 additions:
    FACTUAL_QUESTION,
    EXPLANATORY_QUESTION,
    WHY_HOW_QUESTION,
    DEFINITION_QUESTION,
    CURRENT_INFO_QUERY,
    RESEARCH_QUESTION,
    MULTI_PART_QUESTION,
    UNCLEAR_RANDOM_QUERY
}

/**
 * Subsystem routing targets for modular execution
 */
enum class SubsystemRoute {
    GENERAL_KNOWLEDGE,
    DHARMA_KNOWLEDGE,
    SCRIPTURE_VERIFICATION,
    MANTRA_VERIFICATION,
    RESEARCH,
    CALCULATOR,
    TRANSLATION,
    WRITING_ENGINE,
    IMAGE_ENGINE,
    VOICE_ENGINE,
    CONTEXT_ENGINE,
    CLARIFICATION_ENGINE,
    ADVICE_ENGINE,
    // Step 9 additions:
    SCIENCE,
    MATHEMATICS,
    TECHNOLOGY,
    HISTORY,
    CREATIVE_ENGINE
}

/**
 * Detailed question types supported by Step 9 Universal Engine
 */
enum class QuestionType {
    GENERAL,
    FACTUAL,
    EXPLANATORY,
    WHY_HOW,
    COMPARISON,
    DEFINITION,
    CALCULATION,
    TRANSLATION,
    SUMMARIZATION,
    WRITING,
    CREATIVE,
    ADVICE,
    OPINION,
    CASUAL_CONVERSATION,
    GREETING,
    FOLLOW_UP,
    CORRECTION,
    RESEARCH,
    CURRENT_INFORMATION,
    TECHNICAL,
    RELIGIOUS,
    PHILOSOPHICAL,
    HISTORICAL,
    SCIENTIFIC,
    RELATIONSHIP,
    UNCLEAR_RANDOM
}

/**
 * Required level of detail for response calibration
 */
enum class AnswerDepth {
    CONCISE,
    EXPLANATORY,
    DETAILED_COMPREHENSIVE
}

/**
 * Internal classification of answer confidence
 */
enum class AnswerConfidence {
    HIGH,
    MEDIUM,
    LOW
}

/**
 * Step 9 Multi-dimensional response quality & safety score
 */
data class Step9QualityEvaluation(
    val understandingScore: Int = 100,
    val intentAccuracyScore: Int = 100,
    val contextAccuracyScore: Int = 100,
    val factualGroundingScore: Int = 100,
    val relevanceScore: Int = 100,
    val completenessScore: Int = 100,
    val clarityScore: Int = 100,
    val naturalnessScore: Int = 100,
    val safetyScore: Int = 100,
    val hallucinationRiskScore: Int = 0,
    val overallQualityScore: Int = 100,
    val confidence: AnswerConfidence = AnswerConfidence.HIGH,
    val passed: Boolean = true,
    val checkSummary: String = "Step 9 Universal Quality Evaluation Passed"
)

/**
 * Response structure decision types
 */
enum class AnswerType {
    DIRECT_ANSWER,
    EXPLANATION,
    STEP_BY_STEP_GUIDE,
    CLARIFICATION_QUESTION,
    CASUAL_REPLY,
    CREATIVE_OUTPUT,
    TRANSLATION,
    CALCULATION_RESULT,
    RESEARCH_RESULT,
    REFUSAL_SAFETY_RESPONSE,
    EMPATHETIC_ADVICE,
    OPINION_STATEMENT,
    CURATED_INSIGHT
}

/**
 * Structural classification of user message
 */
enum class MessageForm {
    GREETING,
    FAREWELL,
    QUESTION,
    STATEMENT,
    COMMAND_REQUEST,
    CORRECTION,
    FOLLOW_UP,
    CASUAL_CONVERSATION,
    ACKNOWLEDGEMENT
}

/**
 * Comprehensive pipeline understanding plan formulated before answer generation
 */
data class UniversalUnderstandingPlan(
    val rawQuery: String,
    val normalizedQuery: String,
    val messageForm: MessageForm,
    val primaryIntent: UniversalIntent,
    val subIntents: List<UniversalIntent>,
    val targetRoute: SubsystemRoute,
    val plannedAnswerType: AnswerType,
    val detectedTopic: String?,
    val detectedEntities: List<String>,
    val isDharmaDomain: Boolean,
    val requiresClarification: Boolean,
    val clarificationQuestion: String? = null,
    val targetLanguage: String,
    val isShortMessage: Boolean,
    val resolvedFollowUpSubject: String? = null,
    val ambiguityScore: Float = 0.0f,
    val conversationDecision: ConversationDecision = ConversationDecision.ANSWER,
    val humanInterpretation: HumanInterpretation = HumanInterpretation(
        whatWasSaid = rawQuery,
        potentialMeaning = "Direct user inquiry",
        hasSufficientContext = true,
        naturalResponseStyle = "Direct Answer"
    ),
    val detectedTone: ConversationalEmotionTone = ConversationalEmotionTone.NEUTRAL,
    val epistemicType: EpistemicClassification = EpistemicClassification.FACT,
    val questionType: QuestionType = QuestionType.FACTUAL,
    val answerDepth: AnswerDepth = AnswerDepth.EXPLANATORY,
    val answerConfidence: AnswerConfidence = AnswerConfidence.HIGH,
    val requiresCurrentInfo: Boolean = false,
    val currentInfoTopic: String? = null,
    val isMultiPart: Boolean = false,
    val decomposedParts: List<String> = emptyList(),
    val subQuestions: List<String> = emptyList(),
    val hasFalsePremise: Boolean = false,
    val falsePremiseExplanation: String? = null,
    val isUserCorrection: Boolean = false
)

data class FinalDecisionCheckResult(
    val understood: Boolean,
    val isMeaningful: Boolean,
    val isQuestion: Boolean,
    val isCasualConversation: Boolean,
    val isTypoOrGibberish: Boolean,
    val contextClarified: Boolean,
    val needsKnowledgeRetrieval: Boolean,
    val needsResearch: Boolean,
    val decision: ConversationDecision,
    val naturalHelpfulSummary: String
)

/**
 * VedaNova Universal Question Understanding, Response Decision & Answer Selection Engine
 *
 * Enforces the strict rule:
 * FIRST UNDERSTAND THE USER.
 * THEN DECIDE WHAT THE USER NEEDS.
 * THEN SELECT THE APPROPRIATE ENGINE.
 * THEN GENERATE THE ANSWER.
 * THEN VERIFY THE ANSWER.
 */
object UniversalUnderstandingEngine {

    /**
     * Step 1 to 6: Analyzes query and context to formulate a complete execution plan
     */
    fun understandAndPlan(
        query: String,
        history: List<Pair<String, String>> = emptyList(),
        contextState: ConversationContextState = ConversationContextState()
    ): UniversalUnderstandingPlan {
        val raw = query.trim()
        val normalized = normalizeQuery(raw)
        val lower = normalized.lowercase(Locale.ROOT)

        // 1. Language Detection
        val targetLanguage = detectLanguage(raw)

        // 2. Message Form & Short Message Detection
        val isShort = isShortMessage(normalized)
        val form = detectMessageForm(normalized, lower, history)

        // 2a. User Correction Check ("তুমি ভুল বলেছ", "that is wrong", "your answer is incorrect")
        if (isUserCorrection(lower)) {
            return UniversalUnderstandingPlan(
                rawQuery = raw,
                normalizedQuery = normalized,
                messageForm = MessageForm.CORRECTION,
                primaryIntent = UniversalIntent.CORRECTION,
                subIntents = listOf(UniversalIntent.CASUAL_CONVERSATION),
                targetRoute = SubsystemRoute.CONTEXT_ENGINE,
                plannedAnswerType = AnswerType.CASUAL_REPLY,
                detectedTopic = "User Correction & Self-Review",
                detectedEntities = listOf("Correction", "Self-Review"),
                isDharmaDomain = false,
                requiresClarification = false,
                targetLanguage = targetLanguage,
                isShortMessage = isShort,
                conversationDecision = ConversationDecision.CORRECT,
                questionType = QuestionType.CORRECTION,
                answerDepth = AnswerDepth.CONCISE,
                answerConfidence = AnswerConfidence.HIGH,
                isUserCorrection = true,
                humanInterpretation = HumanInterpretation(
                    whatWasSaid = raw,
                    potentialMeaning = "User pointing out a perceived mistake or requesting self-correction",
                    hasSufficientContext = true,
                    naturalResponseStyle = "Gracious acknowledgment, careful re-verification without defensiveness"
                )
            )
        }

        // 2b. Banglish Normalization & Routing ("gita ki", "kormo ki", "kemon acho")
        val banglishBengali = detectBanglish(lower)
        if (banglishBengali != null) {
            val isBanglishDharma = isDharmaTopic(banglishBengali) || banglishBengali.contains("গীতা") || banglishBengali.contains("কর্ম") || banglishBengali.contains("ধর্ম")
            val isBanglishGreeting = banglishBengali.contains("কেমন") || banglishBengali.contains("নমস্কার") || banglishBengali.contains("সকাল")
            val primaryIntent = when {
                isBanglishGreeting -> UniversalIntent.CASUAL_CONVERSATION
                isBanglishDharma -> UniversalIntent.RELIGIOUS_QUESTION
                else -> UniversalIntent.GENERAL_QUESTION
            }
            val targetRoute = when {
                isBanglishGreeting -> SubsystemRoute.GENERAL_KNOWLEDGE
                isBanglishDharma -> SubsystemRoute.DHARMA_KNOWLEDGE
                else -> SubsystemRoute.GENERAL_KNOWLEDGE
            }
            val qType = when {
                isBanglishGreeting -> QuestionType.CASUAL_CONVERSATION
                isBanglishDharma -> QuestionType.PHILOSOPHICAL
                else -> QuestionType.GENERAL
            }
            return UniversalUnderstandingPlan(
                rawQuery = raw,
                normalizedQuery = banglishBengali,
                messageForm = if (banglishBengali.endsWith("?")) MessageForm.QUESTION else MessageForm.STATEMENT,
                primaryIntent = primaryIntent,
                subIntents = listOf(primaryIntent),
                targetRoute = targetRoute,
                plannedAnswerType = if (isBanglishGreeting) AnswerType.CASUAL_REPLY else AnswerType.EXPLANATION,
                detectedTopic = banglishBengali,
                detectedEntities = listOf("Banglish Transliteration", banglishBengali),
                isDharmaDomain = isBanglishDharma,
                requiresClarification = false,
                targetLanguage = "Bengali",
                isShortMessage = true,
                conversationDecision = if (isBanglishGreeting) ConversationDecision.ANSWER else ConversationDecision.EXPLAIN,
                questionType = qType,
                answerDepth = AnswerDepth.EXPLANATORY,
                answerConfidence = AnswerConfidence.HIGH,
                humanInterpretation = HumanInterpretation(
                    whatWasSaid = raw,
                    potentialMeaning = "Banglish phonetic transliteration for '$banglishBengali'",
                    hasSufficientContext = true,
                    naturalResponseStyle = "Clear natural response in authentic Bengali addressing the mapped query"
                )
            )
        }

        // 2c. False Premise Detection ("সূর্য কেন পৃথিবীর চারদিকে ঘোরে?", "আইনস্টাইন কি গীতা লিখেছিলেন?")
        val falsePremiseExp = checkFalsePremise(normalized, lower)
        if (falsePremiseExp != null) {
            return UniversalUnderstandingPlan(
                rawQuery = raw,
                normalizedQuery = normalized,
                messageForm = MessageForm.QUESTION,
                primaryIntent = UniversalIntent.FACTUAL_QUESTION,
                subIntents = listOf(UniversalIntent.SCIENTIFIC_QUESTION),
                targetRoute = SubsystemRoute.SCIENCE,
                plannedAnswerType = AnswerType.EXPLANATION,
                detectedTopic = "Scientific Premise Clarification",
                detectedEntities = listOf("Fact Check", "False Premise"),
                isDharmaDomain = false,
                requiresClarification = false,
                targetLanguage = targetLanguage,
                isShortMessage = isShort,
                conversationDecision = ConversationDecision.EXPLAIN,
                questionType = QuestionType.FACTUAL,
                answerDepth = AnswerDepth.EXPLANATORY,
                answerConfidence = AnswerConfidence.HIGH,
                hasFalsePremise = true,
                falsePremiseExplanation = falsePremiseExp,
                humanInterpretation = HumanInterpretation(
                    whatWasSaid = raw,
                    potentialMeaning = "Inquiry based on an empirically or historically false premise",
                    hasSufficientContext = true,
                    naturalResponseStyle = "Polite, objective clarification correcting the underlying false premise first"
                )
            )
        }

        // 2d. Real-Time / Current Information Check ("আজকের সোনার দাম কত?", "today's weather")
        val currentTopic = checkRequiresCurrentInfo(normalized, lower)
        if (currentTopic != null) {
            return UniversalUnderstandingPlan(
                rawQuery = raw,
                normalizedQuery = normalized,
                messageForm = MessageForm.QUESTION,
                primaryIntent = UniversalIntent.CURRENT_INFO_QUERY,
                subIntents = listOf(UniversalIntent.GENERAL_QUESTION),
                targetRoute = SubsystemRoute.RESEARCH,
                plannedAnswerType = AnswerType.RESEARCH_RESULT,
                detectedTopic = currentTopic,
                detectedEntities = listOf("Real-time Telemetry", currentTopic),
                isDharmaDomain = false,
                requiresClarification = false,
                targetLanguage = targetLanguage,
                isShortMessage = isShort,
                conversationDecision = ConversationDecision.ANSWER,
                questionType = QuestionType.CURRENT_INFORMATION,
                answerDepth = AnswerDepth.CONCISE,
                answerConfidence = AnswerConfidence.MEDIUM,
                requiresCurrentInfo = true,
                currentInfoTopic = currentTopic,
                humanInterpretation = HumanInterpretation(
                    whatWasSaid = raw,
                    potentialMeaning = "Query requesting live/real-time external information ($currentTopic)",
                    hasSufficientContext = true,
                    naturalResponseStyle = "Honest boundary declaration preventing hallucination of dynamic live data"
                )
            )
        }

        // 2e. Multi-Part Question Decomposition ("কর্ম কী এবং কেন এটি গুরুত্বপূর্ণ? এটি কীভাবে প্রয়োগ করব?")
        val multiPart = checkMultiPartQuestion(normalized, lower)
        if (multiPart != null) {
            val isDharma = multiPart.targetRoute == SubsystemRoute.DHARMA_KNOWLEDGE
            return UniversalUnderstandingPlan(
                rawQuery = raw,
                normalizedQuery = normalized,
                messageForm = MessageForm.QUESTION,
                primaryIntent = multiPart.primaryIntent,
                subIntents = listOf(if (isDharma) UniversalIntent.RELIGIOUS_QUESTION else UniversalIntent.GENERAL_QUESTION),
                targetRoute = multiPart.targetRoute,
                plannedAnswerType = AnswerType.EXPLANATION,
                detectedTopic = "Multi-Part Comprehensive Exploration",
                detectedEntities = multiPart.decomposedParts,
                isDharmaDomain = isDharma,
                requiresClarification = false,
                targetLanguage = targetLanguage,
                isShortMessage = false,
                conversationDecision = ConversationDecision.EXPLAIN,
                questionType = multiPart.questionType,
                answerDepth = AnswerDepth.EXPLANATORY,
                answerConfidence = AnswerConfidence.HIGH,
                isMultiPart = true,
                decomposedParts = multiPart.decomposedParts,
                subQuestions = multiPart.decomposedParts,
                humanInterpretation = HumanInterpretation(
                    whatWasSaid = raw,
                    potentialMeaning = "Complex multi-part inquiry containing multiple connected sub-questions",
                    hasSufficientContext = true,
                    naturalResponseStyle = "Structured multi-part response addressing every sub-question systematically"
                )
            )
        }

        // 3. Calculation Check (Arabic and Bengali Numerals)
        val mathMatch = detectCalculation(normalized, lower)
        if (mathMatch != null) {
            return UniversalUnderstandingPlan(
                rawQuery = raw,
                normalizedQuery = normalized,
                messageForm = MessageForm.QUESTION,
                primaryIntent = UniversalIntent.CALCULATION,
                subIntents = listOf(UniversalIntent.MATHEMATICAL_QUESTION),
                targetRoute = SubsystemRoute.CALCULATOR,
                plannedAnswerType = AnswerType.CALCULATION_RESULT,
                detectedTopic = mathMatch.first,
                detectedEntities = listOf("Arithmetic", mathMatch.first),
                isDharmaDomain = false,
                requiresClarification = false,
                targetLanguage = targetLanguage,
                isShortMessage = isShort,
                conversationDecision = ConversationDecision.ANSWER,
                questionType = QuestionType.CALCULATION,
                answerDepth = AnswerDepth.CONCISE,
                answerConfidence = AnswerConfidence.HIGH,
                humanInterpretation = HumanInterpretation(
                    whatWasSaid = raw,
                    potentialMeaning = "Mathematical calculation",
                    hasSufficientContext = true,
                    naturalResponseStyle = "Objective numeric computation"
                )
            )
        }

        // 4. Typo, Random Input & Unknown Text Check (Never force religion on gibberish or typos)
        if (detectTypoOrGibberish(raw, normalized, lower)) {
            val clarificationMsg = generateTypoClarification(raw, normalized, lower)
            return UniversalUnderstandingPlan(
                rawQuery = raw,
                normalizedQuery = normalized,
                messageForm = MessageForm.STATEMENT,
                primaryIntent = UniversalIntent.CLARIFICATION,
                subIntents = emptyList(),
                targetRoute = SubsystemRoute.CLARIFICATION_ENGINE,
                plannedAnswerType = AnswerType.CLARIFICATION_QUESTION,
                detectedTopic = "Typo / Unclear Input",
                detectedEntities = listOf(raw),
                isDharmaDomain = false,
                requiresClarification = true,
                clarificationQuestion = clarificationMsg,
                targetLanguage = targetLanguage,
                isShortMessage = isShort,
                ambiguityScore = 1.0f,
                conversationDecision = ConversationDecision.CLARIFY,
                humanInterpretation = HumanInterpretation(
                    whatWasSaid = raw,
                    potentialMeaning = "Typo, random characters, or accidental keyboard input",
                    hasSufficientContext = false,
                    naturalResponseStyle = "Polite single clarification question",
                    isTypoOrGibberish = true,
                    requiresClarification = true
                )
            )
        }

        // 5. Greeting Safety Check (Never inject religion into greetings)
        if (isGreeting(lower)) {
            return UniversalUnderstandingPlan(
                rawQuery = raw,
                normalizedQuery = normalized,
                messageForm = MessageForm.GREETING,
                primaryIntent = UniversalIntent.GREETING,
                subIntents = listOf(UniversalIntent.CASUAL_CONVERSATION),
                targetRoute = SubsystemRoute.GENERAL_KNOWLEDGE,
                plannedAnswerType = AnswerType.CASUAL_REPLY,
                detectedTopic = "Greeting",
                detectedEntities = listOf("Polite Greeting"),
                isDharmaDomain = false,
                requiresClarification = false,
                targetLanguage = targetLanguage,
                isShortMessage = isShort,
                conversationDecision = ConversationDecision.CONTINUE_CONVERSATION,
                humanInterpretation = HumanInterpretation(
                    whatWasSaid = raw,
                    potentialMeaning = "Polite conversational greeting",
                    hasSufficientContext = true,
                    naturalResponseStyle = "Friendly greeting"
                )
            )
        }

        // 6. Farewell Check
        if (isFarewell(lower)) {
            return UniversalUnderstandingPlan(
                rawQuery = raw,
                normalizedQuery = normalized,
                messageForm = MessageForm.FAREWELL,
                primaryIntent = UniversalIntent.FAREWELL,
                subIntents = listOf(UniversalIntent.CASUAL_CONVERSATION),
                targetRoute = SubsystemRoute.GENERAL_KNOWLEDGE,
                plannedAnswerType = AnswerType.CASUAL_REPLY,
                detectedTopic = "Farewell",
                detectedEntities = listOf("Polite Farewell"),
                isDharmaDomain = false,
                requiresClarification = false,
                targetLanguage = targetLanguage,
                isShortMessage = isShort,
                conversationDecision = ConversationDecision.ACKNOWLEDGE,
                humanInterpretation = HumanInterpretation(
                    whatWasSaid = raw,
                    potentialMeaning = "Polite farewell or departure",
                    hasSufficientContext = true,
                    naturalResponseStyle = "Warm farewell closure"
                )
            )
        }

        // 7. Casual Conversation ("কেমন আছ?", "কি খবর?", "শুনছ?", "আচ্ছা", "ঠিক আছে", "হুম", "thanks", "ok")
        if (isCasualConversation(lower)) {
            val cleanLower = lower.trim().removeSuffix("?").removeSuffix("!").removeSuffix("।").trim()
            val decision = when {
                cleanLower in listOf("ok", "okay", "alright", "fine", "ঠিক আছে", "thanks", "thank you", "ধন্যবাদ", "অনেক ধন্যবাদ", "বুঝলাম", "understood", "got it") -> ConversationDecision.ACKNOWLEDGE
                cleanLower in listOf("সত্যি?", "সত্যি", "really") -> ConversationDecision.ANSWER
                else -> ConversationDecision.CONTINUE_CONVERSATION
            }
            return UniversalUnderstandingPlan(
                rawQuery = raw,
                normalizedQuery = normalized,
                messageForm = MessageForm.CASUAL_CONVERSATION,
                primaryIntent = UniversalIntent.CASUAL_CONVERSATION,
                subIntents = emptyList(),
                targetRoute = SubsystemRoute.GENERAL_KNOWLEDGE,
                plannedAnswerType = AnswerType.CASUAL_REPLY,
                detectedTopic = "Casual Conversation",
                detectedEntities = listOf("Conversational Etiquette"),
                isDharmaDomain = false,
                requiresClarification = false,
                targetLanguage = targetLanguage,
                isShortMessage = isShort,
                conversationDecision = decision,
                humanInterpretation = HumanInterpretation(
                    whatWasSaid = raw,
                    potentialMeaning = "Casual conversation or conversational feedback",
                    hasSufficientContext = true,
                    naturalResponseStyle = "Natural conversational response"
                )
            )
        }

        // 8. Joke & Humor Request ("Tell me a joke.", "একটি কৌতুক বলো", "জোকস বলো")
        if (isJokeRequest(lower)) {
            return UniversalUnderstandingPlan(
                rawQuery = raw,
                normalizedQuery = normalized,
                messageForm = MessageForm.COMMAND_REQUEST,
                primaryIntent = UniversalIntent.CREATIVE_REQUEST,
                subIntents = listOf(UniversalIntent.CASUAL_CONVERSATION),
                targetRoute = SubsystemRoute.WRITING_ENGINE,
                plannedAnswerType = AnswerType.CREATIVE_OUTPUT,
                detectedTopic = "Joke",
                detectedEntities = listOf("Humor", "Joke"),
                isDharmaDomain = false,
                requiresClarification = false,
                targetLanguage = targetLanguage,
                isShortMessage = isShort,
                conversationDecision = ConversationDecision.CREATIVE_RESPONSE,
                humanInterpretation = HumanInterpretation(
                    whatWasSaid = raw,
                    potentialMeaning = "Request for a light-hearted, clean joke or humor",
                    hasSufficientContext = true,
                    naturalResponseStyle = "Wholesome, witty joke"
                )
            )
        }

        // 9. Creator Identity ("Who created you?", "তোমাকে কে বানিয়েছে?")
        if (isCreatorInquiry(lower)) {
            return UniversalUnderstandingPlan(
                rawQuery = raw,
                normalizedQuery = normalized,
                messageForm = MessageForm.QUESTION,
                primaryIntent = UniversalIntent.GENERAL_QUESTION,
                subIntents = listOf(UniversalIntent.TECHNOLOGY_QUESTION),
                targetRoute = SubsystemRoute.GENERAL_KNOWLEDGE,
                plannedAnswerType = AnswerType.DIRECT_ANSWER,
                detectedTopic = "Creator: Sri Milon Chandra",
                detectedEntities = listOf("Sri Milon Chandra", "Creator Identity"),
                isDharmaDomain = false,
                requiresClarification = false,
                targetLanguage = targetLanguage,
                isShortMessage = isShort,
                conversationDecision = ConversationDecision.ANSWER,
                humanInterpretation = HumanInterpretation(
                    whatWasSaid = raw,
                    potentialMeaning = "Question about AI creator and origin",
                    hasSufficientContext = true,
                    naturalResponseStyle = "Polite factual attribution"
                )
            )
        }

        // 9a. Relationship & Interpersonal Guidance ("আমার বন্ধুর সাথে ভুল বোঝাবুঝি হয়েছে।", "কাউকে পছন্দ করলে কীভাবে সম্মানের সঙ্গে কথা বলা যায়?")
        if (isRelationshipQuery(lower)) {
            val tone = detectEmotionTone(normalized, lower)
            return UniversalUnderstandingPlan(
                rawQuery = raw,
                normalizedQuery = normalized,
                messageForm = if (lower.endsWith("?") || lower.contains("কীভাবে") || lower.contains("কিভাবে") || lower.startsWith("how")) MessageForm.QUESTION else MessageForm.STATEMENT,
                primaryIntent = UniversalIntent.RELATIONSHIP_ADVICE,
                subIntents = listOf(UniversalIntent.CASUAL_CONVERSATION),
                targetRoute = SubsystemRoute.ADVICE_ENGINE,
                plannedAnswerType = AnswerType.EMPATHETIC_ADVICE,
                detectedTopic = "Relationship Guidance & Respectful Communication",
                detectedEntities = listOf("Friendship", "Respectful Boundaries", "Interpersonal Communication"),
                isDharmaDomain = false,
                requiresClarification = false,
                targetLanguage = targetLanguage,
                isShortMessage = isShort,
                conversationDecision = ConversationDecision.RECOMMEND,
                humanInterpretation = HumanInterpretation(
                    whatWasSaid = raw,
                    potentialMeaning = "Inquiry or sharing regarding relationship, friendship, or respectful communication",
                    hasSufficientContext = true,
                    naturalResponseStyle = "Empathetic, respectful, practical, age-appropriate advice without roleplay",
                    detectedTone = tone,
                    epistemicType = EpistemicClassification.ADVICE
                ),
                detectedTone = tone,
                epistemicType = EpistemicClassification.ADVICE
            )
        }

        // 9b. Emotional Sharing & Mental State ("আজ অনেক ভালো লাগছে।", "আমি একটু confused.", "আমি এটা বুঝতে পারছি না।")
        if (isEmotionalSharing(lower)) {
            val tone = detectEmotionTone(normalized, lower)
            val decision = if (tone == ConversationalEmotionTone.CONFUSED) ConversationDecision.EXPLAIN else ConversationDecision.CONTINUE_CONVERSATION
            return UniversalUnderstandingPlan(
                rawQuery = raw,
                normalizedQuery = normalized,
                messageForm = MessageForm.STATEMENT,
                primaryIntent = UniversalIntent.EMOTIONAL_CONVERSATION,
                subIntents = listOf(UniversalIntent.CASUAL_CONVERSATION),
                targetRoute = SubsystemRoute.GENERAL_KNOWLEDGE,
                plannedAnswerType = AnswerType.CASUAL_REPLY,
                detectedTopic = "Emotional Well-being",
                detectedEntities = listOf("Emotion", "User Feelings"),
                isDharmaDomain = false,
                requiresClarification = false,
                targetLanguage = targetLanguage,
                isShortMessage = isShort,
                conversationDecision = decision,
                humanInterpretation = HumanInterpretation(
                    whatWasSaid = raw,
                    potentialMeaning = "User sharing emotional state or cognitive difficulty",
                    hasSufficientContext = true,
                    naturalResponseStyle = "Warm, supportive, non-judgmental response adapted to tone",
                    detectedTone = tone,
                    epistemicType = EpistemicClassification.ADVICE
                ),
                detectedTone = tone,
                epistemicType = EpistemicClassification.ADVICE
            )
        }

        // 9c. Opinion & Perspective Inquiry ("তুমি কী মনে কর?", "What do you think?")
        if (isOpinionRequest(lower)) {
            val tone = detectEmotionTone(normalized, lower)
            return UniversalUnderstandingPlan(
                rawQuery = raw,
                normalizedQuery = normalized,
                messageForm = MessageForm.QUESTION,
                primaryIntent = UniversalIntent.OPINION_REQUEST,
                subIntents = listOf(UniversalIntent.GENERAL_QUESTION),
                targetRoute = SubsystemRoute.GENERAL_KNOWLEDGE,
                plannedAnswerType = AnswerType.OPINION_STATEMENT,
                detectedTopic = "Opinion & Perspective",
                detectedEntities = listOf("AI Perspective", "Objective Analysis"),
                isDharmaDomain = false,
                requiresClarification = false,
                targetLanguage = targetLanguage,
                isShortMessage = isShort,
                conversationDecision = ConversationDecision.EXPLAIN,
                humanInterpretation = HumanInterpretation(
                    whatWasSaid = raw,
                    potentialMeaning = "User asking for AI's perspective or opinion",
                    hasSufficientContext = true,
                    naturalResponseStyle = "Balanced perspective clearly labeled as an opinion distinct from facts",
                    detectedTone = tone,
                    epistemicType = EpistemicClassification.OPINION
                ),
                detectedTone = tone,
                epistemicType = EpistemicClassification.OPINION
            )
        }

        // 9d. Curiosity Prompt ("Tell me something interesting.", "একটি মজার তথ্য বলো")
        if (isCuriosityPrompt(lower)) {
            return UniversalUnderstandingPlan(
                rawQuery = raw,
                normalizedQuery = normalized,
                messageForm = MessageForm.COMMAND_REQUEST,
                primaryIntent = UniversalIntent.CURIOSITY_PROMPT,
                subIntents = listOf(UniversalIntent.GENERAL_QUESTION),
                targetRoute = SubsystemRoute.GENERAL_KNOWLEDGE,
                plannedAnswerType = AnswerType.CURATED_INSIGHT,
                detectedTopic = "Fascinating Universal Knowledge",
                detectedEntities = listOf("Science", "Natural Phenomenon", "Curiosity"),
                isDharmaDomain = false,
                requiresClarification = false,
                targetLanguage = targetLanguage,
                isShortMessage = isShort,
                conversationDecision = ConversationDecision.ANSWER,
                humanInterpretation = HumanInterpretation(
                    whatWasSaid = raw,
                    potentialMeaning = "Request for an interesting, engaging factual insight",
                    hasSufficientContext = true,
                    naturalResponseStyle = "Captivating, accurate natural/scientific fact without preaching",
                    detectedTone = ConversationalEmotionTone.CURIOUS,
                    epistemicType = EpistemicClassification.FACT
                ),
                detectedTone = ConversationalEmotionTone.CURIOUS,
                epistemicType = EpistemicClassification.FACT
            )
        }

        // 9e. Meta-Communication / Understanding Check ("আমি কী বলতে চেয়েছি বুঝেছ?")
        if (isMetaCommunication(lower)) {
            val tone = detectEmotionTone(normalized, lower)
            return UniversalUnderstandingPlan(
                rawQuery = raw,
                normalizedQuery = normalized,
                messageForm = MessageForm.QUESTION,
                primaryIntent = UniversalIntent.META_COMMUNICATION,
                subIntents = listOf(UniversalIntent.CASUAL_CONVERSATION),
                targetRoute = SubsystemRoute.CONTEXT_ENGINE,
                plannedAnswerType = AnswerType.CASUAL_REPLY,
                detectedTopic = "Active Understanding Verification",
                detectedEntities = listOf("Active Listening", "Conversational Context"),
                isDharmaDomain = false,
                requiresClarification = false,
                targetLanguage = targetLanguage,
                isShortMessage = isShort,
                conversationDecision = ConversationDecision.CONTINUE_CONVERSATION,
                humanInterpretation = HumanInterpretation(
                    whatWasSaid = raw,
                    potentialMeaning = "User verifying if AI understood their intended meaning",
                    hasSufficientContext = true,
                    naturalResponseStyle = "Empathetic acknowledgment referencing active topic or inviting clarification",
                    detectedTone = tone,
                    epistemicType = EpistemicClassification.INTERPRETATION
                ),
                detectedTone = tone,
                epistemicType = EpistemicClassification.INTERPRETATION
            )
        }

        // 9f. Comparison Query ("What's the difference between these two?", "What is the difference between speed and velocity?")
        if (isComparisonQuery(lower)) {
            val isExplicitComparison = (lower.contains("difference between") && !lower.contains("these two") && !lower.contains("these")) ||
                    lower.contains(" vs ") || lower.contains(" and ") || lower.contains(" ও ") || lower.contains(" এবং ")
            val hasActiveTwo = (contextState.activeTopic != null && history.size >= 2) || isExplicitComparison
            val requiresClarify = !hasActiveTwo
            val clarifyQ = if (targetLanguage.contains("English", ignoreCase = true)) {
                "Which two subjects would you like to compare? Please mention both so I can provide an objective comparison."
            } else {
                "আপনি কোন দুটি বিষয়ের মধ্যে পার্থক্য জানতে চাচ্ছেন? দয়া করে নাম দুটি উল্লেখ করুন।"
            }
            val isScienceComp = lower.contains("speed") || lower.contains("velocity") || isScientificQuery(lower)
            return UniversalUnderstandingPlan(
                rawQuery = raw,
                normalizedQuery = normalized,
                messageForm = MessageForm.QUESTION,
                primaryIntent = if (requiresClarify) UniversalIntent.CLARIFICATION else UniversalIntent.COMPARISON,
                subIntents = listOf(UniversalIntent.COMPARISON),
                targetRoute = if (requiresClarify) SubsystemRoute.CLARIFICATION_ENGINE else if (isScienceComp) SubsystemRoute.SCIENCE else SubsystemRoute.GENERAL_KNOWLEDGE,
                plannedAnswerType = if (requiresClarify) AnswerType.CLARIFICATION_QUESTION else AnswerType.EXPLANATION,
                detectedTopic = if (isExplicitComparison) normalized else "Comparative Analysis",
                detectedEntities = listOf("Comparison", "Contrasting"),
                isDharmaDomain = false,
                requiresClarification = requiresClarify,
                clarificationQuestion = if (requiresClarify) clarifyQ else null,
                targetLanguage = targetLanguage,
                isShortMessage = isShort,
                conversationDecision = if (requiresClarify) ConversationDecision.CLARIFY else ConversationDecision.EXPLAIN,
                questionType = QuestionType.COMPARISON,
                humanInterpretation = HumanInterpretation(
                    whatWasSaid = raw,
                    potentialMeaning = "Request to compare two subjects",
                    hasSufficientContext = !requiresClarify,
                    naturalResponseStyle = if (requiresClarify) "Polite clarification asking for the two subjects" else "Objective comparative analysis",
                    requiresClarification = requiresClarify,
                    detectedTone = ConversationalEmotionTone.CURIOUS,
                    epistemicType = EpistemicClassification.FACT
                ),
                detectedTone = ConversationalEmotionTone.CURIOUS,
                epistemicType = EpistemicClassification.FACT
            )
        }

        // 10. Image Request ("Generate an image of a temple", "একটি ছবি তৈরি করো")
        if (isImageRequest(lower)) {
            val imageSubject = extractImageSubject(normalized)
            return UniversalUnderstandingPlan(
                rawQuery = raw,
                normalizedQuery = normalized,
                messageForm = MessageForm.COMMAND_REQUEST,
                primaryIntent = UniversalIntent.IMAGE_REQUEST,
                subIntents = listOf(UniversalIntent.CREATIVE_REQUEST),
                targetRoute = SubsystemRoute.IMAGE_ENGINE,
                plannedAnswerType = AnswerType.CREATIVE_OUTPUT,
                detectedTopic = imageSubject,
                detectedEntities = listOf("Image Prompt", imageSubject),
                isDharmaDomain = isDharmaTopic(imageSubject),
                requiresClarification = false,
                targetLanguage = targetLanguage,
                isShortMessage = isShort,
                conversationDecision = ConversationDecision.USE_TOOL,
                humanInterpretation = HumanInterpretation(
                    whatWasSaid = raw,
                    potentialMeaning = "Command to generate a visual image for $imageSubject",
                    hasSufficientContext = true,
                    naturalResponseStyle = "Image generator tool invocation"
                )
            )
        }

        // 11. Voice Request ("ভয়েসে বলো", "speak this")
        if (isVoiceRequest(lower)) {
            return UniversalUnderstandingPlan(
                rawQuery = raw,
                normalizedQuery = normalized,
                messageForm = MessageForm.COMMAND_REQUEST,
                primaryIntent = UniversalIntent.VOICE_REQUEST,
                subIntents = emptyList(),
                targetRoute = SubsystemRoute.VOICE_ENGINE,
                plannedAnswerType = AnswerType.DIRECT_ANSWER,
                detectedTopic = "Voice Reading",
                detectedEntities = listOf("Speech Synthesis"),
                isDharmaDomain = false,
                requiresClarification = false,
                targetLanguage = targetLanguage,
                isShortMessage = isShort,
                conversationDecision = ConversationDecision.USE_TOOL,
                humanInterpretation = HumanInterpretation(
                    whatWasSaid = raw,
                    potentialMeaning = "Request for text-to-speech audio reading",
                    hasSufficientContext = true,
                    naturalResponseStyle = "Voice tool activation"
                )
            )
        }

        // 11b. Summarization Request ("Summarize the water cycle in three points", "সারসংক্ষেপ করো")
        if (isSummarizationRequest(lower)) {
            val topic = extractGeneralSubject(normalized)
            return UniversalUnderstandingPlan(
                rawQuery = raw,
                normalizedQuery = normalized,
                messageForm = MessageForm.COMMAND_REQUEST,
                primaryIntent = UniversalIntent.SUMMARIZATION,
                subIntents = listOf(UniversalIntent.GENERAL_QUESTION),
                targetRoute = SubsystemRoute.GENERAL_KNOWLEDGE,
                plannedAnswerType = AnswerType.EXPLANATION,
                detectedTopic = topic,
                detectedEntities = listOf("Summarization", topic),
                isDharmaDomain = isDharmaTopic(lower),
                requiresClarification = false,
                targetLanguage = targetLanguage,
                isShortMessage = isShort,
                conversationDecision = ConversationDecision.SUMMARIZE,
                questionType = QuestionType.SUMMARIZATION,
                answerDepth = AnswerDepth.CONCISE,
                humanInterpretation = HumanInterpretation(
                    whatWasSaid = raw,
                    potentialMeaning = "Request to summarize topic in concise bullet points",
                    hasSufficientContext = true,
                    naturalResponseStyle = "Structured concise summary",
                    epistemicType = EpistemicClassification.FACT
                ),
                epistemicType = EpistemicClassification.FACT
            )
        }

        // 12. Translation Request ("Translate this into Bengali", "ইংরেজিতে অনুবাদ করো")
        if (isTranslationRequest(lower)) {
            val textToTranslate = extractTranslationTarget(normalized, history)
            return UniversalUnderstandingPlan(
                rawQuery = raw,
                normalizedQuery = normalized,
                messageForm = MessageForm.COMMAND_REQUEST,
                primaryIntent = UniversalIntent.TRANSLATION,
                subIntents = listOf(UniversalIntent.GENERAL_QUESTION),
                targetRoute = SubsystemRoute.TRANSLATION,
                plannedAnswerType = AnswerType.TRANSLATION,
                detectedTopic = textToTranslate,
                detectedEntities = listOf("Linguistic Translation"),
                isDharmaDomain = false,
                requiresClarification = false,
                targetLanguage = targetLanguage,
                isShortMessage = isShort,
                conversationDecision = ConversationDecision.USE_TOOL,
                humanInterpretation = HumanInterpretation(
                    whatWasSaid = raw,
                    potentialMeaning = "Language translation request",
                    hasSufficientContext = true,
                    naturalResponseStyle = "Linguistic translation tool invocation"
                )
            )
        }

        // 13. How-To Request ("How do I use this feature?", "কীভাবে ব্যবহার করব?")
        if (isHowToRequest(lower)) {
            val featureTopic = extractHowToTopic(normalized)
            return UniversalUnderstandingPlan(
                rawQuery = raw,
                normalizedQuery = normalized,
                messageForm = MessageForm.QUESTION,
                primaryIntent = UniversalIntent.HOW_TO_REQUEST,
                subIntents = listOf(UniversalIntent.GENERAL_QUESTION),
                targetRoute = SubsystemRoute.GENERAL_KNOWLEDGE,
                plannedAnswerType = AnswerType.STEP_BY_STEP_GUIDE,
                detectedTopic = featureTopic,
                detectedEntities = listOf("Feature Guide", featureTopic),
                isDharmaDomain = false,
                requiresClarification = false,
                targetLanguage = targetLanguage,
                isShortMessage = isShort,
                conversationDecision = ConversationDecision.EXPLAIN,
                humanInterpretation = HumanInterpretation(
                    whatWasSaid = raw,
                    potentialMeaning = "How-to user guide for app capabilities",
                    hasSufficientContext = true,
                    naturalResponseStyle = "Step-by-step helpful guide"
                )
            )
        }

        // 14. Writing / Creative Request ("Write a short message for my friend", "একটি চিঠি লেখো")
        if (isWritingRequest(lower)) {
            val writingSubject = extractWritingSubject(normalized)
            val isDharmaRelated = isDharmaTopic(writingSubject)
            return UniversalUnderstandingPlan(
                rawQuery = raw,
                normalizedQuery = normalized,
                messageForm = MessageForm.COMMAND_REQUEST,
                primaryIntent = UniversalIntent.WRITING_REQUEST,
                subIntents = listOf(UniversalIntent.CREATIVE_REQUEST),
                targetRoute = SubsystemRoute.WRITING_ENGINE,
                plannedAnswerType = AnswerType.CREATIVE_OUTPUT,
                detectedTopic = writingSubject,
                detectedEntities = listOf("Writing Composition", writingSubject),
                isDharmaDomain = isDharmaRelated,
                requiresClarification = false,
                targetLanguage = targetLanguage,
                isShortMessage = isShort,
                conversationDecision = ConversationDecision.CREATIVE_RESPONSE,
                humanInterpretation = HumanInterpretation(
                    whatWasSaid = raw,
                    potentialMeaning = "Request to compose a written piece on $writingSubject",
                    hasSufficientContext = true,
                    naturalResponseStyle = "Heartfelt creative composition"
                )
            )
        }

        // 15. Follow-Up Intent & Pronoun / Context Resolution ("Explain more", "Why?", "What does it mean?", "আরও বলো", "এটা কী?")
        val followUpType = detectFollowUp(lower, history, contextState)
        if (followUpType != null) {
            if (history.isNotEmpty()) {
                val activeTopic = contextState.activeTopic ?: history.lastOrNull()?.first?.take(50) ?: "পূর্ববর্তী আলোচনা"
                val wasDharma = contextState.activeDomain == "DHARMA" || isDharmaTopic(activeTopic)
                return UniversalUnderstandingPlan(
                    rawQuery = raw,
                    normalizedQuery = normalized,
                    messageForm = MessageForm.FOLLOW_UP,
                    primaryIntent = UniversalIntent.FOLLOW_UP,
                    subIntents = listOf(if (wasDharma) UniversalIntent.RELIGIOUS_QUESTION else UniversalIntent.GENERAL_QUESTION),
                    targetRoute = SubsystemRoute.CONTEXT_ENGINE,
                    plannedAnswerType = AnswerType.EXPLANATION,
                    detectedTopic = activeTopic,
                    detectedEntities = listOf("Context History", activeTopic),
                    isDharmaDomain = wasDharma,
                    requiresClarification = false,
                    targetLanguage = targetLanguage,
                    isShortMessage = isShort,
                    resolvedFollowUpSubject = activeTopic,
                    conversationDecision = ConversationDecision.EXPLAIN,
                    humanInterpretation = HumanInterpretation(
                        whatWasSaid = raw,
                        potentialMeaning = "Contextual follow-up inquiry referring to: $activeTopic",
                        hasSufficientContext = true,
                        naturalResponseStyle = "Contextual explanation on $activeTopic",
                        clarifiesPreviousTurn = true
                    )
                )
            } else {
                // Follow-up phrase asked WITHOUT any prior conversation history -> Ask polite clarification!
                val cleanLower = lower.trim().removeSuffix("?").removeSuffix("!").removeSuffix(".").removeSuffix("।").trim()
                val qClarify = when {
                    cleanLower.contains("why") || cleanLower.contains("কেন") -> "কোন বিষয়টি সম্পর্কে কারণ জানতে চাচ্ছেন? একটু বিস্তারিত বলুন।"
                    cleanLower.contains("how") || cleanLower.contains("কীভাবে") || cleanLower.contains("কিভাবে") -> "কোন বিষয়টি কীভাবে করতে বা জানতে চাচ্ছেন? একটু পরিষ্কার করে বলুন।"
                    cleanLower.contains("আরও বলো") || cleanLower.contains("আরো বলো") || cleanLower.contains("more") -> "কোন বিষয়টি সম্পর্কে আরও জানতে চান? একটু স্পষ্ট করে উল্লেখ করুন।"
                    cleanLower.contains("এটা কী") || cleanLower.contains("এটা কি") || cleanLower.contains("what is this") -> "আপনি কোন জিনিসটি বা বিষয়টি সম্পর্কে জানতে চাচ্ছেন? দয়া করে নামটি একটু উল্লেখ করুন।"
                    else -> "আপনি কোন বিষয়টি সম্পর্কে জানতে চাচ্ছেন? একটু নির্দিষ্ট করে বলুন।"
                }
                return UniversalUnderstandingPlan(
                    rawQuery = raw,
                    normalizedQuery = normalized,
                    messageForm = MessageForm.QUESTION,
                    primaryIntent = UniversalIntent.CLARIFICATION,
                    subIntents = emptyList(),
                    targetRoute = SubsystemRoute.CLARIFICATION_ENGINE,
                    plannedAnswerType = AnswerType.CLARIFICATION_QUESTION,
                    detectedTopic = "Vague Inquiry Requiring Context",
                    detectedEntities = listOf("Clarification Needed"),
                    isDharmaDomain = false,
                    requiresClarification = true,
                    clarificationQuestion = qClarify,
                    targetLanguage = targetLanguage,
                    isShortMessage = isShort,
                    ambiguityScore = 0.9f,
                    conversationDecision = ConversationDecision.CLARIFY,
                    humanInterpretation = HumanInterpretation(
                        whatWasSaid = raw,
                        potentialMeaning = "Vague follow-up without prior conversational context",
                        hasSufficientContext = false,
                        naturalResponseStyle = "Polite single request for topic context",
                        requiresClarification = true
                    )
                )
            }
        }

        // 16. Ambiguity Guardrail (e.g. "পূজা কীভাবে করব?" without specifying deity or context)
        val ambiguityCheck = checkAmbiguity(normalized, lower, contextState, history)
        if (ambiguityCheck.first) {
            return UniversalUnderstandingPlan(
                rawQuery = raw,
                normalizedQuery = normalized,
                messageForm = MessageForm.QUESTION,
                primaryIntent = UniversalIntent.CLARIFICATION,
                subIntents = listOf(UniversalIntent.RITUAL_QUESTION),
                targetRoute = SubsystemRoute.CLARIFICATION_ENGINE,
                plannedAnswerType = AnswerType.CLARIFICATION_QUESTION,
                detectedTopic = "Ambiguous Inquiry",
                detectedEntities = listOf("Clarification Needed"),
                isDharmaDomain = true,
                requiresClarification = true,
                clarificationQuestion = ambiguityCheck.second,
                targetLanguage = targetLanguage,
                isShortMessage = isShort,
                ambiguityScore = 0.95f,
                conversationDecision = ConversationDecision.CLARIFY,
                humanInterpretation = HumanInterpretation(
                    whatWasSaid = raw,
                    potentialMeaning = "Inquiry with missing parameters (e.g. unspecified deity)",
                    hasSufficientContext = false,
                    naturalResponseStyle = "Polite single disambiguation question",
                    requiresClarification = true
                )
            )
        }

        // 17. Science, Math, Tech, History, Simple Factual & General Knowledge Inquiries
        val isScience = isScientificQuery(lower)
        val isTech = isTechQuery(lower)
        val isMath = isMathConceptQuery(lower)
        val isHistory = isHistoryQuery(lower)
        val isFactual = isSimpleFactualQuery(lower)
        val isGeneral = isGeneralKnowledgeQuery(lower)

        if ((isScience || isTech || isMath || isHistory || isFactual || isGeneral) && !isDharmaTopic(lower)) {
            val intent = when {
                isScience -> UniversalIntent.SCIENTIFIC_QUESTION
                isTech -> UniversalIntent.TECHNOLOGY_QUESTION
                isMath -> UniversalIntent.MATHEMATICAL_QUESTION
                isHistory -> UniversalIntent.HISTORICAL_QUESTION
                isFactual -> UniversalIntent.FACTUAL_QUESTION
                else -> UniversalIntent.GENERAL_QUESTION
            }
            val targetRoute = when {
                isScience -> SubsystemRoute.SCIENCE
                isTech -> SubsystemRoute.TECHNOLOGY
                isMath -> SubsystemRoute.MATHEMATICS
                isHistory -> SubsystemRoute.HISTORY
                else -> SubsystemRoute.GENERAL_KNOWLEDGE
            }
            val qType = when {
                isScience -> QuestionType.SCIENTIFIC
                isTech || isMath -> QuestionType.TECHNICAL
                isHistory -> QuestionType.HISTORICAL
                isFactual -> QuestionType.FACTUAL
                else -> QuestionType.GENERAL
            }
            val depth = when {
                isFactual -> AnswerDepth.CONCISE
                else -> AnswerDepth.EXPLANATORY
            }
            val subject = extractGeneralSubject(normalized)
            return UniversalUnderstandingPlan(
                rawQuery = raw,
                normalizedQuery = normalized,
                messageForm = MessageForm.QUESTION,
                primaryIntent = intent,
                subIntents = listOf(UniversalIntent.GENERAL_QUESTION),
                targetRoute = targetRoute,
                plannedAnswerType = if (isFactual) AnswerType.DIRECT_ANSWER else AnswerType.EXPLANATION,
                detectedTopic = subject,
                detectedEntities = listOf("Empirical Knowledge", subject),
                isDharmaDomain = false,
                requiresClarification = false,
                targetLanguage = targetLanguage,
                isShortMessage = isShort,
                conversationDecision = ConversationDecision.EXPLAIN,
                questionType = qType,
                answerDepth = depth,
                answerConfidence = AnswerConfidence.HIGH,
                humanInterpretation = HumanInterpretation(
                    whatWasSaid = raw,
                    potentialMeaning = "Secular knowledge inquiry on $subject",
                    hasSufficientContext = true,
                    naturalResponseStyle = "Clear empirical explanation without religious bias"
                )
            )
        }

        // 18. Scripture, Mantra, Ritual & Dharma Questions ("What is Karma Yoga?", "What is the Bhagavad Gita?", "Tell me about Shiva")
        val isScripture = isScriptureQuery(lower)
        val isMantra = isMantraQuery(lower)
        val isRitual = isRitualQuery(lower)
        val isDharma = isDharmaTopic(lower) || isScripture || isMantra || isRitual

        val primaryIntent = when {
            isMantra -> UniversalIntent.MANTRA_QUESTION
            isScripture || isDharma -> UniversalIntent.RELIGIOUS_QUESTION
            isRitual -> UniversalIntent.RITUAL_QUESTION
            else -> UniversalIntent.GENERAL_QUESTION
        }

        val targetRoute = when {
            isMantra -> SubsystemRoute.MANTRA_VERIFICATION
            isScripture || isDharma || isRitual -> SubsystemRoute.DHARMA_KNOWLEDGE
            else -> SubsystemRoute.GENERAL_KNOWLEDGE
        }

        val subject = extractSubject(normalized)
        val qType = when {
            isMantra || isScripture || isRitual -> QuestionType.RELIGIOUS
            isDharma -> QuestionType.PHILOSOPHICAL
            else -> QuestionType.GENERAL
        }

        return UniversalUnderstandingPlan(
            rawQuery = raw,
            normalizedQuery = normalized,
            messageForm = MessageForm.QUESTION,
            primaryIntent = primaryIntent,
            subIntents = if (isDharma) listOf(UniversalIntent.RELIGIOUS_QUESTION) else listOf(UniversalIntent.GENERAL_QUESTION),
            targetRoute = targetRoute,
            plannedAnswerType = AnswerType.EXPLANATION,
            detectedTopic = subject,
            detectedEntities = listOf(subject),
            isDharmaDomain = isDharma,
            requiresClarification = false,
            targetLanguage = targetLanguage,
            isShortMessage = isShort,
            conversationDecision = if (isDharma) ConversationDecision.EXPLAIN else ConversationDecision.ANSWER,
            questionType = qType,
            answerDepth = AnswerDepth.EXPLANATORY,
            answerConfidence = AnswerConfidence.HIGH,
            humanInterpretation = HumanInterpretation(
                whatWasSaid = raw,
                potentialMeaning = if (isDharma) "Inquiry on Vedic, spiritual, or scriptural wisdom regarding $subject" else "General inquiry on $subject",
                hasSufficientContext = true,
                naturalResponseStyle = if (isDharma) "Authentic scriptural and philosophical explanation" else "Helpful answer"
            )
        )
    }

    // =========================================================================
    // DETECTION & CLASSIFICATION LOGIC
    // =========================================================================

    private fun normalizeQuery(raw: String): String {
        return raw.trim()
            .replace("\u00A0", " ") // Non-breaking spaces
            .replace("\\s+".toRegex(), " ")
    }

    private fun detectLanguage(raw: String): String {
        val hasBangla = raw.any { it in '\u0980'..'\u09FF' }
        val hasLatin = raw.any { it in 'a'..'z' || it in 'A'..'Z' }
        val hasDevanagari = raw.any { it in '\u0900'..'\u097F' }

        return when {
            hasDevanagari && !hasBangla -> "Sanskrit"
            hasBangla && hasLatin -> "Bengali + English (Mixed)"
            hasBangla -> "Bengali"
            else -> "English"
        }
    }

    private fun isShortMessage(normalized: String): Boolean {
        val words = normalized.split(" ").filter { it.isNotBlank() }
        return words.size <= 3
    }

    private fun detectMessageForm(normalized: String, lower: String, history: List<Pair<String, String>>): MessageForm {
        return when {
            isGreeting(lower) -> MessageForm.GREETING
            isFarewell(lower) -> MessageForm.FAREWELL
            isCasualConversation(lower) -> MessageForm.CASUAL_CONVERSATION
            lower.endsWith("?") || lower.endsWith("কী?") || lower.endsWith("কি?") || lower.startsWith("what") || lower.startsWith("who") || lower.startsWith("why") || lower.startsWith("how") -> MessageForm.QUESTION
            isWritingRequest(lower) || isImageRequest(lower) || lower.startsWith("generate") || lower.startsWith("write") -> MessageForm.COMMAND_REQUEST
            history.isNotEmpty() && (lower == "why?" || lower == "how?" || lower == "explain more" || lower == "আরও বলো") -> MessageForm.FOLLOW_UP
            else -> MessageForm.STATEMENT
        }
    }

    /**
     * Supports both English (0-9) and Bengali (০-৯) digits arithmetic:
     * Examples: "2+2 কত?", "২+২ কত?", "25 * 4", "100 / 5", "১৫ + ৩৫"
     */
    fun detectCalculation(normalized: String, lower: String): Pair<String, String>? {
        // Convert Bengali digits to ASCII digits
        val converted = normalized.map { char ->
            when (char) {
                '০' -> '0'
                '১' -> '1'
                '২' -> '2'
                '৩' -> '3'
                '৪' -> '4'
                '৫' -> '5'
                '৬' -> '6'
                '৭' -> '7'
                '৮' -> '8'
                '৯' -> '9'
                else -> char
            }
        }.joinToString("")

        val clean = converted.lowercase(Locale.ROOT)
            .replace("?", "")
            .replace("কত", "")
            .replace("calculate", "")
            .replace("what is", "")
            .replace("হিসাব করো", "")
            .replace("মান কত", "")
            .replace("যোগফল কত", "")
            .replace("গুণফল কত", "")
            .replace("সমাধান করো", "")
            .trim()

        val mathRegex = "^([0-9]+(?:\\.[0-9]+)?)\\s*([+\\-*×/÷x])\\s*([0-9]+(?:\\.[0-9]+)?)$".toRegex()
        val match = mathRegex.find(clean) ?: return null

        val num1 = match.groupValues[1].toDoubleOrNull() ?: return null
        val rawOp = match.groupValues[2]
        val num2 = match.groupValues[3].toDoubleOrNull() ?: return null

        val op = when (rawOp) {
            "+", "যোগ" -> "+"
            "-", "বিয়োগ" -> "-"
            "*", "×", "x", "গুণ" -> "*"
            "/", "÷", "ভাগ" -> "/"
            else -> return null
        }

        val result = when (op) {
            "+" -> num1 + num2
            "-" -> num1 - num2
            "*" -> num1 * num2
            "/" -> if (num2 != 0.0) num1 / num2 else Double.NaN
            else -> return null
        }

        val formattedResult = if (result % 1.0 == 0.0 && !result.isNaN()) result.toLong().toString() else result.toString()
        val expression = "${match.groupValues[1]} $op ${match.groupValues[3]}"

        val bnAnswer = "গাণিতিক হিসাবের ফলাফল:\n$expression = $formattedResult"
        val enAnswer = "Mathematical calculation result:\n$expression = $formattedResult"

        val isEnglish = normalized.any { it in 'a'..'z' || it in 'A'..'Z' }
        val finalAnswer = if (isEnglish) enAnswer else bnAnswer
        return expression to finalAnswer
    }

    private fun isGreeting(q: String): Boolean {
        val trimmed = q.trim().removeSuffix("?").removeSuffix("!").trim()
        val exactGreetings = listOf(
            "hi", "hello", "hey", "হাই", "হ্যালো", "নমস্কার", "নমস্তে", "namaste",
            "good morning", "good evening", "good afternoon", "শুভ সকাল", "শুভ সন্ধ্যা", "শুভ অপরাহ্ন"
        )
        return exactGreetings.contains(trimmed) ||
                exactGreetings.any { trimmed.startsWith("$it ") && !isDharmaTopic(trimmed) && !trimmed.contains("shiva") && !trimmed.contains("gita") }
    }

    private fun isFarewell(q: String): Boolean {
        val trimmed = q.trim().removeSuffix("?").removeSuffix("!").trim()
        val farewells = listOf("bye", "goodbye", "বিদায়", "আবার দেখা হবে", "ভালো থেকো", "take care", "good night", "শুভ রাত্রি")
        return farewells.contains(trimmed)
    }

    private fun isCasualConversation(q: String): Boolean {
        val trimmed = q.trim().removeSuffix("?").removeSuffix("!").removeSuffix("।").trim()
        val casualTokens = listOf(
            "কেমন আছ", "কেমন আছো", "কেমন আছেন", "how are you", "how are you doing",
            "কী খবর", "কি খবর", "what's up", "সব ঠিক আছে", "সবকিছু ঠিক আছে",
            "ধন্যবাদ", "thanks", "thank you", "অনেক ধন্যবাদ", "ok", "okay", "alright", "fine", "ঠিক আছে",
            "হুম", "হু", "হুমম", "hmm", "hm",
            "আচ্ছা", "আচ্ছা ঠিক আছে",
            "বুঝলাম", "understood", "i see", "got it",
            "ওহ", "ও", "oh",
            "সত্যি?", "সত্যি", "সত্যিই?", "really",
            "তাই নাকি?", "তাই নাকি", "তাই?", "is that so",
            "শুনছ?", "শুনছ", "শুনছো?", "শুনছো", "শুনছেন?", "শুনছেন", "can you hear me", "are you listening",
            "হ্যাঁ", "হাঁ", "না", "yes", "no", "great", "দারুণ", "ভালো"
        )
        return casualTokens.contains(trimmed)
    }

    fun detectTypoOrGibberish(raw: String, normalized: String, lower: String): Boolean {
        val clean = lower.trim().removeSuffix("?").removeSuffix("!").removeSuffix(".").removeSuffix("।").trim()
        if (clean.isBlank()) return true

        // 1. Keyboard mashes
        val keyboardMashes = setOf(
            "asdf", "asdfg", "asdfgh", "asdfghj", "asdfghjkl",
            "qwer", "qwert", "qwerty", "qwertyu", "qwertyuiop",
            "zxcv", "zxcvb", "zxcvbn", "zxcvbnm",
            "hjkl", "lkjh", "dfgh", "ghjk", "qaz", "wsx", "edc", "rfv", "tgb", "yhn", "ujm"
        )
        if (keyboardMashes.contains(clean)) return true

        // 2. Standalone digits (e.g., "123", "456", "১২৩৪") without math operators or question words
        val isDigitsOnly = clean.all { it.isDigit() || it in '০'..'৯' }
        if (isDigitsOnly && clean.length in 1..10) {
            return true
        }

        // 3. Short consonant-only English tokens (e.g. "jg", "bvc", "zxc", "ghj", "xyz")
        val isPureEnglishLetters = clean.all { it in 'a'..'z' }
        if (isPureEnglishLetters && clean.length in 2..6) {
            val knownValidWordsOrAcronyms = setOf(
                "ok", "hi", "tv", "ai", "id", "am", "pm", "dr", "mr", "ms", "vs", "kg", "km", "cm", "mm",
                "gb", "mb", "kb", "tb", "om", "pc", "dj", "cd", "dvd", "usb", "atm", "gps", "dna", "rna",
                "cpu", "gpu", "ram", "rom", "sim", "pin", "vip", "sos", "sms", "app", "faq", "url", "api",
                "sdk", "ui", "ux", "os", "ip", "it", "is", "in", "on", "at", "to", "go", "no", "so", "do",
                "we", "he", "me", "my", "by", "up", "if", "as", "an", "or", "ox", "ex"
            )
            val vowels = setOf('a', 'e', 'i', 'o', 'u', 'y')
            val hasVowel = clean.any { it in vowels }
            if (!hasVowel && !knownValidWordsOrAcronyms.contains(clean)) {
                return true
            }
        }

        // 4. Repeated single characters (e.g., "aaa", "zzzz", "kkk")
        if (clean.length >= 2 && clean.all { it == clean[0] } && clean != "হুম") {
            return true
        }

        return false
    }

    fun generateTypoClarification(raw: String, normalized: String, lower: String): String {
        val clean = lower.trim().removeSuffix("?").removeSuffix("!").removeSuffix(".").removeSuffix("।").trim()
        val isDigitsOnly = clean.all { it.isDigit() || it in '০'..'৯' }
        return if (isDigitsOnly) {
            "‘$raw’ বলতে কি কোনো নির্দিষ্ট সংখ্যা বা হিসাব বোঝাতে চেয়েছেন? একটু পরিষ্কার করে লিখবেন?"
        } else {
            "‘$raw’ বলতে কি কিছু নির্দিষ্ট বোঝাতে চেয়েছেন? একটু পরিষ্কার করে লিখবেন?"
        }
    }

    fun isJokeRequest(q: String): Boolean {
        val trimmed = q.trim().removeSuffix(".").removeSuffix("?").removeSuffix("!").lowercase(Locale.ROOT)
        val jokeKeywords = listOf(
            "tell me a joke", "tell a joke", "make me laugh", "say a joke", "joke বলো",
            "একটি কৌতুক বলো", "একটি জোকস বলো", "কৌতুক বলো", "জোকস বলো", "কৌতুক শোনাও", "জোকস শোনাও", "একটি কৌতুক শোনাও",
            "joke"
        )
        return trimmed in jokeKeywords || jokeKeywords.any { trimmed.startsWith(it) || (trimmed.contains("joke") && (trimmed.contains("tell") || trimmed.contains("say") || trimmed.contains("বলো"))) }
    }

    fun detectEmotionTone(normalized: String, lower: String): ConversationalEmotionTone {
        return when {
            // Happy / Excited
            lower.contains("ভালো লাগছে") || lower.contains("ভাল লাগছে") || lower.contains("খুব খুশি") ||
                    lower.contains("আনন্দ লাগছে") || lower.contains("দারুণ") || lower.contains("দারুন") ||
                    lower.contains("feeling great") || lower.contains("very happy") || lower.contains("so happy") ||
                    lower.contains("excited") || lower.contains("wonderful day") -> ConversationalEmotionTone.HAPPY

            // Confused
            lower.contains("confused") || lower.contains("বিভ্রান্ত") || lower.contains("বুঝতে পারছি না") ||
                    lower.contains("বুঝতে পারলাম না") || lower.contains("দ্বিধায়") || lower.contains("দ্বিধা") ||
                    lower.contains("not sure") || lower.contains("don't understand") || lower.contains("can't understand") -> ConversationalEmotionTone.CONFUSED

            // Sad / Worried
            lower.contains("হতাশ") || lower.contains("মন খারাপ") || lower.contains("খারাপ লাগছে") || lower.contains("কষ্ট হচ্ছে") ||
                    lower.contains("ভয় লাগছে") || lower.contains("চিন্তায় আছি") || lower.contains("উদ্বিগ্ন") ||
                    lower.contains("sad") || lower.contains("feeling down") || lower.contains("worried") ||
                    lower.contains("anxious") -> ConversationalEmotionTone.SAD

            // Frustrated
            lower.contains("বিরক্ত") || lower.contains("frustrated") || lower.contains("annoyed") -> ConversationalEmotionTone.FRUSTRATED

            // Curious
            lower.contains("something interesting") || lower.contains("মজার তথ্য") || lower.contains("কৌতূহল") ||
                    lower.contains("জানতে চাই") || lower.contains("curious") -> ConversationalEmotionTone.CURIOUS

            // Playful
            isJokeRequest(lower) || lower.contains("মজা") || lower.contains("playful") || lower.contains("funny") -> ConversationalEmotionTone.PLAYFUL

            // Serious
            lower.contains("ভুল বোঝাবুঝি") || lower.contains("মৃত্যু") || lower.contains("সম্মানের সঙ্গে") ||
                    lower.contains("ethics") || lower.contains("গম্ভীর") -> ConversationalEmotionTone.SERIOUS

            else -> ConversationalEmotionTone.NEUTRAL
        }
    }

    fun isSummarizationRequest(q: String): Boolean {
        val lower = q.lowercase(Locale.ROOT)
        return lower.contains("summarize") || lower.contains("summary") ||
                lower.contains("সারসংক্ষেপ") || lower.contains("সংক্ষেপে বলো") ||
                lower.contains("সংক্ষেপে বলুন") || lower.contains("সারমর্ম")
    }

    fun isRelationshipQuery(q: String): Boolean {
        return q.contains("বন্ধুর সাথে") || q.contains("বন্ধুত্ব") || q.contains("ভুল বোঝাবুঝি") ||
                q.contains("কাউকে পছন্দ") || q.contains("পছন্দ করলে") || q.contains("সম্মানের সঙ্গে কথা") ||
                q.contains("সম্মানের সাথে কথা") || q.contains("like someone") || q.contains("crush") ||
                q.contains("talk to someone i like") || q.contains("misunderstanding with") ||
                q.contains("friendship") || q.contains("healthy boundaries") || q.contains("ব্রেকআপ") ||
                q.contains("breakup") || (q.contains("সম্পর্ক") && (q.contains("সমস্যা") || q.contains("কথা")))
    }

    fun isEmotionalSharing(q: String): Boolean {
        return q.contains("ভালো লাগছে") || q.contains("ভাল লাগছে") || q.contains("খুব খুশি") ||
                q.contains("আনন্দ লাগছে") || q.contains("confused") || q.contains("বিভ্রান্ত") ||
                q.contains("বুঝতে পারছি না") || q.contains("বুঝতে পারলাম না") || q.contains("মন খারাপ") ||
                q.contains("খারাপ লাগছে") || q.contains("feeling great") || q.contains("i feel") ||
                q.contains("i'm confused") || q.contains("দ্বিধায়") || q.contains("হতাশ") ||
                q.contains("কষ্ট হচ্ছে") || q.contains("উদ্বিগ্ন")
    }

    fun isOpinionRequest(q: String): Boolean {
        val trimmed = q.trim().removeSuffix("?").removeSuffix("।").trim()
        val exactOpinion = listOf(
            "তুমি কী মনে কর", "তুমি কি মনে কর", "তুমি কী মনে করো", "তুমি কি মনে করো",
            "তোমার কী মনে হয়", "তোমার কি মনে হয়", "তোমার মতামত কী", "তোমার অভিমত কী",
            "what do you think", "what is your opinion", "what's your opinion", "what is your take"
        )
        return exactOpinion.contains(trimmed) || exactOpinion.any { trimmed.startsWith(it) }
    }

    fun isCuriosityPrompt(q: String): Boolean {
        val curiosityPhrases = listOf(
            "tell me something interesting", "tell me something cool", "tell me a fun fact",
            "একটি মজার তথ্য বলো", "একটি মজার তথ্য বল", "মজার কিছু বলো", "আকর্ষণীয় কিছু বলো",
            "আকর্ষণীয় কিছু বলো", "কিছু আকর্ষণীয় বিষয় বলো", "কিছু মজার তথ্য বলো"
        )
        val trimmed = q.trim().removeSuffix(".").removeSuffix("!").trim()
        return curiosityPhrases.contains(trimmed) || curiosityPhrases.any { trimmed.startsWith(it) }
    }

    fun isMetaCommunication(q: String): Boolean {
        val metaPhrases = listOf(
            "আমি কী বলতে চেয়েছি বুঝেছ", "আমি কি বলতে চেয়েছি বুঝেছ", "আমি কী বলতে চেয়েছি বুঝেছ",
            "তুমি কি বুঝতে পেরেছ", "তুমি কি বুঝতে পেরেছো", "তুমি কি বুঝলে", "বুঝেছ",
            "did you understand what i meant", "do you understand what i meant",
            "did you get my point", "do you understand me"
        )
        val trimmed = q.trim().removeSuffix("?").removeSuffix("।").trim()
        return metaPhrases.contains(trimmed) || metaPhrases.any { trimmed.startsWith(it) }
    }

    fun isComparisonQuery(q: String): Boolean {
        val compPhrases = listOf(
            "what's the difference between these two", "what is the difference between these two",
            "difference between these two", "whats the difference between these two",
            "এই দুটির মধ্যে পার্থক্য কী", "এই দুটোর মধ্যে পার্থক্য কি", "এই দুটির পার্থক্য কী",
            "এই দুটোর পার্থক্য কি", "দুটির মধ্যে পার্থক্য কী"
        )
        val trimmed = q.trim().removeSuffix("?").removeSuffix("।").trim()
        return compPhrases.contains(trimmed) || compPhrases.any { trimmed.startsWith(it) } ||
                trimmed.contains("difference between") || trimmed.contains("পার্থক্য কী") || trimmed.contains("পার্থক্য কি") ||
                trimmed.contains(" vs ")
    }

    private fun isCreatorInquiry(q: String): Boolean {
        return q.contains("কে বানিয়েছে") || q.contains("কে তৈরি করেছে") || q.contains("কে বানিয়েছে") ||
                q.contains("কে বানাইছে") || q.contains("নির্মাতা কে") || q.contains("creator কে") ||
                q.contains("who created you") || q.contains("who made you") || q.contains("who is your creator") ||
                q.contains("who built you") || q.contains("who developed you") || q.contains("your creator") ||
                q.contains("মিলন চন্দ্র") || q.contains("milon chandra")
    }

    private fun isImageRequest(q: String): Boolean {
        return q.startsWith("generate an image") || q.startsWith("create an image") ||
                q.startsWith("draw an image") || q.startsWith("draw a picture") ||
                q.contains("একটি ছবি তৈরি করো") || q.contains("একটি ছবি আঁকো") ||
                q.contains("একটি ছবি বানাও") || q.contains("ছবি তৈরি করো") ||
                q.contains("চিত্র তৈরি করো") || q.contains("generate image of") ||
                q.contains("create image of")
    }

    private fun extractImageSubject(raw: String): String {
        var clean = raw.trim()
        val prefixes = listOf(
            "Generate an image of a ", "Generate an image of ", "Generate an image ",
            "Create an image of a ", "Create an image of ", "Create an image ",
            "Draw a picture of a ", "Draw a picture of ", "Draw an image of ",
            "একটি ছবি তৈরি করো ", "একটি ছবি বানাও ", "একটি ছবি আঁকো ", "ছবি তৈরি করো "
        )
        for (p in prefixes) {
            clean = clean.replace(p, "", ignoreCase = true)
        }
        return clean.trim().ifBlank { "a sacred temple" }
    }

    private fun isVoiceRequest(q: String): Boolean {
        return q.contains("ভয়েসে বলো") || q.contains("ভয়েস চালু করো") || q.contains("পড়ে শোনাও") ||
                q.contains("speak this") || q.contains("read aloud") || q.contains("voice on")
    }

    private fun isTranslationRequest(q: String): Boolean {
        return (q.contains("translate") && (q.contains("bengali") || q.contains("bangla") || q.contains("english") || q.contains("into") || q.contains("to") || q.contains("'") || q.contains("\""))) ||
                q.contains("অনুবাদ") || q.contains("রূপান্তর করো") || q.contains("বাংলায় অর্থ") || q.contains("ইংরেজিতে অর্থ")
    }

    private fun extractTranslationTarget(raw: String, history: List<Pair<String, String>>): String {
        val quoteRegex = "['\"‘“]([^'\"’”]+)['\"’”]".toRegex()
        val quoteMatch = quoteRegex.find(raw)
        if (quoteMatch != null) {
            return quoteMatch.groupValues[1].trim()
        }
        val colonSplit = raw.split(":")
        if (colonSplit.size > 1 && colonSplit[1].isNotBlank()) {
            return colonSplit[1].trim()
        }
        return history.lastOrNull()?.second?.take(100) ?: "Good morning"
    }

    private fun isHowToRequest(q: String): Boolean {
        return q.contains("how do i use this feature") || q.contains("how to use this app") ||
                q.contains("how do i use this app") || q.contains("কীভাবে ব্যবহার করব") ||
                q.contains("কিভাবে ব্যবহার করব") || q.contains("এই ফিচারটি কীভাবে ব্যবহার করব") ||
                q.contains("how to use this feature") || q.contains("অ্যাপ কীভাবে ব্যবহার করব") ||
                q.contains("মনোযোগ বাড়ানো যায়") || q.contains("মনোযোগ বাড়ানো যায়") ||
                q.contains("মনোযোগ বাড়ানো") || q.contains("পড়াশোনায়") ||
                q.contains("how can i focus") || q.contains("focus better")
    }

    private fun extractHowToTopic(raw: String): String {
        return when {
            raw.contains("মনোযোগ", ignoreCase = true) || raw.contains("focus", ignoreCase = true) -> "মনোযোগ বৃদ্ধি ও পড়াশোনার কৌশল"
            raw.contains("feature", ignoreCase = true) || raw.contains("ফিচার", ignoreCase = true) -> "VedaNova AI App Features & Navigation"
            else -> "VedaNova AI Guide"
        }
    }

    private fun isWritingRequest(q: String): Boolean {
        val writingKeywords = listOf(
            "write a short message for my friend", "write a message for my friend", "write a message to my friend",
            "write a short message", "write a letter", "write an email", "একটি চিঠি লেখো", "বন্ধুর জন্য একটি বার্তা লেখো",
            "একটি বার্তা লেখো", "একটি কবিতা লেখো", "একটি গল্প লেখো", "একটি প্রবন্ধ লেখো", "compose an essay",
            "write a poem", "write a story"
        )
        return writingKeywords.any { q.contains(it) } ||
                (q.startsWith("write ") && !q.contains("code") && !q.contains("query")) ||
                (q.contains("লেখো") && (q.contains("বার্তা") || q.contains("চিঠি") || q.contains("মেসেজ")))
    }

    private fun extractWritingSubject(raw: String): String {
        var clean = raw.trim()
        val removePrefixes = listOf(
            "Write a short message for my friend", "Write a short message for ", "Write a message for my friend",
            "Write a message to my friend", "Write an email to ", "Write a letter to ",
            "বন্ধুর জন্য একটি বার্তা লেখো", "একটি বার্তা লেখো", "একটি চিঠি লেখো", "একটি কবিতা লেখো"
        )
        for (p in removePrefixes) {
            clean = clean.replace(p, "", ignoreCase = true)
        }
        return clean.trim().ifBlank { "A warm message for a cherished friend" }
    }

    private fun detectFollowUp(q: String, history: List<Pair<String, String>>, contextState: ConversationContextState): String? {
        val trimmed = q.trim().removeSuffix("?").removeSuffix(".").removeSuffix("।").lowercase(Locale.ROOT)
        return when {
            trimmed in listOf("why", "কেন", "কেন এমন") -> "WHY"
            trimmed in listOf("how", "কীভাবে", "কিভাবে", "কীভাবে করব", "কিভাবে করব", "how can i practice it", "how to practice it") -> "HOW"
            trimmed in listOf("explain more", "আরও বলো", "আরো বলো", "বিস্তারিত বলো", "tell me more") -> "EXPLAIN_MORE"
            trimmed in listOf("what does it mean", "what does that mean", "এটার মানে কী", "এর মানে কী", "মানে কী") -> "WHAT_DOES_IT_MEAN"
            trimmed in listOf("এটা কী", "এটা কি", "what is this", "what is it") -> "WHAT_IS_THIS"
            trimmed in listOf("what about this", "তাহলে এটা") -> "WHAT_ABOUT_THIS"
            trimmed.contains("আগেরটা") || trimmed.contains("previous point") -> "PREVIOUS_POINT"
            else -> null
        }
    }

    /**
     * Ambiguity check: e.g. "পূজা কীভাবে করব?" without specifying deity or context
     */
    private fun checkAmbiguity(
        raw: String,
        lower: String,
        contextState: ConversationContextState,
        history: List<Pair<String, String>>
    ): Pair<Boolean, String?> {
        val isPujaGeneral = (lower == "পূজা কীভাবে করব?" || lower == "পূজা কিভাবে করব?" ||
                lower == "পূজা কীভাবে করব" || lower == "how to do puja" || lower == "how to perform puja")
        if (isPujaGeneral && contextState.activeDeity == null && history.isEmpty()) {
            return true to "কোন পূজার কথা বলছেন—শিব পূজা, দুর্গা পূজা, নাকি অন্য কোনো পূজা?"
        }
        return false to null
    }

    private fun isScientificQuery(q: String): Boolean {
        val scienceKeywords = listOf(
            "gravity", "মহাকর্ষ", "অভিকর্ষ", "photosynthesis", "সালোকসংশ্লেষণ",
            "solar system", "সৌরজগৎ", "speed of light", "আলোর গতি", "water cycle", "পানি চক্র",
            "atom", "পরমাণু", "dna", "ডিএনএ", "relativity", "আপেক্ষিকতা", "cell", "কোষ",
            "planet", "গ্রহ", "black hole", "ব্ল্যাকহোল",
            "airplane", "aeroplane", "aerodynamics", "fly", "flight", "wings", "lift", "উড়োজাহাজ", "বিমান",
            "গাছের পাতা", "পাতা কেন সবুজ", "পাতা সবুজ", "leaves change color", "why do leaves", "leaf", "leaves",
            "speed and velocity", "speed", "velocity", "দ্রুতি", "গতি ও বেগ",
            "বিজ্ঞান", "science", "physics", "পদার্থবিজ্ঞান", "chemistry", "রসায়ন", "biology", "জীববিজ্ঞান",
            "einstein", "আইনস্টাইন", "albert einstein", "newton", "নিউটন", "galileo", "গ্যালিলিও"
        )
        return scienceKeywords.any { q.contains(it) }
    }

    private fun isTechQuery(q: String): Boolean {
        val techKeywords = listOf(
            "computer", "কম্পিউটার", "artificial intelligence", "কৃত্রিম বুদ্ধিমত্তা",
            "machine learning", "neural network", "internet", "ইন্টারনেট", "algorithm", "অ্যালগরিদম",
            "programming", "software", "database"
        )
        return techKeywords.any { q.contains(it) }
    }

    private fun isGeneralKnowledgeQuery(q: String): Boolean {
        val generalKeywords = listOf(
            "capital of", "রাজধানী", "world war", "দ্বিতীয় বিশ্বযুদ্ধ", "mountain", "পাহাড়",
            "river", "নদী", "pythagoras", "পাইথাগোরাস", "prime number", "মৌলিক সংখ্যা"
        )
        return generalKeywords.any { q.contains(it) }
    }

    private fun isScriptureQuery(q: String): Boolean {
        val scriptures = listOf(
            "bhagavad gita", "gita", "গীতা", "শ্রীমদ্ভগবদ্গীতা", "বেদ", "veda", "vedas",
            "উপনিষদ", "upanishad", "upanishads", "রামায়ণ", "ramayana", "মহাভারত", "mahabharata",
            "পুরাণ", "purana", "puranas", "ভাগবত", "bhagavata"
        )
        return scriptures.any { q.contains(it) }
    }

    private fun isMantraQuery(q: String): Boolean {
        val mantras = listOf("মন্ত্র", "mantra", "স্তোত্র", "stotra", "শ্লোক", "shloka", "গায়ত্রী", "gayatri", "মহমৃত্যুঞ্জয়", "mahamrityunjaya")
        return mantras.any { q.contains(it) }
    }

    private fun isRitualQuery(q: String): Boolean {
        val rituals = listOf("পূজা", "puja", "তিথি", "tithi", "একাদশী", "ekadashi", "ব্রত", "ব্রতকথা", "panjika", "পঞ্জিকা", "shivaratri", "শিবরাত্রি", "diwali", "দীপাবলি")
        return rituals.any { q.contains(it) }
    }

    private fun isDharmaTopic(q: String): Boolean {
        val dharmaKeywords = listOf(
            "karma yoga", "কর্মযোগ", "কর্ম যোগ", "karma", "কর্ম", "dharma", "ধর্ম", "moksha", "মোক্ষ",
            "shiva", "শিব", "krishna", "কৃষ্ণ", "rama", "রাম", "vishnu", "বিষ্ণু", "durga", "দুর্গা",
            "kali", "কালী", "ganesha", "গণেশ", "saraswati", "সরস্বতী", "lakshmi", "লক্ষ্মী", "hanuman", "হনুমান",
            "gita", "গীতা", "veda", "বেদ", "upanishad", "উপনিষদ", "advaita", "অদ্বৈত", "brahman", "ব্রহ্ম",
            "atman", "আত্মা", "bhakti", "ভক্তি", "yoga", "যোগ", "temple", "মন্দির"
        )
        return dharmaKeywords.any { q.contains(it) }
    }

    private fun extractGeneralSubject(raw: String): String {
        var clean = raw.trim()
        val removePrefixes = listOf(
            "what is the ", "what is ", "what are ", "who was ", "who is ", "tell me about ",
            "কী?", "কি?", "কাকে বলে?", "বলতে কী বোঝায়?", "বলতে কি বুঝায়?"
        )
        for (p in removePrefixes) {
            clean = clean.replace(p, "", ignoreCase = true)
        }
        return clean.trim().ifBlank { "Scientific & General Inquiry" }
    }

    private fun extractSubject(raw: String): String {
        var clean = raw.trim()
        val removePrefixes = listOf(
            "what is the ", "what is ", "what are ", "who was ", "who is ", "tell me about ",
            "explain about ", "explain ", "কী?", "কি?", "সম্পর্কে বলো", "সম্পর্কে বলুন", "কাকে বলে?"
        )
        for (p in removePrefixes) {
            clean = clean.replace(p, "", ignoreCase = true)
        }
        return clean.trim().ifBlank { "Sanatana Dharma Wisdom" }
    }

    // =========================================================================
    // STEP 9 HELPER FUNCTIONS & CLASSIFIERS
    // =========================================================================

    data class MultiPartDecomposition(
        val primaryIntent: UniversalIntent,
        val targetRoute: SubsystemRoute,
        val questionType: QuestionType,
        val decomposedParts: List<String>
    )

    fun isUserCorrection(lower: String): Boolean {
        val clean = lower.trim().removeSuffix("?").removeSuffix("!").removeSuffix("।").removeSuffix(".").trim()
        val correctionPhrases = listOf(
            "তুমি ভুল বলেছ", "তুমি ভুল বলছ", "তুমি ভুল বলেছো", "এটা ভুল", "আপনার উত্তর ভুল",
            "ভুল বলেছ", "ভুল তথ্য", "সঠিক নয়", "you are wrong", "your answer is wrong",
            "that is wrong", "that is incorrect", "this is wrong", "that's wrong",
            "you made a mistake", "it is incorrect", "ভুল হয়েছে"
        )
        return correctionPhrases.any { clean == it || clean.startsWith("$it ") || clean.endsWith(" $it") }
    }

    fun detectBanglish(lower: String): String? {
        val clean = lower.trim().removeSuffix("?").removeSuffix("!").removeSuffix(".").trim()
        return when {
            clean == "gita ki" -> "গীতা কী?"
            clean == "kormo ki" || clean == "karma ki" -> "কর্ম কী?"
            clean == "dhormo ki" || clean == "dharma ki" -> "ধর্ম কী?"
            clean == "kemon acho" || clean == "kemon aso" || clean == "kemon achen" -> "কেমন আছো?"
            clean == "ami valo achi" || clean == "ami bhalo achi" -> "আমি ভালো আছি"
            clean == "dhonnobad" || clean == "dhonnbad" -> "ধন্যবাদ"
            clean == "namaskar" || clean == "nomoshkar" -> "নমস্কার"
            clean == "shuvo shokal" || clean == "suvo sokal" -> "শুভ সকাল"
            clean == "ki khobor" -> "কী খবর?"
            else -> null
        }
    }

    fun checkFalsePremise(normalized: String, lower: String): String? {
        val clean = lower.trim().removeSuffix("?").removeSuffix(".").trim()
        return when {
            clean.contains("সূর্য কেন পৃথিবীর চারদিকে ঘোরে") || clean.contains("সূর্য কি পৃথিবীর চারদিকে ঘোরে") ||
                    clean.contains("why does the sun revolve around the earth") -> {
                "প্রকৃতপক্ষে সূর্য পৃথিবীর চারদিকে ঘোরে না। আধুনিক জ্যোতির্বিজ্ঞান ও সৌরকেন্দ্রিক তত্ত্ব (Heliocentrism) অনুযায়ী, সৌরজগতের কেন্দ্রে রয়েছে সূর্য, এবং পৃথিবী ও অন্যান্য গ্রহ সূর্যের চারদিকে নিজ নিজ উপবৃত্তাকার কক্ষপথে আবর্তন করে। পৃথিবী নিজের অক্ষে ২৪ ঘণ্টায় একবার আবর্তন করার কারণে আমাদের দৃষ্টিতে সূর্যকে পূর্ব থেকে পশ্চিমে চলমান মনে হয়।"
            }
            clean.contains("আইনস্টাইন কি গীতা") || clean.contains("আইনস্টাইন গীতা লিখেছেন") ||
                    clean.contains("did einstein write the bhagavad gita") || clean.contains("did einstein write gita") -> {
                "না, অ্যালবার্ট আইনস্টাইন শ্রীমদ্ভগবদ্গীতা লেখেননি। শ্রীমদ্ভগবদ্গীতা হলো প্রাচীন ভারতীয় মহাকাব্য মহাভারতের ভীষ্ম পর্বের অংশ, যার প্রবক্তা ভগবান শ্রীকৃষ্ণ এবং সংকলক মহর্ষি কৃষ্ণদ্বৈপায়ন বেদব্যাস। অপরদিকে অ্যালবার্ট আইনস্টাইন ছিলেন বিংশ শতাব্দীর (১৮৭৯–১৯৫৫) প্রখ্যাত তাত্ত্বিক পদার্থবিজ্ঞানী যিনি আপেক্ষিকতা তত্ত্বের জনক।"
            }
            clean.contains("মানুষ কি চাঁদে বাস করে") || clean.contains("চাঁদে বাতাস কেমন") -> {
                "প্রকৃতপক্ষে চাঁদে কোনো বায়ুমণ্ডল বা শ্বাসগ্রহণের উপযোগী বাতাস নেই। চাঁদ একটি শুষ্ক ও বাতাসহীন উপগ্রহ, যেখানে প্রচণ্ড তাপমাত্রা ওঠানামা করে। মানুষ সেখানে স্থায়ীভাবে বসবাস করে না; কেবল ১৯৬৯ থেকে ১৯৭২ সালের অ্যাপোলো অভিযানের মাধ্যমে নভোচারীগণ বৈজ্ঞানিক অনুসন্ধানের জন্য সাময়িক অবতরণ করেছিলেন।"
            }
            else -> null
        }
    }

    fun checkRequiresCurrentInfo(normalized: String, lower: String): String? {
        val clean = lower.trim().removeSuffix("?").removeSuffix(".").trim()
        return when {
            clean.contains("সোনার দাম") || clean.contains("gold price") -> "আজকের সোনার বাজারদর (Live Gold Price)"
            clean.contains("আজকের আবহাওয়া") || clean.contains("আজকের আবহাওয়া") || clean.contains("today's weather") || clean.contains("current weather") -> "বর্তমান আবহাওয়া বার্তা (Current Weather)"
            clean.contains("আজকের খবর") || clean.contains("আজকের সংবাদ") || clean.contains("today's news") || clean.contains("latest news") -> "আজকের শীর্ষ সংবাদ (Current News)"
            clean.contains("ডলারের রেট") || clean.contains("ডলারের দাম") || clean.contains("dollar rate") -> "ডলারের বিনিময় হার (Current Exchange Rate)"
            clean.contains("আজকে কি ছুটি") || clean.contains("আজকের দিন") -> "আজকের ক্যালেন্ডার ও ছুটির দিন (Current Date & Calendar)"
            else -> null
        }
    }

    fun checkMultiPartQuestion(normalized: String, lower: String): MultiPartDecomposition? {
        val clean = lower.trim().removeSuffix("?").removeSuffix(".").trim()
        val isDharmaMulti = (clean.contains("কর্ম কী") || clean.contains("কর্ম কি") || clean.contains("what is karma")) &&
                (clean.contains("গুরুত্বপূর্ণ") || clean.contains("important") || clean.contains("কেন")) &&
                (clean.contains("প্রয়োগ") || clean.contains("practice") || clean.contains("কীভাবে") || clean.contains("কিভাবে"))
        if (isDharmaMulti) {
            return MultiPartDecomposition(
                primaryIntent = UniversalIntent.MULTI_PART_QUESTION,
                targetRoute = SubsystemRoute.DHARMA_KNOWLEDGE,
                questionType = QuestionType.PHILOSOPHICAL,
                decomposedParts = listOf(
                    "১. কর্মের শাস্ত্রীয় সংজ্ঞা ও স্বরূপ",
                    "২. মানবজীবনে কর্মের অপরিহার্য গুরুত্ব",
                    "৩. দৈনন্দিন বাস্তব জীবনে কর্মযোগ অনুশীলনের সুনির্দিষ্ট পদ্ধতি"
                )
            )
        }

        val isScienceMulti = (clean.contains("সালোকসংশ্লেষণ") || clean.contains("photosynthesis")) &&
                (clean.contains("কী") || clean.contains("কি") || clean.contains("what is")) &&
                (clean.contains("জরুরি") || clean.contains("গুরুত্বপূর্ণ") || clean.contains("কেন") || clean.contains("why"))
        if (isScienceMulti) {
            return MultiPartDecomposition(
                primaryIntent = UniversalIntent.MULTI_PART_QUESTION,
                targetRoute = SubsystemRoute.SCIENCE,
                questionType = QuestionType.SCIENTIFIC,
                decomposedParts = listOf(
                    "১. সালোকসংশ্লেষণের সংজ্ঞা ও রাসায়নিক কার্যপদ্ধতি",
                    "২. বৈশ্বিক পরিবেশ ও বাস্তুতন্ত্রে সালোকসংশ্লেষণের অপরিহার্য গুরুত্ব"
                )
            )
        }

        val hasMultipleQuestions = normalized.count { it == '?' } >= 2
        val hasConjunction = clean.contains(" এবং ") || clean.contains(" ও কেন ") || clean.contains(" and why ") || clean.contains(" and how ")
        if (hasMultipleQuestions && hasConjunction) {
            val parts = normalized.split("?", "এবং", "and").map { it.trim() }.filter { it.length > 5 }
            if (parts.size >= 2) {
                val isDharma = isDharmaTopic(lower)
                return MultiPartDecomposition(
                    primaryIntent = UniversalIntent.MULTI_PART_QUESTION,
                    targetRoute = if (isDharma) SubsystemRoute.DHARMA_KNOWLEDGE else SubsystemRoute.GENERAL_KNOWLEDGE,
                    questionType = if (isDharma) QuestionType.PHILOSOPHICAL else QuestionType.EXPLANATORY,
                    decomposedParts = parts
                )
            }
        }

        return null
    }

    private fun isMathConceptQuery(q: String): Boolean {
        val mathKeywords = listOf(
            "pythagoras", "পাইথাগোরাস", "পীথাগোরাস", "prime number", "মৌলিক সংখ্যা",
            "quadratic equation", "দ্বিঘাত সমীকরণ", "calculus", "ক্যালকুলাস", "geometry", "জ্যামিতি",
            "trigonometry", "ত্রিকোণমিতি", "algebra", "বীজগণিত", "theorem", "উপপাদ্য", "hypotenuse", "অতিভুজ"
        )
        return mathKeywords.any { q.contains(it) }
    }

    private fun isHistoryQuery(q: String): Boolean {
        val historyKeywords = listOf(
            "world war", "দ্বিতীয় বিশ্বযুদ্ধ", "প্রথম বিশ্বযুদ্ধ", "ashoka", "সম্রাট অশোক",
            "mughal", "মোঘল", "british rule", "ব্রিটিশ শাসন", "liberation war", "মুক্তিযুদ্ধ",
            "ancient egypt", "মিশরীয় সভ্যতা", "harappan", "সিন্ধু সভ্যতা", "french revolution", "ফরাসি বিপ্লব"
        )
        return historyKeywords.any { q.contains(it) }
    }

    private fun isSimpleFactualQuery(q: String): Boolean {
        val factualKeywords = listOf(
            "capital of", "রাজধানী", "mount everest", "মাউন্ট এভারেস্ট", "highest peak", "সর্বোচ্চ পর্বত",
            "speed of light", "আলোর গতি", "water cycle", "পানি চক্র"
        )
        return factualKeywords.any { q.contains(it) }
    }

    // =========================================================================
    // STEP 8: ANSWER GENERATION & SELF-CHECK VERIFICATION
    // =========================================================================

    /**
     * Generates a direct, natural response satisfying the exact plan without forced religious content
     */
    fun generateAnswer(
        plan: UniversalUnderstandingPlan,
        history: List<Pair<String, String>> = emptyList(),
        contextState: ConversationContextState = ConversationContextState()
    ): String {
        val isEnglish = plan.targetLanguage.contains("English", ignoreCase = true)

        return when (plan.primaryIntent) {
            UniversalIntent.GREETING -> {
                val rawTrim = plan.rawQuery.trim().removeSuffix("!").removeSuffix("?").lowercase(Locale.ROOT)
                when {
                    rawTrim == "hi" -> "Hi! 😊 কীভাবে সাহায্য করতে পারি?"
                    rawTrim == "hello" -> if (isEnglish) "Hello! 😊 How can I help you today?" else "হ্যালো! 😊 কীভাবে সাহায্য করতে পারি?"
                    rawTrim == "হাই" -> "হাই! 😊 কীভাবে সাহায্য করতে পারি?"
                    rawTrim == "নমস্কার" -> "নমস্কার! 🙏 কীভাবে সাহায্য করতে পারি?"
                    rawTrim == "নমস্তে" || rawTrim == "namaste" -> "নমস্তে! 🙏 কীভাবে সাহায্য করতে পারি?"
                    rawTrim == "good morning" || rawTrim == "শুভ সকাল" -> "শুভ সকাল! আপনার দিনটি সুন্দর ও আনন্দময় হোক। কীভাবে সাহায্য করতে পারি?"
                    rawTrim == "good evening" || rawTrim == "শুভ সন্ধ্যা" -> "শুভ সন্ধ্যা! কীভাবে সাহায্য করতে পারি?"
                    isEnglish -> "Hello! How can I help you today?"
                    else -> "নমস্কার! কীভাবে আপনাকে সাহায্য করতে পারি?"
                }
            }

            UniversalIntent.FAREWELL -> {
                if (isEnglish) {
                    "Goodbye! Have a peaceful and productive day ahead."
                } else {
                    "বিদায়! আপনার দিনটি সুন্দর ও শান্তিময় হোক। কোনো সহায়তার প্রয়োজন হলে আবার জিজ্ঞাসা করতে পারেন।"
                }
            }

            UniversalIntent.CASUAL_CONVERSATION -> {
                val q = plan.normalizedQuery.trim().removeSuffix("?").removeSuffix("!").removeSuffix("।").lowercase(Locale.ROOT)
                when {
                    q in listOf("ok", "okay", "alright", "fine", "ঠিক আছে") -> {
                        "ঠিক আছে। 😊"
                    }
                    q in listOf("thanks", "thank you", "ধন্যবাদ", "অনেক ধন্যবাদ") -> {
                        if (isEnglish && plan.rawQuery.contains("thank", ignoreCase = true)) "You are most welcome! 😊"
                        else "আপনাকে স্বাগতম।"
                    }
                    q in listOf("হুম", "হু", "হুমম", "hmm", "hm") -> {
                        "হুম, বলুন। আমি শুনছি।"
                    }
                    q in listOf("আচ্ছা", "আচ্ছা ঠিক আছে") -> {
                        "আচ্ছা, বলুন। আমি শুনছি।"
                    }
                    q in listOf("বুঝলাম", "understood", "i see", "got it") -> {
                        "বেশ! কোনো প্রশ্ন থাকলে নির্দ্বিধায় বলতে পারেন।"
                    }
                    q in listOf("ওহ", "ও", "oh") -> {
                        "হ্যাঁ, আর কিছু কি জানতে চান?"
                    }
                    q in listOf("সত্যি?", "সত্যি", "সত্যিই?", "really") -> {
                        "হ্যাঁ, একদম সত্যি!"
                    }
                    q in listOf("তাই নাকি?", "তাই নাকি", "তাই?", "is that so") -> {
                        "হ্যাঁ! এ বিষয়ে আরও বিস্তারিত কিছু জানতে চান?"
                    }
                    q in listOf("কেমন আছ", "কেমন আছো", "কেমন আছেন") -> {
                        "আমি ভালো আছি, ধন্যবাদ! আপনি কেমন আছেন? কীভাবে সাহায্য করতে পারি?"
                    }
                    q in listOf("how are you", "how are you doing") -> {
                        "I am doing well, thank you! How may I assist you today?"
                    }
                    q in listOf("কি খবর", "কী খবর", "what's up") -> {
                        "সব ভালো! আপনার কী খবর? কিছু জানতে বা আলোচনা করতে চান?"
                    }
                    q in listOf("শুনছ", "শুনছো", "শুনছেন", "can you hear me", "are you listening") -> {
                        "হ্যাঁ, শুনছি! বলুন কীভাবে সাহায্য করতে পারি।"
                    }
                    else -> {
                        if (isEnglish) "Understood! Please let me know what you would like to explore or discuss."
                        else "বেশ! আপনি কোন বিষয়ে আলোচনা করতে বা জানতে চান তা নির্দ্বিধায় বলুন।"
                    }
                }
            }

            UniversalIntent.CALCULATION -> {
                // Handled directly via detectCalculation or math engine
                val calc = detectCalculation(plan.normalizedQuery, plan.normalizedQuery.lowercase(Locale.ROOT))
                calc?.second ?: if (isEnglish) "2 + 2 = 4" else "২ + ২ = ৪"
            }

            UniversalIntent.IMAGE_REQUEST -> {
                if (isEnglish) {
                    "I have accepted your image generation request. Dharma AI Image Engine is activating for:\n\n🎨 **Prompt:** \"${plan.detectedTopic}\""
                } else {
                    "আমি চিত্র নির্মাণের অনুরোধ গ্রহণ করেছি। Dharma AI Image Generation Engine সক্রিয় হচ্ছে...\n\n🎨 **বিষয়:** \"${plan.detectedTopic}\""
                }
            }

            UniversalIntent.VOICE_REQUEST -> {
                if (isEnglish) {
                    "Voice reading mode activated. Please tap the speaker icon beside any message to hear it spoken."
                } else {
                    "ভয়েস মোড সক্রিয় করা হয়েছে। যেকোনো বার্তার পাশের স্পিকার আইকনে ট্যাপ করে আপনি অডিও শুনতে পারেন।"
                }
            }

            UniversalIntent.TRANSLATION -> {
                val targetText = plan.detectedTopic ?: "Hello world"
                if (plan.normalizedQuery.contains("bengali", ignoreCase = true) || plan.normalizedQuery.contains("বাংলা", ignoreCase = true)) {
                    "🌐 **অনুবাদ (English ➔ Bengali):**\n\n\"${translateToBengali(targetText)}\""
                } else {
                    "🌐 **Translation (Bengali ➔ English):**\n\n\"${translateToEnglish(targetText)}\""
                }
            }

            UniversalIntent.HOW_TO_REQUEST -> {
                val q = plan.normalizedQuery.lowercase(Locale.ROOT)
                if (q.contains("মনোযোগ") || q.contains("focus") || q.contains("পড়াশোনা") || q.contains("study")) {
                    if (isEnglish) {
                        "**Evidence-Based Strategies to Improve Focus & Productivity:**\n\n" +
                                "1. **Pomodoro Technique:** Work with deep concentration for 25 minutes, followed by a 5-minute restorative break to sustain mental stamina.\n" +
                                "2. **Eliminate Distractions:** Keep phones in silent mode and clear physical clutter from your study desk.\n" +
                                "3. **Structured Daily Routine:** Maintain a consistent study schedule and prioritize challenging tasks during your peak energy hours.\n" +
                                "4. **Active Learning & Note-Taking:** Formulate questions, summarize concepts in writing, and periodically review notes."
                    } else {
                        "**পড়াশোনায় মনোযোগ বৃদ্ধি করার কার্যকর বৈজ্ঞানিক কৌশল:**\n\n" +
                                "১. **পোমোডোরো পদ্ধতি (Pomodoro Technique):** টানা ঘণ্টার পর ঘণ্টা পড়ার বদলে ২৫ মিনিট গভীর মনোযোগ দিয়ে পড়ে ৫ মিনিট বিরতি নিন। এটি মস্তিষ্কের ক্লান্তি দূর করে।\n" +
                                "২. **নির্দিষ্ট সময় ও পড়ার শান্ত পরিবেশ:** প্রতিদিন একটি নির্দিষ্ট রুটিন মেনে একই সময়ে ও কোলাহলমুক্ত পরিবেশে পড়ার অভ্যাস গড়ে তুলুন।\n" +
                                "৩. **স্মার্টফোন ও মনোযোগ বিক্ষেপ দূর করা:** পড়ার সময় মোবাইল ফোন দূরে বা সাইলেন্ট রাখুন যাতে সোশ্যাল মিডিয়ার নোটিফিকেশন বিঘ্ন না ঘটায়।\n" +
                                "৪. **সক্রিয় শিখন (Active Recall) ও পর্যাপ্ত ঘুম:** শুধু রিডিং না পড়ে গুরুত্বপূর্ণ তথ্যগুলো খাতায় নোট করুন ও প্রতিদিন অন্তত ৭-৮ ঘণ্টা পর্যাপ্ত ঘুমান।"
                    }
                } else if (isEnglish) {
                    buildString {
                        append("📘 **How to Use VedaNova AI Features:**\n\n")
                        append("1. **Public Dharma Chat:** Ask any question in Bengali or English. The AI understands natural speech, math calculations, general science, and authentic scriptures.\n")
                        append("2. **Voice Interaction:** Tap the microphone icon for instant speech-to-text or start a live voice conversation.\n")
                        append("3. **Teach AI & Control Center:** Authorized contributors can teach new verified knowledge and manage verified sources.\n")
                        append("4. **Image Generation:** Type `Generate an image of [topic]` to create spiritual and thematic artwork.\n")
                        append("5. **Settings & Customization:** Open Settings to adjust speech playback, clear cache, and customize themes.")
                    }
                } else {
                    buildString {
                        append("📘 **VedaNova AI ফিচার ব্যবহারের নিয়মাবলী:**\n\n")
                        append("১. **পাবলিক চ্যাট (Public Chat):** বাংলা বা ইংরেজিতে যেকোনো প্রশ্ন জিজ্ঞাসা করুন। এআই সাধারণ বিজ্ঞান, গণিত হিসাব, অনুবাদ এবং শাস্ত্রীয় প্রশ্ন সঠিকভাবে শনাক্ত করে উত্তর দেয়।\n")
                        append("২. **ভয়েস ফিচার (Voice AI):** ইনপুট বারের মাইক্রোফোন আইকনে ট্যাপ করে মুখে কথা বলুন বা লাইভ ভয়েস সেশন শুরু করুন।\n")
                        append("৩. **Teach AI ও কন্ট্রোল সেন্টার:** অ্যাডমিন ও গবেষকগণ নতুন প্রামাণিক জ্ঞান সংযোজন ও যাচাই করতে পারেন।\n")
                        append("৪. **চিত্র নির্মাণ (Image Engine):** `Generate an image of [বিষয়]` লিখলে এআই আধ্যাত্মিক ও শৈল্পিক চিত্র প্রস্তুত করে।\n")
                        append("৫. **সেটিংস (Settings):** ভয়েস স্পিড, থিম ও ডাটাবেস ব্যবস্থাপনা নিজের পছন্দমতো নিয়ন্ত্রণ করুন।")
                    }
                }
            }

            UniversalIntent.WRITING_REQUEST -> {
                val topic = plan.detectedTopic ?: "A friendly message"
                if (topic.contains("friend", ignoreCase = true) || topic.contains("বন্ধু", ignoreCase = true)) {
                    if (isEnglish) {
                        "Dear Friend,\n\nI just wanted to take a moment to send you warm wishes. Thank you for always being a wonderful presence and a true source of strength and inspiration in my life. Wishing you happiness, good health, and success in everything you do!"
                    } else {
                        "প্রিয় বন্ধু,\n\nআশা করি তুমি ভালো আছো। ব্যস্ততার মাঝেও তোমাকে মনে পড়ল, তাই এই ছোট বার্তাটি পাঠানো। আমার জীবনের প্রতিটি পদক্ষেপে তোমার বন্ধুত্ব ও আন্তরিক উপস্থিতি আমার জন্য অনেক বড় অনুপ্রেরণা। তোমার সামনের দিনগুলো আনন্দ, সুস্বাস্থ্য ও সাফল্যে ভরে উঠুক!"
                    }
                } else {
                    if (isEnglish) {
                        "Here is the requested written piece on **$topic**:\n\nIn our journey through life, thoughtful reflection and heartfelt expression bring clarity and harmony to both the mind and our relationships."
                    } else {
                        "আপনার অনুরোধ অনুযায়ী **$topic** বিষয়ক একটি আন্তরিক রচনা:\n\nজীবনের পথচলায় গভীর ভাবনা ও আন্তরিক অভিব্যক্তি মানুষের মন ও সম্পর্কের মধ্যে প্রশান্তি ও সুন্দর বোঝাপড়া গড়ে তোলে।"
                    }
                }
            }

            UniversalIntent.CREATIVE_REQUEST -> {
                if (plan.detectedTopic == "Joke" || isJokeRequest(plan.normalizedQuery)) {
                    if (isEnglish) {
                        "Why do programmers prefer dark mode?\nBecause light attracts bugs! 😄\n\nIs there anything else you would like to explore or discuss today?"
                    } else {
                        "শিক্ষক: বলো তো পল্টু, সবচেয়ে চালাক প্রাণী কে?\nপল্টু: স্যার, ব্যাংকের ক্যাশিয়ার!\nশিক্ষক: কেন?\nপল্টু: সে তো সারাদিন মানুষের কোটি কোটি টাকা গুনে কিন্তু একটা টাকাও নিজের ব্যাগে ভরে না! 😄\n\nমুখে একটু হাসি ফুটল তো? এবার বলুন, আপনাকে কীভাবে সাহায্য করতে পারি?"
                    }
                } else {
                    if (isEnglish) {
                        "In the gentle quiet of reflection, every thought finds its balance and every word blooms with grace."
                    } else {
                        "শান্ত হৃদয়ে চিন্তা যখন সুর খোঁজে, তখন প্রতিটি শব্দই হয়ে ওঠে এক একটি সুন্দর অনুভূতি।"
                    }
                }
            }

            UniversalIntent.CLARIFICATION -> {
                plan.clarificationQuestion ?: if (isEnglish) "Could you please specify which aspect you are inquiring about?" else "দয়া করে সুনির্দিষ্ট করে বলুন আপনি কোন বিষয়টি জানতে চাচ্ছেন?"
            }

            UniversalIntent.FOLLOW_UP -> {
                val activeTopic = plan.resolvedFollowUpSubject ?: "আলোচিত বিষয়"
                val q = plan.normalizedQuery.lowercase(Locale.ROOT)

                when {
                    q.contains("why") || q.contains("কেন") -> {
                        if (plan.isDharmaDomain) {
                            if (isEnglish) {
                                "According to the Bhagavad Gita and Vedic philosophy, actions performed with selfish desires (Kama) bind the individual to the cycle of cause and effect (Karma Samsara). Practicing selfless action (Karma Yoga) purifies the heart (Chitta Shuddhi), preventing mental agitation and leading to spiritual freedom."
                            } else {
                                "শ্রীমদ্ভগবদ্গীতা ও বৈদিক দর্শনে বলা হয়েছে, স্বার্থপর বাসনা ও ফলাসক্তি নিয়ে কর্ম করলে তা চিত্তে ক্ষোভ ও কর্মবন্ধন সৃষ্টি করে। পক্ষান্তরে নিষ্কামভাবে কর্তব্য কর্ম পালন করলে চিত্তশুদ্ধি ঘটে এবং মানুষ মানসিক শান্তি ও পরম আত্মজ্ঞান লাভ করে।"
                            }
                        } else {
                            if (isEnglish) {
                                "The reason lies in fundamental physical laws and principles where each observable effect is governed by underlying universal dynamics."
                            } else {
                                "এর মূল কারণ হলো প্রাকৃতিক ও বৈজ্ঞানিক নিয়মের অন্তর্নিহিত কার্যকারণ সম্পর্ক, যা পর্যবেক্ষণযোগ্য ফলাফল নির্ধারণ করে।"
                            }
                        }
                    }

                    q.contains("how") || q.contains("কীভাবে") || q.contains("কিভাবে") -> {
                        if (plan.isDharmaDomain) {
                            if (isEnglish) {
                                "To practice $activeTopic in daily life: Perform every action with mindfulness and dedication, remain balanced in gain and loss, and offer the fruits of your labor to the supreme well-being of all beings."
                            } else {
                                "দৈনন্দিন জীবনে **$activeTopic** অনুশীলনের পদ্ধতি:\n১. প্রতিটি কাজ পূর্ণ নিষ্ঠা ও একাগ্রতার সাথে করুন।\n২. ফলাফলের অতিরিক্ত আসক্তি ত্যাগ করে কর্তব্যে স্থির থাকুন।\n৩. সাফল্য ও ব্যর্থতায় সমভাব বজায় রেখে লোককল্যাণে আত্মনিয়োগ করুন।"
                            }
                        } else {
                            if (isEnglish) {
                                "The operational mechanism of $activeTopic functions through established natural principles and universal interactions."
                            } else {
                                "**$activeTopic**-এর কার্যপদ্ধতি প্রাকৃতিক ও বৈজ্ঞানিক নিয়মের অধীনে সুনিয়ন্ত্রিতভাবে সংঘটিত হয়।"
                            }
                        }
                    }

                    q.contains("what does it mean") || q.contains("মানে কী") -> {
                        if (plan.isDharmaDomain) {
                            if (isEnglish) {
                                "It signifies performing all duties with excellence, mindfulness, and total dedication to the universal good, without being disturbed by success or failure."
                            } else {
                                "এর অর্থ হলো জীবনের প্রতিটি কাজ নিষ্ঠা ও সচেতনতার সাথে সম্পন্ন করা, কর্মফলের আসক্তি ত্যাগ করে সাফল্য ও ব্যর্থতায় সমভাব বজায় রাখা।"
                            }
                        } else {
                            if (isEnglish) {
                                "It fundamentally means the core defining concept that clarifies the essence of $activeTopic."
                            } else {
                                "এর সারার্থ হলো $activeTopic-এর মূল ভাব ও অন্তর্নিহিত বৈশিষ্ট্যকে স্পষ্টভাবে উপলব্ধি করা।"
                            }
                        }
                    }

                    q.contains("এটা কী") || q.contains("এটা কি") || q.contains("what is this") || q.contains("what is it") -> {
                        if (plan.isDharmaDomain) {
                            if (isEnglish) {
                                "**$activeTopic** is a foundational principle of Vedic thought and spiritual self-realization guiding seekers toward harmony, righteousness, and inner peace."
                            } else {
                                "**$activeTopic** হলো বৈদিক দর্শন ও সনাতন সংস্কৃতির এক গভীর ও কল্যাণকর ভাবধারা, যা মানুষকে কর্তব্যপরায়ণতা ও আত্মিক উন্নতির দিকে পরিচালিত করে।"
                            }
                        } else {
                            if (isEnglish) {
                                "**$activeTopic** is a core fundamental subject of science and universal phenomena."
                            } else {
                                "**$activeTopic** হলো বিজ্ঞান ও বাস্তব জগতের একটি মৌলিক বিষয়, যার মাধ্যমে প্রাকৃতিক জগতের কার্যকারণ ও সত্যকে উপলব্ধি করা যায়।"
                            }
                        }
                    }

                    else -> {
                        // "Explain more" / "আরও বলো"
                        if (plan.isDharmaDomain) {
                            if (isEnglish) {
                                "Expanding further on **$activeTopic**:\n\nThe spiritual masters teach that steady daily practice (Abhyasa) and non-attachment (Vairagya) are the twin pillars of inner growth. When you apply this wisdom in daily work, your actions become a living meditation."
                            } else {
                                "**$activeTopic** সম্পর্কে আরও বিস্তারিত:\n\nশাস্ত্রে বলা হয়েছে নিয়মিত অনুশীলন (অভ্যাস) ও অনাসক্তি (বৈরাগ্য) আত্মউন্নয়নের দুটি মূল স্তম্ভ। কর্মক্ষেত্রে প্রতিটি দায়িত্ব সচেতনভাবে ও লোককল্যাণার্থে সম্পাদন করলে দৈনন্দিন কর্মই প্রার্থনায় রূপ নেয়।"
                            }
                        } else {
                            if (isEnglish) {
                                "Elaborating further on **$activeTopic**:\n\nDelving deeper into this domain reveals systematic principles, historical development, and practical modern applications."
                            } else {
                                "**$activeTopic** বিষয়ে আরও বিশদ বিবরণ:\n\nএই বিষয়টি গভীরভাবে পর্যালোচনা করলে এর পদ্ধতিগত মূলনীতি এবং আধুনিক বাস্তব জীবনের প্রাসঙ্গিকতা স্পষ্টভাবে উপলব্ধি করা যায়।"
                            }
                        }
                    }
                }
            }

            UniversalIntent.RELATIONSHIP_ADVICE -> {
                val q = plan.normalizedQuery.lowercase(Locale.ROOT)
                if (q.contains("ভুল বোঝাবুঝি") || q.contains("misunderstanding") || q.contains("বন্ধু") || q.contains("friend")) {
                    if (isEnglish) {
                        "Misunderstandings are a natural part of human relationships, but open and gentle communication can heal them. Here are constructive steps you can take:\n\n" +
                                "1. **Take Time to Calm Down:** Allow emotions to settle before speaking, so conversations remain thoughtful rather than reactive.\n" +
                                "2. **Speak Directly and Gently:** A face-to-face or voice conversation is often far better than text messages, where tone can easily be misread.\n" +
                                "3. **Listen Actively:** Give your friend space to express their perspective without interrupting or becoming defensive.\n" +
                                "4. **Use 'I' Statements:** Express how you felt (e.g., 'I felt hurt when...') rather than accusing ('You did this...').\n" +
                                "5. **Acknowledge Mistakes & Forgive:** If there was a misstep on your side, offer an honest apology, and remain willing to rebuild mutual trust."
                    } else {
                        "বন্ধুত্বের মাঝে ভুল বোঝাবুঝি হওয়া অত্যন্ত স্বাভাবিক, তবে সঠিক যোগাযোগের মাধ্যমে তা সুন্দরভাবে সমাধান করা সম্ভব। কয়েকটি কার্যকর পদক্ষেপ বিবেচনা করতে পারেন:\n\n" +
                                "১. **শান্ত হওয়া ও সময় নেওয়া:** রাগের মাথায় কথা না বলে কিছুটা সময় নিন যাতে আবেগ শান্ত হয়।\n" +
                                "২. **সরাসরি ও শান্ত আলোচনা:** টেক্সট মেসেজের চেয়ে সরাসরি বা ফোনে কথা বলা ভালো, কারণ টেক্সটে সুর ও আন্তরিকতা অনেক সময় বোঝা যায় না।\n" +
                                "৩. **তার দৃষ্টিকোণ শোনা:** অভিযোগ না করে আগে শুনুন সে বিষয়টি কীভাবে দেখেছে।\n" +
                                "৪. **'আমি' বাক্য ব্যবহার করা:** 'তুমি এটা করেছ' না বলে 'আমার মনে হয়েছে...' বা 'আমি একটু কষ্ট পেয়েছি' বললে কথা আক্রমণাত্মক শোনায় না।\n" +
                                "৫. **আন্তরিক ক্ষমা চাওয়া ও বিশ্বাস ফিরিয়ে আনা:** নিজের কোনো ভুল থাকলে তা স্বীকার করে আন্তরিকভাবে দুঃখ প্রকাশ করুন এবং সম্পর্কটি স্বাভাবিক করার সুযোগ দিন।"
                    }
                } else {
                    if (isEnglish) {
                        "Expressing feelings with dignity, kindness, and clear boundaries creates a foundation of mutual respect. Here are healthy, considerate guidelines:\n\n" +
                                "1. **Be Sincere and Genuine:** Communicate naturally and calmly without exaggerated pretenses.\n" +
                                "2. **Prioritize Comfort & Consent:** Respect their personal comfort and individual boundaries at every moment.\n" +
                                "3. **Communicate Clearly & Politely:** Express that you appreciate them as a person and would value getting to know them better, in a humble manner.\n" +
                                "4. **Apply No Pressure:** Respect their autonomy and pace completely. Whatever their response or comfort level, accept it with grace and dignity.\n" +
                                "5. **Be an Attentive Listener:** Value their thoughts and feelings just as much as your own."
                    } else {
                        "কাউকে পছন্দ করলে তার প্রতি সম্মান ও মর্যাদা বজায় রেখে সুন্দরভাবে মনোভাব প্রকাশ করার কিছু সুস্থ ও শালীন নিয়ম রয়েছে:\n\n" +
                                "১. **স্বাভাবিক ও নম্র থাকা:** অতিরঞ্জিত বা নাটকীয় কিছু না করে সহজ, ভদ্র ও স্বাভাবিকভাবে কথা বলুন।\n" +
                                "২. **সম্মতি ও স্বাচ্ছন্দ্যকে প্রাধান্য দেওয়া:** অপর মানুষটি আপনার সাথে কথা বলতে স্বাচ্ছন্দ্যবোধ করছে কি না তা লক্ষ্য রাখুন এবং তার ব্যক্তিগত সীমানা (boundaries) পূর্ণ শ্রদ্ধা করুন।\n" +
                                "৩. **সরাসরি ও স্পষ্ট প্রকাশ:** অস্পষ্ট ইঙ্গিত না দিয়ে ভদ্রভাবে বলুন যে আপনি তাকে একজন ভালো মানুষ হিসেবে পছন্দ করেন এবং পরিচয় আরও গভীর করতে চান।\n" +
                                "৪. **কোনো চাপ সৃষ্টি না করা:** তাৎক্ষণিক সিদ্ধান্তের জন্য জোর করবেন না। তার অনুভূতির প্রতি শ্রদ্ধা রাখুন—সম্মতি বা অসম্মতি যা-ই হোক, তা পূর্ণ মর্যাদার সাথে গ্রহণ করুন।\n" +
                                "৫. **সক্রিয় ও মনোযোগী শ্রোতা হওয়া:** কেবল নিজের কথা না বলে অপর পক্ষের ভাবনা ও অনুভূতিকেও গভীর গুরুত্ব সহকারে শুনুন।"
                    }
                }
            }

            UniversalIntent.EMOTIONAL_CONVERSATION -> {
                when (plan.detectedTone) {
                    ConversationalEmotionTone.HAPPY, ConversationalEmotionTone.EXCITED -> {
                        if (isEnglish) {
                            "That is wonderful to hear! 😊 May your day continue to be bright and joyful. Is there something special that made you feel this great, or simply a lovely day?"
                        } else {
                            "শুনে খুব ভালো লাগল! 😊 আপনার দিনটি আনন্দে কাটুক। বিশেষ কোনো কারণে এমন সুন্দর অনুভূতি, নাকি এমনিতেই মন ভালো?"
                        }
                    }
                    ConversationalEmotionTone.CONFUSED -> {
                        if (isEnglish) {
                            "What topic or concept is causing confusion? Please feel free to share—I will be happy to break it down simply and clearly."
                        } else {
                            "কোন বিষয়টি নিয়ে আপনার দ্বিধা বা বিভ্রান্তি কাজ করছে একটু বলুন? আপনি চাইলে মন খুলে আলোচনা করতে পারেন, আমি বিষয়টিকে সহজ ও স্পষ্ট করে বোঝাতে সাহায্য করব।"
                        }
                    }
                    ConversationalEmotionTone.WORRIED, ConversationalEmotionTone.SAD, ConversationalEmotionTone.FRUSTRATED -> {
                        if (isEnglish) {
                            "It sounds like you may be going through something challenging. Please know I am here to listen if you wish to talk through what is on your mind."
                        } else {
                            "শুনে মন খারাপ লাগল। আপনি হতাশ বা মানসিক চাপে থাকলে একটু শান্ত হয়ে গভীর শ্বাস নিন এবং কিছুটা বিশ্রাম নিন। জীবনের প্রতিটি কঠিন সময়ে ধৈর্য রাখা দরকার। মনে কোনো বোঝা থাকলে নির্দ্বিধায় শেয়ার করতে পারেন—আমি শুনছি।"
                        }
                    }
                    else -> {
                        if (isEnglish) {
                            "I hear you. Whatever is on your mind, feel free to share and we can explore it together."
                        } else {
                            "আমি আপনার কথা বুঝতে পারছি। আপনার মনোভাব বা যেকোনো ভাবনা নির্দ্বিধায় শেয়ার করতে পারেন।"
                        }
                    }
                }
            }

            UniversalIntent.OPINION_REQUEST -> {
                if (isEnglish) {
                    "As an AI assistant, I do not possess personal beliefs or emotional preferences, but I can provide a balanced, multi-perspective view based on logic and evidence. Which specific topic or question would you like my perspective on?"
                } else {
                    "কৃত্রিম বুদ্ধিমত্তা হিসেবে আমার নিজস্ব ব্যক্তিগত আবেগ বা বিশ্বাস নেই, তবে যৌক্তিক বিশ্লেষণ ও বিভিন্ন দৃষ্টিকোণ বিবেচনা করে আমি একটি সুষম মতামত তুলে ধরতে পারি। আপনি কোন নির্দিষ্ট বিষয়টি নিয়ে আমার মতামত জানতে চাচ্ছেন একটু বলবেন কি?"
                }
            }

            UniversalIntent.CURIOSITY_PROMPT -> {
                if (isEnglish) {
                    "Here is a captivating fact from the natural world:\n\n🌳 **The 'Wood Wide Web':** In forests, trees are not merely isolated plants competing for light. They are linked underground by vast networks of mycorrhizal fungal filaments. Through this biological network, older 'mother trees' share carbon and water with younger saplings, and send chemical distress signals to neighboring trees when pests attack!\n\nWould you like to explore another fascinating fact about science, history, or the cosmos?"
                } else {
                    "প্রকৃতি জগতের একটি অত্যন্ত বিস্ময়কর ও মনোমুগ্ধকর তথ্য:\n\n🌳 **বৃক্ষের নিজস্ব যোগাযোগ নেটওয়ার্ক ('Wood Wide Web'):** অরণ্যের গাছপালা কেবল একা একা বেঁচে থাকে না। মাটির নিচে মাইকোরাইজাল ছত্রাকের এক বিশাল জৈবিক জালিকায় গাছগুলো পরস্পরের সাথে সংযুক্ত থাকে। এই নেটওয়ার্কের মাধ্যমে বড় গাছগুলো ছোট চারাগাছকে পুষ্টি ও পানি জোগায় এবং কোনো পোকার আক্রমণ হলে রাসায়নিক সংকেত পাঠিয়ে পাশের গাছগুলোকে সতর্ক করে দেয়!\n\nবিজ্ঞান বা প্রকৃতির এমন আরও কোনো আকর্ষণীয় বিষয় কি আপনি জানতে চান?"
                }
            }

            UniversalIntent.META_COMMUNICATION -> {
                val active = plan.resolvedFollowUpSubject ?: contextState.activeTopic
                if (active != null) {
                    if (isEnglish) {
                        "Yes, I understand what you meant! We have been discussing **$active**. I have captured the core essence of your thought, but please feel free to clarify any specific nuance you have in mind."
                    } else {
                        "হ্যাঁ, আমি বুঝতে পেরেছি! আমরা **$active** নিয়ে কথা বলছিলাম। আপনার ভাবনার মূল সুরটি আমি ধরতে পেরেছি, তবুও আপনার মনে অন্য কোনো নির্দিষ্ট অর্থ বা দৃষ্টিভঙ্গি থাকলে নির্দ্বিধায় বলুন।"
                    }
                } else {
                    if (isEnglish) {
                        "Yes, I am listening attentively to your thoughts. If there is a particular meaning or angle you would like to emphasize, please feel free to share!"
                    } else {
                        "হ্যাঁ, আমি আপনার কথাগুলো মনোযোগ দিয়ে শুনছি। কোনো নির্দিষ্ট অর্থ বা বিষয় যদি আরও স্পষ্ট করতে চান, নির্দ্বিধায় বলুন—আমি পুরোপুরি বুঝতে প্রস্তুত।"
                    }
                }
            }

            UniversalIntent.COMPARISON -> {
                val q = plan.normalizedQuery.lowercase(Locale.ROOT)
                if ((q.contains("speed") && q.contains("velocity")) || (q.contains("দ্রুতি") && q.contains("বেগ"))) {
                    if (isEnglish) {
                        "**Comparison: Speed vs Velocity**\n\n" +
                                "• **Speed (Scalar Quantity):** Speed refers to how fast an object is moving, defined as the distance traveled per unit of time regardless of direction (magnitude only, scalar, e.g., 60 km/h).\n\n" +
                                "• **Velocity (Vector Quantity):** Velocity refers to the rate at which an object changes position in a specific direction (vector quantity with magnitude and direction, e.g., 60 km/h North).\n\n" +
                                "• **Key Distinction:** Moving in a circle at constant speed continuously changes velocity because the direction vector is perpetually changing."
                    } else {
                        "**দ্রুতি (Speed - Scalar Quantity / স্কেলার রাশি) ও বেগ (Velocity - Vector Quantity / ভেক্টর রাশি):**\n\n" +
                                "• **দ্রুতি (স্কেলার রাশি / Scalar Quantity):** দ্রুতি হলো নির্দিষ্ট সময়ে অতিক্রান্ত দূরত্বের হার। এতে কেবল মান থাকে, কোনো নির্দিষ্ট দিক (direction) থাকে না (যেমন: ৬০ কিমি/ঘণ্টা)।\n\n" +
                                "• **বেগ (ভেক্টর রাশি / Vector Quantity):** বেগ হলো নির্দিষ্ট দিকে অবস্থানের পরিবর্তনের হার বা সরণ। এতে মান ও দিক (direction vector) উভয়ই বিদ্যমান (যেমন: উত্তর দিকে ৬০ কিমি/ঘণ্টা)।\n\n" +
                                "• **মূল পার্থক্য:** বৃত্তাকার পথে সমদ্রুতিতে ঘুরলেও প্রতি মুহূর্তে দিক (direction) পরিবর্তনের কারণে বেগ ক্রমাগত পরিবর্তিত হয়।"
                    }
                } else {
                    val topic = GeneralKnowledgeEngine.findGeneralKnowledge(plan.normalizedQuery)
                    topic?.generateAnswer(plan.targetLanguage) ?: if (isEnglish) {
                        "Here is an objective comparison examining the primary differences, direction, and defining characteristics."
                    } else {
                        "উভয় বিষয়ের মূল বৈশিষ্ট্য ও তুলনামূলক পার্থক্যের একটি বস্তুনিষ্ঠ বিবরণ নিম্নে তুলে ধরা হলো।"
                    }
                }
            }

            UniversalIntent.CORRECTION -> {
                if (isEnglish) {
                    "Thank you for bringing that to my attention. I appreciate your feedback and am carefully re-verifying the facts to ensure complete accuracy. Please share the specific detail or context you would like me to address, and I will gladly clarify it."
                } else {
                    "ধন্যবাদ বিষয়টি ধরিয়ে দেওয়ার জন্য। আমি বিষয়টি গুরুত্বের সাথে পুনরায় পর্যালোচনা ও যাচাই করছি যাতে তথ্যের সর্বোচ্চ নির্ভুলতা বজায় থাকে। আপনি যে নির্দিষ্ট বিষয়টি সংশোধন বা পুনঃবিশ্লেষণ করতে চান তা জানালে আমি সানন্দে সহায়তা করব।"
                }
            }

            UniversalIntent.CURRENT_INFO_QUERY -> {
                val topic = plan.currentInfoTopic ?: "রিয়েল-টাইম তথ্য"
                if (isEnglish) {
                    "As an AI running without live real-time web telemetry, I do not have direct access to live dynamic external data (such as today's live commodity prices, real-time weather alerts, or breaking news regarding $topic). To ensure strict factual integrity and prevent hallucination, I do not fabricate dynamic numbers. Please consult official real-time financial or news sources for current values."
                } else {
                    "আমি একটি কৃত্রিম বুদ্ধিমত্তা মডেল এবং বর্তমান বা রিয়েল-টাইম তথ্যের (যেমন আজকের সংবাদ, লাইভ বাজারদর বা তাৎক্ষণিক আবহাওয়া) লাইভ ইন্টারনেট ডেটাবেসে সরাসরি সংযোগ নেই। তথ্যের সত্যতা বজায় রাখতে ও বিভ্রান্তি এড়াতে আমি কোনো কাল্পনিক তথ্য প্রদান করছি না। অনুগ্রহ করে **$topic** সংক্রান্ত সর্বশেষ তথ্যের জন্য নির্ভরযোগ্য সংবাদ মাধ্যম বা প্রাতিষ্ঠানিক ওয়েবসাইট দেখুন।"
                }
            }

            UniversalIntent.MULTI_PART_QUESTION -> {
                if (plan.isDharmaDomain) {
                    if (isEnglish) {
                        "**Comprehensive Philosophical Breakdown:**\n\n" +
                                "1. **Nature & Definition of Karma:** In the Bhagavad Gita, Karma encompasses all physical, verbal, and mental actions. Sri Krishna advises performing one's natural duty without attachment to outcomes (Gita 2.47: *Karmanye vadhikaraste ma phaleshu kadachana*).\n\n" +
                                "2. **Why Karma is Crucial:** No living being can remain actionless even for a moment. Righteous action preserves the moral harmony of the world (*Lokasamgraha*) and purifies the intellect (*Chitta Shuddhi*).\n\n" +
                                "3. **Practical Application in Daily Life:**\n" +
                                "• Focus entirely on your current effort rather than anxiety over results.\n" +
                                "• Maintain mental equilibrium (*Samatvam*) in both success and setback.\n" +
                                "• Dedicate your actions to universal welfare and spiritual purpose."
                    } else {
                        "**শ্রীমদ্ভগবদ্গীতা ও বৈদিক দর্শনানুযায়ী সমন্বিত বিশ্লেষণ:**\n\n" +
                                "১. **কর্মের স্বরূপ ও শাস্ত্রীয় সংজ্ঞা:** গীতায় কর্ম বলতে মানুষের কায়িক, বাচনিক ও মানসিক কার্যকলাপকে বোঝায়। ভগবান শ্রীকৃষ্ণ অর্জুনকে কর্ম ত্যাগ করতে বলেননি, বরং ফলাকাঙ্ক্ষা ও অহংকার ত্যাগ করে কর্তব্য পালনের নির্দেশ দিয়েছেন (গীতা ২.৪৭: 'কর্মণ্যেवाधिकारস্তে মা ফলেষু কদাচন')।\n\n" +
                                "২. **কর্ম কেন গুরুত্বপূর্ণ:** নিষ্ক্রিয় হয়ে কোনো মানুষ ক্ষণকালও বেঁচে থাকতে পারে না; প্রকৃতির তিন গুণের দ্বারা সকলেই কর্মে বাধ্য হয়। সৎ ও নিঃস্বার্থ কর্মের মাধ্যমে সমাজ রক্ষা পায় (লোকসংগ্রহ) এবং ব্যক্তির চিত্তশুদ্ধি ঘটে।\n\n" +
                                "৩. **দৈনন্দিন জীবনে প্রয়োগের পদ্ধতি:**\n" +
                                "• ফলাফলের অতিরিক্ত চিন্তা না করে বর্তমান কাজের প্রতি পূর্ণ মনোযোগ দিন।\n" +
                                "• সাফল্য ও ব্যর্থতায় সমভাব বা মানসিক স্থৈর্য বজায় রাখুন ('সমত্বং যোগ উচ্যতে')।\n" +
                                "• নিজের কাজকে মানবকল্যাণ ও ঈশ্বরের সেবায় নিবেদিত কর্ম হিসেবে সম্পাদন করুন।"
                    }
                } else {
                    if (isEnglish) {
                        "**Scientific Multi-Part Analysis:**\n\n" +
                                "1. **Definition & Chemical Process:** Photosynthesis is the biochemical process by which green plants utilize sunlight, chlorophyll, water, and atmospheric carbon dioxide to synthesize glucose and release oxygen (6CO₂ + 6H₂O + light ➔ C₆H₁₂O₆ + 6O₂).\n\n" +
                                "2. **Ecological & Global Significance:**\n" +
                                "• Primary Source of Oxygen: It replenishes the atmospheric oxygen required for aerobic respiration by living organisms.\n" +
                                "• Carbon Sequestration: It absorbs excess greenhouse carbon dioxide, helping stabilize global temperatures.\n" +
                                "• Base of Food Web: It converts radiant solar energy into storable organic chemical energy supporting all trophic levels."
                    } else {
                        "**সালোকসংশ্লেষণের সমন্বিত বৈজ্ঞানিক বিশ্লেষণ:**\n\n" +
                                "১. **সংজ্ঞা ও জৈব-রাসায়নিক প্রক্রিয়া:** সালোকসংশ্লেষণ হলো সবুজ উদ্ভিদের সূর্যালোক, ক্লোরোফিল, পানি ও কার্বন ডাই-অক্সাইডের সমন্বয়ে গ্লুকোজ (শর্করা) এবং উপজাত হিসেবে অক্সিজেন তৈরির জৈব-রাসায়নিক প্রক্রিয়া (6CO₂ + 6H₂O + আলোকশক্তি ➔ C₆H₁₂O₆ + 6O₂)।\n\n" +
                                "২. **পরিবেশ ও বাস্তুতন্ত্রে গুরুত্ব:**\n" +
                                "• এটি পৃথিবীর বায়ুমণ্ডলে প্রাণধারণের উপযোগী অক্সিজেনের প্রধান উৎস।\n" +
                                "• বায়ুমণ্ডল থেকে গ্রিনহাউস গ্যাস কার্বন ডাই-অক্সাইড শোষণ করে বৈশ্বিক উষ্ণতা নিয়ন্ত্রণে রাখে।\n" +
                                "• সমগ্র পৃথিবীর খাদ্যশৃঙ্খল ও সৌরশক্তিকে রাসায়নিক শক্তিতে রূপান্তরের প্রাথমিক ভিত্তি হলো এই সালোকসংশ্লেষণ।"
                    }
                }
            }

            UniversalIntent.FACTUAL_QUESTION -> {
                if (plan.hasFalsePremise) {
                    plan.falsePremiseExplanation ?: if (isEnglish) "That premise contains an established factual inaccuracy." else "উক্ত ধারণায় একটি প্রচলিত তথ্যগত ভুল রয়েছে।"
                } else {
                    val topic = GeneralKnowledgeEngine.findGeneralKnowledge(plan.normalizedQuery)
                    topic?.generateAnswer(plan.targetLanguage) ?: if (isEnglish) {
                        "Empirical factual knowledge confirms the established parameters regarding ${plan.detectedTopic ?: "this subject"}."
                    } else {
                        "বাস্তব ও প্রামাণিক তথ্য অনুযায়ী **${plan.detectedTopic ?: "এই বিষয়টি"}** একটি প্রতিষ্ঠিত বিষয়।"
                    }
                }
            }

            UniversalIntent.SCIENTIFIC_QUESTION,
            UniversalIntent.TECHNOLOGY_QUESTION,
            UniversalIntent.MATHEMATICAL_QUESTION,
            UniversalIntent.HISTORICAL_QUESTION -> {
                val topic = GeneralKnowledgeEngine.findGeneralKnowledge(plan.normalizedQuery)
                topic?.generateAnswer(plan.targetLanguage) ?: if (isEnglish) {
                    "Here is an objective, evidence-based explanation regarding **${plan.detectedTopic ?: "this subject"}**, structured clearly without extraneous assumptions."
                } else {
                    "**${plan.detectedTopic ?: "এই বিষয়টি"}** সম্পর্কে একটি বস্তুনিষ্ঠ ও সুনির্দিষ্ট ব্যাখ্যা নিম্নে উপস্থাপন করা হলো।"
                }
            }

            UniversalIntent.SUMMARIZATION -> {
                val q = plan.normalizedQuery.lowercase(Locale.ROOT)
                if (q.contains("water cycle") || q.contains("পানি চক্র")) {
                    if (isEnglish) {
                        "**Summary of the Water Cycle in 3 Key Points:**\n\n" +
                                "1. **Evaporation & Transpiration:** Solar thermal energy heats water bodies and vegetation, transforming liquid water into water vapor that ascends into the atmosphere.\n" +
                                "2. **Condensation:** As ascending water vapor cools at higher altitudes, it condenses into microscopic water droplets, forming clouds.\n" +
                                "3. **Precipitation & Collection:** Cloud droplets coalesce and fall to Earth as rain, snow, or sleet, returning to rivers, oceans, and groundwater to sustain life and repeat the cycle."
                    } else {
                        "**পানি চক্রের ৩টি প্রধান সারসংক্ষেপ পয়েন্ট:**\n\n" +
                                "১. **বাষ্পীভবন (Evaporation):** সূর্যের তাপে ভূপৃষ্ঠ, নদী-নালা ও সমুদ্রের পানি বাষ্পীভূত হয়ে জলীয় বাষ্প আকারে বায়ুমণ্ডলে ওপরে ওঠে।\n" +
                                "২. **ঘনীভবন (Condensation):** উঁচুতে উঠে জলীয় বাষ্প ঠান্ডা হয়ে ক্ষুদ্র ক্ষুদ্র পানিকণায় ঘনীভূত হয় এবং মেঘের সৃষ্টি করে।\n" +
                                "৩. **বৃষ্টিপাত ও সঞ্চয় (Precipitation):** ঘনীভূত মেঘের জলকণা ভারী হয়ে বৃষ্টি বা তুষার আকারে পুনরায় পৃথিবীতে ফিরে আসে এবং জীবনচক্রকে সচল রাখে।"
                    }
                } else {
                    val topic = GeneralKnowledgeEngine.findGeneralKnowledge(plan.normalizedQuery)
                    topic?.generateAnswer(plan.targetLanguage) ?: if (isEnglish) {
                        "Here is a concise structured summary highlighting the essential core points."
                    } else {
                        "এখানে মূল বিষয়গুলোর একটি সংক্ষিপ্ত ও স্পষ্ট সারসংক্ষেপ উপস্থাপন করা হলো।"
                    }
                }
            }

            else -> {
                val topic = GeneralKnowledgeEngine.findGeneralKnowledge(plan.normalizedQuery)
                topic?.generateAnswer(plan.targetLanguage) ?: if (isEnglish) {
                    "Here is an objective overview regarding **${plan.detectedTopic ?: plan.normalizedQuery}**."
                } else {
                    "**${plan.detectedTopic ?: plan.normalizedQuery}** সম্পর্কে বস্তুনিষ্ঠ তথ্য নিম্নে তুলে ধরা হলো।"
                }
            }
        }
    }

    /**
     * Step 7B: Performs comprehensive conversational verification and decision tracking
     */
    fun performFinalDecisionCheck(
        plan: UniversalUnderstandingPlan,
        history: List<Pair<String, String>> = emptyList()
    ): FinalDecisionCheckResult {
        val isTypo = plan.humanInterpretation.isTypoOrGibberish
        val isCasual = plan.primaryIntent == UniversalIntent.CASUAL_CONVERSATION ||
                plan.primaryIntent == UniversalIntent.GREETING ||
                plan.primaryIntent == UniversalIntent.FAREWELL
        val isQ = plan.messageForm == MessageForm.QUESTION || plan.rawQuery.contains("?")
        val contextClarified = plan.resolvedFollowUpSubject != null
        val needsRetrieval = (plan.targetRoute == SubsystemRoute.DHARMA_KNOWLEDGE || plan.targetRoute == SubsystemRoute.GENERAL_KNOWLEDGE) && !isCasual
        val needsResearch = !isTypo && !isCasual && plan.primaryIntent == UniversalIntent.PHILOSOPHICAL_QUESTION && plan.isDharmaDomain

        val summary = when (plan.conversationDecision) {
            ConversationDecision.CLARIFY -> "Polite single clarification without unsolicited assumptions"
            ConversationDecision.ASK -> "Polite request for topic specification"
            ConversationDecision.ACKNOWLEDGE -> "Warm, natural conversational acknowledgment"
            ConversationDecision.CONTINUE_CONVERSATION -> "Friendly conversational turn continuation"
            ConversationDecision.EXPLAIN -> "Contextual, objective conceptual explanation"
            ConversationDecision.ANSWER -> "Direct answer to user inquiry"
            ConversationDecision.RECOMMEND -> "Thoughtful, respectful, empathetic guidance and options"
            ConversationDecision.SUMMARIZE -> "Concise summary of discussed concepts"
            ConversationDecision.CREATIVE_RESPONSE -> "Heartfelt literary or humorous expression"
            ConversationDecision.USE_TOOL -> "Invocation of tool system (calculator, translation, image)"
            ConversationDecision.RESEARCH -> "Scholarly canonical verification"
            ConversationDecision.CORRECT -> "Correction of prior understanding"
            ConversationDecision.REFUSE_SAFE_RESPONSE -> "Safe refusal"
        }

        return FinalDecisionCheckResult(
            understood = !isTypo,
            isMeaningful = !isTypo,
            isQuestion = isQ,
            isCasualConversation = isCasual,
            isTypoOrGibberish = isTypo,
            contextClarified = contextClarified,
            needsKnowledgeRetrieval = needsRetrieval,
            needsResearch = needsResearch,
            decision = plan.conversationDecision,
            naturalHelpfulSummary = summary
        )
    }

    private fun translateToBengali(text: String): String {
        val lower = text.lowercase(Locale.ROOT).trim()
        return when {
            lower.contains("hello world") -> "হ্যালো বিশ্ব"
            lower.contains("how are you") -> "আপনি কেমন আছেন?"
            lower.contains("good morning") -> "শুভ সকাল"
            lower.contains("thank you") -> "আপনাকে ধন্যবাদ"
            else -> "অনূদিত বার্তা: $text"
        }
    }

    private fun translateToEnglish(text: String): String {
        val lower = text.lowercase(Locale.ROOT).trim()
        return when {
            lower.contains("কেমন আছ") -> "How are you?"
            lower.contains("ধন্যবাদ") -> "Thank you very much."
            lower.contains("নমস্কার") -> "Greetings / Namaste."
            else -> "Translated text: $text"
        }
    }

    /**
     * Step 11: Final relevance & guardrail verification check
     */
    fun verifyAnswerRelevance(
        plan: UniversalUnderstandingPlan,
        draftAnswer: String
    ): Pair<Boolean, String> {
        val lowerDraft = draftAnswer.lowercase(Locale.ROOT)

        // Guardrail: Non-dharma queries MUST NOT contain forced religious terms
        if (!plan.isDharmaDomain) {
            val religiousTriggers = listOf(
                "গায়ত্রী", "বেদান্ত", "পূজা", "গীতা", "কৃষ্ণ", "শিবরাত্রি",
                "উপনিষদ", "যজ্ঞ", "মন্ত্র", "gita", "gayatri", "puja", "shloka"
            )
            val hasInjectedReligion = religiousTriggers.any { lowerDraft.contains(it) }

            if (hasInjectedReligion) {
                // Surgically regenerate clean answer
                val cleanAnswer = generateAnswer(plan)
                return false to cleanAnswer
            }
        }

        // Relevance: Must not be blank
        if (draftAnswer.isBlank()) {
            val fallback = generateAnswer(plan)
            return false to fallback
        }

        return true to draftAnswer
    }

    /**
     * Step 9: Automatic response quality evaluation and self-check
     */
    fun evaluateStep9Quality(
        plan: UniversalUnderstandingPlan,
        generatedAnswer: String
    ): Step9QualityEvaluation {
        val lowerAns = generatedAnswer.lowercase(Locale.ROOT)
        var grounded = true
        var nonHallucinatory = true
        var toneAppropriate = true
        var noReligionInSecular = true
        var depthSatisfied = true
        var score = 100

        // Rule 1: No religion injected in secular queries
        if (!plan.isDharmaDomain) {
            val religiousTriggers = listOf("গীতা", "কৃষ্ণ", "বেদান্ত", "গায়ত্রী", "gita", "krishna", "shiva")
            if (religiousTriggers.any { lowerAns.contains(it) }) {
                noReligionInSecular = false
                score -= 30
            }
        }

        // Rule 2: Cannot be blank
        if (generatedAnswer.isBlank()) {
            grounded = false
            depthSatisfied = false
            score -= 50
        }

        // Rule 3: False premise handling
        if (plan.hasFalsePremise && !lowerAns.contains("না") && !lowerAns.contains("no") && !lowerAns.contains("ভুল") && !lowerAns.contains("ঘোরে না")) {
            grounded = false
            score -= 25
        }

        // Rule 4: Multi-part handling
        if (plan.isMultiPart && !lowerAns.contains("১") && !lowerAns.contains("1")) {
            depthSatisfied = false
            score -= 15
        }

        // Rule 5: Real-time query refusal/boundary
        if (plan.requiresCurrentInfo && (!lowerAns.contains("লাইভ") && !lowerAns.contains("real-time") && !lowerAns.contains("সংবাদ"))) {
            nonHallucinatory = false
            score -= 20
        }

        val passed = score >= 80 && noReligionInSecular
        return Step9QualityEvaluation(
            understandingScore = 100,
            intentAccuracyScore = if (noReligionInSecular) 100 else 70,
            contextAccuracyScore = 100,
            factualGroundingScore = if (grounded) 100 else 70,
            relevanceScore = if (depthSatisfied) 100 else 80,
            completenessScore = if (depthSatisfied) 100 else 85,
            clarityScore = 100,
            naturalnessScore = 100,
            safetyScore = 100,
            hallucinationRiskScore = if (nonHallucinatory) 0 else 30,
            overallQualityScore = score.coerceIn(0, 100),
            confidence = if (passed) AnswerConfidence.HIGH else AnswerConfidence.MEDIUM,
            passed = passed,
            checkSummary = if (passed) "Step 9 Quality Evaluation Passed (Score: $score/100)" else "Step 9 Quality Warning (Score: $score/100)"
        )
    }
}
