package com.example.domain.ai

import com.example.data.dao.CapabilityProposalDao
import com.example.data.model.CapabilityProposalEntity
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

data class VedaNovaCapability(
    val code: String,
    val nameEn: String,
    val nameBn: String,
    val category: String,
    val description: String,
    val requiredScope: String,
    val endpoint: String,
    val isCore: Boolean = true,
    val safetyRating: String = "Canonical Safe",
    val sampleInputJson: String,
    val sampleOutputJson: String
)

object ExternalAppCapabilityEngine {

    val STANDARD_CAPABILITIES = listOf(
        VedaNovaCapability(
            code = "AI_CHAT",
            nameEn = "AI Chat & Multi-Intent Exegesis",
            nameBn = "এআই ধর্মীয় প্রশ্নোত্তর ও শাস্ত্র ব্যাখ্যা",
            category = "Core AI",
            description = "Multi-turn context-aware natural language Dharma conversation with scriptural grounding.",
            requiredScope = "CHAT",
            endpoint = "/api/v1/chat",
            sampleInputJson = "{\n  \"query\": \"গীতা অনুসারে কর্মের ফল কী এবং কীভাবে শান্ত থাকতে হয়?\"\n}",
            sampleOutputJson = "{\n  \"answer\": \"...\",\n  \"scripture_references\": [\"BG 2.47\", \"BG 2.48\"],\n  \"is_canonical_verified\": true\n}"
        ),
        VedaNovaCapability(
            code = "DAILY_DATE",
            nameEn = "Gregorian & Ephemeris Resolution",
            nameBn = "দৈনিক গ্রেগরিয়ান ও জ্যোতির্বৈজ্ঞানিক সময় সমাধান",
            category = "Calendar",
            description = "Returns current day, month, year, leap year, and astronomical coordinates.",
            requiredScope = "CALENDAR",
            endpoint = "/api/v1/daily/today",
            sampleInputJson = "{\n  \"region\": \"BANGLADESH_DHAKA\"\n}",
            sampleOutputJson = "{\n  \"gregorian_date\": \"25 August 2026\",\n  \"timezone\": \"Asia/Dhaka\"\n}"
        ),
        VedaNovaCapability(
            code = "BANGLA_DATE",
            nameEn = "Bengali Solar & Lunar Calendar",
            nameBn = "বঙ্গাব্দ, সৌর মাস, তারিখ ও তিথি পঞ্জিকা",
            category = "Calendar",
            description = "Accurate Bengali year, month, date, and lunar paksha calculation according to Surya Siddhanta standard.",
            requiredScope = "CALENDAR",
            endpoint = "/api/v1/daily/today",
            sampleInputJson = "{\n  \"region\": \"BANGLADESH_DHAKA\"\n}",
            sampleOutputJson = "{\n  \"bengali_year\": \"১৪৩৩ বঙ্গাব্দ\",\n  \"bengali_month\": \"ভাদ্র\",\n  \"bengali_day\": \"৯\",\n  \"bengali_weekday\": \"মঙ্গলবার\"\n}"
        ),
        VedaNovaCapability(
            code = "TITHI_INFORMATION",
            nameEn = "Lunar Tithi, Nakshatra & Muhurta",
            nameBn = "তিথি, নক্ষত্র, সূর্যোদয়-সূর্যাস্ত ও মুহূর্ত",
            category = "Calendar",
            description = "Provides current tithi, paksha, nakshatra, brahma muhurta, rahu kala, and abhijit muhurta.",
            requiredScope = "CALENDAR",
            endpoint = "/api/v1/daily/today",
            sampleInputJson = "{\n  \"region\": \"BANGLADESH_DHAKA\"\n}",
            sampleOutputJson = "{\n  \"tithi\": \"শুক্লা দ্বাদশী তিথি\",\n  \"nakshatra\": \"শ্রবণা নক্ষত্র\",\n  \"sunrise\": \"০৫:৩৮ AM\",\n  \"sunset\": \"০৬:২৩ PM\"\n}"
        ),
        VedaNovaCapability(
            code = "UPCOMING_FESTIVAL",
            nameEn = "Festival Countdown & Upcoming Schedule",
            nameBn = "আসন্ন হিন্দু উৎসব ও লাইভ কাউন্টডাউন",
            category = "Festivals",
            description = "Calculates days, hours, and remaining time for major upcoming Hindu festivals.",
            requiredScope = "FESTIVAL",
            endpoint = "/api/v1/daily/festivals/upcoming",
            sampleInputJson = "{}",
            sampleOutputJson = "{\n  \"upcoming_festivals\": [\n    {\n      \"name\": \"Sri Krishna Janmashtami\",\n      \"name_bn\": \"শ্রীশ্রীকৃষ্ণের জন্মাষ্টমী\",\n      \"days_remaining\": 10,\n      \"date\": \"2026-09-04\"\n    }\n  ]\n}"
        ),
        VedaNovaCapability(
            code = "FESTIVAL_DETAILS",
            nameEn = "Deep Festival Rituals & Lore",
            nameBn = "উৎসবের শাস্ত্রীয় বিধি, ইতিহাস ও ব্রতকথা",
            category = "Festivals",
            description = "Complete ritual steps, samagri requirements, fast rules, and scriptural roots of festivals.",
            requiredScope = "FESTIVAL",
            endpoint = "/api/v1/daily/festivals/upcoming",
            sampleInputJson = "{\n  \"festival_id\": \"janmashtami\"\n}",
            sampleOutputJson = "{\n  \"rituals\": [\"Fasting\", \"Abhishekam\"],\n  \"scriptures\": [\"Srimad Bhagavatam Canto 10\"]\n}"
        ),
        VedaNovaCapability(
            code = "PUJA_INFORMATION",
            nameEn = "Puja Vidhi, Samagri & Sankalpa",
            nameBn = "পূজা বিধি, সামগ্রী তালিকা ও সংকল্প বাক্য",
            category = "Puja & Rituals",
            description = "Step-by-step puja guidance, required ingredients, mudras, and mantras.",
            requiredScope = "PUJA",
            endpoint = "/api/v1/puja/info",
            sampleInputJson = "{\n  \"puja_name\": \"Shiva Puja\"\n}",
            sampleOutputJson = "{\n  \"puja_type\": \"Nitya Shiva Puja\",\n  \"steps\": [\"Achamana\", \"Dhyanam\", \"Panchamrita Snana\", \"Belpatra Samarpana\"]\n}"
        ),
        VedaNovaCapability(
            code = "MANTRA_SEARCH",
            nameEn = "Canonical Mantra Search & Audio Rules",
            nameBn = "বৈদিক ও পৌরাণিক মন্ত্র অনুসন্ধান",
            category = "Mantras",
            description = "Verified mantra text in Devanagari, Bengali, IAST transliteration with Vedic accent rules.",
            requiredScope = "MANTRA",
            endpoint = "/api/v1/mantra/search",
            sampleInputJson = "{\n  \"query\": \"Gayatri Mantra\"\n}",
            sampleOutputJson = "{\n  \"sanskrit\": \"ॐ भूर्भुवः स्वः...\",\n  \"bangla_meaning\": \"...\",\n  \"rishi\": \"Vishwamitra\",\n  \"chhandas\": \"Gayatri\"\n}"
        ),
        VedaNovaCapability(
            code = "SCRIPTURE_SEARCH",
            nameEn = "Canonical Scripture & Shloka Retrieval",
            nameBn = "শাস্ত্র ও শ্লোক অনুসন্ধান (বেদ, উপনিষদ, গীতা)",
            category = "Scriptures",
            description = "Exact chapter and verse lookup across Shruti, Smriti, Gita, and Upanishads.",
            requiredScope = "SCRIPTURE",
            endpoint = "/api/v1/scripture/search",
            sampleInputJson = "{\n  \"query\": \"BG 2.47\"\n}",
            sampleOutputJson = "{\n  \"scripture\": \"Bhagavad Gita\",\n  \"chapter\": \"2\",\n  \"verse\": \"47\",\n  \"sanskrit\": \"कर्मण्येवाधिकारस्ते...\"\n}"
        ),
        VedaNovaCapability(
            code = "DAILY_DHARMA",
            nameEn = "Daily Dharma Reflection & Verse",
            nameBn = "দৈনিক আধ্যাত্মিক সুবচন ও গীতা শ্লোক",
            category = "Spiritual Feed",
            description = "Daily inspirational thought, Gita verse, and Sanskrit shloka with Bengali commentary.",
            requiredScope = "CHAT",
            endpoint = "/api/v1/daily/today",
            sampleInputJson = "{}",
            sampleOutputJson = "{\n  \"daily_quote\": \"সত্যমেব জয়তে...\",\n  \"daily_gita\": \"BG 2.47\"\n}"
        ),
        VedaNovaCapability(
            code = "IMAGE_GENERATION",
            nameEn = "Dharma AI Image & Art Generation Engine",
            nameBn = "ধর্ম এআই দিব্য আধ্যাত্মিক চিত্র ও রূপ তৈরীকরণ",
            category = "Visual & Creative AI",
            description = "Internal Image Generation Engine with canonical spiritual prompt enhancement and aspect ratio controls.",
            requiredScope = "IMAGE_GENERATION",
            endpoint = "/api/v1/image/generate",
            sampleInputJson = "{\n  \"prompt\": \"শ্রীকৃষ্ণের একটি দিব্য রূপ\",\n  \"aspect_ratio\": \"1:1\",\n  \"quality\": \"STANDARD\",\n  \"dharma_enhanced\": true\n}",
            sampleOutputJson = "{\n  \"image_code\": \"IMG-12345\",\n  \"image_uri\": \"https://vedanova.storage/images/img_12345.png\",\n  \"local_file_path\": \"/data/user/0/com.example/files/dharma_images/...\",\n  \"aspect_ratio\": \"1:1\",\n  \"dharma_enhanced_prompt\": \"...\",\n  \"status\": \"SUCCESS\"\n}"
        ),
        VedaNovaCapability(
            code = "VISION_UNDERSTANDING",
            nameEn = "Dharma Vision & Sacred Image Understanding",
            nameBn = "ধর্ম ভিশন ও পবিত্র আধ্যাত্মিক চিত্র বিশ্লেষণ",
            category = "Visual & Creative AI",
            description = "Analyzes sacred iconography, deities, mudras, symbols, and spiritual artifacts from image files.",
            requiredScope = "VISION",
            endpoint = "/api/v1/image/understand",
            sampleInputJson = "{\n  \"image_file_path\": \"/path/to/image.jpg\",\n  \"question\": \"এই বিগ্রহের প্রতীক ও আয়ুধ বিশ্লেষণ করুন\"\n}",
            sampleOutputJson = "{\n  \"analysis\": \"...\",\n  \"detected_elements\": [\"Trishula\", \"Damaru\", \"Crescent Moon\"],\n  \"spiritual_significance\": \"...\"\n}"
        ),
        VedaNovaCapability(
            code = "DEEP_RESEARCH",
            nameEn = "Deep Scholarly Research & Cross-Verification",
            nameBn = "গভীর শাস্ত্রীয় গবেষণা ও বহু-উৎস সত্যতা যাচাই",
            category = "Research & Verification",
            description = "Multi-source scholarly web, literature, and cross-tradition consensus research engine.",
            requiredScope = "RESEARCH",
            endpoint = "/api/v1/research",
            sampleInputJson = "{\n  \"query\": \"উপনিষদ ও সাংখ্য দর্শনের মূল পার্থক্য\"\n}",
            sampleOutputJson = "{\n  \"research_topic\": \"...\",\n  \"consensus\": \"...\",\n  \"web_sources\": [...],\n  \"cross_verification\": {...}\n}"
        ),
        VedaNovaCapability(
            code = "SCRIPTURE_VERIFICATION",
            nameEn = "Canonical Authenticity Verification",
            nameBn = "শাস্ত্রীয় প্রামাণিকতা যাচাইকরণ",
            category = "Verification",
            description = "Validates whether a religious claim or verse is canonically grounded in Shruti/Smriti.",
            requiredScope = "VERIFY",
            endpoint = "/api/v1/verify",
            sampleInputJson = "{\n  \"claim\": \"গায়ত্রী মন্ত্র ঋগ্বেদে আছে\"\n}",
            sampleOutputJson = "{\n  \"status\": \"VERIFIED\",\n  \"confidence\": 0.99,\n  \"source\": \"Rigveda 3.62.10\"\n}"
        ),
        VedaNovaCapability(
            code = "KIRTAN_CREATOR",
            nameEn = "AI Kirtan Creator & Devotional Music Intelligence",
            nameBn = "এআই কীর্তন রচয়িতা ও ভক্তি সঙ্গীত উদ্ভাবনী প্ল্যাটফর্ম",
            category = "Creative AI & Devotional Music",
            description = "Professional production-ready Kirtan synthesis engine supporting dynamic title, multi-part Call & Response, tempo curve, and dharma copyright verification.",
            requiredScope = "KIRTAN",
            endpoint = "/api/v1/kirtan/generate",
            sampleInputJson = "{\n  \"prompt\": \"শ্রীকৃষ্ণকে নিয়ে একটি আনন্দময় বাংলা কীর্তন তৈরি করো\",\n  \"mood\": \"Joyful\",\n  \"duration_minutes\": 10,\n  \"language\": \"Bengali\"\n}",
            sampleOutputJson = "{\n  \"title\": \"বৃন্দাবন মাধুর্য প্রেমসুধাময় সংকীর্তন\",\n  \"deity\": \"শ্রীকৃষ্ণ\",\n  \"structure\": \"1. বন্দনা ➔ 2. ধ্রুবপদ ➔ 3. কল-রেসপন্স ➔ 4. অন্তরা ➔ 5. ক্লাইম্যাক্স ➔ 6. সমাপনী ➔ 7. শান্তিপাঠ\",\n  \"is_original_verified\": true\n}"
        )
    )

    fun getCapabilitiesForScopes(scopes: String): List<VedaNovaCapability> {
        val scopeList = scopes.split(",").map { it.trim().uppercase() }
        if (scopeList.contains("*") || scopeList.contains("ALL")) {
            return STANDARD_CAPABILITIES
        }
        return STANDARD_CAPABILITIES.filter { cap ->
            scopeList.contains(cap.requiredScope.uppercase()) ||
            scopeList.contains("ALL") ||
            scopeList.contains(cap.code.uppercase())
        }
    }

    suspend fun analyzeAndProposeCapabilities(
        query: String,
        appName: String,
        proposalDao: CapabilityProposalDao
    ) = withContext(Dispatchers.IO) {
        val qLower = query.lowercase()

        // Detect need for Geo-Localized Puja Muhurta
        if ((qLower.contains("এলাকার") || qLower.contains("লোকাল") || qLower.contains("ঢাকা") || qLower.contains("চট্টগ্রাম") || qLower.contains("কলকাতা")) &&
            (qLower.contains("পূজা") || qLower.contains("সময়") || qLower.contains("মুহূর্ত") || qLower.contains("তিথি"))
        ) {
            val code = "LOCATION_PUJA_TIMING"
            val existing = proposalDao.getAllProposals()
            // We insert if not duplicate
            proposalDao.insertProposal(
                CapabilityProposalEntity(
                    capabilityCode = code,
                    name = "Geo-Localized Puja Muhurta & Tithi Calculator",
                    bengaliName = "স্থানভিত্তিক পূজা তিথি ও শুভ মুহূর্ত গণক",
                    category = "Location / Calendar",
                    description = "Resolves exact local sunrise/sunset and computes local Puja tithi start/end timings dynamically for $appName.",
                    proposedByApp = appName,
                    triggerQuery = query,
                    detectedNeeds = "User GPS/City + Ephemeris Tithi Calculation Engine",
                    inputSchemaJson = "{\n  \"city\": \"String\",\n  \"country\": \"String\",\n  \"puja_name\": \"String\"\n}",
                    outputSchemaJson = "{\n  \"local_tithi_start\": \"ISO-8601\",\n  \"local_tithi_end\": \"ISO-8601\",\n  \"abhijit_muhurta\": \"String\"\n}",
                    safetyRating = "Safe - Composed Read-Only Computation",
                    status = "AI_PROPOSED"
                )
            )
        }

        // Detect need for Custom Sankalpa Generator
        if (qLower.contains("সংকল্প") || qLower.contains("নামে পূজা") || qLower.contains("গোত্র")) {
            val code = "CUSTOM_SANKALPA_GEN"
            proposalDao.insertProposal(
                CapabilityProposalEntity(
                    capabilityCode = code,
                    name = "Personalized Vedic Sankalpa Generator",
                    bengaliName = "ব্যক্তিগত বৈদিক সংকল্প বাক্য প্রস্তুতকারক",
                    category = "Puja / Rituals",
                    description = "Synthesizes authentic Sanskrit Sankalpa substituting Devotee Name, Gotra, Desha, Kala and Purpose for $appName.",
                    proposedByApp = appName,
                    triggerQuery = query,
                    detectedNeeds = "Devotee Details + Dynamic Bengali Year/Tithi/Paksha + Deity Target",
                    inputSchemaJson = "{\n  \"name\": \"String\",\n  \"gotra\": \"String\",\n  \"deity\": \"String\",\n  \"purpose\": \"String\"\n}",
                    outputSchemaJson = "{\n  \"sanskrit_sankalpa\": \"String\",\n  \"bengali_transliteration\": \"String\",\n  \"meaning\": \"String\"\n}",
                    safetyRating = "Safe - Canonical Smriti Formula",
                    status = "AI_PROPOSED"
                )
            )
        }
    }
}
