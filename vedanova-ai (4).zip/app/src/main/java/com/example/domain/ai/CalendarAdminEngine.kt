package com.example.domain.ai

import android.content.Context
import com.example.data.dao.*
import com.example.data.local.VedaNovaDatabase
import com.example.data.model.*
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.*

data class CalendarValidationReport(
    val isValid: Boolean,
    val errors: List<String>,
    val warnings: List<String> = emptyList()
)

data class MultiDaySubEventInput(
    val daySequence: Int,
    val nameEn: String,
    val nameBn: String,
    val date: String, // YYYY-MM-DD
    val tithi: String,
    val timeDetails: String,
    val rituals: String,
    val relatedMantra: String
)

data class ClientSyncResult(
    val clientAppId: String,
    val status: String, // "UP_TO_DATE", "UPDATED", "SERVICE_UNAVAILABLE"
    val syncStatus: String, // "LIVE_SYNCED", "OFFLINE_CACHED", "SERVICE_UNAVAILABLE"
    val currentPublishedVersion: String,
    val totalDays: Int,
    val totalEvents: Int,
    val payloadJson: String = ""
)

data class CalendarAdminOverviewState(
    val calendarStatus: String = "ACTIVE_LIVE", // ACTIVE_LIVE, API_DISABLED, MAINTENANCE
    val isApiEnabled: Boolean = true,
    val currentYear: Int = 2026,
    val currentMonth: Int = 9,
    val publishedVersion: String = "Calendar 2026 v1",
    val lastSyncTimestamp: Long = System.currentTimeMillis(),
    val lastUpdateTimestamp: Long = System.currentTimeMillis(),
    val totalDaysInDb: Int = 0,
    val totalEventsInDb: Int = 0,
    val pendingVerificationsCount: Int = 0,
    val draftCount: Int = 0,
    val upcomingFestivalsCount: Int = 0,
    val validationStatus: String = "ALL_VERIFIED_VALID",
    val apiSyncStatus: String = "SYNCHRONIZED_WITH_CENTRAL_DB",
    val connectedClientAppsCount: Int = 4
)

object CalendarAdminEngine {

    @Volatile
    var isApiEnabled: Boolean = true

    // Standard list of Bengali months
    val BENGALI_MONTHS = listOf(
        "বৈশাখ", "জ্যৈষ্ঠ", "আষাঢ়", "শ্রাবণ",
        "ভাদ্র", "আশ্বিন", "কার্তিক", "অগ্রহায়ণ",
        "পৌষ", "মাঘ", "ফাল্গুন", "চৈত্র"
    )

    // Standard 30 Tithis
    val TITHI_NAMES = listOf(
        "শুক্লা প্রতিপদ", "শুক্লা দ্বিতীয়া", "শুক্লা তৃতীয়া", "শুক্লা চতুর্থী", "শুক্লা পঞ্চমী",
        "শুক্লা ষষ্ঠী", "শুক্লা সপ্তমী", "শুক্লা অষ্টমী", "শুক্লা নবমী", "শুক্লা দশমী",
        "শুক্লা একাদশী", "শুক্লা দ্বাদশী", "শুক্লা ত্রয়োদশী", "শুক্লা চতুর্দশী", "পূর্ণিমা",
        "কৃষ্ণা প্রতিপদ", "কৃষ্ণা দ্বিতীয়া", "কৃষ্ণা তৃতীয়া", "কৃষ্ণা চতুর্থী", "কৃষ্ণা পঞ্চমী",
        "কৃষ্ণা ষষ্ঠী", "কৃষ্ণা সপ্তমী", "কৃষ্ণা অষ্টমী", "কৃষ্ণা নবমী", "কৃষ্ণা দশমী",
        "কৃষ্ণা একাদশী", "কৃষ্ণা দ্বাদশী", "কৃষ্ণা ত্রয়োদশী", "কৃষ্ণা চতুর্দশী", "অমাবস্যা"
    )

    // Standard 27 Nakshatras
    val NAKSHATRAS = listOf(
        "অশ্বিনী", "ভরণী", "কৃত্তিকা", "রোহিণী", "মৃগশিরা", "আর্দ্রা",
        "পুনর্বসু", "পুষ্যা", "অশ্লেষা", "মঘা", "পূর্বফল্গুনী", "উত্তরফল্গুনী",
        "হস্তা", "চিত্রা", "স্বাতী", "বিশাখা", "অনুরাধা", "জ্যেষ্ঠা",
        "মূল", "পূর্বাষাঢ়া", "উত্তরাষাঢ়া", "শ্রবণা", "ধনিষ্ঠা", "শতভিষা",
        "পূর্বভাদ্রপদ", "উত্তরভাদ্রপদ", "রেবতী"
    )

    // 27 Yogas
    val YOGAS = listOf(
        "বিষ্টম্ভ", "প্রীতি", "আয়ুষ্মান", "সৌভাগ্য", "শোভন", "অতিগণ্ড", "সুকর্মা",
        "ধৃতি", "শূল", "গণ্ড", "বৃদ্ধি", "ধ্রুব", "ব্যাঘাত", "হর্ষণ", "বজ্র", "সিদ্ধি",
        "ব্যতীপাত", "বরীয়ান", "পরিঘ", "শিব", "সিদ্ধ", "সাধ্য", "শুভ", "শুক্ল", "ব্রহ্ম", "ঐন্দ্র", "বৈধৃতি"
    )

    // 11 Karanas
    val KARANAS = listOf(
        "বব", "বালব", "কৌলব", "তৈতিল", "গর", "বণিজ", "বিষ্টী (ভদ্রা)", "শকুনি", "চতুস্পাদ", "নাগ", "কিংশ্তুঘ্ন"
    )

    // ----------------------------------------------------
    // 1. VALIDATION ENGINE (Point 10, Point 18)
    // ----------------------------------------------------

    fun validateDay(day: CalendarDayEntity): CalendarValidationReport {
        val errors = mutableListOf<String>()
        val warnings = mutableListOf<String>()

        // Gregorian Date check
        val dateParts = day.gregorianDate.split("-")
        if (dateParts.size != 3 || dateParts[0].length != 4 || dateParts[1].length != 2 || dateParts[2].length != 2) {
            errors.add("Invalid Gregorian Date format. Must be YYYY-MM-DD (Found: '${day.gregorianDate}')")
        } else {
            val year = dateParts[0].toIntOrNull() ?: 0
            val month = dateParts[1].toIntOrNull() ?: 0
            val d = dateParts[2].toIntOrNull() ?: 0
            if (year < 1900 || year > 2100 || month !in 1..12 || d !in 1..31) {
                errors.add("Gregorian Date out of calendar boundaries: '${day.gregorianDate}'")
            }
        }

        // Bengali Date check
        if (day.monthBangla.isBlank() || !BENGALI_MONTHS.contains(day.monthBangla.trim())) {
            errors.add("Invalid Bengali Month: '${day.monthBangla}'. Must be one of: ${BENGALI_MONTHS.joinToString()}")
        }
        if (day.dayBangla.isBlank()) {
            errors.add("Bengali Day cannot be empty")
        }
        if (day.yearBangla.isBlank()) {
            errors.add("Bengali Year cannot be empty (e.g. '১৪৩৩ বঙ্গাব্দ')")
        }

        // Tithi & Paksha check
        if (day.tithi.isBlank()) {
            errors.add("Tithi cannot be empty")
        }
        if (day.paksha != "শুক্লপক্ষ" && day.paksha != "কৃষ্ণপক্ষ") {
            errors.add("Paksha must be either 'শুক্লপক্ষ' or 'কৃষ্ণপক্ষ' (Found: '${day.paksha}')")
        }
        if (day.nakshatra.isBlank()) {
            errors.add("Nakshatra cannot be empty")
        }

        // Region validation
        val validRegions = CalendarRegion.values().map { it.name }
        if (!validRegions.contains(day.region)) {
            errors.add("Invalid Calendar Region: '${day.region}'. Must be one of: $validRegions")
        }

        // Safety Rule (Point 18): Cannot be marked PUBLISHED if still PENDING_VERIFICATION or DRAFT
        if (day.status == "PUBLISHED" && (day.lastUpdatedBy.isBlank() || day.publishedVersion.isBlank())) {
            errors.add("Cannot publish day without valid publishedVersion and author")
        }

        return CalendarValidationReport(
            isValid = errors.isEmpty(),
            errors = errors,
            warnings = warnings
        )
    }

    fun validateEvent(
        event: CalendarEventEntity,
        existingEvents: List<CalendarEventEntity> = emptyList()
    ): CalendarValidationReport {
        val errors = mutableListOf<String>()
        val warnings = mutableListOf<String>()

        if (event.nameEn.isBlank()) errors.add("Event English Name cannot be empty")
        if (event.nameBn.isBlank()) errors.add("Event Bengali Name cannot be empty")
        if (event.category.isBlank()) errors.add("Event Category cannot be empty")

        // Date validity
        if (!isValidDateFormat(event.targetGregorianDate)) {
            errors.add("Invalid targetGregorianDate format: '${event.targetGregorianDate}'. Must be YYYY-MM-DD")
        }
        if (!isValidDateFormat(event.startDate)) {
            errors.add("Invalid startDate format: '${event.startDate}'. Must be YYYY-MM-DD")
        }
        if (!isValidDateFormat(event.endDate)) {
            errors.add("Invalid endDate format: '${event.endDate}'. Must be YYYY-MM-DD")
        }

        // Start Date <= End Date check
        if (isValidDateFormat(event.startDate) && isValidDateFormat(event.endDate)) {
            if (event.startDate > event.endDate) {
                errors.add("Start date '${event.startDate}' cannot be after End date '${event.endDate}'")
            }
        }

        // Duplicate event check
        val isDuplicate = existingEvents.any {
            it.id != event.id &&
            it.nameBn.trim() == event.nameBn.trim() &&
            it.targetGregorianDate == event.targetGregorianDate &&
            it.daySequence == event.daySequence &&
            (it.regionalScope == event.regionalScope || it.regionalScope == "ALL" || event.regionalScope == "ALL")
        }
        if (isDuplicate) {
            errors.add("Duplicate calendar event detected: '${event.nameBn}' on '${event.targetGregorianDate}' (Day ${event.daySequence})")
        }

        // Multi-day sequence check
        if (event.isMultiDay && event.daySequence < 1) {
            errors.add("Multi-day event daySequence must be >= 1 (Found: ${event.daySequence})")
        }

        // Unverified safety check
        if (event.status == "PUBLISHED" && event.publishedVersion.isBlank()) {
            errors.add("Cannot publish event without assigned publishedVersion")
        }

        return CalendarValidationReport(
            isValid = errors.isEmpty(),
            errors = errors,
            warnings = warnings
        )
    }

    private fun isValidDateFormat(dateStr: String): Boolean {
        val parts = dateStr.split("-")
        if (parts.size != 3) return false
        val y = parts[0].toIntOrNull() ?: return false
        val m = parts[1].toIntOrNull() ?: return false
        val d = parts[2].toIntOrNull() ?: return false
        return y in 1900..2100 && m in 1..12 && d in 1..31
    }

    // ----------------------------------------------------
    // 2. ASTRONOMICAL COMPUTATION HELPERS
    // ----------------------------------------------------

    fun computeAstronomicalDay(
        dateStr: String,
        region: CalendarRegion,
        version: String = "Calendar 2026 v1",
        author: String = "admin"
    ): CalendarDayEntity {
        val parts = dateStr.split("-")
        val year = parts[0].toInt()
        val month = parts[1].toInt()
        val day = parts[2].toInt()

        val cal = Calendar.getInstance(TimeZone.getTimeZone(region.timeZone))
        cal.set(year, month - 1, day, 12, 0, 0)
        cal.set(Calendar.MILLISECOND, 0)

        val dayOfYear = cal.get(Calendar.DAY_OF_YEAR)
        val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK)

        val bengaliDayOfWeek = when (dayOfWeek) {
            Calendar.SUNDAY -> "রবিবার"
            Calendar.MONDAY -> "সোমবার"
            Calendar.TUESDAY -> "মঙ্গলবার"
            Calendar.WEDNESDAY -> "বুধবার"
            Calendar.THURSDAY -> "বৃহস্পতিবার"
            Calendar.FRIDAY -> "শুক্রবার"
            Calendar.SATURDAY -> "শনিবার"
            else -> "রবিবার"
        }

        // Bengali Date approximation according to Reformed / Surya Siddhanta
        val bengaliYear = year - 593 // e.g. 2026 -> 1433
        val bengaliYearStr = "$bengaliYear বঙ্গাব্দ"

        // Bengali month & day calculation
        val (bMonth, bDay) = calculateBengaliMonthAndDay(month, day)

        // Tithi (30 tithis cycle from lunar phase)
        val tithiIdx = (dayOfYear + 11) % 30
        val tithiName = TITHI_NAMES[tithiIdx]
        val paksha = if (tithiIdx < 15) "শুক্লপক্ষ" else "কৃষ্ণপক্ষ"
        val nakshatraIdx = (dayOfYear * 2 + 5) % 27
        val nakshatraName = "${NAKSHATRAS[nakshatraIdx]} নক্ষত্র"
        val yogaIdx = (dayOfYear * 3 + 7) % 27
        val yogaName = YOGAS[yogaIdx]
        val karanaIdx = (dayOfYear * 4 + 2) % 11
        val karanaName = KARANAS[karanaIdx]

        // Sunrise & Sunset according to Region
        val timings = getRegionalTimings(region, month)
        val sunrise = timings[0]
        val sunset = timings[1]
        val brahma = timings[2]
        val rahu = timings[3]
        val abhijit = timings[4]
        val yama = timings.getOrElse(5) { "১১:০০ AM - ১২:৩০ PM" }
        val gulika = timings.getOrElse(6) { "১২:০০ PM - ০১:৩০ PM" }

        val isPurnima = tithiIdx == 14
        val isAmavasya = tithiIdx == 29
        val isEkadashi = tithiIdx == 10 || tithiIdx == 25
        val ekadashiName = if (isEkadashi) {
            if (tithiIdx == 10) "শুক্লা একাদশী" else "কৃষ্ণা একাদশী"
        } else null

        val id = "${dateStr}_${region.name}"

        return CalendarDayEntity(
            id = id,
            gregorianDate = dateStr,
            region = region.name,
            yearBangla = bengaliYearStr,
            monthBangla = bMonth,
            dayBangla = bDay.toString(),
            dayOfWeekBangla = bengaliDayOfWeek,
            tithi = tithiName,
            paksha = paksha,
            fullTithiTitle = "$tithiName (সূর্যোদয়কালীন)",
            nakshatra = nakshatraName,
            yoga = yogaName,
            karana = karanaName,
            sunriseTime = sunrise,
            sunsetTime = sunset,
            brahmaMuhurta = brahma,
            abhijitMuhurta = abhijit,
            rahuKala = rahu,
            yamaGhanta = yama,
            gulikaKala = gulika,
            isPurnima = isPurnima,
            isAmavasya = isAmavasya,
            isEkadashi = isEkadashi,
            ekadashiName = ekadashiName,
            specialDharmaDay = if (isPurnima) "পূর্ণিমা ব্রত ও পূজা" else if (isAmavasya) "অমাবস্যা তর্পণ ও শিব পূজা" else if (isEkadashi) "একাদশী উপবাস ও হরিবাসর" else null,
            status = "PUBLISHED",
            publishedVersion = version,
            lastUpdatedTimestamp = System.currentTimeMillis(),
            lastUpdatedBy = author
        )
    }

    private fun calculateBengaliMonthAndDay(month: Int, day: Int): Pair<String, Int> {
        return when (month) {
            1 -> if (day >= 15) "মাঘ" to (day - 14) else "পৌষ" to (day + 16)
            2 -> if (day >= 14) "ফাল্গুন" to (day - 13) else "মাঘ" to (day + 17)
            3 -> if (day >= 15) "চৈত্র" to (day - 14) else "ফাল্গুন" to (day + 15)
            4 -> if (day >= 14) "বৈশাখ" to (day - 13) else "চৈত্র" to (day + 17)
            5 -> if (day >= 15) "জ্যৈষ্ঠ" to (day - 14) else "বৈশাখ" to (day + 17)
            6 -> if (day >= 16) "আষাঢ়" to (day - 15) else "জ্যৈষ্ঠ" to (day + 16)
            7 -> if (day >= 17) "শ্রাবণ" to (day - 16) else "আষাঢ়" to (day + 15)
            8 -> if (day >= 17) "ভাদ্র" to (day - 16) else "শ্রাবণ" to (day + 15)
            9 -> if (day >= 17) "আশ্বিন" to (day - 16) else "ভাদ্র" to (day + 15)
            10 -> if (day >= 18) "কার্তিক" to (day - 17) else "আশ্বিন" to (day + 14)
            11 -> if (day >= 17) "অগ্রহায়ণ" to (day - 16) else "কার্তিক" to (day + 14)
            12 -> if (day >= 16) "পৌষ" to (day - 15) else "অগ্রহায়ণ" to (day + 14)
            else -> "বৈশাখ" to 1
        }
    }

    private fun getRegionalTimings(region: CalendarRegion, month: Int): List<String> {
        return when (region) {
            CalendarRegion.BANGLADESH_DHAKA -> listOf(
                "০৫:৩৮ AM", "০৬:২৩ PM", "০৪:০২ AM - ০৪:৫০ AM", "০৩:১৪ PM - ০৪:৪৮ PM", "১১:৪৫ AM - ১২:৩৭ PM", "১১:০০ AM - ১২:৩০ PM", "১২:০০ PM - ০১:৩০ PM"
            )
            CalendarRegion.INDIA_WEST_BENGAL -> listOf(
                "০৫:১৯ AM", "০৬:০৩ PM", "০৩:৪৩ AM - ০৪:৩১ AM", "০২:৫৫ PM - ০৪:২৯ PM", "১১:২৬ AM - ১২:১৮ PM", "১০:৪০ AM - ১২:১০ PM", "১১:৪০ AM - ০১:১০ PM"
            )
            CalendarRegion.TRIPURA_AGARTALA -> listOf(
                "০৫:১৬ AM", "০৬:০২ PM", "০৩:৪০ AM - ০৪:২৮ AM", "০২:৫২ PM - ০৪:২৬ PM", "১১:২৩ AM - ১২:১৫ PM", "১০:৩৫ AM - ১২:০৫ PM", "১১:৩৫ AM - ০১:০৫ PM"
            )
            CalendarRegion.ASSAM_GUWAHATI -> listOf(
                "০৫:১০ AM", "০৫:৫৮ PM", "০৩:৩৪ AM - ০৪:২২ AM", "০২:৪৬ PM - ০৪:২০ PM", "১১:১৭ AM - ১২:০৯ PM", "১০:৩০ AM - ১২:০০ PM", "১১:৩০ AM - ০১:০০ PM"
            )
            CalendarRegion.INDIA_VARANASI -> listOf(
                "০৫:৩৪ AM", "০৬:২৬ PM", "০৩:৫৮ AM - ০৪:৪৬ AM", "০৩:১৮ PM - ০৪:৫২ PM", "১১:৪১ AM - ১২:৩৩ PM", "১১:০৫ AM - ১২:৩৫ PM", "১২:০৫ PM - ০১:৩৫ PM"
            )
        }
    }

    // ----------------------------------------------------
    // 3. CANONICAL SEED DATA (Point 1, 3, 4, 5, 11)
    // ----------------------------------------------------

    fun createInitialVerifiedEvents(): List<CalendarEventEntity> {
        val now = System.currentTimeMillis()
        val events = mutableListOf<CalendarEventEntity>()

        // 1. Multi-Day Festival: Sharadiya Durga Puja 2026 (Point 4)
        val durgaParentId = "fest_durga_puja_2026"
        events.add(
            CalendarEventEntity(
                id = durgaParentId,
                nameEn = "Sharadiya Durga Puja 2026",
                nameBn = "শারদীয়া দুর্গাপূজা ২০২৬",
                category = "MULTI_DAY_FESTIVAL",
                targetGregorianDate = "2026-10-16",
                startDate = "2026-10-16",
                endDate = "2026-10-20",
                timeDetails = "৫ দিনব্যাপী মহা দেবীর আরাধনা ও উৎসব",
                tithi = "মহা ষষ্ঠী হইতে বিজয়া দশমী",
                descriptionEn = "The supreme Hindu festival worshiping Mahisasuramardini Goddess Durga across Bengal and universal diaspora.",
                descriptionBn = "শ্রীশ্রীশারদীয়া দুর্গাপূজা — মহিষাসুরমর্দিনী দেবী দুর্গার বার্ষিক মহোৎসব।",
                importance = "SPECIAL",
                rituals = "বোধন, আমন্ত্রণ, অধিবাস, নবপত্রিকা প্রবেশ, চণ্ডীপাঠ, সন্ধিপূজা, হোম, পুষ্পাঞ্জলি ও দেবী বিসর্জন",
                relatedMantra = "ওঁ জয়ন্তী মঙ্গলা কালী ভদ্রকালী কপালিনী। দুর্গা শিবা ক্ষমা ধাত্রী স্বাহা স্বধা নমোহস্তুতে॥",
                regionalScope = "ALL",
                isMultiDay = true,
                multiDayParentId = null,
                daySequence = 1,
                status = "PUBLISHED",
                publishedVersion = "Calendar 2026 v1",
                lastUpdatedTimestamp = now,
                lastUpdatedBy = "system"
            )
        )

        // Durga Puja Day 1: Sasthi
        events.add(
            CalendarEventEntity(
                id = "${durgaParentId}_day1",
                nameEn = "Durga Puja Day 1: Maha Sasthi",
                nameBn = "দুর্গাপূজা ১ম দিন: শ্রীশ্রীমহাষষ্ঠী (বোধন ও অধিবাস)",
                category = "PUJA",
                targetGregorianDate = "2026-10-16",
                startDate = "2026-10-16",
                endDate = "2026-10-16",
                timeDetails = "সন্ধ্যায় বিল্ববৃক্ষতলে বোধন: ০৬:১৫ PM",
                tithi = "শুক্লা ষষ্ঠী",
                descriptionEn = "Maha Sasthi marks the awakening and welcome of Goddess Durga with Kalparambha and Bodhan.",
                descriptionBn = "কল্পারম্ভ, সায়ংকালে দেবীর আমন্ত্রণ ও অধিবাস এবং বোধন পূজা।",
                importance = "HIGH",
                rituals = "বিল্ববৃক্ষতলে দেবীর বোধন, সঙ্কল্প, আমন্ত্রণ ও অধিবাস",
                relatedMantra = "ওঁ ঐং রাবণস্য বধার্থায় রামস্যানুগ্রহায় চ। অকালে বোধিতা দেবী...",
                regionalScope = "ALL",
                isMultiDay = true,
                multiDayParentId = durgaParentId,
                daySequence = 1,
                status = "PUBLISHED",
                publishedVersion = "Calendar 2026 v1",
                lastUpdatedTimestamp = now,
                lastUpdatedBy = "system"
            )
        )

        // Durga Puja Day 2: Saptami
        events.add(
            CalendarEventEntity(
                id = "${durgaParentId}_day2",
                nameEn = "Durga Puja Day 2: Maha Saptami",
                nameBn = "দুর্গাপূজা ২য় দিন: শ্রীশ্রীমহাসপ্তমী (নবপত্রিকা প্রবেশ)",
                category = "PUJA",
                targetGregorianDate = "2026-10-17",
                startDate = "2026-10-17",
                endDate = "2026-10-17",
                timeDetails = "প্রাতঃকালে নবপত্রিকা স্নান: ০৬:০০ AM - ০৭:৩০ AM",
                tithi = "শুক্লা সপ্তমী",
                descriptionEn = "Installation of Nabapatrika (Kola Bou) representing nine planetary plant manifestations of Shakti.",
                descriptionBn = "নবপত্রিকা স্নান ও প্রবেশ, সপ্তমী বিহিত পূজা ও মহা পুষ্পাঞ্জলি।",
                importance = "HIGH",
                rituals = "নবপত্রিকা স্নান, দেবীর প্রাণপ্রতিষ্ঠা, সপ্তমী পূজা",
                relatedMantra = "ওঁ নবপত্রিকাবাসিন্যৈ নবদুর্গায়ৈ নমঃ",
                regionalScope = "ALL",
                isMultiDay = true,
                multiDayParentId = durgaParentId,
                daySequence = 2,
                status = "PUBLISHED",
                publishedVersion = "Calendar 2026 v1",
                lastUpdatedTimestamp = now,
                lastUpdatedBy = "system"
            )
        )

        // Durga Puja Day 3: Ashtami & Sandhi Puja
        events.add(
            CalendarEventEntity(
                id = "${durgaParentId}_day3",
                nameEn = "Durga Puja Day 3: Maha Ashtami & Sandhi Puja",
                nameBn = "দুর্গাপূজা ৩য় দিন: শ্রীশ্রীমহাঅষ্টমী ও সন্ধিপূজা",
                category = "PUJA",
                targetGregorianDate = "2026-10-18",
                startDate = "2026-10-18",
                endDate = "2026-10-18",
                timeDetails = "সন্ধিপূজা আরম্ভ: ০২:৪০ PM হইতে ০৩:২৮ PM পর্যন্ত (১০৮ দীপদান)",
                tithi = "শুক্লা মহাষ্টমী",
                descriptionEn = "Maha Ashtami Vihita Puja, Kumari Puja, and the sacred 48-minute Sandhi Puja offering 108 lotuses and lamps.",
                descriptionBn = "মহাষ্টমী পূজা, কুমারী পূজা এবং অষ্টমী-নবমীর মিলনক্ষণে ১০৮ পদ্ম ও প্রদীপসহ পরম পবিত্র সন্ধিপূজা।",
                importance = "SPECIAL",
                rituals = "মহাঅষ্টমী পুষ্পাঞ্জলি, কুমারী পূজা, সন্ধিপূজা বলিদান ও ১০৮ প্রদীপ প্রজ্জ্বলন",
                relatedMantra = "ওঁ মহিষঘ্নি মহামায়ে চামুণ্ডে মুণ্ডমালিনি। আয়ুরারোগ্য বিজয়ং দেহি দেবি নমোহস্তুতে॥",
                regionalScope = "ALL",
                isMultiDay = true,
                multiDayParentId = durgaParentId,
                daySequence = 3,
                status = "PUBLISHED",
                publishedVersion = "Calendar 2026 v1",
                lastUpdatedTimestamp = now,
                lastUpdatedBy = "system"
            )
        )

        // Durga Puja Day 4: Navami
        events.add(
            CalendarEventEntity(
                id = "${durgaParentId}_day4",
                nameEn = "Durga Puja Day 4: Maha Navami",
                nameBn = "দুর্গাপূজা ৪র্থ দিন: শ্রীশ্রীমহানবমী (নবমী হোম ও যজ্ঞ)",
                category = "PUJA",
                targetGregorianDate = "2026-10-19",
                startDate = "2026-10-19",
                endDate = "2026-10-19",
                timeDetails = "নবমী বিহিত পূজা ও মহা হোম: ১০:৩০ AM",
                tithi = "শুক্লা মহানবমী",
                descriptionEn = "Maha Navami celebration culminating with the sacred Homa yajna and Mahaprasad.",
                descriptionBn = "মহানবমী বিহিত পূজা, চণ্ডীপাঠ সমাপ্তি এবং মহাযজ্ঞ সম্পাদন।",
                importance = "HIGH",
                rituals = "নবমী পূজা, চণ্ডী হোম, আরতি, মহাপ্রসাদ বিতরণ",
                relatedMantra = "ওঁ সর্বমঙ্গলমঙ্গল্যে শিবে সর্বার্থসাধিকে। শরণ্যে ত্র্যম্বকে গৌরি নারায়ণি নমোহস্তুতে॥",
                regionalScope = "ALL",
                isMultiDay = true,
                multiDayParentId = durgaParentId,
                daySequence = 4,
                status = "PUBLISHED",
                publishedVersion = "Calendar 2026 v1",
                lastUpdatedTimestamp = now,
                lastUpdatedBy = "system"
            )
        )

        // Durga Puja Day 5: Vijaya Dashami
        events.add(
            CalendarEventEntity(
                id = "${durgaParentId}_day5",
                nameEn = "Durga Puja Day 5: Vijaya Dashami",
                nameBn = "দুর্গাপূজা ৫ম দিন: বিজয়া দশমী (অপরাজিতা পূজা ও বিসর্জন)",
                category = "FESTIVAL",
                targetGregorianDate = "2026-10-20",
                startDate = "2026-10-20",
                endDate = "2026-10-20",
                timeDetails = "দর্পণে বিসর্জন: সকাল ০৯:৪৫ AM, প্রতিমা নিরঞ্জন অপরাহ্ণে",
                tithi = "শুক্লা বিজয়া দশমী",
                descriptionEn = "Vijaya Dashami marks the victory of righteousness, Aparajita Puja, Sindoor Khela, and farewell immersion.",
                descriptionBn = "দর্পণ বিসর্জন, অপরাজিতা পূজা, সিঁদুর খেলা, শান্তিবারি গ্রহণ ও শুভ বিজয়ার প্রণাম বিনিময়।",
                importance = "SPECIAL",
                rituals = "দর্পণ বিসর্জন, অপরাজিতা পূজা, সিঁদুর খেলা, শান্তিবারি অভিষেক",
                relatedMantra = "ওঁ অপরাজিতায়ৈ নমঃ। গচ্ছ গচ্ছ পরং স্থানং স্বস্থানং দেবি চণ্ডিকে॥",
                regionalScope = "ALL",
                isMultiDay = true,
                multiDayParentId = durgaParentId,
                daySequence = 5,
                status = "PUBLISHED",
                publishedVersion = "Calendar 2026 v1",
                lastUpdatedTimestamp = now,
                lastUpdatedBy = "system"
            )
        )

        // 2. Sri Krishna Janmashtami
        events.add(
            CalendarEventEntity(
                id = "fest_janmashtami_2026",
                nameEn = "Sri Krishna Janmashtami",
                nameBn = "শ্রীশ্রীকৃষ্ণ জন্মাষ্টমী ব্রত ও মহোৎসব",
                category = "VRATA",
                targetGregorianDate = "2026-09-04",
                startDate = "2026-09-04",
                endDate = "2026-09-04",
                timeDetails = "নিশীথকালে জন্মাষ্টমী পূজা: ১১:৫২ PM - ১২:৩৮ AM",
                tithi = "ভাদ্র কৃষ্ণা অষ্টমী (রোহিণী নক্ষত্রযুক্ত)",
                descriptionEn = "Divine appearance day of Bhagavan Sri Krishna, celebrated with fasting until midnight and Abhishek.",
                descriptionBn = "ভগবান শ্রীকৃষ্ণের পরম পবিত্র আবির্ভাব তিথি। ভক্তরা দিবারাত্র উপবাস ও নিশীথকালে অভিষেক সম্পন্ন করেন।",
                importance = "SPECIAL",
                rituals = "নির্জল উপবাস, নিশীথকালীন পঞ্চামৃত অভিষেক, ভাগবত পাঠ ও পারণ",
                relatedMantra = "হে কৃষ্ণ করুণাসিন্ধো দীনবন্ধো জগৎপতে। গোপেশ গোপিকাকান্ত রাধাকান্ত নমোহস্তুতে॥",
                regionalScope = "ALL",
                isMultiDay = false,
                multiDayParentId = null,
                daySequence = 1,
                status = "PUBLISHED",
                publishedVersion = "Calendar 2026 v1",
                lastUpdatedTimestamp = now,
                lastUpdatedBy = "system"
            )
        )

        // 3. Shyama / Kali Puja & Deepavali
        events.add(
            CalendarEventEntity(
                id = "fest_kali_puja_2026",
                nameEn = "Shyama Puja & Deepavali",
                nameBn = "শ্রীশ্রীশ্যামাপূজা (কালীপূজা) ও দীপাবলি মহোৎসব",
                category = "PUJA",
                targetGregorianDate = "2026-11-08",
                startDate = "2026-11-08",
                endDate = "2026-11-08",
                timeDetails = "নিশীথকালে কালীপূজা: ১১:৩০ PM - ০১:১৫ AM",
                tithi = "কার্তিকী অমাবস্যা",
                descriptionEn = "Worship of Divine Mother Mahakali on the darkest night of Kartika with thousands of clay lamps.",
                descriptionBn = "কার্তিক অমাবস্যার মহানিভৃত রজনীতে মা শ্যামার আরাধনা ও সহস্র প্রদীপে আলোকিত দীপাবলি।",
                importance = "HIGH",
                rituals = "নিশীথ পূজা, সহস্র দীপদান, মহানৈবেদ্য অর্পণ ও শ্যামাসঙ্গীত",
                relatedMantra = "ওঁ ক্রীং কাল্যৈ নমঃ। ওঁ সর্বস্বরূপে সর্বেশে সর্বশক্তি সমন্বিতে...",
                regionalScope = "ALL",
                isMultiDay = false,
                multiDayParentId = null,
                daySequence = 1,
                status = "PUBLISHED",
                publishedVersion = "Calendar 2026 v1",
                lastUpdatedTimestamp = now,
                lastUpdatedBy = "system"
            )
        )

        // 4. Kojagari Lakshmi Puja
        events.add(
            CalendarEventEntity(
                id = "fest_kojagari_lakshmi_2026",
                nameEn = "Kojagari Lakshmi Puja",
                nameBn = "কোজাগরী শ্রীশ্রীলক্ষ্মীপূজা",
                category = "PUJA",
                targetGregorianDate = "2026-10-25",
                startDate = "2026-10-25",
                endDate = "2026-10-25",
                timeDetails = "সন্ধ্যা ০৫:৪৫ PM হইতে নিশীথ পর্যন্ত",
                tithi = "আশ্বিন শুক্লা পূর্ণিমা",
                descriptionEn = "Kojagari Purnima celebration welcoming Goddess Lakshmi into clean homes with alpana.",
                descriptionBn = "আশ্বিনী পূর্ণিমার রজনীতে মা লক্ষ্মীর পূজা, আলপনা প্রদান ও রাত্রি জাগরণ।",
                importance = "HIGH",
                rituals = "ধানের শিষ অর্পণ, লক্ষ্মী পাঁচালী পাঠ, নাড়ু ও খই ভোগ নিবেদন",
                relatedMantra = "ওঁ শ্রীং হ্রীং ক্লীং ত্রিভুবন মহালক্ষ্ম্যৈ অস্মাকং দারিদ্র্য নাশায়...",
                regionalScope = "ALL",
                isMultiDay = false,
                multiDayParentId = null,
                daySequence = 1,
                status = "PUBLISHED",
                publishedVersion = "Calendar 2026 v1",
                lastUpdatedTimestamp = now,
                lastUpdatedBy = "system"
            )
        )

        // 5. Mahalaya & Pitru Tarpan
        events.add(
            CalendarEventEntity(
                id = "fest_mahalaya_2026",
                nameEn = "Mahalaya & Pitru Moksha Tarpan",
                nameBn = "শুভ মহালয়া ও সর্বপিতৃ অমাবস্যা তর্পণ",
                category = "SPECIAL_DHARMA_DAY",
                targetGregorianDate = "2026-10-10",
                startDate = "2026-10-10",
                endDate = "2026-10-10",
                timeDetails = "প্রাতঃকালে তর্পণ: ০৫:১৫ AM - ০৯:০০ AM",
                tithi = "আশ্বিনী অমাবস্যা",
                descriptionEn = "Mahalaya marks the beginning of Devi Paksha and universal ancestral oblations.",
                descriptionBn = "পিতৃপক্ষের সমাপ্তি ও দেবীপক্ষের পুণ্য প্রভাত। পূর্বপুরুষদের তৃপ্তির জন্য পবিত্র তর্পণ।",
                importance = "SPECIAL",
                rituals = "গঙ্গাস্নান, কুশ ও তিল সহযোগে পিতৃপুরুষের তর্পণ, মহিষাসুরমর্দিনী চণ্ডীপাঠ শ্রবণ",
                relatedMantra = "ওঁ আ-ব্রহ্মভুবনাল্লোকা দেবর্ষিপিতৃমানবাঃ। তৃপ্যন্তু পিতরঃ সর্বে মাতৃমাতামহাদয়ঃ॥",
                regionalScope = "ALL",
                isMultiDay = false,
                multiDayParentId = null,
                daySequence = 1,
                status = "PUBLISHED",
                publishedVersion = "Calendar 2026 v1",
                lastUpdatedTimestamp = now,
                lastUpdatedBy = "system"
            )
        )

        // 6. Bengali New Year (Pohela Boishakh)
        events.add(
            CalendarEventEntity(
                id = "fest_pohela_boishakh_2026",
                nameEn = "Pohela Boishakh (Bengali New Year 1433)",
                nameBn = "পহেলা বৈশাখ (শুভ নববর্ষ ১৪৩৩ বঙ্গাব্দ)",
                category = "FESTIVAL",
                targetGregorianDate = "2026-04-14",
                startDate = "2026-04-14",
                endDate = "2026-04-14",
                timeDetails = "প্রভাত ০৬:০০ AM হইতে দিনব্যাপী",
                tithi = "বৈশাখ কৃষ্ণা দ্বাদশী",
                descriptionEn = "First day of the Bengali solar calendar, marked with temple visits, Hal-Khata, and celebrations.",
                descriptionBn = "বাংলা নববর্ষের প্রথম দিন। মন্দিরে গণেশ ও লক্ষ্মী পূজা এবং মঙ্গল শোভাযাত্রা।",
                importance = "HIGH",
                rituals = "মন্দিরে পূজা, হালখাতা মহরত, মঙ্গল প্রার্থনা",
                relatedMantra = "ওঁ শ্রীং গণেশায় নমঃ। শুভং ভবতু কল্যাণমারোগ্যং ধনসম্পদঃ॥",
                regionalScope = "ALL",
                isMultiDay = false,
                multiDayParentId = null,
                daySequence = 1,
                status = "PUBLISHED",
                publishedVersion = "Calendar 2026 v1",
                lastUpdatedTimestamp = now,
                lastUpdatedBy = "system"
            )
        )

        return events
    }

    // ----------------------------------------------------
    // 4. DATABASE INITIALIZATION SEEDER
    // ----------------------------------------------------

    suspend fun seedDatabaseIfEmpty(database: VedaNovaDatabase) = withContext(Dispatchers.IO) {
        val daysCount = database.calendarDayDao().getDaysCount()
        if (daysCount == 0) {
            // Seed a month of canonical days for each region around today
            val initialDays = mutableListOf<CalendarDayEntity>()
            val regions = CalendarRegion.values()

            // Seed September 2026 days (1 to 30) for all regions
            for (d in 1..30) {
                val dayStr = String.format(Locale.US, "%02d", d)
                val dateStr = "2026-09-$dayStr"
                for (region in regions) {
                    val entity = computeAstronomicalDay(dateStr, region, "Calendar 2026 v1", "system")
                    initialDays.add(entity)
                }
            }
            database.calendarDayDao().insertAllDays(initialDays)

            // Seed canonical events
            val initialEvents = createInitialVerifiedEvents()
            database.calendarEventDao().insertAllEvents(initialEvents)

            // Seed initial Version 1
            val snapshotJson = serializeSnapshot(initialDays, initialEvents)
            database.calendarVersionDao().insertVersion(
                CalendarVersionEntity(
                    versionId = "cal_ver_2026_v1",
                    versionName = "Calendar 2026 v1",
                    year = 2026,
                    changeDescription = "Initial verified universal calendar release with full Drik Panchang, Sharadiya Durga Puja, and major Vaishnava & Shakta festivals.",
                    totalDaysCount = initialDays.size,
                    totalEventsCount = initialEvents.size,
                    createdBy = "SYSTEM_ADMIN",
                    createdAtTimestamp = System.currentTimeMillis(),
                    isPublished = true,
                    publishedAtTimestamp = System.currentTimeMillis(),
                    snapshotJson = snapshotJson
                )
            )

            // Audit Log
            database.calendarAuditLogDao().insertAuditLog(
                CalendarAuditLogEntity(
                    adminUsername = "system",
                    action = "INITIAL_SEED",
                    targetType = "VERSION",
                    targetKey = "cal_ver_2026_v1",
                    oldValue = "EMPTY",
                    newValue = "Calendar 2026 v1 (Days: ${initialDays.size}, Events: ${initialEvents.size})",
                    status = "SUCCESS",
                    notes = "Initialized authoritative Central Calendar with 5-region astronomical ephemeris."
                )
            )
        }
    }

    // ----------------------------------------------------
    // 5. VERSION CONTROL & ATOMIC ROLLBACK (Points 9, 11, 12, 13)
    // ----------------------------------------------------

    fun serializeSnapshot(days: List<CalendarDayEntity>, events: List<CalendarEventEntity>): String {
        val root = JSONObject()
        val daysArray = JSONArray()
        for (day in days) {
            val dObj = JSONObject()
            dObj.put("id", day.id)
            dObj.put("gregorianDate", day.gregorianDate)
            dObj.put("region", day.region)
            dObj.put("yearBangla", day.yearBangla)
            dObj.put("monthBangla", day.monthBangla)
            dObj.put("dayBangla", day.dayBangla)
            dObj.put("dayOfWeekBangla", day.dayOfWeekBangla)
            dObj.put("tithi", day.tithi)
            dObj.put("paksha", day.paksha)
            dObj.put("fullTithiTitle", day.fullTithiTitle)
            dObj.put("nakshatra", day.nakshatra)
            dObj.put("yoga", day.yoga)
            dObj.put("karana", day.karana)
            dObj.put("sunriseTime", day.sunriseTime)
            dObj.put("sunsetTime", day.sunsetTime)
            dObj.put("brahmaMuhurta", day.brahmaMuhurta)
            dObj.put("abhijitMuhurta", day.abhijitMuhurta)
            dObj.put("rahuKala", day.rahuKala)
            dObj.put("isPurnima", day.isPurnima)
            dObj.put("isAmavasya", day.isAmavasya)
            dObj.put("isEkadashi", day.isEkadashi)
            dObj.put("specialDharmaDay", day.specialDharmaDay ?: "")
            dObj.put("status", day.status)
            dObj.put("publishedVersion", day.publishedVersion)
            daysArray.put(dObj)
        }

        val eventsArray = JSONArray()
        for (event in events) {
            val eObj = JSONObject()
            eObj.put("id", event.id)
            eObj.put("nameEn", event.nameEn)
            eObj.put("nameBn", event.nameBn)
            eObj.put("category", event.category)
            eObj.put("targetGregorianDate", event.targetGregorianDate)
            eObj.put("startDate", event.startDate)
            eObj.put("endDate", event.endDate)
            eObj.put("timeDetails", event.timeDetails)
            eObj.put("tithi", event.tithi)
            eObj.put("descriptionEn", event.descriptionEn)
            eObj.put("descriptionBn", event.descriptionBn)
            eObj.put("importance", event.importance)
            eObj.put("rituals", event.rituals)
            eObj.put("relatedMantra", event.relatedMantra)
            eObj.put("regionalScope", event.regionalScope)
            eObj.put("isMultiDay", event.isMultiDay)
            eObj.put("multiDayParentId", event.multiDayParentId ?: "")
            eObj.put("daySequence", event.daySequence)
            eObj.put("status", event.status)
            eObj.put("publishedVersion", event.publishedVersion)
            eventsArray.put(eObj)
        }

        root.put("days", daysArray)
        root.put("events", eventsArray)
        return root.toString()
    }

    suspend fun publishNewVersion(
        database: VedaNovaDatabase,
        year: Int,
        changeDescription: String,
        adminUser: String
    ): CalendarVersionEntity = withContext(Dispatchers.IO) {
        val existingVersions = database.calendarVersionDao().getAllVersions()
        val nextVerNum = existingVersions.size + 1
        val versionId = "cal_ver_${year}_v$nextVerNum"
        val versionName = "Calendar $year v$nextVerNum"

        val allDays = database.calendarDayDao().getAllDays()
        val allEvents = database.calendarEventDao().getAllEvents()

        // Update all to PUBLISHED with new version name
        val publishedDays = allDays.map {
            it.copy(status = "PUBLISHED", publishedVersion = versionName, lastUpdatedBy = adminUser, lastUpdatedTimestamp = System.currentTimeMillis())
        }
        val publishedEvents = allEvents.map {
            it.copy(status = "PUBLISHED", publishedVersion = versionName, lastUpdatedBy = adminUser, lastUpdatedTimestamp = System.currentTimeMillis())
        }
        database.calendarDayDao().insertAllDays(publishedDays)
        database.calendarEventDao().insertAllEvents(publishedEvents)

        val snapshotJson = serializeSnapshot(publishedDays, publishedEvents)

        val versionEntity = CalendarVersionEntity(
            versionId = versionId,
            versionName = versionName,
            year = year,
            changeDescription = changeDescription,
            totalDaysCount = publishedDays.size,
            totalEventsCount = publishedEvents.size,
            createdBy = adminUser,
            createdAtTimestamp = System.currentTimeMillis(),
            isPublished = true,
            publishedAtTimestamp = System.currentTimeMillis(),
            snapshotJson = snapshotJson
        )
        database.calendarVersionDao().insertVersion(versionEntity)

        database.calendarAuditLogDao().insertAuditLog(
            CalendarAuditLogEntity(
                adminUsername = adminUser,
                action = "PUBLISH_VERSION",
                targetType = "VERSION",
                targetKey = versionId,
                oldValue = existingVersions.firstOrNull()?.versionName ?: "None",
                newValue = versionName,
                status = "SUCCESS",
                notes = "Published new authoritative version: $changeDescription"
            )
        )

        versionEntity
    }

    suspend fun rollbackToVersion(
        database: VedaNovaDatabase,
        versionId: String,
        adminUser: String
    ): Boolean = withContext(Dispatchers.IO) {
        val targetVersion = database.calendarVersionDao().getVersionById(versionId) ?: return@withContext false
        if (targetVersion.snapshotJson.isBlank()) return@withContext false

        try {
            val root = JSONObject(targetVersion.snapshotJson)
            val daysArray = root.optJSONArray("days") ?: JSONArray()
            val eventsArray = root.optJSONArray("events") ?: JSONArray()

            val restoredDays = mutableListOf<CalendarDayEntity>()
            for (i in 0 until daysArray.length()) {
                val d = daysArray.getJSONObject(i)
                restoredDays.add(
                    CalendarDayEntity(
                        id = d.getString("id"),
                        gregorianDate = d.getString("gregorianDate"),
                        region = d.getString("region"),
                        yearBangla = d.getString("yearBangla"),
                        monthBangla = d.getString("monthBangla"),
                        dayBangla = d.getString("dayBangla"),
                        dayOfWeekBangla = d.getString("dayOfWeekBangla"),
                        tithi = d.getString("tithi"),
                        paksha = d.getString("paksha"),
                        fullTithiTitle = d.optString("fullTithiTitle", d.getString("tithi")),
                        nakshatra = d.getString("nakshatra"),
                        yoga = d.optString("yoga", "সুকর্মা"),
                        karana = d.optString("karana", "বব"),
                        sunriseTime = d.getString("sunriseTime"),
                        sunsetTime = d.getString("sunsetTime"),
                        brahmaMuhurta = d.getString("brahmaMuhurta"),
                        abhijitMuhurta = d.getString("abhijitMuhurta"),
                        rahuKala = d.getString("rahuKala"),
                        isPurnima = d.optBoolean("isPurnima", false),
                        isAmavasya = d.optBoolean("isAmavasya", false),
                        isEkadashi = d.optBoolean("isEkadashi", false),
                        specialDharmaDay = d.optString("specialDharmaDay").ifBlank { null },
                        status = d.getString("status"),
                        publishedVersion = targetVersion.versionName,
                        lastUpdatedTimestamp = System.currentTimeMillis(),
                        lastUpdatedBy = "$adminUser (Rollback to ${targetVersion.versionName})"
                    )
                )
            }

            val restoredEvents = mutableListOf<CalendarEventEntity>()
            for (i in 0 until eventsArray.length()) {
                val e = eventsArray.getJSONObject(i)
                restoredEvents.add(
                    CalendarEventEntity(
                        id = e.getString("id"),
                        nameEn = e.getString("nameEn"),
                        nameBn = e.getString("nameBn"),
                        category = e.getString("category"),
                        targetGregorianDate = e.getString("targetGregorianDate"),
                        startDate = e.getString("startDate"),
                        endDate = e.getString("endDate"),
                        timeDetails = e.optString("timeDetails", ""),
                        tithi = e.optString("tithi", ""),
                        descriptionEn = e.optString("descriptionEn", ""),
                        descriptionBn = e.optString("descriptionBn", ""),
                        importance = e.optString("importance", "HIGH"),
                        rituals = e.optString("rituals", ""),
                        relatedMantra = e.optString("relatedMantra", ""),
                        regionalScope = e.optString("regionalScope", "ALL"),
                        isMultiDay = e.optBoolean("isMultiDay", false),
                        multiDayParentId = e.optString("multiDayParentId").ifBlank { null },
                        daySequence = e.optInt("daySequence", 1),
                        status = e.getString("status"),
                        publishedVersion = targetVersion.versionName,
                        lastUpdatedTimestamp = System.currentTimeMillis(),
                        lastUpdatedBy = "$adminUser (Rollback to ${targetVersion.versionName})"
                    )
                )
            }

            // Atomically replace days and events
            database.calendarDayDao().deleteAllDays()
            database.calendarDayDao().insertAllDays(restoredDays)

            database.calendarEventDao().deleteAllEvents()
            database.calendarEventDao().insertAllEvents(restoredEvents)

            // Audit Log
            database.calendarAuditLogDao().insertAuditLog(
                CalendarAuditLogEntity(
                    adminUsername = adminUser,
                    action = "ROLLBACK_VERSION",
                    targetType = "VERSION",
                    targetKey = versionId,
                    oldValue = "CURRENT_STATE",
                    newValue = "RESTORED_${targetVersion.versionName}",
                    status = "SUCCESS",
                    notes = "Atomically rolled back all days and events to version ${targetVersion.versionName}"
                )
            )

            true
        } catch (e: Exception) {
            false
        }
    }

    // ----------------------------------------------------
    // 6. CLIENT APP SYNC & OFFLINE SAFETY (Points 8, 14, 15)
    // ----------------------------------------------------

    suspend fun syncClientApp(
        database: VedaNovaDatabase,
        clientAppId: String,
        clientCachedVersion: String,
        region: CalendarRegion
    ): ClientSyncResult = withContext(Dispatchers.IO) {
        if (!isApiEnabled) {
            // Emergency / Admin Disable Switch active
            return@withContext ClientSyncResult(
                clientAppId = clientAppId,
                status = "SERVICE_UNAVAILABLE",
                syncStatus = "SERVICE_UNAVAILABLE",
                currentPublishedVersion = "NONE",
                totalDays = 0,
                totalEvents = 0,
                payloadJson = "{\"error\": \"Calendar API is temporarily disabled by Central Admin Panel.\"}"
            )
        }

        val latestVersion = database.calendarVersionDao().getLatestPublishedVersion()
        val latestVerName = latestVersion?.versionName ?: "Calendar 2026 v1"

        if (clientCachedVersion == latestVerName && clientCachedVersion.isNotBlank()) {
            // Client is already up to date!
            database.clientCalendarCacheDao().insertOrUpdateCache(
                ClientCalendarCacheEntity(
                    clientAppId = clientAppId,
                    cachedVersion = clientCachedVersion,
                    cachedAtTimestamp = System.currentTimeMillis(),
                    syncStatus = "LIVE_SYNCED"
                )
            )

            return@withContext ClientSyncResult(
                clientAppId = clientAppId,
                status = "UP_TO_DATE",
                syncStatus = "LIVE_SYNCED",
                currentPublishedVersion = latestVerName,
                totalDays = latestVersion?.totalDaysCount ?: 0,
                totalEvents = latestVersion?.totalEventsCount ?: 0,
                payloadJson = "{\"status\": \"UP_TO_DATE\", \"version\": \"$latestVerName\"}"
            )
        }

        // Return updated payload
        val days = database.calendarDayDao().getAllDays().filter { it.region == region.name }
        val events = database.calendarEventDao().getAllEvents().filter { it.regionalScope == "ALL" || it.regionalScope == region.name }

        val payload = serializeSnapshot(days, events)

        database.clientCalendarCacheDao().insertOrUpdateCache(
            ClientCalendarCacheEntity(
                clientAppId = clientAppId,
                cachedVersion = latestVerName,
                cachedAtTimestamp = System.currentTimeMillis(),
                syncStatus = "LIVE_SYNCED",
                cachedPayloadJson = payload,
                lastServerChecksum = "chk_${System.currentTimeMillis()}"
            )
        )

        ClientSyncResult(
            clientAppId = clientAppId,
            status = "UPDATED",
            syncStatus = "LIVE_SYNCED",
            currentPublishedVersion = latestVerName,
            totalDays = days.size,
            totalEvents = events.size,
            payloadJson = payload
        )
    }

    // ----------------------------------------------------
    // 7. OVERVIEW STATS HELPER (Point 17)
    // ----------------------------------------------------

    suspend fun getOverviewState(database: VedaNovaDatabase): CalendarAdminOverviewState = withContext(Dispatchers.IO) {
        val totalDays = database.calendarDayDao().getDaysCount()
        val totalEvents = database.calendarEventDao().getEventsCount()
        val pendingDays = database.calendarDayDao().getPendingDays().size
        val pendingEvents = database.calendarEventDao().getPendingEvents().size
        val totalPending = pendingDays + pendingEvents

        val latestVersion = database.calendarVersionDao().getLatestPublishedVersion()
        val latestVerName = latestVersion?.versionName ?: "Calendar 2026 v1"

        val auditLogs = database.calendarAuditLogDao().getRecentAuditLogs(1)
        val lastUpdate = auditLogs.firstOrNull()?.timestamp ?: System.currentTimeMillis()

        val cal = Calendar.getInstance()
        val curYear = cal.get(Calendar.YEAR)
        val curMonth = cal.get(Calendar.MONTH) + 1

        val clientCaches = database.clientCalendarCacheDao().getAllClientCaches()

        CalendarAdminOverviewState(
            calendarStatus = if (isApiEnabled) "ACTIVE_LIVE" else "API_DISABLED",
            isApiEnabled = isApiEnabled,
            currentYear = curYear,
            currentMonth = curMonth,
            publishedVersion = latestVerName,
            lastSyncTimestamp = System.currentTimeMillis(),
            lastUpdateTimestamp = lastUpdate,
            totalDaysInDb = totalDays,
            totalEventsInDb = totalEvents,
            pendingVerificationsCount = totalPending,
            draftCount = 0,
            upcomingFestivalsCount = totalEvents,
            validationStatus = if (totalPending > 0) "$totalPending PENDING VERIFICATION" else "ALL_VERIFIED_VALID",
            apiSyncStatus = if (isApiEnabled) "SYNCHRONIZED_WITH_CENTRAL_DB" else "API_SYNC_DISABLED",
            connectedClientAppsCount = if (clientCaches.isNotEmpty()) clientCaches.size else 4
        )
    }
}

data class CalendarAdminUiState(
    val selectedTab: Int = 0, // 0: Daily Panchang Control, 1: Month Grid View, 2: Puja & Festival Manager, 3: Multi-Day Breakdown, 4: Versions & Rollback, 5: Audit History, 6: Client Sync & Offline Safety
    val selectedRegion: CalendarRegion = CalendarRegion.BANGLADESH_DHAKA,
    val selectedDate: String = "2026-09-08",
    val activeMonth: String = "2026-09",
    val currentDayEntity: CalendarDayEntity? = null,
    val isEditingDay: Boolean = false,
    val editingDayDraft: CalendarDayEntity? = null,
    val isEditingEvent: Boolean = false,
    val editingEventDraft: CalendarEventEntity? = null,
    val filterStatus: String = "ALL", // "ALL", "PUBLISHED", "VERIFIED", "DRAFT", "PENDING_VERIFICATION"
    val searchQuery: String = "",
    val isApiMasterEnabled: Boolean = true,
    val snapshotVersionNameInput: String = "Calendar 2026 v2",
    val snapshotNotesInput: String = "Updated Ashwin Durga Puja timings and Kartik vratas",
    val statusMessage: String? = null,
    val validationErrors: List<String> = emptyList(),
    val isTestingSync: Boolean = false,
    val lastSyncResultJson: String? = null
)
