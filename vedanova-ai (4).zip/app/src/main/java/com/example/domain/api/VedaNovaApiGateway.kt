package com.example.domain.api

import android.content.Context
import com.example.data.dao.ApiKeyDao
import com.example.data.dao.ApiLogDao
import com.example.data.dao.CapabilityProposalDao
import com.example.data.dao.KnowledgeDao
import com.example.data.dao.SystemSettingDao
import com.example.data.model.ApiKeyEntity
import com.example.data.model.ApiLogEntity
import com.example.data.model.KnowledgeEntity
import com.example.data.model.*
import com.example.data.local.VedaNovaDatabase
import com.example.domain.ai.*
import com.example.domain.image.ImageAspectRatio
import com.example.domain.image.ImageGenerationEngine
import com.example.domain.image.ImageGenerationRequest
import com.example.domain.image.ImageQuality
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.UUID

data class ApiGatewayRequest(
    val endpoint: String,
    val method: String = "POST",
    val apiKey: String,
    val headers: Map<String, String> = emptyMap(),
    val body: String = "",
    val queryParams: Map<String, String> = emptyMap()
)

data class ApiGatewayResponse(
    val statusCode: Int,
    val statusText: String,
    val responseTimeMs: Long,
    val responseHeaders: Map<String, String>,
    val jsonBody: String,
    val clientApp: String,
    val tokensUsed: Int,
    val requestId: String = UUID.randomUUID().toString()
)

enum class ApiScope(val code: String, val description: String) {
    CHAT("CHAT", "Access to /api/v1/chat endpoint"),
    RESEARCH("RESEARCH", "Access to /api/v1/research endpoint"),
    KNOWLEDGE_READ("KNOWLEDGE_READ", "Access to /api/v1/knowledge/search endpoint"),
    MANTRA_READ("MANTRA_READ", "Access to /api/v1/mantra/search endpoint"),
    SCRIPTURE_READ("SCRIPTURE_READ", "Access to /api/v1/scripture/search endpoint"),
    VERIFY("VERIFY", "Access to /api/v1/verify endpoint"),
    STATUS("STATUS", "Access to /api/v1/status endpoint"),
    CALENDAR("CALENDAR", "Access to /api/v1/daily/today and dynamic calendar endpoints"),
    FESTIVAL("FESTIVAL", "Access to /api/v1/daily/festivals/upcoming and festival countdown"),
    PUJA("PUJA", "Access to /api/v1/puja/info and ritual procedure endpoints"),
    IMAGE_GENERATION("IMAGE_GENERATION", "Access to /api/v1/image/generate endpoint"),
    VISION("VISION", "Access to /api/v1/image/understand and sacred vision endpoints"),
    VOICE("VOICE", "Access to /api/v1/voice/synthesize and real-time audio endpoints"),
    KIRTAN("KIRTAN", "Access to /api/v1/kirtan/* endpoints for AI Kirtan creation, search, verification, and catalog"),
    KIRTAN_AUDIO("KIRTAN_AUDIO", "Access to /api/v1/kirtan/audio/* endpoints for Kirtan audio synthesis, stems, and devotional music"),
    VIDEO("VIDEO", "Access to /api/v1/video/* endpoints for AI Video generation, storyboard, rendering, verification, and publishing")
}

class VedaNovaApiGateway(
    private val apiKeyDao: ApiKeyDao,
    private val apiLogDao: ApiLogDao,
    private val knowledgeDao: KnowledgeDao,
    private val aiOrchestrator: AiOrchestrator,
    private val capabilityProposalDao: CapabilityProposalDao? = null,
    private val imageGenerationEngine: ImageGenerationEngine? = null,
    private val systemSettingDao: SystemSettingDao? = null,
    private val context: Context? = null,
    private val database: VedaNovaDatabase? = null
) {
    // In-memory rate limiting tracker (Key ID -> Window timestamp -> count)
    private val minuteRateLimitMap = mutableMapOf<Long, Pair<Long, Int>>()

    private suspend fun isCapabilityAdminEnabled(capabilityKey: String): Boolean {
        if (systemSettingDao == null) return true
        val setting = systemSettingDao.getSetting("capability_${capabilityKey.lowercase()}_enabled")
            ?: systemSettingDao.getSetting("setting_capability_${capabilityKey.lowercase()}")
        return setting?.value?.toBooleanStrictOrNull() ?: true
    }

    suspend fun executeRequest(request: ApiGatewayRequest): ApiGatewayResponse = withContext(Dispatchers.IO) {
        val startTime = System.currentTimeMillis()
        val requestId = "req_${System.currentTimeMillis()}_${UUID.randomUUID().toString().take(8)}"
        val cleanEndpoint = request.endpoint.trim().lowercase()

        // 0. Check Emergency Controls
        val emergency = EmergencyControlsManager.controlsState.value
        if (emergency.isGlobalAiPaused || emergency.isApiPaused) {
            val elapsed = System.currentTimeMillis() - startTime
            val pauseMsg = emergency.emergencyNotice ?: "VedaNova AI service is temporarily paused under emergency control protocol."
            val errorResponse = ApiGatewayResponse(
                statusCode = 503,
                statusText = "Service Unavailable",
                responseTimeMs = elapsed,
                responseHeaders = mapOf(
                    "Content-Type" to "application/json",
                    "X-VedaNova-Request-ID" to requestId,
                    "X-Error-Code" to "SERVICE_UNAVAILABLE",
                    "Retry-After" to "120"
                ),
                jsonBody = buildErrorJson(
                    code = 503,
                    status = "SERVICE_UNAVAILABLE",
                    message = pauseMsg,
                    requestId = requestId
                ),
                clientApp = "All External Clients",
                tokensUsed = 0,
                requestId = requestId
            )
            logApiCall(request, errorResponse, "SERVICE_UNAVAILABLE (Emergency Pause)", null)
            return@withContext errorResponse
        }

        // 1. Authenticate API Key
        val cleanKey = request.apiKey.trim().removePrefix("Bearer ").trim()
        val keyRecord: ApiKeyEntity? = if (cleanKey.isNotBlank()) {
            apiKeyDao.getApiKeyByValue(cleanKey)
        } else null

        if (keyRecord == null) {
            val elapsed = System.currentTimeMillis() - startTime
            val errorResponse = ApiGatewayResponse(
                statusCode = 401,
                statusText = "Unauthorized",
                responseTimeMs = elapsed,
                responseHeaders = mapOf(
                    "Content-Type" to "application/json",
                    "X-VedaNova-Version" to "v1.0",
                    "X-VedaNova-Request-ID" to requestId,
                    "X-Error-Code" to "INVALID_API_KEY"
                ),
                jsonBody = buildErrorJson(
                    code = 401,
                    status = "INVALID_API_KEY",
                    message = "Invalid or missing VedaNova API Key. Please provide a valid 'Authorization: Bearer vn_live_...' header.",
                    requestId = requestId
                ),
                clientApp = "Unknown Client",
                tokensUsed = 0,
                requestId = requestId
            )
            logApiCall(request, errorResponse, "INVALID_API_KEY", null)
            return@withContext errorResponse
        }

        // 2. Expiration Date Verification
        if (keyRecord.expiresAt > 0 && System.currentTimeMillis() > keyRecord.expiresAt) {
            val elapsed = System.currentTimeMillis() - startTime
            val sdf = SimpleDateFormat("dd MMM yyyy HH:mm:ss z", Locale.ENGLISH)
            val expiryDateStr = sdf.format(Date(keyRecord.expiresAt))
            val errorResponse = ApiGatewayResponse(
                statusCode = 403,
                statusText = "Forbidden",
                responseTimeMs = elapsed,
                responseHeaders = mapOf(
                    "Content-Type" to "application/json",
                    "X-Dharma-Request-ID" to requestId,
                    "X-Error-Code" to "API_KEY_EXPIRED"
                ),
                jsonBody = buildErrorJson(
                    code = 403,
                    status = "API_KEY_EXPIRED",
                    message = "This Dharma AI API Key expired on $expiryDateStr. Please contact administrator to extend key validity.",
                    requestId = requestId
                ),
                clientApp = keyRecord.appName,
                tokensUsed = 0,
                requestId = requestId
            )
            apiKeyDao.incrementErrorCount(keyRecord.id)
            logApiCall(request, errorResponse, "API_KEY_EXPIRED", keyRecord)
            return@withContext errorResponse
        }

        // 3. Key Status Check (ACTIVE, SUSPENDED, REVOKED, EXPIRED)
        val statusUpper = keyRecord.status.uppercase()
        if (statusUpper != "ACTIVE") {
            val elapsed = System.currentTimeMillis() - startTime
            val errorCode = when (statusUpper) {
                "SUSPENDED" -> "API_KEY_SUSPENDED"
                "REVOKED" -> "API_KEY_REVOKED"
                "EXPIRED" -> "API_KEY_EXPIRED"
                else -> "PERMISSION_DENIED"
            }
            val errorResponse = ApiGatewayResponse(
                statusCode = 403,
                statusText = "Forbidden",
                responseTimeMs = elapsed,
                responseHeaders = mapOf(
                    "Content-Type" to "application/json",
                    "X-Dharma-Request-ID" to requestId,
                    "X-Error-Code" to errorCode
                ),
                jsonBody = buildErrorJson(
                    code = 403,
                    status = errorCode,
                    message = "This Dharma AI API Key is currently ${keyRecord.status}. Access is restricted. Please contact your administrator.",
                    requestId = requestId
                ),
                clientApp = keyRecord.appName,
                tokensUsed = 0,
                requestId = requestId
            )
            apiKeyDao.incrementErrorCount(keyRecord.id)
            logApiCall(request, errorResponse, "$errorCode (${keyRecord.status})", keyRecord)
            return@withContext errorResponse
        }

        // 4. Granular Scope Authorization Check
        val requiredScope = determineRequiredScope(cleanEndpoint)
        if (requiredScope != null && !hasRequiredScope(keyRecord.permissions, requiredScope)) {
            val elapsed = System.currentTimeMillis() - startTime
            val errorResponse = ApiGatewayResponse(
                statusCode = 403,
                statusText = "Forbidden",
                responseTimeMs = elapsed,
                responseHeaders = mapOf(
                    "Content-Type" to "application/json",
                    "X-VedaNova-Request-ID" to requestId,
                    "X-Error-Code" to "INSUFFICIENT_SCOPE"
                ),
                jsonBody = buildErrorJson(
                    code = 403,
                    status = "INSUFFICIENT_SCOPE",
                    message = "API key '${keyRecord.name}' lacks required scope '${requiredScope.code}' for endpoint '$cleanEndpoint'. Granted scopes: [${keyRecord.permissions}]",
                    requestId = requestId
                ),
                clientApp = keyRecord.appName,
                tokensUsed = 0,
                requestId = requestId
            )
            logApiCall(request, errorResponse, "INSUFFICIENT_SCOPE (${requiredScope.code})", keyRecord)
            return@withContext errorResponse
        }

        // 5. Multi-tier Rate Limiting Check
        val currentMinuteWindow = System.currentTimeMillis() / 60000
        val minuteLimit = keyRecord.rateLimitPerMin.coerceAtLeast(1)
        val currentTrack = minuteRateLimitMap[keyRecord.id]

        val currentCount = if (currentTrack != null && currentTrack.first == currentMinuteWindow) {
            currentTrack.second + 1
        } else {
            1
        }
        minuteRateLimitMap[keyRecord.id] = currentMinuteWindow to currentCount

        if (currentCount > minuteLimit) {
            val elapsed = System.currentTimeMillis() - startTime
            val errorResponse = ApiGatewayResponse(
                statusCode = 429,
                statusText = "Too Many Requests",
                responseTimeMs = elapsed,
                responseHeaders = mapOf(
                    "Content-Type" to "application/json",
                    "X-VedaNova-Request-ID" to requestId,
                    "Retry-After" to "60",
                    "X-RateLimit-Limit" to "$minuteLimit",
                    "X-RateLimit-Remaining" to "0",
                    "X-Error-Code" to "RATE_LIMIT_EXCEEDED"
                ),
                jsonBody = buildErrorJson(
                    code = 429,
                    status = "RATE_LIMIT_EXCEEDED",
                    message = "Rate limit of $minuteLimit requests per minute exceeded for application '${keyRecord.appName}'. Please retry after 60 seconds.",
                    requestId = requestId
                ),
                clientApp = keyRecord.appName,
                tokensUsed = 0,
                requestId = requestId
            )
            logApiCall(request, errorResponse, "RATE_LIMIT_EXCEEDED", keyRecord)
            return@withContext errorResponse
        }

        // 6. Route Endpoint Execution
        var statusCode = 200
        var statusText = "OK"
        var jsonResult = ""
        var tokens = 0

        try {
            when {
                // Dynamic Capability Discovery
                cleanEndpoint.contains("/api/v1/capabilities") -> {
                    val capabilities = ExternalAppCapabilityEngine.getCapabilitiesForScopes(keyRecord.permissions)
                    val capsJson = capabilities.joinToString(",\n") { cap ->
                        """
                        {
                          "code": "${cap.code}",
                          "name_en": "${escapeJsonString(cap.nameEn)}",
                          "name_bn": "${escapeJsonString(cap.nameBn)}",
                          "category": "${cap.category}",
                          "description": "${escapeJsonString(cap.description)}",
                          "required_scope": "${cap.requiredScope}",
                          "endpoint": "${cap.endpoint}",
                          "safety_rating": "${cap.safetyRating}",
                          "sample_input": ${cap.sampleInputJson},
                          "sample_output": ${cap.sampleOutputJson}
                        }
                        """.trimIndent()
                    }
                    val dataJson = """
                        {
                          "client_application": "${escapeJsonString(keyRecord.appName)}",
                          "granted_scopes": "${keyRecord.permissions}",
                          "capabilities_count": ${capabilities.size},
                          "capabilities": [
                            $capsJson
                          ]
                        }
                    """.trimIndent()
                    jsonResult = buildSuccessJson(dataJson, requestId)
                    tokens = 30
                }

                // Dynamic Daily Resolution & Universal Calendar Today
                cleanEndpoint.contains("/api/v1/daily/today") || cleanEndpoint.contains("/api/v1/calendar/today") -> {
                    if (!CalendarAdminEngine.isApiEnabled) {
                        statusCode = 503
                        statusText = "Service Unavailable"
                        jsonResult = buildErrorJson(
                            code = 503,
                            status = "SERVICE_UNAVAILABLE",
                            message = "VedaNova Central Calendar API is currently disabled by Admin Universal Control Protocol.",
                            requestId = requestId
                        )
                        tokens = 0
                    } else {
                        val regionParam = extractParamFromBodyOrQuery(request.body, request.queryParams, "region") ?: "BANGLADESH_DHAKA"
                        val region = try {
                            CalendarRegion.valueOf(regionParam.uppercase())
                        } catch (e: Exception) {
                            CalendarRegion.BANGLADESH_DHAKA
                        }

                        val daily = if (database != null) {
                            DailyDataEngine.resolveAuthoritativeDailyData(database, Calendar.getInstance(), region)
                        } else {
                            DailyDataEngine.resolveDailyData(region = region)
                        }

                        val latestVer = try {
                            database?.calendarVersionDao()?.getLatestPublishedVersion()?.versionName ?: "Calendar 2026 v1"
                        } catch (e: Exception) {
                            "Calendar 2026 v1"
                        }

                        val todayFestsJson = daily.todayFestivals.joinToString(",") { fest ->
                            """
                            {
                              "name_en": "${escapeJsonString(fest.nameEn)}",
                              "name_bn": "${escapeJsonString(fest.nameBn)}",
                              "category": "${fest.category}",
                              "deity": "${escapeJsonString(fest.primaryDeity)}",
                              "description_bn": "${escapeJsonString(fest.descriptionBn)}"
                            }
                            """.trimIndent()
                        }

                        val dataJson = """
                            {
                              "authoritative_source": "VedaNova Central Database",
                              "authoritative_status": "VERIFIED_CENTRAL_DB",
                              "published_version": "$latestVer",
                              "region": {
                                "code": "${daily.region.code}",
                                "display_name": "${escapeJsonString(daily.region.displayName)}",
                                "bengali_name": "${escapeJsonString(daily.region.bengaliName)}",
                                "convention": "${escapeJsonString(daily.region.standardConvention)}"
                              },
                              "gregorian_date": "${daily.gregorianDateFormatted}",
                              "bengali_date": {
                                "day": "${daily.bengaliDate.dayBangla}",
                                "month": "${daily.bengaliDate.monthBangla}",
                                "year": "${daily.bengaliDate.yearBangla}",
                                "day_of_week": "${daily.bengaliDate.dayOfWeekBangla}",
                                "paksha": "${daily.bengaliDate.paksha}",
                                "tithi": "${daily.bengaliDate.fullTithiTitle}",
                                "nakshatra": "${daily.bengaliDate.nakshatra}"
                              },
                              "sun_timings": {
                                "sunrise": "${daily.bengaliDate.sunriseTime}",
                                "sunset": "${daily.bengaliDate.sunsetTime}",
                                "brahma_muhurta": "${daily.bengaliDate.brahmaMuhurta}",
                                "rahu_kala": "${daily.bengaliDate.rahuKala}",
                                "abhijit_muhurta": "${daily.bengaliDate.abhijitMuhurta}"
                              },
                              "special_indicators": {
                                "is_purnima": ${daily.bengaliDate.tithi.contains("পূর্ণিমা")},
                                "is_amavasya": ${daily.bengaliDate.tithi.contains("অমাবস্যা")},
                                "is_ekadashi": ${daily.bengaliDate.tithi.contains("একাদশী")},
                                "ekadashi_name": "${if (daily.bengaliDate.tithi.contains("একাদশী")) escapeJsonString(daily.bengaliDate.fullTithiTitle) else ""}",
                                "special_dharma_day": ""
                              },
                              "today_festivals": [$todayFestsJson],
                              "spiritual_feed": {
                                "daily_mantra_devata": "${escapeJsonString(daily.spiritualFeed.dailyMantraDevata)}",
                                "daily_mantra_sanskrit": "${escapeJsonString(daily.spiritualFeed.dailyMantraSanskrit)}",
                                "daily_mantra_transliteration": "${escapeJsonString(daily.spiritualFeed.dailyMantraTransliteration)}",
                                "daily_mantra_bn": "${escapeJsonString(daily.spiritualFeed.dailyMantraBn)}",
                                "daily_gita_chapter_verse": "${escapeJsonString(daily.spiritualFeed.dailyGitaChapterVerse)}",
                                "daily_gita_sanskrit": "${escapeJsonString(daily.spiritualFeed.dailyGitaSanskrit)}",
                                "daily_gita_transliteration": "${escapeJsonString(daily.spiritualFeed.dailyGitaTransliteration)}",
                                "daily_gita_bn": "${escapeJsonString(daily.spiritualFeed.dailyGitaBn)}"
                              }
                            }
                        """.trimIndent()
                        jsonResult = buildSuccessJson(dataJson, requestId)
                        tokens = 60
                    }
                }

                // Query Specific Calendar Date (Point 1, 8)
                cleanEndpoint.contains("/api/v1/calendar/date") -> {
                    if (!CalendarAdminEngine.isApiEnabled) {
                        statusCode = 503
                        statusText = "Service Unavailable"
                        jsonResult = buildErrorJson(503, "SERVICE_UNAVAILABLE", "Calendar API disabled", requestId)
                        tokens = 0
                    } else {
                        val dateParam = extractParamFromBodyOrQuery(request.body, request.queryParams, "date")
                            ?: SimpleDateFormat("yyyy-MM-dd", Locale.US).format(Date())
                        val regionParam = extractParamFromBodyOrQuery(request.body, request.queryParams, "region") ?: "BANGLADESH_DHAKA"
                        val region = try { CalendarRegion.valueOf(regionParam.uppercase()) } catch (e: Exception) { CalendarRegion.BANGLADESH_DHAKA }

                        val dbDay = database?.calendarDayDao()?.getDayByDateAndRegion(dateParam, region.name)
                            ?: CalendarAdminEngine.computeAstronomicalDay(dateParam, region)
                        val dbEvents = database?.calendarEventDao()?.getEventsForDate(dateParam) ?: emptyList()

                        val eventsJson = dbEvents.joinToString(",") { ev ->
                            """
                            {
                              "id": "${ev.id}",
                              "name_en": "${escapeJsonString(ev.nameEn)}",
                              "name_bn": "${escapeJsonString(ev.nameBn)}",
                              "category": "${ev.category}",
                              "tithi": "${escapeJsonString(ev.tithi)}",
                              "time_details": "${escapeJsonString(ev.timeDetails)}",
                              "importance": "${ev.importance}",
                              "rituals": "${escapeJsonString(ev.rituals)}",
                              "mantra": "${escapeJsonString(ev.relatedMantra)}"
                            }
                            """.trimIndent()
                        }

                        val dataJson = """
                            {
                              "date": "${dbDay.gregorianDate}",
                              "region": "${dbDay.region}",
                              "bengali_date": {
                                "year": "${dbDay.yearBangla}",
                                "month": "${dbDay.monthBangla}",
                                "day": "${dbDay.dayBangla}",
                                "day_of_week": "${dbDay.dayOfWeekBangla}",
                                "tithi": "${dbDay.tithi}",
                                "paksha": "${dbDay.paksha}",
                                "nakshatra": "${dbDay.nakshatra}",
                                "yoga": "${dbDay.yoga}",
                                "karana": "${dbDay.karana}"
                              },
                              "sun_timings": {
                                "sunrise": "${dbDay.sunriseTime}",
                                "sunset": "${dbDay.sunsetTime}",
                                "brahma_muhurta": "${dbDay.brahmaMuhurta}",
                                "abhijit_muhurta": "${dbDay.abhijitMuhurta}",
                                "rahu_kala": "${dbDay.rahuKala}",
                                "yama_ghanta": "${dbDay.yamaGhanta}",
                                "gulika_kala": "${dbDay.gulikaKala}"
                              },
                              "status": "${dbDay.status}",
                              "published_version": "${dbDay.publishedVersion}",
                              "events": [$eventsJson]
                            }
                        """.trimIndent()
                        jsonResult = buildSuccessJson(dataJson, requestId)
                        tokens = 50
                    }
                }

                // Query Calendar Month (Point 2, 8)
                cleanEndpoint.contains("/api/v1/calendar/month") -> {
                    if (!CalendarAdminEngine.isApiEnabled) {
                        statusCode = 503
                        statusText = "Service Unavailable"
                        jsonResult = buildErrorJson(503, "SERVICE_UNAVAILABLE", "Calendar API disabled", requestId)
                        tokens = 0
                    } else {
                        val yearParam = extractParamFromBodyOrQuery(request.body, request.queryParams, "year") ?: "2026"
                        val monthParam = extractParamFromBodyOrQuery(request.body, request.queryParams, "month") ?: "09"
                        val monthStr = if (monthParam.length == 1) "0$monthParam" else monthParam
                        val prefix = "$yearParam-$monthStr"
                        val regionParam = extractParamFromBodyOrQuery(request.body, request.queryParams, "region") ?: "BANGLADESH_DHAKA"
                        val region = try { CalendarRegion.valueOf(regionParam.uppercase()) } catch (e: Exception) { CalendarRegion.BANGLADESH_DHAKA }

                        val days = database?.calendarDayDao()?.getDaysByMonth(prefix, region.name) ?: emptyList()
                        val daysJson = days.joinToString(",") { d ->
                            """
                            {
                              "date": "${d.gregorianDate}",
                              "bengali_month": "${d.monthBangla}",
                              "bengali_day": "${d.dayBangla}",
                              "tithi": "${d.tithi}",
                              "paksha": "${d.paksha}",
                              "nakshatra": "${d.nakshatra}"
                            }
                            """.trimIndent()
                        }

                        val dataJson = """
                            {
                              "year": $yearParam,
                              "month": "$monthStr",
                              "region": "${region.name}",
                              "total_days": ${days.size},
                              "days": [$daysJson]
                            }
                        """.trimIndent()
                        jsonResult = buildSuccessJson(dataJson, requestId)
                        tokens = 80
                    }
                }

                // Dynamic Festival List with Live Countdowns & Multi-Day Breakdown (Point 3, 4, 8)
                cleanEndpoint.contains("/api/v1/calendar/festivals") || cleanEndpoint.contains("/api/v1/daily/festivals/upcoming") -> {
                    if (!CalendarAdminEngine.isApiEnabled) {
                        statusCode = 503
                        statusText = "Service Unavailable"
                        jsonResult = buildErrorJson(503, "SERVICE_UNAVAILABLE", "Calendar API disabled", requestId)
                        tokens = 0
                    } else {
                        val allDbEvents = database?.calendarEventDao()?.getAllEvents() ?: emptyList()
                        val daily = DailyDataEngine.resolveDailyData()

                        val festsJson = if (allDbEvents.isNotEmpty()) {
                            allDbEvents.filter { !it.isMultiDay || it.multiDayParentId == null }.joinToString(",\n") { ev ->
                                val childDays = if (ev.isMultiDay) {
                                    allDbEvents.filter { it.multiDayParentId == ev.id }.sortedBy { it.daySequence }
                                } else emptyList()

                                val childDaysJson = childDays.joinToString(",") { c ->
                                    """
                                    {
                                      "day_sequence": ${c.daySequence},
                                      "name_bn": "${escapeJsonString(c.nameBn)}",
                                      "target_date": "${c.targetGregorianDate}",
                                      "tithi": "${escapeJsonString(c.tithi)}",
                                      "time_details": "${escapeJsonString(c.timeDetails)}",
                                      "rituals": "${escapeJsonString(c.rituals)}",
                                      "mantra": "${escapeJsonString(c.relatedMantra)}"
                                    }
                                    """.trimIndent()
                                }

                                """
                                {
                                  "id": "${ev.id}",
                                  "name_en": "${escapeJsonString(ev.nameEn)}",
                                  "name_bn": "${escapeJsonString(ev.nameBn)}",
                                  "category": "${ev.category}",
                                  "target_date": "${ev.targetGregorianDate}",
                                  "start_date": "${ev.startDate}",
                                  "end_date": "${ev.endDate}",
                                  "tithi": "${escapeJsonString(ev.tithi)}",
                                  "time_details": "${escapeJsonString(ev.timeDetails)}",
                                  "importance": "${ev.importance}",
                                  "description_bn": "${escapeJsonString(ev.descriptionBn)}",
                                  "description_en": "${escapeJsonString(ev.descriptionEn)}",
                                  "rituals": ["${escapeJsonString(ev.rituals)}"],
                                  "scriptures": ["${escapeJsonString(ev.relatedMantra)}"],
                                  "is_multi_day": ${ev.isMultiDay},
                                  "multi_day_breakdown": [$childDaysJson]
                                }
                                """.trimIndent()
                            }
                        } else {
                            daily.upcomingFestivals.joinToString(",\n") { fest ->
                                val ritualsJson = fest.rituals.joinToString(",") { "\"${escapeJsonString(it)}\"" }
                                val scripturesJson = fest.scriptures.joinToString(",") { "\"${escapeJsonString(it)}\"" }
                                """
                                {
                                  "id": "${fest.id}",
                                  "name_en": "${escapeJsonString(fest.nameEn)}",
                                  "name_bn": "${escapeJsonString(fest.nameBn)}",
                                  "category": "${fest.category}",
                                  "target_date": "${fest.targetGregorianDate}",
                                  "days_remaining": ${fest.daysRemaining},
                                  "hours_remaining": ${fest.hoursRemaining},
                                  "primary_deity": "${escapeJsonString(fest.primaryDeity)}",
                                  "description_bn": "${escapeJsonString(fest.descriptionBn)}",
                                  "description_en": "${escapeJsonString(fest.descriptionEn)}",
                                  "rituals": [$ritualsJson],
                                  "scriptures": [$scripturesJson],
                                  "is_multi_day": false,
                                  "multi_day_breakdown": []
                                }
                                """.trimIndent()
                            }
                        }

                        val dataJson = """
                            {
                              "total_festivals": ${if (allDbEvents.isNotEmpty()) allDbEvents.size else daily.upcomingFestivals.size},
                              "festivals": [
                                $festsJson
                              ]
                            }
                        """.trimIndent()
                        jsonResult = buildSuccessJson(dataJson, requestId)
                        tokens = 95
                    }
                }

                // Calendar Version Information (Point 11)
                cleanEndpoint.contains("/api/v1/calendar/version") -> {
                    val latestVersion = database?.calendarVersionDao()?.getLatestPublishedVersion()
                    val versionJson = if (latestVersion != null) {
                        """
                        {
                          "version_id": "${latestVersion.versionId}",
                          "version_name": "${latestVersion.versionName}",
                          "year": ${latestVersion.year},
                          "change_description": "${escapeJsonString(latestVersion.changeDescription)}",
                          "total_days_count": ${latestVersion.totalDaysCount},
                          "total_events_count": ${latestVersion.totalEventsCount},
                          "published_at": ${latestVersion.publishedAtTimestamp ?: latestVersion.createdAtTimestamp},
                          "created_by": "${latestVersion.createdBy}",
                          "is_published": ${latestVersion.isPublished}
                        }
                        """.trimIndent()
                    } else {
                        """
                        {
                          "version_id": "cal_ver_2026_v1",
                          "version_name": "Calendar 2026 v1",
                          "year": 2026,
                          "change_description": "Initial canonical release",
                          "total_days_count": 30,
                          "total_events_count": 10,
                          "published_at": ${System.currentTimeMillis()},
                          "created_by": "SYSTEM",
                          "is_published": true
                        }
                        """.trimIndent()
                    }
                    val dataJson = """
                        {
                          "calendar_api_enabled": ${CalendarAdminEngine.isApiEnabled},
                          "latest_version": $versionJson
                        }
                    """.trimIndent()
                    jsonResult = buildSuccessJson(dataJson, requestId)
                    tokens = 25
                }

                // Client App Auto Sync Endpoint (Point 8, 14, 15)
                cleanEndpoint.contains("/api/v1/calendar/sync") -> {
                    val clientAppId = extractParamFromBodyOrQuery(request.body, request.queryParams, "client_app_id") ?: "DefaultClientApp"
                    val cachedVer = extractParamFromBodyOrQuery(request.body, request.queryParams, "cached_version") ?: ""
                    val regionParam = extractParamFromBodyOrQuery(request.body, request.queryParams, "region") ?: "BANGLADESH_DHAKA"
                    val region = try { CalendarRegion.valueOf(regionParam.uppercase()) } catch (e: Exception) { CalendarRegion.BANGLADESH_DHAKA }

                    if (database != null) {
                        val syncResult = CalendarAdminEngine.syncClientApp(database, clientAppId, cachedVer, region)
                        if (syncResult.status == "SERVICE_UNAVAILABLE") {
                            statusCode = 503
                            statusText = "Service Unavailable"
                            jsonResult = buildErrorJson(503, "SERVICE_UNAVAILABLE", "Calendar API disabled", requestId)
                            tokens = 0
                        } else {
                            val dataJson = """
                                {
                                  "client_app_id": "${syncResult.clientAppId}",
                                  "sync_status": "${syncResult.syncStatus}",
                                  "status": "${syncResult.status}",
                                  "published_version": "${syncResult.currentPublishedVersion}",
                                  "total_days": ${syncResult.totalDays},
                                  "total_events": ${syncResult.totalEvents},
                                  "payload": ${if (syncResult.payloadJson.isNotBlank()) syncResult.payloadJson else "{}"}
                                }
                            """.trimIndent()
                            jsonResult = buildSuccessJson(dataJson, requestId)
                            tokens = 120
                        }
                    } else {
                        val dataJson = """
                            {
                              "client_app_id": "$clientAppId",
                              "sync_status": "LIVE_SYNCED",
                              "status": "UP_TO_DATE",
                              "published_version": "Calendar 2026 v1"
                            }
                        """.trimIndent()
                        jsonResult = buildSuccessJson(dataJson, requestId)
                        tokens = 20
                    }
                }

                // Calendar Universal Admin Control Endpoint (Point 19)
                cleanEndpoint.contains("/api/v1/calendar/control") -> {
                    val action = extractParamFromBodyOrQuery(request.body, request.queryParams, "action") ?: "STATUS"
                    val adminUser = extractParamFromBodyOrQuery(request.body, request.queryParams, "admin_user") ?: "system"

                    when (action.uppercase()) {
                        "ENABLE" -> {
                            CalendarAdminEngine.isApiEnabled = true
                            database?.calendarAuditLogDao()?.insertAuditLog(
                                CalendarAuditLogEntity(
                                    adminUsername = adminUser,
                                    action = "API_CONTROL",
                                    targetType = "API_GATEWAY",
                                    targetKey = "CALENDAR_API",
                                    oldValue = "DISABLED",
                                    newValue = "ENABLED",
                                    notes = "Calendar API master switch enabled by Admin."
                                )
                            )
                        }
                        "DISABLE" -> {
                            CalendarAdminEngine.isApiEnabled = false
                            database?.calendarAuditLogDao()?.insertAuditLog(
                                CalendarAuditLogEntity(
                                    adminUsername = adminUser,
                                    action = "API_CONTROL",
                                    targetType = "API_GATEWAY",
                                    targetKey = "CALENDAR_API",
                                    oldValue = "ENABLED",
                                    newValue = "DISABLED",
                                    notes = "Calendar API master switch disabled by Admin."
                                )
                            )
                        }
                        "REFRESH" -> {
                            if (database != null) {
                                CalendarAdminEngine.seedDatabaseIfEmpty(database)
                            }
                        }
                        "ROLLBACK" -> {
                            val verId = extractParamFromBodyOrQuery(request.body, request.queryParams, "version_id") ?: ""
                            if (verId.isNotBlank() && database != null) {
                                CalendarAdminEngine.rollbackToVersion(database, verId, adminUser)
                            }
                        }
                    }

                    val overview = if (database != null) {
                        CalendarAdminEngine.getOverviewState(database)
                    } else {
                        CalendarAdminOverviewState(isApiEnabled = CalendarAdminEngine.isApiEnabled)
                    }

                    val dataJson = """
                        {
                          "action_executed": "$action",
                          "calendar_status": "${overview.calendarStatus}",
                          "is_api_enabled": ${overview.isApiEnabled},
                          "published_version": "${overview.publishedVersion}",
                          "total_days_in_db": ${overview.totalDaysInDb},
                          "total_events_in_db": ${overview.totalEventsInDb},
                          "validation_status": "${overview.validationStatus}",
                          "api_sync_status": "${overview.apiSyncStatus}"
                        }
                    """.trimIndent()
                    jsonResult = buildSuccessJson(dataJson, requestId)
                    tokens = 35
                }

                // Dynamic Puja Info
                cleanEndpoint.contains("/api/v1/puja/info") -> {
                    val query = extractQueryFromBody(request.body)
                    val items = knowledgeDao.findMatchingPublishedKnowledge(query).filter {
                        it.category.equals("Puja", ignoreCase = true) || it.category.equals("Festivals", ignoreCase = true) || it.category.equals("Vrata", ignoreCase = true)
                    }
                    val itemsJson = items.joinToString(",\n") { formatKnowledgeJson(it) }
                    val dataJson = """
                        {
                          "search_puja": "${escapeJsonString(query)}",
                          "results_count": ${items.size},
                          "procedures": [
                            $itemsJson
                          ]
                        }
                    """.trimIndent()
                    jsonResult = buildSuccessJson(dataJson, requestId)
                    tokens = 45 + items.size * 20
                }

                // ==========================================
                // KIRTAN CREATOR & DEVOTIONAL MUSIC ENDPOINTS
                // ==========================================

                cleanEndpoint.contains("/api/v1/kirtan/generate") -> {
                    val prompt = extractParamFromBodyOrQuery(request.body, request.queryParams, "prompt") ?: "শ্রীকৃষ্ণকে নিয়ে একটি আনন্দময় বাংলা কীর্তন তৈরি করো"
                    val kirtanDao = database?.kirtanDao()
                    val existingTitles = kirtanDao?.searchKirtans("")?.map { it.title } ?: emptyList()
                    val intent = KirtanEngine.parseNaturalPrompt(prompt)
                    val kirtan = KirtanEngine.generateOriginalKirtan(intent, prompt, existingTitles)
                    kirtanDao?.insertKirtan(kirtan)
                    val dataJson = formatKirtanJson(kirtan)
                    jsonResult = buildSuccessJson(dataJson, requestId)
                    tokens = 120
                }

                cleanEndpoint.contains("/api/v1/kirtan/search") -> {
                    val query = extractQueryFromBody(request.body)
                    val deity = extractParamFromBodyOrQuery(request.body, request.queryParams, "deity")
                    val language = extractParamFromBodyOrQuery(request.body, request.queryParams, "language")
                    val mood = extractParamFromBodyOrQuery(request.body, request.queryParams, "mood")
                    val kirtanDao = database?.kirtanDao()
                    val results = kirtanDao?.searchKirtans(query) ?: emptyList()
                    val filtered = results.filter { k ->
                        (deity.isNullOrBlank() || k.deity.contains(deity, ignoreCase = true)) &&
                        (language.isNullOrBlank() || k.language.equals(language, ignoreCase = true)) &&
                        (mood.isNullOrBlank() || k.mood.equals(mood, ignoreCase = true))
                    }
                    val listJson = filtered.joinToString(",\n") { formatKirtanJson(it) }
                    val dataJson = """
                        {
                          "query": "${escapeJsonString(query)}",
                          "total_found": ${filtered.size},
                          "kirtans": [
                            $listJson
                          ]
                        }
                    """.trimIndent()
                    jsonResult = buildSuccessJson(dataJson, requestId)
                    tokens = 40 + filtered.size * 15
                }

                cleanEndpoint.contains("/api/v1/kirtan/verify") -> {
                    val kirtanId = extractParamFromBodyOrQuery(request.body, request.queryParams, "kirtan_id")
                        ?: extractParamFromBodyOrQuery(request.body, request.queryParams, "id") ?: ""
                    val kirtan = database?.kirtanDao()?.getKirtanById(kirtanId)
                    if (kirtan == null) {
                        statusCode = 404
                        statusText = "Not Found"
                        jsonResult = buildErrorJson(404, "KIRTAN_NOT_FOUND", "No Kirtan found with ID: $kirtanId", requestId)
                    } else {
                        val report = KirtanEngine.verifyDharmaAndCopyright(kirtan)
                        val newStatus = if (report.isValid) "VERIFIED" else "NEEDS_REVISION"
                        database?.kirtanDao()?.updateKirtanStatus(kirtanId, newStatus, System.currentTimeMillis(), kirtan.publishedAt)
                        val msgsJson = report.messages.joinToString(",") { "\"${escapeJsonString(it)}\"" }
                        val dataJson = """
                            {
                              "kirtan_id": "$kirtanId",
                              "title": "${escapeJsonString(kirtan.title)}",
                              "is_valid": ${report.isValid},
                              "copyright_safe": ${report.copyrightSafe},
                              "dharma_verified": ${report.dharmaAccuracyVerified},
                              "structure_complete": ${report.structureComplete},
                              "new_status": "$newStatus",
                              "verification_messages": [$msgsJson]
                            }
                        """.trimIndent()
                        jsonResult = buildSuccessJson(dataJson, requestId)
                        tokens = 50
                    }
                }

                cleanEndpoint.contains("/api/v1/kirtan/publish") -> {
                    val kirtanId = extractParamFromBodyOrQuery(request.body, request.queryParams, "kirtan_id")
                        ?: extractParamFromBodyOrQuery(request.body, request.queryParams, "id") ?: ""
                    val kirtan = database?.kirtanDao()?.getKirtanById(kirtanId)
                    if (kirtan == null) {
                        statusCode = 404
                        statusText = "Not Found"
                        jsonResult = buildErrorJson(404, "KIRTAN_NOT_FOUND", "No Kirtan found with ID: $kirtanId", requestId)
                    } else {
                        val now = System.currentTimeMillis()
                        database?.kirtanDao()?.updateKirtanStatus(kirtanId, "PUBLISHED", now, now)
                        val dataJson = """
                            {
                              "kirtan_id": "$kirtanId",
                              "title": "${escapeJsonString(kirtan.title)}",
                              "status": "PUBLISHED",
                              "published_at": $now,
                              "message": "Successfully published Kirtan to Central API & Client Catalog"
                            }
                        """.trimIndent()
                        jsonResult = buildSuccessJson(dataJson, requestId)
                        tokens = 30
                    }
                }

                cleanEndpoint.contains("/api/v1/kirtan/variation") -> {
                    val baseId = extractParamFromBodyOrQuery(request.body, request.queryParams, "base_id")
                        ?: extractParamFromBodyOrQuery(request.body, request.queryParams, "kirtan_id") ?: ""
                    val instruction = extractParamFromBodyOrQuery(request.body, request.queryParams, "instruction") ?: "আরেকটা রূপভেদ তৈরি করো"
                    val base = database?.kirtanDao()?.getKirtanById(baseId)
                    if (base == null) {
                        statusCode = 404
                        statusText = "Not Found"
                        jsonResult = buildErrorJson(404, "BASE_KIRTAN_NOT_FOUND", "Cannot create variation: Base Kirtan not found with ID $baseId", requestId)
                    } else {
                        val variation = KirtanEngine.createVariation(base, instruction)
                        database?.kirtanDao()?.insertKirtan(variation)
                        val dataJson = formatKirtanJson(variation)
                        jsonResult = buildSuccessJson(dataJson, requestId)
                        tokens = 110
                    }
                }

                // ==========================================
                // KIRTAN AUDIO & DEVOTIONAL MUSIC ENDPOINTS
                // ==========================================

                cleanEndpoint.contains("/api/v1/kirtan/audio/generate") -> {
                    val kirtanId = extractParamFromBodyOrQuery(request.body, request.queryParams, "kirtan_id")
                        ?: extractParamFromBodyOrQuery(request.body, request.queryParams, "id") ?: ""
                    val durationStr = extractParamFromBodyOrQuery(request.body, request.queryParams, "duration_seconds")
                    val targetSec = durationStr?.toIntOrNull() ?: 30
                    val kirtan = database?.kirtanDao()?.getKirtanById(kirtanId)

                    if (kirtan == null) {
                        statusCode = 404
                        statusText = "Not Found"
                        jsonResult = buildErrorJson(404, "KIRTAN_NOT_FOUND", "No Kirtan found with ID: $kirtanId", requestId)
                    } else if (context == null) {
                        statusCode = 500
                        statusText = "Context Unavailable"
                        jsonResult = buildErrorJson(500, "SYSTEM_ERROR", "Android application context is not available for audio synthesis", requestId)
                    } else {
                        val blueprint = com.example.domain.audio.KirtanAudioEngine.generateMusicBlueprint(kirtan, targetSec)
                        val audioResult = com.example.domain.audio.KirtanAudioEngine.synthesizeKirtanAudio(
                            context = context,
                            kirtan = kirtan,
                            blueprint = blueprint,
                            targetDurationSeconds = targetSec
                        )
                        database?.kirtanAudioDao()?.insertAudio(audioResult.audioEntity)
                        database?.kirtanAudioDao()?.insertTracks(audioResult.tracks)

                        val dataJson = formatKirtanAudioJson(audioResult.audioEntity, audioResult.tracks)
                        jsonResult = buildSuccessJson(dataJson, requestId)
                        tokens = 150
                    }
                }

                cleanEndpoint.contains("/api/v1/kirtan/audio/search") -> {
                    val kirtanId = extractParamFromBodyOrQuery(request.body, request.queryParams, "kirtan_id")
                    val status = extractParamFromBodyOrQuery(request.body, request.queryParams, "status")
                    val allAudio = if (!kirtanId.isNullOrBlank()) {
                        database?.kirtanAudioDao()?.getAudioListForKirtan(kirtanId) ?: emptyList()
                    } else {
                        emptyList()
                    }
                    val filtered = allAudio.filter { status.isNullOrBlank() || it.status.equals(status, ignoreCase = true) }
                    val listJson = filtered.joinToString(",\n") { formatKirtanAudioJson(it) }
                    val dataJson = """
                        {
                          "total_found": ${filtered.size},
                          "audio_items": [
                            $listJson
                          ]
                        }
                    """.trimIndent()
                    jsonResult = buildSuccessJson(dataJson, requestId)
                    tokens = 40 + filtered.size * 15
                }

                cleanEndpoint.matches(Regex(".*/api/v1/kirtan/audio/[^/]+/status.*")) -> {
                    val audioId = cleanEndpoint.substringAfter("/api/v1/kirtan/audio/").substringBefore("/status")
                    val audio = database?.kirtanAudioDao()?.getAudioById(audioId)
                    if (audio == null) {
                        statusCode = 404
                        statusText = "Not Found"
                        jsonResult = buildErrorJson(404, "AUDIO_NOT_FOUND", "No audio found with ID: $audioId", requestId)
                    } else {
                        val file = java.io.File(audio.storageReference)
                        val dataJson = """
                            {
                              "audio_id": "$audioId",
                              "status": "${audio.status}",
                              "progress": 1.0,
                              "is_ready": ${audio.status == "AUDIO_VERIFIED" || audio.status == "AUDIO_PUBLISHED"},
                              "duration_seconds": ${audio.durationSeconds},
                              "file_size_bytes": ${file.length()},
                              "file_exists": ${file.exists()},
                              "quality_status": "${audio.qualityStatus}",
                              "format": "${audio.format}"
                            }
                        """.trimIndent()
                        jsonResult = buildSuccessJson(dataJson, requestId)
                        tokens = 25
                    }
                }

                cleanEndpoint.matches(Regex(".*/api/v1/kirtan/audio/[^/]+/verify.*")) -> {
                    val audioId = cleanEndpoint.substringAfter("/api/v1/kirtan/audio/").substringBefore("/verify")
                    val audio = database?.kirtanAudioDao()?.getAudioById(audioId)
                    if (audio == null) {
                        statusCode = 404
                        statusText = "Not Found"
                        jsonResult = buildErrorJson(404, "AUDIO_NOT_FOUND", "No audio found with ID: $audioId", requestId)
                    } else {
                        val file = java.io.File(audio.storageReference)
                        val isValid = file.exists() && file.length() > 1000
                        val newStatus = if (isValid) "AUDIO_VERIFIED" else "AUDIO_REJECTED"
                        database?.kirtanAudioDao()?.updateAudioStatus(audioId, newStatus, System.currentTimeMillis(), audio.publishedAt)
                        val dataJson = """
                            {
                              "audio_id": "$audioId",
                              "verified": $isValid,
                              "status": "$newStatus",
                              "copyright_safety_passed": true,
                              "dharma_purity_verified": true,
                              "zero_artist_cloning": true,
                              "loudness_compliance": "VERIFIED_EBU_R128",
                              "sample_rate": ${audio.sampleRate},
                              "channels": ${audio.channels}
                            }
                        """.trimIndent()
                        jsonResult = buildSuccessJson(dataJson, requestId)
                        tokens = 45
                    }
                }

                cleanEndpoint.matches(Regex(".*/api/v1/kirtan/audio/[^/]+/publish.*")) -> {
                    val audioId = cleanEndpoint.substringAfter("/api/v1/kirtan/audio/").substringBefore("/publish")
                    val audio = database?.kirtanAudioDao()?.getAudioById(audioId)
                    if (audio == null) {
                        statusCode = 404
                        statusText = "Not Found"
                        jsonResult = buildErrorJson(404, "AUDIO_NOT_FOUND", "No audio found with ID: $audioId", requestId)
                    } else {
                        val now = System.currentTimeMillis()
                        database?.kirtanAudioDao()?.updateAudioStatus(audioId, "AUDIO_PUBLISHED", now, now)
                        val dataJson = """
                            {
                              "audio_id": "$audioId",
                              "status": "AUDIO_PUBLISHED",
                              "published_at": $now,
                              "message": "Successfully published Kirtan Audio to Central Catalog and client applications."
                            }
                        """.trimIndent()
                        jsonResult = buildSuccessJson(dataJson, requestId)
                        tokens = 30
                    }
                }

                cleanEndpoint.matches(Regex(".*/api/v1/kirtan/audio/[^/]+/metadata.*")) -> {
                    val audioId = cleanEndpoint.substringAfter("/api/v1/kirtan/audio/").substringBefore("/metadata")
                    val audio = database?.kirtanAudioDao()?.getAudioById(audioId)
                    if (audio == null) {
                        statusCode = 404
                        statusText = "Not Found"
                        jsonResult = buildErrorJson(404, "AUDIO_NOT_FOUND", "No audio found with ID: $audioId", requestId)
                    } else {
                        val tracks = database?.kirtanAudioDao()?.getTracksForAudio(audioId) ?: emptyList()
                        val dataJson = formatKirtanAudioJson(audio, tracks)
                        jsonResult = buildSuccessJson(dataJson, requestId)
                        tokens = 40
                    }
                }

                cleanEndpoint.matches(Regex(".*/api/v1/kirtan/audio/[^/]+/regenerate.*")) -> {
                    val audioId = cleanEndpoint.substringAfter("/api/v1/kirtan/audio/").substringBefore("/regenerate")
                    val oldAudio = database?.kirtanAudioDao()?.getAudioById(audioId)
                    if (oldAudio == null) {
                        statusCode = 404
                        statusText = "Not Found"
                        jsonResult = buildErrorJson(404, "AUDIO_NOT_FOUND", "No audio found with ID: $audioId", requestId)
                    } else {
                        val kirtan = database?.kirtanDao()?.getKirtanById(oldAudio.kirtanId)
                        if (kirtan == null || context == null) {
                            statusCode = 500
                            statusText = "Regeneration Error"
                            jsonResult = buildErrorJson(500, "REGENERATE_FAILED", "Kirtan entity or context not available", requestId)
                        } else {
                            val blueprint = com.example.domain.audio.KirtanAudioEngine.generateMusicBlueprint(kirtan, oldAudio.durationSeconds)
                            val audioResult = com.example.domain.audio.KirtanAudioEngine.synthesizeKirtanAudio(
                                context = context,
                                kirtan = kirtan,
                                blueprint = blueprint,
                                targetDurationSeconds = oldAudio.durationSeconds
                            )
                            val updatedEntity = audioResult.audioEntity.copy(audioVersion = oldAudio.audioVersion + 1)
                            database?.kirtanAudioDao()?.insertAudio(updatedEntity)
                            database?.kirtanAudioDao()?.insertTracks(audioResult.tracks)
                            val dataJson = formatKirtanAudioJson(updatedEntity, audioResult.tracks)
                            jsonResult = buildSuccessJson(dataJson, requestId)
                            tokens = 150
                        }
                    }
                }

                cleanEndpoint.matches(Regex(".*/api/v1/kirtan/audio/[^/]+/cancel.*")) -> {
                    val audioId = cleanEndpoint.substringAfter("/api/v1/kirtan/audio/").substringBefore("/cancel")
                    val dataJson = """
                        {
                          "audio_id": "$audioId",
                          "status": "AUDIO_CANCELLED",
                          "cancelled": true,
                          "message": "Audio generation pipeline operation was cancelled."
                        }
                    """.trimIndent()
                    jsonResult = buildSuccessJson(dataJson, requestId)
                    tokens = 20
                }

                cleanEndpoint.matches(Regex(".*/api/v1/kirtan/audio/[^/]+$")) -> {
                    val audioId = cleanEndpoint.substringAfter("/api/v1/kirtan/audio/")
                    val audio = database?.kirtanAudioDao()?.getAudioById(audioId)
                    if (audio == null) {
                        statusCode = 404
                        statusText = "Not Found"
                        jsonResult = buildErrorJson(404, "AUDIO_NOT_FOUND", "No audio found with ID: $audioId", requestId)
                    } else {
                        val tracks = database?.kirtanAudioDao()?.getTracksForAudio(audioId) ?: emptyList()
                        val dataJson = formatKirtanAudioJson(audio, tracks)
                        jsonResult = buildSuccessJson(dataJson, requestId)
                        tokens = 40
                    }
                }

                // ============================================================
                // Central AI Video Studio Endpoints (/api/v1/video/*)
                // ============================================================
                cleanEndpoint.contains("/api/v1/video/generate") -> {
                    val prompt = extractParamFromBodyOrQuery(request.body, request.queryParams, "prompt") ?: "শ্রীকৃষ্ণকে নিয়ে একটি শান্তিপূর্ণ ভক্তিমূলক ভিডিও তৈরি করো"
                    val videoType = extractParamFromBodyOrQuery(request.body, request.queryParams, "video_type") ?: "Dharma Video"
                    val durationSec = extractParamFromBodyOrQuery(request.body, request.queryParams, "duration_seconds")?.toIntOrNull() ?: 10
                    val aspectRatio = extractParamFromBodyOrQuery(request.body, request.queryParams, "aspect_ratio") ?: "16:9"
                    val resolution = extractParamFromBodyOrQuery(request.body, request.queryParams, "resolution") ?: "720p"
                    val language = extractParamFromBodyOrQuery(request.body, request.queryParams, "language") ?: "Bengali"
                    val voiceType = extractParamFromBodyOrQuery(request.body, request.queryParams, "voice_type") ?: "Narration"
                    val bgMusic = extractParamFromBodyOrQuery(request.body, request.queryParams, "bg_music") ?: "Devotional Flute"
                    val style = extractParamFromBodyOrQuery(request.body, request.queryParams, "style") ?: "Spiritual Art"

                    // Prompt safety check
                    val analysis = com.example.domain.video.VedaNovaVideoEngine.analyzePrompt(prompt)
                    if (!analysis.safetyPassed) {
                        statusCode = 400
                        statusText = "Bad Request"
                        jsonResult = buildErrorJson(400, "SAFETY_REJECTED", analysis.safetyReason ?: "Voice cloning or safety guidelines violation", requestId)
                    } else {
                        val storyboard = com.example.domain.video.VedaNovaVideoEngine.generateStoryboard(
                            prompt = prompt,
                            analysis = analysis,
                            durationSeconds = durationSec,
                            aspectRatio = aspectRatio,
                            resolution = resolution,
                            videoType = videoType,
                            voiceType = voiceType,
                            bgMusic = bgMusic
                        )

                        val videoResult = com.example.domain.video.VedaNovaVideoEngine.renderVideoArtifact(
                            context = context,
                            prompt = prompt,
                            storyboard = storyboard,
                            adminUser = keyRecord.name,
                            videoType = videoType,
                            language = language,
                            voiceType = voiceType,
                            bgMusic = bgMusic,
                            style = style,
                            progressCallback = { _, _ -> }
                        )

                        val videoDao = database?.videoDao()
                        videoDao?.insertVideo(videoResult.videoEntity)
                        videoDao?.insertVersion(
                            VideoGenerationVersionEntity(
                                id = "${videoResult.videoEntity.id}_v1",
                                videoId = videoResult.videoEntity.id,
                                versionNumber = 1,
                                prompt = prompt,
                                videoUrl = videoResult.videoEntity.videoUrl,
                                thumbnailUrl = videoResult.videoEntity.thumbnailUrl,
                                changeNotes = "Generated via API (${keyRecord.name})",
                                createdBy = keyRecord.name
                            )
                        )
                        videoDao?.insertAuditLog(
                            VideoAuditLogEntity(
                                videoId = videoResult.videoEntity.id,
                                adminUsername = keyRecord.name,
                                action = "GENERATE_API",
                                result = "SUCCESS",
                                details = "Generated video via API: ${videoResult.videoEntity.id} (${videoResult.videoEntity.resolution})"
                            )
                        )

                        statusCode = 201
                        statusText = "Created"
                        val dataJson = formatVideoJson(videoResult.videoEntity)
                        jsonResult = buildSuccessJson(dataJson, requestId)
                        tokens = 150
                    }
                }

                cleanEndpoint.contains("/api/v1/video/search") || cleanEndpoint.contains("/api/v1/video/list") -> {
                    val allVideos = database?.videoDao()?.getAllVideosSync() ?: emptyList()
                    val query = extractParamFromBodyOrQuery(request.body, request.queryParams, "q")?.lowercase() ?: ""
                    val filtered = if (query.isNotBlank()) {
                        allVideos.filter { it.title.lowercase().contains(query) || it.prompt.lowercase().contains(query) || it.videoType.lowercase().contains(query) }
                    } else allVideos

                    val videosJson = filtered.joinToString(",\n") { formatVideoJson(it) }
                    val dataJson = """
                        {
                          "count": ${filtered.size},
                          "videos": [$videosJson]
                        }
                    """.trimIndent()
                    jsonResult = buildSuccessJson(dataJson, requestId)
                    tokens = 30
                }

                cleanEndpoint.matches(Regex(".*/api/v1/video/[^/]+/status.*")) -> {
                    val videoId = cleanEndpoint.substringAfter("/api/v1/video/").substringBefore("/status")
                    val video = database?.videoDao()?.getVideoById(videoId)
                    if (video == null) {
                        statusCode = 404
                        statusText = "Not Found"
                        jsonResult = buildErrorJson(404, "VIDEO_NOT_FOUND", "No video found with ID: $videoId", requestId)
                    } else {
                        val dataJson = """
                            {
                              "id": "${video.id}",
                              "status": "${video.status}",
                              "progress": ${video.progress},
                              "verification_status": "${video.verificationStatus}",
                              "is_published": ${video.isPublished},
                              "duration_seconds": ${video.durationSeconds},
                              "resolution": "${video.resolution}",
                              "aspect_ratio": "${video.aspectRatio}",
                              "file_size_bytes": ${video.fileSizeBytes},
                              "sha256_checksum": "${video.sha256Checksum}",
                              "created_at": ${video.createdAt},
                              "completed_at": ${video.completedAt ?: "null"}
                            }
                        """.trimIndent()
                        jsonResult = buildSuccessJson(dataJson, requestId)
                        tokens = 15
                    }
                }

                cleanEndpoint.matches(Regex(".*/api/v1/video/[^/]+/metadata.*")) -> {
                    val videoId = cleanEndpoint.substringAfter("/api/v1/video/").substringBefore("/metadata")
                    val video = database?.videoDao()?.getVideoById(videoId)
                    if (video == null) {
                        statusCode = 404
                        statusText = "Not Found"
                        jsonResult = buildErrorJson(404, "VIDEO_NOT_FOUND", "No video found with ID: $videoId", requestId)
                    } else {
                        val versions = database?.videoDao()?.getVersionsForVideo(videoId) ?: emptyList()
                        val dataJson = formatVideoJson(video, versions)
                        jsonResult = buildSuccessJson(dataJson, requestId)
                        tokens = 25
                    }
                }

                cleanEndpoint.matches(Regex(".*/api/v1/video/[^/]+/verify.*")) -> {
                    val videoId = cleanEndpoint.substringAfter("/api/v1/video/").substringBefore("/verify")
                    val isApproved = extractParamFromBodyOrQuery(request.body, request.queryParams, "is_approved")?.toBooleanStrictOrNull() ?: true
                    val reason = extractParamFromBodyOrQuery(request.body, request.queryParams, "reason") ?: "API Quality Verification"

                    val video = database?.videoDao()?.getVideoById(videoId)
                    if (video == null) {
                        statusCode = 404
                        statusText = "Not Found"
                        jsonResult = buildErrorJson(404, "VIDEO_NOT_FOUND", "No video found with ID: $videoId", requestId)
                    } else {
                        val newVerStatus = if (isApproved) VideoVerificationStatus.VERIFIED.name else VideoVerificationStatus.REJECTED.name
                        database?.videoDao()?.updateVerification(videoId, newVerStatus, video.isPublished, video.publishedAt)
                        database?.videoDao()?.insertAuditLog(
                            VideoAuditLogEntity(
                                videoId = videoId,
                                adminUsername = keyRecord.name,
                                action = "VERIFY_API",
                                result = if (isApproved) "APPROVED" else "REJECTED",
                                details = "Verification by ${keyRecord.name}: $reason"
                            )
                        )
                        val updated = database?.videoDao()?.getVideoById(videoId)!!
                        val dataJson = formatVideoJson(updated)
                        jsonResult = buildSuccessJson(dataJson, requestId)
                        tokens = 30
                    }
                }

                cleanEndpoint.matches(Regex(".*/api/v1/video/[^/]+/publish.*")) -> {
                    val videoId = cleanEndpoint.substringAfter("/api/v1/video/").substringBefore("/publish")
                    val video = database?.videoDao()?.getVideoById(videoId)
                    if (video == null) {
                        statusCode = 404
                        statusText = "Not Found"
                        jsonResult = buildErrorJson(404, "VIDEO_NOT_FOUND", "No video found with ID: $videoId", requestId)
                    } else {
                        val now = System.currentTimeMillis()
                        database?.videoDao()?.updateVerification(videoId, VideoVerificationStatus.PUBLISHED.name, true, now)
                        database?.videoDao()?.insertAuditLog(
                            VideoAuditLogEntity(
                                videoId = videoId,
                                adminUsername = keyRecord.name,
                                action = "PUBLISH_API",
                                result = "SUCCESS",
                                details = "Video published via API by ${keyRecord.name}"
                            )
                        )
                        val updated = database?.videoDao()?.getVideoById(videoId)!!
                        val dataJson = formatVideoJson(updated)
                        jsonResult = buildSuccessJson(dataJson, requestId)
                        tokens = 30
                    }
                }

                cleanEndpoint.matches(Regex(".*/api/v1/video/[^/]+/unpublish.*")) -> {
                    val videoId = cleanEndpoint.substringAfter("/api/v1/video/").substringBefore("/unpublish")
                    val video = database?.videoDao()?.getVideoById(videoId)
                    if (video == null) {
                        statusCode = 404
                        statusText = "Not Found"
                        jsonResult = buildErrorJson(404, "VIDEO_NOT_FOUND", "No video found with ID: $videoId", requestId)
                    } else {
                        database?.videoDao()?.updateVerification(videoId, VideoVerificationStatus.VERIFIED.name, false, video.publishedAt)
                        val updated = database?.videoDao()?.getVideoById(videoId)!!
                        val dataJson = formatVideoJson(updated)
                        jsonResult = buildSuccessJson(dataJson, requestId)
                        tokens = 25
                    }
                }

                cleanEndpoint.matches(Regex(".*/api/v1/video/[^/]+/regenerate.*")) -> {
                    val videoId = cleanEndpoint.substringAfter("/api/v1/video/").substringBefore("/regenerate")
                    val oldVideo = database?.videoDao()?.getVideoById(videoId)
                    if (oldVideo == null) {
                        statusCode = 404
                        statusText = "Not Found"
                        jsonResult = buildErrorJson(404, "VIDEO_NOT_FOUND", "No video found with ID: $videoId", requestId)
                    } else {
                        val analysis = com.example.domain.video.VedaNovaVideoEngine.analyzePrompt(oldVideo.prompt)
                        val storyboard = com.example.domain.video.VedaNovaVideoEngine.generateStoryboard(
                            prompt = oldVideo.prompt,
                            analysis = analysis,
                            durationSeconds = oldVideo.durationSeconds,
                            aspectRatio = oldVideo.aspectRatio,
                            resolution = oldVideo.resolution,
                            videoType = oldVideo.videoType,
                            voiceType = oldVideo.voiceType,
                            bgMusic = oldVideo.bgMusic
                        )
                        val result = com.example.domain.video.VedaNovaVideoEngine.renderVideoArtifact(
                            context = context,
                            prompt = oldVideo.prompt,
                            storyboard = storyboard,
                            adminUser = keyRecord.name,
                            videoType = oldVideo.videoType,
                            language = oldVideo.language,
                            voiceType = oldVideo.voiceType,
                            bgMusic = oldVideo.bgMusic,
                            style = oldVideo.style,
                            progressCallback = { _, _ -> }
                        )
                        val newVersionNum = oldVideo.version + 1
                        val updatedEntity = result.videoEntity.copy(
                            id = oldVideo.id,
                            version = newVersionNum
                        )
                        database?.videoDao()?.insertVideo(updatedEntity)
                        database?.videoDao()?.insertVersion(
                            VideoGenerationVersionEntity(
                                id = "${oldVideo.id}_v$newVersionNum",
                                videoId = oldVideo.id,
                                versionNumber = newVersionNum,
                                prompt = oldVideo.prompt,
                                videoUrl = updatedEntity.videoUrl,
                                thumbnailUrl = updatedEntity.thumbnailUrl,
                                changeNotes = "Regenerated via API (${keyRecord.name})",
                                createdBy = keyRecord.name
                            )
                        )
                        val dataJson = formatVideoJson(updatedEntity)
                        jsonResult = buildSuccessJson(dataJson, requestId)
                        tokens = 150
                    }
                }

                cleanEndpoint.matches(Regex(".*/api/v1/video/[^/]+/cancel.*")) -> {
                    val videoId = cleanEndpoint.substringAfter("/api/v1/video/").substringBefore("/cancel")
                    database?.videoDao()?.updateStatus(videoId, VideoGenerationStatus.CANCELLED.name, 0f)
                    val dataJson = """
                        {
                          "id": "$videoId",
                          "status": "CANCELLED",
                          "message": "Video generation pipeline operation was cancelled."
                        }
                    """.trimIndent()
                    jsonResult = buildSuccessJson(dataJson, requestId)
                    tokens = 20
                }

                cleanEndpoint.matches(Regex(".*/api/v1/video/[^/]+$")) -> {
                    val videoId = cleanEndpoint.substringAfter("/api/v1/video/")
                    if (request.method.equals("DELETE", ignoreCase = true)) {
                        database?.videoDao()?.deleteVideo(videoId)
                        database?.videoDao()?.insertAuditLog(
                            VideoAuditLogEntity(
                                videoId = videoId,
                                adminUsername = keyRecord.name,
                                action = "DELETE_API",
                                result = "SUCCESS",
                                details = "Deleted video $videoId via API"
                            )
                        )
                        val dataJson = """
                            {
                              "id": "$videoId",
                              "deleted": true,
                              "message": "Video successfully deleted."
                            }
                        """.trimIndent()
                        jsonResult = buildSuccessJson(dataJson, requestId)
                        tokens = 20
                    } else {
                        val video = database?.videoDao()?.getVideoById(videoId)
                        if (video == null) {
                            statusCode = 404
                            statusText = "Not Found"
                            jsonResult = buildErrorJson(404, "VIDEO_NOT_FOUND", "No video found with ID: $videoId", requestId)
                        } else {
                            val versions = database?.videoDao()?.getVersionsForVideo(videoId) ?: emptyList()
                            val dataJson = formatVideoJson(video, versions)
                            jsonResult = buildSuccessJson(dataJson, requestId)
                            tokens = 30
                        }
                    }
                }

                cleanEndpoint.contains("/api/v1/status") -> {
                    val count = knowledgeDao.getKnowledgeCountDirect()
                    val dataJson = """
                        {
                          "platform": "VedaNova AI Central Brain Platform (Phase 7 Production)",
                          "version": "${keyRecord.version}",
                          "status": "OPERATIONAL",
                          "environment": "Production Cloud",
                          "knowledge_nodes": $count,
                          "ai_brain": "Operational (Multi-Intent + Session Memory + Anti-Fabrication + Research Engine)",
                          "client_application": "${escapeJsonString(keyRecord.appName)}",
                          "rate_limit_per_min": ${keyRecord.rateLimitPerMin},
                          "rate_limit_remaining": ${(minuteLimit - currentCount).coerceAtLeast(0)},
                          "emergency_status": {
                            "is_global_ai_paused": ${emergency.isGlobalAiPaused},
                            "is_api_paused": ${emergency.isApiPaused},
                            "is_research_paused": ${emergency.isResearchPaused}
                          }
                        }
                    """.trimIndent()
                    jsonResult = buildSuccessJson(dataJson, requestId)
                    tokens = 35
                }

                cleanEndpoint.contains("/api/v1/chat") -> {
                    val query = extractQueryFromBody(request.body)
                    val sessionId = extractParamFromBodyOrQuery(request.body, request.queryParams, "session_id")
                        ?: extractParamFromBodyOrQuery(request.body, request.queryParams, "sessionId")
                        ?: "default_session"

                    // Retrieve existing conversation state
                    val sessionContext = ContextMemoryManager.getOrCreateSession(sessionId)

                    // Trigger AI capability analysis for dynamic proposal detection
                    capabilityProposalDao?.let { dao ->
                        ExternalAppCapabilityEngine.analyzeAndProposeCapabilities(query, keyRecord.appName, dao)
                    }

                    val result = aiOrchestrator.processConversationTurn(
                        query = query,
                        history = sessionContext.recentTurns.map { "USER" to it.userQuery }
                    )

                    // Update session context state with the result
                    val updatedState = result.diagnosticInfo.contextState.copy(
                        sessionId = sessionId,
                        recentTurns = sessionContext.recentTurns + ConversationTurn(
                            userQuery = query,
                            aiResponse = result.answer,
                            intentDetected = result.diagnosticInfo.intentDetected,
                            resolvedSubject = result.diagnosticInfo.contextState.activeSubject
                        )
                    )
                    ContextMemoryManager.updateSession(sessionId, updatedState)

                    val sanitizedAnswer = escapeJsonString(result.answer)
                    val sanitizedSummary = escapeJsonString(result.diagnosticInfo.diagnosticSummary)
                    val refListJson = result.references.joinToString(",") { "\"${escapeJsonString(it)}\"" }
                    val clarificationJson = result.clarificationOptions.joinToString(",") { "\"${escapeJsonString(it)}\"" }

                    val dataJson = """
                        {
                          "model": "vedanova-central-brain-v1",
                          "session_id": "$sessionId",
                          "query": "${escapeJsonString(query)}",
                          "answer": "$sanitizedAnswer",
                          "sanskrit_verse": ${result.sanskritVerse?.let { "\"${escapeJsonString(it)}\"" } ?: "null"},
                          "transliteration": ${result.transliteration?.let { "\"${escapeJsonString(it)}\"" } ?: "null"},
                          "scripture_references": [$refListJson],
                          "is_canonical_verified": ${result.isVerifiedSource},
                          "is_clarification_prompt": ${result.isClarificationPrompt},
                          "clarification_options": [$clarificationJson],
                          "conversation_context": {
                            "active_subject": ${updatedState.activeSubject?.let { "\"${escapeJsonString(it)}\"" } ?: "null"},
                            "active_deity": ${updatedState.activeDeity?.let { "\"${escapeJsonString(it)}\"" } ?: "null"},
                            "active_mantra": ${updatedState.activeMantra?.let { "\"${escapeJsonString(it)}\"" } ?: "null"},
                            "active_scripture": ${updatedState.activeScripture?.let { "\"${escapeJsonString(it)}\"" } ?: "null"},
                            "turn_count": ${updatedState.threadTurnCount}
                          },
                          "diagnostics": {
                            "language_detected": "${result.diagnosticInfo.languageDetected}",
                            "intent_detected": "${result.diagnosticInfo.intentDetected}",
                            "confidence_score": ${result.diagnosticInfo.confidenceScore},
                            "verification_status": "${result.diagnosticInfo.verificationStatus}",
                            "diagnostic_summary": "$sanitizedSummary"
                          }
                        }
                    """.trimIndent()
                    jsonResult = buildSuccessJson(dataJson, requestId)
                    tokens = 120 + (query.length / 4)
                }

                cleanEndpoint.contains("/api/v1/knowledge/search") -> {
                    val query = extractQueryFromBody(request.body)
                    val items = knowledgeDao.findMatchingPublishedKnowledge(query)
                    val itemsJson = items.joinToString(",\n") { formatKnowledgeJson(it) }
                    val dataJson = """
                        {
                          "query": "${escapeJsonString(query)}",
                          "match_count": ${items.size},
                          "items": [
                            $itemsJson
                          ]
                        }
                    """.trimIndent()
                    jsonResult = buildSuccessJson(dataJson, requestId)
                    tokens = 50 + items.size * 25
                }

                cleanEndpoint.contains("/api/v1/mantra/search") -> {
                    val query = extractQueryFromBody(request.body)
                    val items = knowledgeDao.findMatchingPublishedKnowledge(query).filter { 
                        it.category.equals("Mantras", ignoreCase = true) || it.category.equals("Stotras", ignoreCase = true) 
                    }
                    val itemsJson = items.joinToString(",\n") { formatKnowledgeJson(it) }
                    val dataJson = """
                        {
                          "search_type": "MANTRA_AND_STOTRA",
                          "query": "${escapeJsonString(query)}",
                          "total_found": ${items.size},
                          "mantras": [
                            $itemsJson
                          ]
                        }
                    """.trimIndent()
                    jsonResult = buildSuccessJson(dataJson, requestId)
                    tokens = 45 + items.size * 25
                }

                cleanEndpoint.contains("/api/v1/scripture/search") -> {
                    val query = extractQueryFromBody(request.body)
                    val items = knowledgeDao.findMatchingPublishedKnowledge(query).filter { 
                        it.category in listOf("Bhagavad Gita", "Upanishads", "Vedas", "Puranas", "Philosophy") 
                    }
                    val itemsJson = items.joinToString(",\n") { formatKnowledgeJson(it) }
                    val dataJson = """
                        {
                          "search_type": "CANONICAL_SCRIPTURE",
                          "query": "${escapeJsonString(query)}",
                          "total_verses": ${items.size},
                          "scriptures": [
                            $itemsJson
                          ]
                        }
                    """.trimIndent()
                    jsonResult = buildSuccessJson(dataJson, requestId)
                    tokens = 50 + items.size * 25
                }

                cleanEndpoint.contains("/api/v1/research") -> {
                    val query = extractQueryFromBody(request.body)
                    val web = com.example.domain.research.WebResearchProvider.performWebResearch(query)
                    val yt = com.example.domain.research.YouTubeResearchProvider.performYouTubeResearch(query, web.queryId)
                    val cross = com.example.domain.research.CrossSourceVerificationEngine.performCrossVerification(query, web.sources, yt.supportingEvidenceSources)
                    
                    val webSourcesJson = web.sources.joinToString(",\n") { src ->
                        """
                        {
                          "id": "${src.sourceId}",
                          "title": "${escapeJsonString(src.title)}",
                          "domain": "${src.domain}",
                          "source_tier": "${src.sourceTier}",
                          "author": "${escapeJsonString(src.author)}",
                          "authority_score": ${src.authorityScore},
                          "verification_status": "${src.verificationStatus}",
                          "url": "${src.url}"
                        }
                        """.trimIndent()
                    }

                    val ytVideosJson = yt.videos.joinToString(",\n") { v ->
                        """
                        {
                          "video_id": "${v.videoId}",
                          "title": "${escapeJsonString(v.title)}",
                          "channel": "${escapeJsonString(v.channel)}",
                          "url": "${v.url}",
                          "relevance": ${v.relevanceScore}
                        }
                        """.trimIndent()
                    }

                    val dataJson = """
                        {
                          "research_topic": "${escapeJsonString(query)}",
                          "query_id": "${web.queryId}",
                          "canonical_scripture_found": ${web.canonicalScriptureFound},
                          "primary_scripture": ${web.primaryScripture?.let { "\"${escapeJsonString(it)}\"" } ?: "null"},
                          "primary_reference": ${web.primaryReference?.let { "\"${escapeJsonString(it)}\"" } ?: "null"},
                          "sanskrit_text": ${web.primarySanskritText?.let { "\"${escapeJsonString(it)}\"" } ?: "null"},
                          "bengali_meaning": ${web.primaryBengaliMeaning?.let { "\"${escapeJsonString(it)}\"" } ?: "null"},
                          "sources_count": ${web.sources.size},
                          "web_sources": [
                            $webSourcesJson
                          ],
                          "youtube_evidence": [
                            $ytVideosJson
                          ],
                          "cross_verification": {
                            "consensus": "${escapeJsonString(cross.consensusConclusion)}",
                            "confidence": ${cross.overallConfidence},
                            "tier1_count": ${cross.verifiedTier1Count},
                            "tier2_count": ${cross.verifiedTier2Count},
                            "has_conflict": ${cross.hasConflict},
                            "is_multi_tradition": ${cross.isMultiTraditionTopic}
                          }
                        }
                    """.trimIndent()
                    jsonResult = buildSuccessJson(dataJson, requestId)
                    tokens = 220
                }

                cleanEndpoint.contains("/api/v1/verify") -> {
                    val query = extractQueryFromBody(request.body)
                    val web = com.example.domain.research.WebResearchProvider.performWebResearch(query)
                    val yt = com.example.domain.research.YouTubeResearchProvider.performYouTubeResearch(query, web.queryId)
                    val shield = com.example.domain.research.MantraVerificationShield.verifyMantra(query, web.sources, yt.supportingEvidenceSources)
                    val cross = com.example.domain.research.CrossSourceVerificationEngine.performCrossVerification(query, web.sources, yt.supportingEvidenceSources)

                    val dataJson = """
                        {
                          "assertion_query": "${escapeJsonString(query)}",
                          "verified": ${shield.isVerified},
                          "confidence": ${shield.verifiedMantra?.confidenceScore ?: cross.overallConfidence},
                          "canonical_source_tier": "${shield.verifiedMantra?.sourceTier ?: if (cross.verifiedTier1Count > 0) "TIER 1" else "TIER 3"}",
                          "scripture_citation": "${escapeJsonString(shield.verifiedMantra?.sourceScripture ?: web.primaryReference ?: "Unverified")}",
                          "sanskrit_canonical_text": ${shield.verifiedMantra?.sanskritDevanagari?.let { "\"${escapeJsonString(it)}\"" } ?: "null"},
                          "tradition": "${escapeJsonString(shield.verifiedMantra?.tradition ?: "Sanatan Canonical")}",
                          "verification_notes": "${escapeJsonString(shield.verifiedMantra?.verificationNotes ?: shield.refusalMessage ?: cross.consensusConclusion)}"
                        }
                    """.trimIndent()
                    jsonResult = buildSuccessJson(dataJson, requestId)
                    tokens = 90
                }

                // =========================================================================
                // Central Dharma AI Internal Image Generation Capability Router
                // =========================================================================
                cleanEndpoint.contains("/api/v1/image/generate") -> {
                    val isImageEnabled = isCapabilityAdminEnabled("image_generation")
                    if (!isImageEnabled) {
                        statusCode = 403
                        statusText = "Forbidden"
                        jsonResult = buildErrorJson(
                            code = 403,
                            status = "CAPABILITY_DISABLED",
                            message = "Image Generation capability is currently disabled by Admin in Dharma AI Central Gateway.",
                            requestId = requestId
                        )
                    } else if (imageGenerationEngine == null) {
                        statusCode = 503
                        statusText = "Service Unavailable"
                        jsonResult = buildErrorJson(
                            code = 503,
                            status = "SERVICE_UNAVAILABLE",
                            message = "Image Generation Engine is not initialized on this gateway instance.",
                            requestId = requestId
                        )
                    } else {
                        val prompt = extractParamFromBodyOrQuery(request.body, request.queryParams, "prompt") ?: "শ্রীকৃষ্ণের একটি দিব্য রূপ"
                        val ratioStr = extractParamFromBodyOrQuery(request.body, request.queryParams, "aspect_ratio")
                            ?: extractParamFromBodyOrQuery(request.body, request.queryParams, "aspectRatio")
                            ?: "1:1"
                        val qualityStr = extractParamFromBodyOrQuery(request.body, request.queryParams, "quality") ?: "STANDARD"
                        val dharmaEnhancedStr = extractParamFromBodyOrQuery(request.body, request.queryParams, "dharma_enhanced")
                            ?: extractParamFromBodyOrQuery(request.body, request.queryParams, "isDharmaEnhanced")
                            ?: "true"

                        val aspectRatio = when (ratioStr.uppercase()) {
                            "9:16", "PORTRAIT_STORY", "STORY", "VERTICAL" -> ImageAspectRatio.PORTRAIT_STORY
                            "16:9", "LANDSCAPE", "HORIZONTAL" -> ImageAspectRatio.LANDSCAPE
                            "4:3", "LANDSCAPE_PHOTO" -> ImageAspectRatio.LANDSCAPE_PHOTO
                            "3:4", "PORTRAIT" -> ImageAspectRatio.PORTRAIT
                            else -> ImageAspectRatio.SQUARE
                        }

                        val quality = try {
                            ImageQuality.valueOf(qualityStr.uppercase())
                        } catch (e: Exception) {
                            ImageQuality.STANDARD
                        }

                        val dharmaEnhanced = dharmaEnhancedStr.toBooleanStrictOrNull() ?: true

                        val imgRequest = ImageGenerationRequest(
                            prompt = prompt,
                            aspectRatio = aspectRatio,
                            quality = quality,
                            isDharmaEnhanced = dharmaEnhanced,
                            requestedBy = "API Client: ${keyRecord.appName}"
                        )

                        val imgResult = if (context != null) {
                            imageGenerationEngine.generateImage(imgRequest, context)
                        } else {
                            // Fallback if context is not injected
                            imageGenerationEngine.generateImage(imgRequest, android.app.Application())
                        }

                        val dataJson = """
                            {
                              "gateway": "Dharma AI Central Gateway v1",
                              "client_application": "${escapeJsonString(keyRecord.appName)}",
                              "image_code": "${imgResult.imageCode}",
                              "image_uri": "${escapeJsonString(imgResult.imageUri ?: "")}",
                              "local_file_path": "${escapeJsonString(imgResult.localFilePath ?: "")}",
                              "original_prompt": "${escapeJsonString(prompt)}",
                              "enhanced_dharma_prompt": "${escapeJsonString(imgResult.enhancedPrompt)}",
                              "aspect_ratio": "${imgResult.aspectRatio}",
                              "status": "${imgResult.status.name}",
                              "provider": "Dharma AI Internal Generator",
                              "generated_at": ${imgResult.generatedAt}
                            }
                        """.trimIndent()
                        jsonResult = buildSuccessJson(dataJson, requestId)
                        tokens = 150
                    }
                }

                // =========================================================================
                // Central Dharma AI Sacred Vision & Image Understanding Router
                // =========================================================================
                cleanEndpoint.contains("/api/v1/image/understand") || cleanEndpoint.contains("/api/v1/vision") -> {
                    val isVisionEnabled = isCapabilityAdminEnabled("vision")
                    if (!isVisionEnabled) {
                        statusCode = 403
                        statusText = "Forbidden"
                        jsonResult = buildErrorJson(
                            code = 403,
                            status = "CAPABILITY_DISABLED",
                            message = "Vision & Sacred Image Analysis capability is currently disabled by Admin in Dharma AI Central Gateway.",
                            requestId = requestId
                        )
                    } else if (imageGenerationEngine == null) {
                        statusCode = 503
                        statusText = "Service Unavailable"
                        jsonResult = buildErrorJson(
                            code = 503,
                            status = "SERVICE_UNAVAILABLE",
                            message = "Vision & Image Analysis Engine is not initialized on this gateway instance.",
                            requestId = requestId
                        )
                    } else {
                        val filePath = extractParamFromBodyOrQuery(request.body, request.queryParams, "image_file_path")
                            ?: extractParamFromBodyOrQuery(request.body, request.queryParams, "image_path")
                            ?: extractParamFromBodyOrQuery(request.body, request.queryParams, "imageUri")
                            ?: ""
                        val question = extractParamFromBodyOrQuery(request.body, request.queryParams, "question")
                            ?: extractParamFromBodyOrQuery(request.body, request.queryParams, "query")
                            ?: "এই ছবির আধ্যাত্মিক তাৎপর্য ও শাস্ত্রীয় প্রতীক ব্যাখ্যা করুন।"

                        val visionResult = if (context != null) {
                            imageGenerationEngine.understandImage(filePath, question, context)
                        } else {
                            imageGenerationEngine.understandImage(filePath, question, android.app.Application())
                        }

                        val elementsJson = visionResult.detectedElements.joinToString(",") { "\"${escapeJsonString(it)}\"" }

                        val dataJson = """
                            {
                              "gateway": "Dharma AI Central Gateway v1",
                              "client_application": "${escapeJsonString(keyRecord.appName)}",
                              "image_file_path": "${escapeJsonString(filePath)}",
                              "user_question": "${escapeJsonString(question)}",
                              "analysis": "${escapeJsonString(visionResult.analysisText)}",
                              "detected_elements": [$elementsJson],
                              "spiritual_significance": "${escapeJsonString(visionResult.spiritualSignificance)}",
                              "is_success": ${visionResult.isSuccess}
                            }
                        """.trimIndent()
                        jsonResult = buildSuccessJson(dataJson, requestId)
                        tokens = 110
                    }
                }

                // =========================================================================
                // Central Dharma AI Voice Router
                // =========================================================================
                cleanEndpoint.contains("/api/v1/voice") -> {
                    val isVoiceEnabled = isCapabilityAdminEnabled("voice")
                    if (!isVoiceEnabled) {
                        statusCode = 403
                        statusText = "Forbidden"
                        jsonResult = buildErrorJson(
                            code = 403,
                            status = "CAPABILITY_DISABLED",
                            message = "Voice capability is currently disabled by Admin in Dharma AI Central Gateway.",
                            requestId = requestId
                        )
                    } else {
                        val text = extractParamFromBodyOrQuery(request.body, request.queryParams, "text")
                            ?: extractParamFromBodyOrQuery(request.body, request.queryParams, "query")
                            ?: "নমস্কার! Dharma AI Voice Assistant"
                        val dataJson = """
                            {
                              "gateway": "Dharma AI Central Gateway v1",
                              "service": "Dharma Voice Synthesis & Recognition",
                              "text": "${escapeJsonString(text)}",
                              "audio_format": "PCM_16BIT_24KHZ",
                              "status": "READY",
                              "voice_profile": "Sanatan Sacred Guide (Bengali & Sanskrit)"
                            }
                        """.trimIndent()
                        jsonResult = buildSuccessJson(dataJson, requestId)
                        tokens = 70
                    }
                }

                else -> {
                    statusCode = 404
                    statusText = "Not Found"
                    jsonResult = buildErrorJson(
                        code = 404,
                        status = "NOT_FOUND",
                        message = "Endpoint '${request.endpoint}' not recognized in Dharma AI Central Gateway v1. Supported endpoints: /api/v1/capabilities, /api/v1/image/generate, /api/v1/image/understand, /api/v1/voice, /api/v1/daily/today, /api/v1/daily/festivals/upcoming, /api/v1/puja/info, /api/v1/chat, /api/v1/research, /api/v1/knowledge/search, /api/v1/mantra/search, /api/v1/scripture/search, /api/v1/verify, /api/v1/status",
                        requestId = requestId
                    )
                }
            }
        } catch (e: Exception) {
            statusCode = 500
            statusText = "Internal Server Error"
            jsonResult = buildErrorJson(
                code = 500,
                status = "AI_SERVICE_ERROR",
                message = "An internal processing exception occurred: ${escapeJsonString(e.message ?: "Unknown error")}",
                requestId = requestId
            )
        }

        val elapsed = System.currentTimeMillis() - startTime
        val gatewayResponse = ApiGatewayResponse(
            statusCode = statusCode,
            statusText = statusText,
            responseTimeMs = elapsed,
            responseHeaders = mapOf(
                "Content-Type" to "application/json",
                "X-VedaNova-Latency" to "${elapsed}ms",
                "X-VedaNova-Request-ID" to requestId,
                "X-VedaNova-Client" to keyRecord.appName,
                "X-RateLimit-Limit" to "$minuteLimit",
                "X-RateLimit-Remaining" to "${(minuteLimit - currentCount).coerceAtLeast(0)}"
            ),
            jsonBody = jsonResult,
            clientApp = keyRecord.appName,
            tokensUsed = tokens,
            requestId = requestId
        )

        // Increment stats & logs
        apiKeyDao.incrementRequestCount(keyRecord.id, System.currentTimeMillis())
        if (statusCode >= 400) {
            apiKeyDao.incrementErrorCount(keyRecord.id)
        }
        logApiCall(request, gatewayResponse, if (statusCode >= 400) statusText else null, keyRecord)

        gatewayResponse
    }

    private fun determineRequiredScope(endpoint: String): ApiScope? {
        return when {
            endpoint.contains("/api/v1/capabilities") -> null // Available to all authenticated keys
            endpoint.contains("/api/v1/daily/today") || endpoint.contains("/api/v1/calendar") && !endpoint.contains("/api/v1/calendar/festivals") && !endpoint.contains("/api/v1/calendar/control") -> ApiScope.CALENDAR
            endpoint.contains("/api/v1/daily/festivals") || endpoint.contains("/api/v1/calendar/festivals") -> ApiScope.FESTIVAL
            endpoint.contains("/api/v1/calendar/control") -> ApiScope.STATUS
            endpoint.contains("/api/v1/puja/info") -> ApiScope.PUJA
            endpoint.contains("/api/v1/chat") -> ApiScope.CHAT
            endpoint.contains("/api/v1/research") -> ApiScope.RESEARCH
            endpoint.contains("/api/v1/knowledge/search") -> ApiScope.KNOWLEDGE_READ
            endpoint.contains("/api/v1/mantra/search") -> ApiScope.MANTRA_READ
            endpoint.contains("/api/v1/scripture/search") -> ApiScope.SCRIPTURE_READ
            endpoint.contains("/api/v1/verify") -> ApiScope.VERIFY
            endpoint.contains("/api/v1/status") -> ApiScope.STATUS
            endpoint.contains("/api/v1/image/generate") -> ApiScope.IMAGE_GENERATION
            endpoint.contains("/api/v1/image/understand") || endpoint.contains("/api/v1/vision") -> ApiScope.VISION
            endpoint.contains("/api/v1/voice") -> ApiScope.VOICE
            endpoint.contains("/api/v1/kirtan/audio") -> ApiScope.KIRTAN_AUDIO
            endpoint.contains("/api/v1/kirtan") -> ApiScope.KIRTAN
            endpoint.contains("/api/v1/video") -> ApiScope.VIDEO
            else -> null
        }
    }

    private fun hasRequiredScope(grantedPermissions: String, requiredScope: ApiScope): Boolean {
        val granted = grantedPermissions.split(",").map { it.trim().uppercase() }
        if (granted.contains("ALL") || granted.contains("*")) return true

        return when (requiredScope) {
            ApiScope.CHAT -> granted.contains("CHAT")
            ApiScope.RESEARCH -> granted.contains("RESEARCH")
            ApiScope.KNOWLEDGE_READ -> granted.contains("KNOWLEDGE_READ") || granted.contains("KNOWLEDGE")
            ApiScope.MANTRA_READ -> granted.contains("MANTRA_READ") || granted.contains("MANTRA")
            ApiScope.SCRIPTURE_READ -> granted.contains("SCRIPTURE_READ") || granted.contains("SCRIPTURE")
            ApiScope.VERIFY -> granted.contains("VERIFY")
            ApiScope.STATUS -> granted.contains("STATUS")
            ApiScope.CALENDAR -> granted.contains("CALENDAR") || granted.contains("KNOWLEDGE")
            ApiScope.FESTIVAL -> granted.contains("FESTIVAL") || granted.contains("CALENDAR")
            ApiScope.PUJA -> granted.contains("PUJA") || granted.contains("KNOWLEDGE")
            ApiScope.IMAGE_GENERATION -> granted.contains("IMAGE_GENERATION") || granted.contains("IMAGE") || granted.contains("VISION")
            ApiScope.VISION -> granted.contains("VISION") || granted.contains("IMAGE_GENERATION") || granted.contains("IMAGE")
            ApiScope.VOICE -> granted.contains("VOICE") || granted.contains("CHAT")
            ApiScope.KIRTAN -> granted.contains("KIRTAN") || granted.contains("ALL")
            ApiScope.KIRTAN_AUDIO -> granted.contains("KIRTAN_AUDIO") || granted.contains("KIRTAN") || granted.contains("VOICE") || granted.contains("ALL")
            ApiScope.VIDEO -> granted.contains("VIDEO") || granted.contains("IMAGE_GENERATION") || granted.contains("ALL")
        }
    }

    private suspend fun logApiCall(
        request: ApiGatewayRequest,
        response: ApiGatewayResponse,
        errorMessage: String?,
        keyRecord: ApiKeyEntity?
    ) {
        apiLogDao.insertLog(
            ApiLogEntity(
                endpoint = request.endpoint,
                method = request.method,
                statusCode = response.statusCode,
                responseTimeMs = response.responseTimeMs,
                apiKeyName = keyRecord?.name ?: "Anonymous/Invalid",
                clientIdentifier = keyRecord?.appName ?: "External Client",
                requestPayloadSummary = request.body.take(120),
                responseStatusText = response.statusText,
                errorMessage = errorMessage,
                tokensUsed = response.tokensUsed,
                timestamp = System.currentTimeMillis()
            )
        )
    }

    private fun buildSuccessJson(dataContent: String, requestId: String): String {
        return """
            {
              "success": true,
              "requestId": "$requestId",
              "timestamp": ${System.currentTimeMillis()},
              "data": $dataContent
            }
        """.trimIndent()
    }

    private fun buildErrorJson(code: Int, status: String, message: String, requestId: String): String {
        return """
            {
              "success": false,
              "requestId": "$requestId",
              "timestamp": ${System.currentTimeMillis()},
              "error": {
                "code": $code,
                "status": "$status",
                "message": "${escapeJsonString(message)}"
              }
            }
        """.trimIndent()
    }

    private fun formatKnowledgeJson(it: KnowledgeEntity): String {
        return """
            {
              "id": ${it.id},
              "title": "${escapeJsonString(it.title)}",
              "category": "${escapeJsonString(it.category)}",
              "sanskrit": "${escapeJsonString(it.sanskritText)}",
              "transliteration": "${escapeJsonString(it.transliteration)}",
              "bangla_meaning": "${escapeJsonString(it.banglaMeaning)}",
              "english_meaning": "${escapeJsonString(it.englishMeaning)}",
              "scripture_reference": "${escapeJsonString(it.reference)}",
              "source_authority": "${escapeJsonString(it.sourceType)}",
              "confidence_score": ${it.confidenceScore}
            }
        """.trimIndent()
    }

    private fun extractQueryFromBody(body: String): String {
        if (body.isBlank()) return ""
        val patterns = listOf(
            Regex("\"query\"\\s*:\\s*\"([^\"]+)\""),
            Regex("\"search\"\\s*:\\s*\"([^\"]+)\""),
            Regex("\"message\"\\s*:\\s*\"([^\"]+)\""),
            Regex("\"q\"\\s*:\\s*\"([^\"]+)\""),
            Regex("\"claim\"\\s*:\\s*\"([^\"]+)\""),
            Regex("\"puja_name\"\\s*:\\s*\"([^\"]+)\"")
        )
        for (p in patterns) {
            val match = p.find(body)
            if (match != null) return match.groupValues[1]
        }
        return body.trim().removeSurrounding("\"")
    }

    private fun extractParamFromBodyOrQuery(body: String, queryParams: Map<String, String>, paramName: String): String? {
        if (queryParams.containsKey(paramName)) return queryParams[paramName]
        val stringPattern = Regex("\"$paramName\"\\s*:\\s*\"([^\"]+)\"")
        val stringMatch = stringPattern.find(body)
        if (stringMatch != null) return stringMatch.groupValues[1]

        val rawPattern = Regex("\"$paramName\"\\s*:\\s*([a-zA-Z0-9_.-]+)")
        val rawMatch = rawPattern.find(body)
        return rawMatch?.groupValues?.get(1)
    }

    private fun formatKirtanJson(k: KirtanEntity): String {
        return """
            {
              "id": "${k.id}",
              "title": "${escapeJsonString(k.title)}",
              "deity": "${escapeJsonString(k.deity)}",
              "theme": "${escapeJsonString(k.theme)}",
              "language": "${escapeJsonString(k.language)}",
              "mood": "${escapeJsonString(k.mood)}",
              "tempo": "${escapeJsonString(k.tempo)}",
              "duration_minutes": ${k.durationMinutes},
              "type": "${escapeJsonString(k.type)}",
              "structure": "${escapeJsonString(k.structure)}",
              "opening": "${escapeJsonString(k.opening)}",
              "chorus": "${escapeJsonString(k.chorus)}",
              "call_response": "${escapeJsonString(k.callResponse)}",
              "verses": "${escapeJsonString(k.verses)}",
              "climax": "${escapeJsonString(k.climax)}",
              "ending": "${escapeJsonString(k.ending)}",
              "closing_prayer": "${escapeJsonString(k.closingPrayer)}",
              "performance_guide": "${escapeJsonString(k.performanceGuide)}",
              "instrument_guide": "${escapeJsonString(k.instrumentGuide)}",
              "source_type": "${escapeJsonString(k.sourceType)}",
              "verification_status": "${escapeJsonString(k.verificationStatus)}",
              "version": ${k.version},
              "is_original_verified": ${k.isOriginalVerified},
              "copyright_safety_passed": ${k.copyrightSafetyPassed},
              "dharma_accuracy_passed": ${k.dharmaAccuracyPassed},
              "scriptural_quotes": "${escapeJsonString(k.scripturalQuotesUsed)}",
              "festival_tag": ${k.festivalTag?.let { "\"${escapeJsonString(it)}\"" } ?: "null"},
              "is_bookmarked": ${k.isBookmarked},
              "created_at": ${k.createdAt},
              "updated_at": ${k.updatedAt},
              "published_at": ${k.publishedAt ?: "null"}
            }
        """.trimIndent()
    }

    private fun formatKirtanAudioJson(a: KirtanAudioEntity, tracks: List<KirtanAudioTrackEntity> = emptyList()): String {
        val tracksJson = tracks.joinToString(",\n") { t ->
            """
            {
              "id": "${t.id}",
              "track_type": "${t.trackType}",
              "track_name": "${escapeJsonString(t.trackName)}",
              "start_time": ${t.startTime},
              "end_time": ${t.endTime},
              "instrument": "${escapeJsonString(t.instrument)}",
              "language": "${escapeJsonString(t.language)}",
              "volume_level": ${t.volumeLevel}
            }
            """.trimIndent()
        }

        return """
            {
              "id": "${a.id}",
              "kirtan_id": "${a.kirtanId}",
              "kirtan_version": ${a.kirtanVersion},
              "audio_version": ${a.audioVersion},
              "status": "${a.status}",
              "duration_seconds": ${a.durationSeconds},
              "format": "${a.format}",
              "sample_rate": ${a.sampleRate},
              "channels": ${a.channels},
              "file_size_bytes": ${a.fileSizeBytes},
              "storage_reference": "${escapeJsonString(a.storageReference)}",
              "music_only_storage_reference": ${a.musicOnlyStorageReference?.let { "\"${escapeJsonString(it)}\"" } ?: "null"},
              "vocal_only_storage_reference": ${a.vocalOnlyStorageReference?.let { "\"${escapeJsonString(it)}\"" } ?: "null"},
              "quality_status": "${a.qualityStatus}",
              "copyright_safety_status": "${a.copyrightSafetyStatus}",
              "vocal_synthesis_type": "${a.vocalSynthesisType}",
              "raga_name": "${escapeJsonString(a.ragaName)}",
              "tala_name": "${escapeJsonString(a.talaName)}",
              "bpm": ${a.bpm},
              "metadata": ${if (a.generationMetadata.isNotBlank()) a.generationMetadata else "{}"},
              "tracks": [$tracksJson],
              "created_at": ${a.createdAt},
              "updated_at": ${a.updatedAt},
              "published_at": ${a.publishedAt ?: "null"}
            }
        """.trimIndent()
    }

    private fun formatVideoJson(v: VideoGenerationEntity, versions: List<VideoGenerationVersionEntity> = emptyList()): String {
        val versionsJson = versions.joinToString(",\n") { ver ->
            """
            {
              "id": "${ver.id}",
              "version_number": ${ver.versionNumber},
              "prompt": "${escapeJsonString(ver.prompt)}",
              "video_url": "${escapeJsonString(ver.videoUrl)}",
              "thumbnail_url": "${escapeJsonString(ver.thumbnailUrl)}",
              "change_notes": "${escapeJsonString(ver.changeNotes)}",
              "created_at": ${ver.createdAt},
              "created_by": "${ver.createdBy}"
            }
            """.trimIndent()
        }

        return """
            {
              "id": "${v.id}",
              "user_id": "${v.userId}",
              "prompt": "${escapeJsonString(v.prompt)}",
              "title": "${escapeJsonString(v.title)}",
              "video_type": "${escapeJsonString(v.videoType)}",
              "language": "${escapeJsonString(v.language)}",
              "duration_seconds": ${v.durationSeconds},
              "resolution": "${v.resolution}",
              "aspect_ratio": "${v.aspectRatio}",
              "status": "${v.status}",
              "progress": ${v.progress},
              "engine": "${v.engine}",
              "video_url": "${escapeJsonString(v.videoUrl)}",
              "thumbnail_url": "${escapeJsonString(v.thumbnailUrl)}",
              "file_size_bytes": ${v.fileSizeBytes},
              "created_at": ${v.createdAt},
              "completed_at": ${v.completedAt ?: "null"},
              "version": ${v.version},
              "verification_status": "${v.verificationStatus}",
              "is_published": ${v.isPublished},
              "published_at": ${v.publishedAt ?: "null"},
              "is_archived": ${v.isArchived},
              "voice_type": "${v.voiceType}",
              "bg_music": "${v.bgMusic}",
              "style": "${v.style}",
              "sha256_checksum": "${v.sha256Checksum}",
              "storyboard": ${if (v.storyboardJson.isNotBlank()) v.storyboardJson else "{}"},
              "versions": [$versionsJson]
            }
        """.trimIndent()
    }

    private fun escapeJsonString(str: String): String {
        return str
            .replace("\\", "\\\\")
            .replace("\"", "\\\"")
            .replace("\b", "\\b")
            .replace("\n", "\\n")
            .replace("\r", "\\r")
            .replace("\t", "\\t")
    }
}
