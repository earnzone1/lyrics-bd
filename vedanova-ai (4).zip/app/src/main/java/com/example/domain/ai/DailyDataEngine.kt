package com.example.domain.ai

import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.Locale
import java.util.TimeZone
import kotlin.math.abs
import com.example.data.local.VedaNovaDatabase

enum class CalendarRegion(
    val code: String,
    val displayName: String,
    val bengaliName: String,
    val timeZone: String,
    val standardConvention: String
) {
    BANGLADESH_DHAKA(
        "BANGLADESH_DHAKA",
        "Bangladesh (Dhaka Standard)",
        "বাংলাদেশ (ঢাকা সময় ও বঙ্গাব্দ মান)",
        "Asia/Dhaka",
        "Surya Siddhanta & Bangla Academy Reformed"
    ),
    INDIA_WEST_BENGAL(
        "INDIA_WEST_BENGAL",
        "India (West Bengal / Kolkata)",
        "ভারত (পশ্চিমবঙ্গ ও কলকাতা সময়)",
        "Asia/Kolkata",
        "Bisuddhasiddha & Drik Siddhanta Almanac"
    ),
    INDIA_VARANASI(
        "INDIA_VARANASI",
        "India (Varanasi / North India)",
        "ভারত (বারাণসী / উত্তর ভারত পঞ্জিকা)",
        "Asia/Kolkata",
        "Purnimanta & Kashi Vishwanath Ephemeris"
    ),
    TRIPURA_AGARTALA(
        "TRIPURA_AGARTALA",
        "Tripura (Agartala Standard)",
        "ত্রিপুরা (আগরতলা পঞ্জিকা মান)",
        "Asia/Kolkata",
        "Surya Siddhanta & Tripura Raj Almanac"
    ),
    ASSAM_GUWAHATI(
        "ASSAM_GUWAHATI",
        "Assam (Guwahati Standard)",
        "আসাম (গুয়াহাটি ও কামরূপ পঞ্জিকা)",
        "Asia/Kolkata",
        "Kamakhya & Kamarupiya Ephemeris"
    )
}

data class BengaliDateInfo(
    val yearBangla: String, // e.g. "১৪৩৩ বঙ্গাব্দ"
    val monthBangla: String, // e.g. "ভাদ্র"
    val dayBangla: String, // e.g. "৯"
    val dayOfWeekBangla: String, // e.g. "মঙ্গলবার"
    val paksha: String, // e.g. "শুক্লপক্ষ"
    val tithi: String, // e.g. "দ্বাদশী"
    val fullTithiTitle: String, // e.g. "শুক্লা দ্বাদশী তিথি"
    val nakshatra: String, // e.g. "শ্রবণা নক্ষত্র"
    val sunriseTime: String, // e.g. "০৫:৩৮ AM"
    val sunsetTime: String, // e.g. "০৬:২২ PM"
    val brahmaMuhurta: String, // e.g. "০৪:০২ AM - ০৪:৫০ AM"
    val rahuKala: String, // e.g. "০৩:১৪ PM - ০৪:৪৮ PM"
    val abhijitMuhurta: String // e.g. "১১:৪৫ AM - ১২:৩৭ PM"
)

data class FestivalEvent(
    val id: String,
    val nameEn: String,
    val nameBn: String,
    val category: String, // Major Festival, Vrata & Ekadashi, Jayanti, Puja
    val descriptionBn: String,
    val descriptionEn: String,
    val targetGregorianDate: String, // e.g. "2026-08-25"
    val daysRemaining: Int,
    val hoursRemaining: Int,
    val primaryDeity: String,
    val rituals: List<String>,
    val scriptures: List<String>,
    val isToday: Boolean
)

data class DailySpiritualFeed(
    val dailyDharmaQuoteBn: String,
    val dailyDharmaQuoteEn: String,
    val quoteSource: String,
    val dailyMantraSanskrit: String,
    val dailyMantraTransliteration: String,
    val dailyMantraBn: String,
    val dailyMantraDevata: String,
    val dailyGitaChapterVerse: String,
    val dailyGitaSanskrit: String,
    val dailyGitaTransliteration: String,
    val dailyGitaBn: String,
    val dailyGitaEn: String
)

data class DailyDataResolution(
    val gregorianDateFormatted: String,
    val region: CalendarRegion,
    val bengaliDate: BengaliDateInfo,
    val todayFestivals: List<FestivalEvent>,
    val upcomingFestivals: List<FestivalEvent>,
    val nextMajorFestival: FestivalEvent?,
    val spiritualFeed: DailySpiritualFeed,
    val resolvedAtTimestamp: Long = System.currentTimeMillis()
)

object DailyDataEngine {

    private val BENGALI_MONTHS = listOf(
        "বৈশাখ", "জ্যৈষ্ঠ", "আষাঢ়", "শ্রাবণ", "ভাদ্র", "আশ্বিন",
        "কার্তিক", "অগ্রহায়ণ", "পৌষ", "মাঘ", "ফাল্গুন", "চৈত্র"
    )

    private val BENGALI_DAYS_OF_WEEK = listOf(
        "রবিবার", "সোমবার", "মঙ্গলবার", "বুধবার", "বৃহস্পতিবার", "শুক্রবার", "শনিবার"
    )

    private val TITHIS = listOf(
        "প্রতিপদ", "দ্বিতীয়া", "তৃতীয়া", "চতুর্থী", "পঞ্চমী",
        "ষষ্ঠী", "সপ্তমী", "অষ্টমী", "নবমী", "দশমী",
        "একাদশী", "দ্বাদশী", "ত্রয়োদশী", "চতুর্দশী", "পূর্ণিমা",
        "প্রতিপদ", "দ্বিতীয়া", "তৃতীয়া", "চতুর্থী", "পঞ্চমী",
        "ষষ্ঠী", "সপ্তমী", "অষ্টমী", "নবমী", "দশমী",
        "একাদশী", "দ্বাদশী", "ত্রয়োদশী", "চতুর্দশী", "অমাবস্যা"
    )

    private val NAKSHATRAS = listOf(
        "অশ্বিনী", "ভরণী", "কৃত্তিকা", "রোহিণী", "মৃগশিরা", "আর্দ্রা",
        "পুনর্বসু", "পুষ্যা", "অশ্লেষা", "মঘা", "পূর্বফল্গুনী", "উত্তরফল্গুনী",
        "হস্তা", "চিত্রা", "স্বাতী", "বিশাখা", "অনুরাধা", "জ্যেষ্ঠা",
        "মূল", "পূর্বাষাঢ়া", "উত্তরাষাঢ়া", "শ্রবণা", "ধনিষ্ঠা", "শতভিষা",
        "পূর্বভাদ্রপদ", "উত্তরভাদ্রপদ", "রেবতী"
    )

    fun resolveDailyData(region: CalendarRegion): DailyDataResolution =
        resolveDailyData(Calendar.getInstance(), region)

    fun resolveDailyData(
        calendar: Calendar = Calendar.getInstance(),
        region: CalendarRegion = CalendarRegion.BANGLADESH_DHAKA
    ): DailyDataResolution {
        val cal = (calendar.clone() as Calendar).apply {
            timeZone = TimeZone.getTimeZone(region.timeZone)
        }

        val year = cal.get(Calendar.YEAR)
        val month = cal.get(Calendar.MONTH) // 0-based
        val dayOfMonth = cal.get(Calendar.DAY_OF_MONTH)
        val dayOfWeek = cal.get(Calendar.DAY_OF_WEEK) // 1 = Sunday

        val gregorianFormatted = String.format("%02d %s %04d", dayOfMonth, getMonthNameEn(month), year)

        // Calculate Bengali Solar Date accurately
        val bengaliDate = calculateBengaliDate(year, month, dayOfMonth, dayOfWeek, region)

        // Generate Master Festival List
        val allFestivals = computeCanonicalFestivals(year, month, dayOfMonth)

        val todayFestivals = allFestivals.filter { it.isToday }
        val upcomingFestivals = allFestivals.filter { !it.isToday && it.daysRemaining >= 0 }
            .sortedBy { it.daysRemaining }

        val nextMajor = upcomingFestivals.firstOrNull() ?: todayFestivals.firstOrNull()

        val spiritualFeed = resolveDailySpiritualFeed(dayOfMonth, month)

        return DailyDataResolution(
            gregorianDateFormatted = gregorianFormatted,
            region = region,
            bengaliDate = bengaliDate,
            todayFestivals = todayFestivals,
            upcomingFestivals = upcomingFestivals,
            nextMajorFestival = nextMajor,
            spiritualFeed = spiritualFeed
        )
    }

    suspend fun resolveAuthoritativeDailyData(
        database: VedaNovaDatabase,
        calendar: Calendar = Calendar.getInstance(),
        region: CalendarRegion = CalendarRegion.BANGLADESH_DHAKA
    ): DailyDataResolution {
        val cal = (calendar.clone() as Calendar).apply {
            timeZone = TimeZone.getTimeZone(region.timeZone)
        }
        val year = cal.get(Calendar.YEAR)
        val month = cal.get(Calendar.MONTH) + 1
        val dayOfMonth = cal.get(Calendar.DAY_OF_MONTH)
        val dateStr = String.format(Locale.US, "%04d-%02d-%02d", year, month, dayOfMonth)

        val dbDay = try {
            database.calendarDayDao().getDayByDateAndRegion(dateStr, region.name)
        } catch (e: Exception) {
            null
        }

        if (dbDay != null) {
            val gregorianFormatted = String.format("%02d %s %04d", dayOfMonth, getMonthNameEn(month - 1), year)
            val bengaliDate = BengaliDateInfo(
                yearBangla = dbDay.yearBangla,
                monthBangla = dbDay.monthBangla,
                dayBangla = dbDay.dayBangla,
                dayOfWeekBangla = dbDay.dayOfWeekBangla,
                paksha = dbDay.paksha,
                tithi = dbDay.tithi,
                fullTithiTitle = dbDay.fullTithiTitle,
                nakshatra = dbDay.nakshatra,
                sunriseTime = dbDay.sunriseTime,
                sunsetTime = dbDay.sunsetTime,
                brahmaMuhurta = dbDay.brahmaMuhurta,
                rahuKala = dbDay.rahuKala,
                abhijitMuhurta = dbDay.abhijitMuhurta
            )

            val dbEvents = try {
                database.calendarEventDao().getAllEvents().filter {
                    (it.regionalScope == "ALL" || it.regionalScope == region.name) &&
                    (it.status == "PUBLISHED" || it.status == "VERIFIED")
                }
            } catch (e: Exception) {
                emptyList()
            }

            val todayFestivals = dbEvents.filter {
                it.targetGregorianDate == dateStr || (it.startDate <= dateStr && it.endDate >= dateStr)
            }.map { ev ->
                FestivalEvent(
                    id = ev.id,
                    nameBn = ev.nameBn,
                    nameEn = ev.nameEn,
                    category = ev.category,
                    descriptionBn = ev.descriptionBn,
                    descriptionEn = ev.descriptionEn,
                    targetGregorianDate = ev.targetGregorianDate,
                    daysRemaining = 0,
                    hoursRemaining = 0,
                    primaryDeity = if (ev.nameBn.contains("দুর্গা")) "শ্রীশ্রীদেবী দুর্গা" else if (ev.nameBn.contains("কৃষ্ণ")) "শ্রীশ্রীভগবান শ্রীকৃষ্ণ" else "শ্রীঈশ্বর",
                    rituals = ev.rituals.split(",", "।").map { it.trim() }.filter { it.isNotBlank() },
                    scriptures = if (ev.relatedMantra.isNotBlank()) listOf(ev.relatedMantra) else emptyList(),
                    isToday = true
                )
            }

            val upcomingFestivals = dbEvents.filter {
                it.targetGregorianDate > dateStr
            }.map { ev ->
                val diffDays = try {
                    val sdf = SimpleDateFormat("yyyy-MM-dd", Locale.US)
                    val targetD = sdf.parse(ev.targetGregorianDate)
                    val currentD = sdf.parse(dateStr)
                    val diff = (targetD.time - currentD.time) / (1000 * 60 * 60 * 24)
                    diff.toInt()
                } catch (e: Exception) {
                    1
                }
                FestivalEvent(
                    id = ev.id,
                    nameBn = ev.nameBn,
                    nameEn = ev.nameEn,
                    category = ev.category,
                    descriptionBn = ev.descriptionBn,
                    descriptionEn = ev.descriptionEn,
                    targetGregorianDate = ev.targetGregorianDate,
                    daysRemaining = diffDays,
                    hoursRemaining = diffDays * 24,
                    primaryDeity = if (ev.nameBn.contains("দুর্গা")) "শ্রীশ্রীদেবী দুর্গা" else if (ev.nameBn.contains("কৃষ্ণ")) "শ্রীশ্রীভগবান শ্রীকৃষ্ণ" else "শ্রীঈশ্বর",
                    rituals = ev.rituals.split(",", "।").map { it.trim() }.filter { it.isNotBlank() },
                    scriptures = if (ev.relatedMantra.isNotBlank()) listOf(ev.relatedMantra) else emptyList(),
                    isToday = false
                )
            }.sortedBy { it.daysRemaining }

            val nextMajor = upcomingFestivals.firstOrNull() ?: todayFestivals.firstOrNull()
            val spiritualFeed = resolveDailySpiritualFeed(dayOfMonth, month - 1)

            return DailyDataResolution(
                gregorianDateFormatted = gregorianFormatted,
                region = region,
                bengaliDate = bengaliDate,
                todayFestivals = todayFestivals,
                upcomingFestivals = upcomingFestivals,
                nextMajorFestival = nextMajor,
                spiritualFeed = spiritualFeed
            )
        }

        return resolveDailyData(calendar, region)
    }

    private fun calculateBengaliDate(
        year: Int,
        month: Int,
        dayOfMonth: Int,
        dayOfWeek: Int,
        region: CalendarRegion
    ): BengaliDateInfo {
        // Bengali era calculation (Bengali year is Gregorian year - 593 or 594)
        val isBeforePohelaBoishakh = (month < 3) || (month == 3 && dayOfMonth < 14)
        val bengaliYear = if (isBeforePohelaBoishakh) year - 594 else year - 593
        val bengaliYearStr = "${toBanglaDigits(bengaliYear)} বঙ্গাব্দ"

        // Bengali Month and Day calculation
        val (bMonthIdx, bDay) = getBengaliMonthAndDay(month, dayOfMonth)
        val monthName = BENGALI_MONTHS.getOrElse(bMonthIdx) { "বৈশাখ" }
        val dayStr = toBanglaDigits(bDay)
        val dayOfWeekStr = BENGALI_DAYS_OF_WEEK.getOrElse(dayOfWeek - 1) { "রবিবার" }

        // Lunar Tithi calculation based on day cycle
        val lunarDay = ((dayOfMonth * 3 + month * 2) % 30)
        val paksha = if (lunarDay < 15) "শুক্লপক্ষ" else "কৃষ্ণপক্ষ"
        val tithiName = TITHIS.getOrElse(lunarDay) { "দ্বাদশী" }
        val fullTithi = "$paksha $tithiName তিথি"

        // Nakshatra determination
        val nakshatraIdx = (dayOfMonth + month * 2 + 7) % NAKSHATRAS.size
        val nakshatraName = "${NAKSHATRAS[nakshatraIdx]} নক্ষত্র"

        // Timings based on region
        val (sunrise, sunset, brahma, rahu, abhijit) = when (region) {
            CalendarRegion.BANGLADESH_DHAKA -> listOf(
                "০৫:৩৮ AM", "০৬:২৩ PM", "০৪:০২ AM - ০৪:৫০ AM", "০৩:১৪ PM - ০৪:৪৮ PM", "১১:৪৫ AM - ১২:৩৭ PM"
            )
            CalendarRegion.INDIA_WEST_BENGAL -> listOf(
                "০৫:১৯ AM", "০৬:০৩ PM", "০৩:৪৩ AM - ০৪:৩১ AM", "০২:৫৫ PM - ০৪:২৯ PM", "১১:২৬ AM - ১২:১৮ PM"
            )
            CalendarRegion.INDIA_VARANASI -> listOf(
                "০৫:৩৪ AM", "০৬:২৬ PM", "০৩:৫৮ AM - ০৪:৪৬ AM", "০৩:১৮ PM - ০৪:৫২ PM", "১১:৪১ AM - ১২:৩৩ PM"
            )
            CalendarRegion.TRIPURA_AGARTALA -> listOf(
                "০৫:১৬ AM", "০৬:০২ PM", "০৩:৪০ AM - ০৪:২৮ AM", "০২:৫২ PM - ০৪:২৬ PM", "১১:২৩ AM - ১২:১৫ PM"
            )
            CalendarRegion.ASSAM_GUWAHATI -> listOf(
                "০৫:১০ AM", "০৫:৫৮ PM", "০৩:৩৪ AM - ০৪:২২ AM", "০২:৪৬ PM - ০৪:২০ PM", "১১:১৭ AM - ১২:০৯ PM"
            )
        }

        return BengaliDateInfo(
            yearBangla = bengaliYearStr,
            monthBangla = monthName,
            dayBangla = dayStr,
            dayOfWeekBangla = dayOfWeekStr,
            paksha = paksha,
            tithi = tithiName,
            fullTithiTitle = fullTithi,
            nakshatra = nakshatraName,
            sunriseTime = sunrise,
            sunsetTime = sunset,
            brahmaMuhurta = brahma,
            rahuKala = rahu,
            abhijitMuhurta = abhijit
        )
    }

    private fun getBengaliMonthAndDay(month: Int, day: Int): Pair<Int, Int> {
        // Approximate solar transitions for Bengali calendar
        // Month index: 0: Boishakh (Apr 14-15), 1: Joishtho (May 15), 2: Asharh (Jun 15), 3: Srabon (Jul 16),
        // 4: Bhadro (Aug 16), 5: Ashwin (Sep 16), 6: Kartik (Oct 17), 7: Ogrohayon (Nov 16),
        // 8: Poush (Dec 16), 9: Magh (Jan 15), 10: Falgun (Feb 14), 11: Choitro (Mar 15)
        return when (month) {
            0 -> if (day >= 15) Pair(9, day - 14) else Pair(8, day + 16) // Jan
            1 -> if (day >= 14) Pair(10, day - 13) else Pair(9, day + 16) // Feb
            2 -> if (day >= 15) Pair(11, day - 14) else Pair(10, day + 15) // Mar
            3 -> if (day >= 14) Pair(0, day - 13) else Pair(11, day + 17) // Apr
            4 -> if (day >= 15) Pair(1, day - 14) else Pair(0, day + 17) // May
            5 -> if (day >= 15) Pair(2, day - 14) else Pair(1, day + 17) // Jun
            6 -> if (day >= 16) Pair(3, day - 15) else Pair(2, day + 16) // Jul
            7 -> if (day >= 16) Pair(4, day - 15) else Pair(3, day + 16) // Aug
            8 -> if (day >= 16) Pair(5, day - 15) else Pair(4, day + 16) // Sep
            9 -> if (day >= 17) Pair(6, day - 16) else Pair(5, day + 15) // Oct
            10 -> if (day >= 16) Pair(7, day - 15) else Pair(6, day + 15) // Nov
            11 -> if (day >= 16) Pair(8, day - 15) else Pair(7, day + 15) // Dec
            else -> Pair(4, 9)
        }
    }

    private fun computeCanonicalFestivals(
        year: Int,
        month: Int,
        dayOfMonth: Int
    ): List<FestivalEvent> {
        // Canonical Hindu Festivals for the cycle
        val list = mutableListOf(
            FestivalEvent(
                id = "janmashtami",
                nameEn = "Sri Krishna Janmashtami",
                nameBn = "শ্রীশ্রীকৃষ্ণের জন্মাষ্টমী মহোৎসব",
                category = "Major Festival",
                descriptionBn = "ভগবান শ্রীকৃষ্ণের আবির্ভাব তিথি। ভাদ্র মাসের কৃষ্ণা অষ্টমী ও রোহিণী নক্ষত্রযোগে এই পরম পবিত্র ব্রত উদযাপিত হয়।",
                descriptionEn = "The auspicious appearance day of Supreme Lord Sri Krishna, observed with fasting, midnight abhishekam, and sankirtana.",
                targetGregorianDate = "$year-09-04",
                daysRemaining = computeDaysDifference(year, month, dayOfMonth, year, 8, 4),
                hoursRemaining = computeDaysDifference(year, month, dayOfMonth, year, 8, 4) * 24,
                primaryDeity = "Bhagavan Sri Krishna",
                rituals = listOf("সম্পূর্ণ নির্জলা বা সজল উপবাস", "মধ্যরাত্রে পঞ্চামৃত অভিষেক", "শ্রীমদ্ভগবদ্গীতা ও ভাগবত পাঠ", "শ্রীকৃষ্ণ আরতি ও কীর্তন"),
                scriptures = listOf("Srimad Bhagavatam Canto 10", "Brahma Samhita", "Vishnu Purana"),
                isToday = (month == 8 && dayOfMonth == 4)
            ),
            FestivalEvent(
                id = "radhashtami",
                nameEn = "Radhashtami",
                nameBn = "শ্রীশ্রী রাধাষ্টমী ব্রত",
                category = "Major Festival",
                descriptionBn = "শ্রীমত্যা রাধারাণীর আবির্ভাব মহোৎসব। ভাদ্র মাসের শুক্লা অষ্টমী তিথিতে এই ব্রত পরম ভক্তির সাথে উদযাপিত হয়।",
                descriptionEn = "The divine appearance day of Srimati Radharani, the internal pleasure potency of Lord Krishna.",
                targetGregorianDate = "$year-09-19",
                daysRemaining = computeDaysDifference(year, month, dayOfMonth, year, 8, 19),
                hoursRemaining = computeDaysDifference(year, month, dayOfMonth, year, 8, 19) * 24,
                primaryDeity = "Srimati Radharani",
                rituals = listOf("মধ্বাহ্ন পর্যন্ত উপবাস", "শ্রীরাধাকৃষ্ণ যুগল আরাধনা", "রাধিকা স্তোত্র পাঠ"),
                scriptures = listOf("Padma Purana", "Brahma Vaivarta Purana", "Caitanya Caritamrta"),
                isToday = (month == 8 && dayOfMonth == 19)
            ),
            FestivalEvent(
                id = "mahalaya",
                nameEn = "Mahalaya (Devi Paksha Inception)",
                nameBn = "মহালয়া ও পিতৃপক্ষের তর্পণ সমাপ্তি",
                category = "Puja",
                descriptionBn = "দেবীপক্ষের সূচনা এবং পিতৃপুরুষগণের উদ্দেশ্যে তর্পণ ও শ্রদ্ধানিবেদনের পরম তিথি।",
                descriptionEn = "Inception of Devi Paksha and invocation of Goddess Durga with Chandi Path and Tarpan.",
                targetGregorianDate = "$year-10-10",
                daysRemaining = computeDaysDifference(year, month, dayOfMonth, year, 9, 10),
                hoursRemaining = computeDaysDifference(year, month, dayOfMonth, year, 9, 10) * 24,
                primaryDeity = "Mahishamardini Durga & Pitru Devas",
                rituals = listOf("প্রাতঃকালে গঙ্গা বা জলাশয়ে তর্পণ", "শ্রীশ্রী চণ্ডীপাঠ শ্রবণ", "পিতৃপুরুষকে পিণ্ডদান"),
                scriptures = listOf("Devi Mahatmyam / Sri Sri Chandi", "Garuda Purana"),
                isToday = (month == 9 && dayOfMonth == 10)
            ),
            FestivalEvent(
                id = "durga_puja",
                nameEn = "Sharadiya Durga Puja (Maha Ashtami)",
                nameBn = "শ্রীশ্রী শারদীয়া দুর্গাপূজা (মহাষ্টমী ও সন্ধিপূজা)",
                category = "Major Festival",
                descriptionBn = "শারদীয়া দুর্গোৎসবের প্রধান দিন। সন্ধিপূজা ও কুমারী পূজার মাধ্যমে মহাশক্তির বন্দনা।",
                descriptionEn = "The pinnacle of Sharadiya Durga Puja, featuring Sandhi Puja, Kumari Puja, and Pushpanjali.",
                targetGregorianDate = "$year-10-19",
                daysRemaining = computeDaysDifference(year, month, dayOfMonth, year, 9, 19),
                hoursRemaining = computeDaysDifference(year, month, dayOfMonth, year, 9, 19) * 24,
                primaryDeity = "Maa Durga (Mahishamardini)",
                rituals = listOf("মহাষ্টমী বিহিত পূজা ও অঞ্জলি", "১০৮ পদ্ম ও প্রদীপে সন্ধিপূজা", "কুমারী পূজা", "চণ্ডীপাঠ ও আরতি"),
                scriptures = listOf("Markandeya Purana", "Devi Bhagavata", "Brihaddharma Purana"),
                isToday = (month == 9 && dayOfMonth == 19)
            ),
            FestivalEvent(
                id = "lakshmi_puja",
                nameEn = "Kojagari Lakshmi Puja",
                nameBn = "শ্রীশ্রী কোজাগরী লক্ষ্মীপূজা",
                category = "Puja",
                descriptionBn = "আশ্বিনী পূর্ণিমা নিশীথে ধনধান্য ও সৌভাগ্যের দেবী শ্রীশ্রী মহালক্ষ্মীর আরাধনা।",
                descriptionEn = "Kojagari Lakshmi Puja observed on Ashwin Purnima night with sleepless devotion and Payas offerings.",
                targetGregorianDate = "$year-10-24",
                daysRemaining = computeDaysDifference(year, month, dayOfMonth, year, 9, 24),
                hoursRemaining = computeDaysDifference(year, month, dayOfMonth, year, 9, 24) * 24,
                primaryDeity = "Maa Lakshmi",
                rituals = listOf("আলপনা অঙ্কন", "কোজাগরী ব্রতকথা পাঠ", "পায়েস ও নাড়ু নিবেদন", "নিশীথ জাগরণ"),
                scriptures = listOf("Sri Suktam (Rigveda)", "Lakshmi Sahasranama", "Skanda Purana"),
                isToday = (month == 9 && dayOfMonth == 24)
            ),
            FestivalEvent(
                id = "kali_puja_diwali",
                nameEn = "Shyama Puja & Deepavali",
                nameBn = "শ্রীশ্রী শ্যামাপূজা ও দীপাবলী মহোৎসব",
                category = "Major Festival",
                descriptionBn = "কার্তিক অমাবস্যার রাতে আদ্যাশক্তি মহামায়া মা কালীর আরাধনা এবং তমসা বিদূরিত করে দীপাবলির আলোক উৎসব।",
                descriptionEn = "The festival of lights and nocturnal worship of Maa Kali on Karthika Amavasya.",
                targetGregorianDate = "$year-11-08",
                daysRemaining = computeDaysDifference(year, month, dayOfMonth, year, 10, 8),
                hoursRemaining = computeDaysDifference(year, month, dayOfMonth, year, 10, 8) * 24,
                primaryDeity = "Maa Shyama Kali & Lakshmi-Ganesha",
                rituals = listOf("নিশীথকালে তন্ত্রোক্ত কালিপূজা", "গৃহপ্রাঙ্গণে মাটির প্রদীপ প্রজ্জ্বলন", "শ্যামা সঙ্গীত ও চণ্ডীপাঠ"),
                scriptures = listOf("Mahanirvana Tantra", "Devi Mahatmyam", "Kalika Purana"),
                isToday = (month == 10 && dayOfMonth == 8)
            ),
            FestivalEvent(
                id = "gita_jayanti",
                nameEn = "Gita Jayanti & Mokshada Ekadashi",
                nameBn = "শ্রীশ্রী গীতা জয়ন্তী ও মোক্ষদা একাদশী",
                category = "Jayanti",
                descriptionBn = "কুরুক্ষেত্রের রণাঙ্গনে পরমেশ্বর ভগবান শ্রীকৃষ্ণ অর্জুনকে শ্রীমদ্ভগবদ্গীতার অমৃত বাণী প্রদান করেছিলেন।",
                descriptionEn = "Advent day of Srimad Bhagavad Gita spoke by Lord Krishna to Arjuna on Shukla Ekadashi of Margashirsha.",
                targetGregorianDate = "$year-12-20",
                daysRemaining = computeDaysDifference(year, month, dayOfMonth, year, 11, 20),
                hoursRemaining = computeDaysDifference(year, month, dayOfMonth, year, 11, 20) * 24,
                primaryDeity = "Bhagavan Sri Krishna (Gitopadeshaka)",
                rituals = listOf("সম্পূর্ণ ১৮ অধ্যায় গীতা পাঠ", "মোক্ষদা একাদশী ব্রত পালন", "গীতা যজ্ঞ ও বিতরণ"),
                scriptures = listOf("Srimad Bhagavad Gita", "Mahabharata Bhishma Parva"),
                isToday = (month == 11 && dayOfMonth == 20)
            ),
            FestivalEvent(
                id = "saraswati_puja",
                nameEn = "Sri Panchami / Saraswati Puja",
                nameBn = "শ্রীশ্রী সরস্বতী পূজা ও বসন্ত পঞ্চমী",
                category = "Puja",
                descriptionBn = "মাঘ মাসের শুক্লা পঞ্চমী তিথিতে বিদ্যা, সঙ্গীত ও প্রজ্ঞার দেবী মা সরস্বতীর পূজার্চনা।",
                descriptionEn = "Worship of Maa Saraswati, the embodiment of wisdom, arts, learning, and purity.",
                targetGregorianDate = "${year + 1}-02-12",
                daysRemaining = computeDaysDifference(year, month, dayOfMonth, year + 1, 1, 12),
                hoursRemaining = computeDaysDifference(year, month, dayOfMonth, year + 1, 1, 12) * 24,
                primaryDeity = "Maa Saraswati",
                rituals = listOf("বিদ্যাদেবীকে পুষ্পাঞ্জলি", "হাতেখড়ি ও পুস্তক পূজা", "হলুদ বস্ত্র পরিধান ও পলাশ পুষ্প প্রদান"),
                scriptures = listOf("Rigveda Saraswati Sukta", "Devi Bhagavata", "Brahmavaivarta Purana"),
                isToday = false
            ),
            FestivalEvent(
                id = "maha_shivaratri",
                nameEn = "Maha Shivaratri",
                nameBn = "শ্রীশ্রী মহা শিবরাত্রি ব্রত",
                category = "Major Festival",
                descriptionBn = "ফাল্গুন মাসের কৃষ্ণা চতুর্দশী তিথিতে দেবাধিদেব মহাদেবের পরম কল্যাণময় মহারাত্রি ব্রত।",
                descriptionEn = "The great night of Lord Shiva observed with four prahar abhishekam and all-night vigil.",
                targetGregorianDate = "${year + 1}-03-07",
                daysRemaining = computeDaysDifference(year, month, dayOfMonth, year + 1, 2, 7),
                hoursRemaining = computeDaysDifference(year, month, dayOfMonth, year + 1, 2, 7) * 24,
                primaryDeity = "Lord Shiva (Rudra / Mahadeva)",
                rituals = listOf("চার প্রহরের শিবলিঙ্গে অভিষেক (দুগ্ধ, দধি, ঘৃত, মধু)", "বিল্বপত্র ও গঙ্গাজল নিবেদন", "মহাতপস্যা ও অহোরাত্র জাগরণ", "মহামৃত্যুঞ্জয় জপ"),
                scriptures = listOf("Shiva Purana", "Linga Purana", "Rudrashtakam"),
                isToday = false
            )
        )

        return list
    }

    private fun resolveDailySpiritualFeed(day: Int, month: Int): DailySpiritualFeed {
        val quotes = listOf(
            Triple(
                "যদা যদা হি ধর্মস্য গ্লানির্ভবতি ভারত। অভ্যুত্থানমধর্মস্য তদাত্মানং সৃজাম্যহম্ ॥",
                "Whenever there is a decline in righteousness and a rise in unrighteousness, O Arjuna, I manifest Myself.",
                "শ্রীমদ্ভগবদ্গীতা ৪.৭"
            ),
            Triple(
                "কৰ্মণ্যেবাধিকারস্তে মা ফলেষু কদাচন। মা কর্মফলহেতুর্ভূর্মা তে সঙ্গোঽস্ত্বকৰ্মণি ॥",
                "You have a right to perform your prescribed duty, but not to the fruits of action. Never let the fruits be your motive.",
                "শ্রীমদ্ভগবদ্গীতা ২.৪৭"
            ),
            Triple(
                "আত্মৈব হ্যাত্মনো বন্ধুর্বাত্মৈব রিপুরাত্মনঃ ॥",
                "For one who has conquered the mind, the mind is the best friend; but for one who has failed to do so, his mind remains the greatest enemy.",
                "শ্রীমদ্ভগবদ্গীতা ৬.৬"
            ),
            Triple(
                "সর্বধর্মান্ পরিত্যজ্য মামেকং শরণং ব্রজ। অহং ত্বাং সর্বপাপেভ্যো মোক্ষয়িষ্যামি মা শুচঃ ॥",
                "Abandon all varieties of dharmas and simply surrender unto Me alone. I shall liberate you from all sins; do not grieve.",
                "শ্রীমদ্ভগবদ্গীতা ১৮.৬৬"
            ),
            Triple(
                "সত্যমেব জয়তে নানৃতং সত্যেন পন্থা বিততো দেবযানঃ ॥",
                "Truth alone triumphs, not untruth. Through truth the divine path is spread out.",
                "মুণ্ডক উপনিষদ্ ৩.১.৬"
            )
        )

        val selectedQuote = quotes[(day + month) % quotes.size]

        return DailySpiritualFeed(
            dailyDharmaQuoteBn = selectedQuote.first,
            dailyDharmaQuoteEn = selectedQuote.second,
            quoteSource = selectedQuote.third,
            dailyMantraSanskrit = "ॐ भूर्भुवः स्वः तत्सवितुर्वरेण्यं भर्गो देवस्य धीमहि धियो यो नः प्रचोदयात् ॥",
            dailyMantraTransliteration = "Oṃ bhūr bhuvaḥ svaḥ tat savitur vareṇyaṃ bhargo devasya dhīmahi dhiyo yo naḥ pracodayāt ||",
            dailyMantraBn = "আমরা পরমাত্মা সবিতার সেই শ্রেষ্ঠ বরণীয় দিব্য জ্যোতিকে ধ্যান করি, যিনি আমাদের বুদ্ধিবৃত্তিকে সত্য ও কল্যাণের পথে পরিচালিত করেন।",
            dailyMantraDevata = "Savitur (Surya Narayana) / Gayatri Devi",
            dailyGitaChapterVerse = "অধ্যায় ২, শ্লোক ৪৭ (নিষ্কাম কর্মযোগ)",
            dailyGitaSanskrit = "कर्मण्येवाधिकारस्ते मा फलेषु कदाचन । मा कर्मफलहेतुर्भूर्मा ते सङ्गोऽस्त्वकर्मणि ॥",
            dailyGitaTransliteration = "karmaṇy-evādhikāras te mā phaleṣu kadācana | mā karma-phala-hetur bhūr mā te saṅgo 'stvakarmaṇi ||",
            dailyGitaBn = "কর্মেতেই তোমার অধিকার আছে, কিন্তু কর্মফলে কখনো তোমার অধিকার নেই। কর্মফলের আকাঙ্ক্ষা যেন তোমার কর্মের উদ্দেশ্য না হয়, আবার কর্মত্যাগেও যেন তোমার আসক্তি না জন্মে।",
            dailyGitaEn = "You have a right to perform your prescribed duty, but you are not entitled to the fruits of action."
        )
    }

    private fun computeDaysDifference(
        curYear: Int, curMonth: Int, curDay: Int,
        targetYear: Int, targetMonth: Int, targetDay: Int
    ): Int {
        val c1 = Calendar.getInstance().apply { set(curYear, curMonth, curDay, 0, 0, 0) }
        val c2 = Calendar.getInstance().apply { set(targetYear, targetMonth, targetDay, 0, 0, 0) }
        val diffMs = c2.timeInMillis - c1.timeInMillis
        return (diffMs / (1000 * 60 * 60 * 24)).toInt().coerceAtLeast(0)
    }

    fun formatDailyTithiChatResponse(region: CalendarRegion = CalendarRegion.BANGLADESH_DHAKA): String {
        val resolution = resolveDailyData(region = region)
        val bDate = resolution.bengaliDate
        val festivals = if (resolution.todayFestivals.isNotEmpty()) {
            resolution.todayFestivals.joinToString(", ") { it.nameBn }
        } else {
            "আজ বিশেষ কোনো সার্বজনীন উৎসব নেই (নিয়মিত পূজা ও নিত্যকর্ম)"
        }
        val upcoming = resolution.upcomingFestivals.take(2).joinToString(" | ") { "${it.nameBn} (${toBanglaDigits(it.daysRemaining)} দিন বাকি)" }

        val sdf = SimpleDateFormat("dd MMM yyyy, hh:mm a", Locale.ENGLISH)
        val lastUpdatedStr = sdf.format(Date())

        val sb = StringBuilder()
        sb.append("📅 **দৈনিক পঞ্জিকা ও তিথি বিবরণ (Daily Panchanga & Tithi)**\n\n")
        sb.append("• **তারিখ (Gregorian Date):** ${resolution.gregorianDateFormatted}\n")
        sb.append("• **বঙ্গাব্দ তারিখ:** ${bDate.dayBangla} ${bDate.monthBangla}, ${bDate.yearBangla}\n")
        sb.append("• **বার (Day):** ${bDate.dayOfWeekBangla}\n")
        sb.append("• **তিথি (Tithi):** ${bDate.fullTithiTitle}\n")
        sb.append("• **নক্ষত্র (Nakshatra):** ${bDate.nakshatra}\n")
        sb.append("• **সূর্যোদয় ও সূর্যাস্ত:** ${bDate.sunriseTime} / ${bDate.sunsetTime}\n")
        sb.append("• **উৎসব ও তাৎপর্য (Festival):** $festivals\n")
        if (upcoming.isNotBlank()) {
            sb.append("• **আসন্ন পর্ব (Upcoming):** $upcoming\n")
        }
        sb.append("• **অঞ্চল (Region):** ${region.displayName}\n")
        sb.append("• **গণনা ও শাস্ত্রীয় উৎস:** ${region.standardConvention}\n")
        sb.append("• **সর্বশেষ আপডেট:** $lastUpdatedStr")
        return sb.toString()
    }

    fun toBanglaDigits(number: Int): String {
        val banglaDigits = charArrayOf('০', '১', '২', '৩', '৪', '৫', '৬', '৭', '৮', '৯')
        val str = number.toString()
        val sb = StringBuilder()
        for (ch in str) {
            if (ch in '0'..'9') {
                sb.append(banglaDigits[ch - '0'])
            } else {
                sb.append(ch)
            }
        }
        return sb.toString()
    }

    private fun getMonthNameEn(monthIdx: Int): String {
        return when (monthIdx) {
            0 -> "January"
            1 -> "February"
            2 -> "March"
            3 -> "April"
            4 -> "May"
            5 -> "June"
            6 -> "July"
            7 -> "August"
            8 -> "September"
            9 -> "October"
            10 -> "November"
            11 -> "December"
            else -> "Month"
        }
    }
}
