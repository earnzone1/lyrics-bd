package com.example.domain.image

import android.content.Context
import android.graphics.BitmapFactory
import android.util.Base64
import com.example.data.remote.GeminiNetworkClient
import com.example.domain.diagnostic.CrashReportingManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.util.concurrent.TimeUnit

class GeminiImageProvider : ImageGenerationProvider {

    override val providerId: String = "gemini_image_provider"
    override val providerName: String = "Google Gemini Image AI"
    override val defaultModel: String = "gemini-2.5-flash-image"

    private val httpClient: OkHttpClient by lazy {
        OkHttpClient.Builder()
            .connectTimeout(60, TimeUnit.SECONDS)
            .readTimeout(90, TimeUnit.SECONDS)
            .writeTimeout(60, TimeUnit.SECONDS)
            .build()
    }

    override fun isConfigured(): Boolean {
        val key = GeminiNetworkClient.getApiKey()
        return key.isNotBlank() && key != "MY_GEMINI_API_KEY"
    }

    override fun getConfigurationMessage(): String {
        return if (isConfigured()) {
            "Google Gemini Image Generation Provider সক্রিয় ও কনফিগার করা রয়েছে।"
        } else {
            "Image Generation service বর্তমানে configured নয়। অনুগ্রহ করে API Key কনফিগার করুন।"
        }
    }

    override fun getSupportedAspectRatios(): List<ImageAspectRatio> {
        return listOf(
            ImageAspectRatio.SQUARE,
            ImageAspectRatio.PORTRAIT,
            ImageAspectRatio.PORTRAIT_STORY,
            ImageAspectRatio.LANDSCAPE,
            ImageAspectRatio.LANDSCAPE_PHOTO
        )
    }

    override fun supportsImageEditing(): Boolean = true
    override fun supportsVision(): Boolean = true

    override suspend fun generateImage(
        request: ImageGenerationRequest,
        context: Context
    ): ImageGenerationResult = withContext(Dispatchers.IO) {
        if (!isConfigured()) {
            return@withContext ImageGenerationResult(
                status = ImageGenerationStatus.NOT_CONFIGURED,
                rawPrompt = request.prompt,
                aspectRatio = request.aspectRatio.ratioStr,
                providerName = providerName,
                modelName = defaultModel,
                errorMessage = "Image Generation service বর্তমানে configured নয়।"
            )
        }

        val apiKey = GeminiNetworkClient.getApiKey()
        val finalPrompt = if (request.isDharmaEnhanced) {
            val styleTag = request.style.stylePromptTag
            val enhanced = DharmaPromptEnhancer.enhancePrompt(request.prompt)
            "$enhanced. Visual Style: $styleTag."
        } else {
            "${request.prompt}. Visual Style: ${request.style.stylePromptTag}."
        }

        try {
            // Construct payload for gemini-2.5-flash-image with multimodal responseModalities
            val root = JSONObject()
            val contentsArray = JSONArray()
            val contentObj = JSONObject()
            val partsArray = JSONArray()

            val partObj = JSONObject()
            partObj.put("text", finalPrompt)
            partsArray.put(partObj)

            // Support reference image (for variation / guided generation)
            if (!request.referenceImageUri.isNullOrBlank()) {
                try {
                    val refBytes = if (request.referenceImageUri.startsWith("file://")) {
                        val file = File(request.referenceImageUri.removePrefix("file://"))
                        if (file.exists()) file.readBytes() else null
                    } else if (request.referenceImageUri.startsWith("/")) {
                        val file = File(request.referenceImageUri)
                        if (file.exists()) file.readBytes() else null
                    } else {
                        ImageStorageManager.readBytesFromUri(context, android.net.Uri.parse(request.referenceImageUri))
                    }

                    if (refBytes != null && refBytes.isNotEmpty()) {
                        val refBase64 = Base64.encodeToString(refBytes, Base64.NO_WRAP)
                        val refPart = JSONObject()
                        val inlineData = JSONObject()
                        inlineData.put("mimeType", "image/png")
                        inlineData.put("data", refBase64)
                        refPart.put("inlineData", inlineData)
                        partsArray.put(refPart)
                    }
                } catch (e: Exception) {
                    // Non-fatal, proceed with prompt
                }
            }

            contentObj.put("parts", partsArray)
            contentsArray.put(contentObj)
            root.put("contents", contentsArray)

            val genConfig = JSONObject()
            val modalities = JSONArray()
            modalities.put("TEXT")
            modalities.put("IMAGE")
            genConfig.put("responseModalities", modalities)

            val imageConfig = JSONObject()
            imageConfig.put("aspectRatio", request.aspectRatio.ratioStr)
            imageConfig.put("imageSize", if (request.quality == ImageQuality.HIGH) "2K" else "1K")
            genConfig.put("imageConfig", imageConfig)

            root.put("generationConfig", genConfig)

            val url = "https://generativelanguage.googleapis.com/v1beta/models/$defaultModel:generateContent?key=$apiKey"
            val mediaType = "application/json; charset=utf-8".toMediaType()
            val requestBody = root.toString().toRequestBody(mediaType)

            val httpRequest = Request.Builder()
                .url(url)
                .post(requestBody)
                .build()

            val response = httpClient.newCall(httpRequest).execute()
            val responseBody = response.body?.string()

            if (!response.isSuccessful || responseBody.isNullOrBlank()) {
                val errorMsg = parseErrorMessage(response.code, responseBody)
                CrashReportingManager.recordException(
                    screen = "IMAGE_STUDIO",
                    throwable = Exception(errorMsg),
                    action = "GeminiImageProvider.generateImage: HTTP ${response.code}"
                )
                return@withContext ImageGenerationResult(
                    status = ImageGenerationStatus.FAILED,
                    rawPrompt = request.prompt,
                    enhancedPrompt = finalPrompt,
                    aspectRatio = request.aspectRatio.ratioStr,
                    providerName = providerName,
                    modelName = defaultModel,
                    errorMessage = "Image generation failed ($errorMsg)"
                )
            }

            // Parse response JSON for inline image bytes
            val json = JSONObject(responseBody)
            val candidates = json.optJSONArray("candidates")
            if (candidates == null || candidates.length() == 0) {
                return@withContext ImageGenerationResult(
                    status = ImageGenerationStatus.FAILED,
                    rawPrompt = request.prompt,
                    enhancedPrompt = finalPrompt,
                    aspectRatio = request.aspectRatio.ratioStr,
                    providerName = providerName,
                    modelName = defaultModel,
                    errorMessage = "Image generation failed (No candidates returned from provider)"
                )
            }

            val firstCandidate = candidates.getJSONObject(0)
            val candidateContent = firstCandidate.optJSONObject("content")
            val parts = candidateContent?.optJSONArray("parts")

            var imageBytes: ByteArray? = null
            var textDescription = ""

            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    if (p.has("inlineData")) {
                        val inlineData = p.getJSONObject("inlineData")
                        val b64 = inlineData.optString("data")
                        if (b64.isNotBlank()) {
                            imageBytes = Base64.decode(b64, Base64.DEFAULT)
                            break
                        }
                    } else if (p.has("text")) {
                        textDescription += p.optString("text") + " "
                    }
                }
            }

            if (imageBytes != null && imageBytes.isNotEmpty()) {
                val savedFile = ImageStorageManager.saveImageBytesLocally(
                    context = context,
                    imageBytes = imageBytes,
                    filePrefix = "dharma_gen"
                )

                if (savedFile != null && savedFile.exists()) {
                    return@withContext ImageGenerationResult(
                        status = ImageGenerationStatus.SUCCESS,
                        imageCode = "IMG-${System.currentTimeMillis() % 1000000}",
                        imageUri = "file://${savedFile.absolutePath}",
                        localFilePath = savedFile.absolutePath,
                        rawPrompt = request.prompt,
                        enhancedPrompt = finalPrompt,
                        aspectRatio = request.aspectRatio.ratioStr,
                        providerName = providerName,
                        modelName = defaultModel,
                        errorMessage = null
                    )
                } else {
                    return@withContext ImageGenerationResult(
                        status = ImageGenerationStatus.FAILED,
                        rawPrompt = request.prompt,
                        enhancedPrompt = finalPrompt,
                        aspectRatio = request.aspectRatio.ratioStr,
                        providerName = providerName,
                        modelName = defaultModel,
                        errorMessage = "Image generation failed (Error saving image locally)"
                    )
                }
            } else {
                return@withContext ImageGenerationResult(
                    status = ImageGenerationStatus.FAILED,
                    rawPrompt = request.prompt,
                    enhancedPrompt = finalPrompt,
                    aspectRatio = request.aspectRatio.ratioStr,
                    providerName = providerName,
                    modelName = defaultModel,
                    errorMessage = if (textDescription.isNotBlank()) "Image generation failed: $textDescription" else "Image generation failed (No image data produced)"
                )
            }
        } catch (e: Exception) {
            CrashReportingManager.recordException(
                screen = "IMAGE_STUDIO",
                throwable = e,
                action = "GeminiImageProvider.generateImage"
            )
            return@withContext ImageGenerationResult(
                status = ImageGenerationStatus.FAILED,
                rawPrompt = request.prompt,
                enhancedPrompt = finalPrompt,
                aspectRatio = request.aspectRatio.ratioStr,
                providerName = providerName,
                modelName = defaultModel,
                errorMessage = "Image generation failed: ${e.localizedMessage ?: e.message}"
            )
        }
    }

    override suspend fun editImage(
        baseImageFilePath: String,
        editPrompt: String,
        context: Context
    ): ImageGenerationResult = withContext(Dispatchers.IO) {
        if (!isConfigured()) {
            return@withContext ImageGenerationResult(
                status = ImageGenerationStatus.NOT_CONFIGURED,
                rawPrompt = editPrompt,
                providerName = providerName,
                modelName = defaultModel,
                errorMessage = "Image Generation service বর্তমানে configured নয়।"
            )
        }

        val baseFile = File(baseImageFilePath)
        if (!baseFile.exists()) {
            return@withContext ImageGenerationResult(
                status = ImageGenerationStatus.FAILED,
                rawPrompt = editPrompt,
                providerName = providerName,
                modelName = defaultModel,
                errorMessage = "Image editing failed (Original image file not found on device)"
            )
        }

        val apiKey = GeminiNetworkClient.getApiKey()
        try {
            val imageBytes = baseFile.readBytes()
            val base64Data = Base64.encodeToString(imageBytes, Base64.NO_WRAP)

            val root = JSONObject()
            val contentsArray = JSONArray()
            val contentObj = JSONObject()
            val partsArray = JSONArray()

            // Text instruction
            val partText = JSONObject()
            partText.put("text", "Edit this image based on the following instruction: $editPrompt. Produce the resulting image.")
            partsArray.put(partText)

            // Image input
            val partImage = JSONObject()
            val inlineData = JSONObject()
            inlineData.put("mimeType", "image/png")
            inlineData.put("data", base64Data)
            partImage.put("inlineData", inlineData)
            partsArray.put(partImage)

            contentObj.put("parts", partsArray)
            contentsArray.put(contentObj)
            root.put("contents", contentsArray)

            val genConfig = JSONObject()
            val modalities = JSONArray()
            modalities.put("TEXT")
            modalities.put("IMAGE")
            genConfig.put("responseModalities", modalities)
            root.put("generationConfig", genConfig)

            val url = "https://generativelanguage.googleapis.com/v1beta/models/$defaultModel:generateContent?key=$apiKey"
            val mediaType = "application/json; charset=utf-8".toMediaType()
            val requestBody = root.toString().toRequestBody(mediaType)

            val httpRequest = Request.Builder().url(url).post(requestBody).build()
            val response = httpClient.newCall(httpRequest).execute()
            val responseBody = response.body?.string()

            if (!response.isSuccessful || responseBody.isNullOrBlank()) {
                val errorMsg = parseErrorMessage(response.code, responseBody)
                return@withContext ImageGenerationResult(
                    status = ImageGenerationStatus.FAILED,
                    rawPrompt = editPrompt,
                    providerName = providerName,
                    modelName = defaultModel,
                    errorMessage = "Image editing failed ($errorMsg)"
                )
            }

            val json = JSONObject(responseBody)
            val candidates = json.optJSONArray("candidates")
            val candidateContent = candidates?.optJSONObject(0)?.optJSONObject("content")
            val parts = candidateContent?.optJSONArray("parts")

            var editedBytes: ByteArray? = null
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    if (p.has("inlineData")) {
                        val b64 = p.getJSONObject("inlineData").optString("data")
                        if (b64.isNotBlank()) {
                            editedBytes = Base64.decode(b64, Base64.DEFAULT)
                            break
                        }
                    }
                }
            }

            if (editedBytes != null && editedBytes.isNotEmpty()) {
                val savedFile = ImageStorageManager.saveImageBytesLocally(
                    context = context,
                    imageBytes = editedBytes,
                    filePrefix = "dharma_edit"
                )
                if (savedFile != null && savedFile.exists()) {
                    return@withContext ImageGenerationResult(
                        status = ImageGenerationStatus.SUCCESS,
                        imageCode = "IMG-EDIT-${System.currentTimeMillis() % 1000000}",
                        imageUri = "file://${savedFile.absolutePath}",
                        localFilePath = savedFile.absolutePath,
                        rawPrompt = editPrompt,
                        enhancedPrompt = editPrompt,
                        providerName = providerName,
                        modelName = defaultModel,
                        errorMessage = null
                    )
                }
            }

            return@withContext ImageGenerationResult(
                status = ImageGenerationStatus.FAILED,
                rawPrompt = editPrompt,
                providerName = providerName,
                modelName = defaultModel,
                errorMessage = "Image editing failed (No modified image returned)"
            )
        } catch (e: Exception) {
            CrashReportingManager.recordException(
                screen = "IMAGE_STUDIO",
                throwable = e,
                action = "GeminiImageProvider.editImage"
            )
            return@withContext ImageGenerationResult(
                status = ImageGenerationStatus.FAILED,
                rawPrompt = editPrompt,
                providerName = providerName,
                modelName = defaultModel,
                errorMessage = "Image editing failed: ${e.message}"
            )
        }
    }

    override suspend fun understandImage(
        imageFilePath: String,
        userQuestion: String,
        context: Context
    ): ImageUnderstandingResult = withContext(Dispatchers.IO) {
        if (!isConfigured()) {
            return@withContext ImageUnderstandingResult(
                isSuccess = false,
                analysisText = "",
                errorMessage = "Vision / Image Understanding service বর্তমানে configured নয়।"
            )
        }

        val file = File(imageFilePath)
        if (!file.exists()) {
            return@withContext ImageUnderstandingResult(
                isSuccess = false,
                analysisText = "",
                errorMessage = "ছবিটি খুঁজে পাওয়া যায়নি।"
            )
        }

        val apiKey = GeminiNetworkClient.getApiKey()
        try {
            val bytes = file.readBytes()
            val base64Data = Base64.encodeToString(bytes, Base64.NO_WRAP)

            val root = JSONObject()
            val contentsArray = JSONArray()
            val contentObj = JSONObject()
            val partsArray = JSONArray()

            val questionText = if (userQuestion.isNotBlank()) {
                "$userQuestion\nঅনুগ্রহ করে ছবিটির সার্বিক এবং ধর্মীয়/আধ্যাত্মিক প্রেক্ষাপট বিশ্লেষণ করুন।"
            } else {
                "এই ছবিতে কী আছে? ছবিটির বিশদ বিবরণ ও আধ্যাত্মিক তাৎপর্য বাংলায় ব্যাখ্যা করুন।"
            }

            val textPart = JSONObject()
            textPart.put("text", questionText)
            partsArray.put(textPart)

            val imagePart = JSONObject()
            val inlineData = JSONObject()
            inlineData.put("mimeType", "image/png")
            inlineData.put("data", base64Data)
            imagePart.put("inlineData", inlineData)
            partsArray.put(imagePart)

            contentObj.put("parts", partsArray)
            contentsArray.put(contentObj)
            root.put("contents", contentsArray)

            // Using gemini-3.5-flash for vision understanding
            val url = "https://generativelanguage.googleapis.com/v1beta/models/gemini-3.5-flash:generateContent?key=$apiKey"
            val mediaType = "application/json; charset=utf-8".toMediaType()
            val requestBody = root.toString().toRequestBody(mediaType)

            val httpRequest = Request.Builder().url(url).post(requestBody).build()
            val response = httpClient.newCall(httpRequest).execute()
            val responseBody = response.body?.string()

            if (!response.isSuccessful || responseBody.isNullOrBlank()) {
                val errorMsg = parseErrorMessage(response.code, responseBody)
                return@withContext ImageUnderstandingResult(
                    isSuccess = false,
                    analysisText = "",
                    errorMessage = "Image analysis failed ($errorMsg)"
                )
            }

            val json = JSONObject(responseBody)
            val candidates = json.optJSONArray("candidates")
            val candidateContent = candidates?.optJSONObject(0)?.optJSONObject("content")
            val parts = candidateContent?.optJSONArray("parts")

            val resultText = StringBuilder()
            if (parts != null) {
                for (i in 0 until parts.length()) {
                    val p = parts.getJSONObject(i)
                    if (p.has("text")) {
                        resultText.append(p.optString("text")).append("\n")
                    }
                }
            }

            val analysis = resultText.toString().trim()
            if (analysis.isNotBlank()) {
                return@withContext ImageUnderstandingResult(
                    isSuccess = true,
                    analysisText = analysis,
                    spiritualSignificance = "সনাতন ঐতিহ্য ও শাস্ত্রীয় প্রতীকবিদ্যা অনুযায়ী বিশ্লেষিত।"
                )
            } else {
                return@withContext ImageUnderstandingResult(
                    isSuccess = false,
                    analysisText = "",
                    errorMessage = "Image analysis failed (Empty analysis returned)"
                )
            }
        } catch (e: Exception) {
            CrashReportingManager.recordException(
                screen = "IMAGE_VISION",
                throwable = e,
                action = "GeminiImageProvider.understandImage"
            )
            return@withContext ImageUnderstandingResult(
                isSuccess = false,
                analysisText = "",
                errorMessage = "Image analysis failed: ${e.message}"
            )
        }
    }

    private fun parseErrorMessage(code: Int, responseBody: String?): String {
        val rawMsg = if (responseBody.isNullOrBlank()) {
            when (code) {
                400 -> "Bad Request / Invalid Prompt"
                401, 403 -> "Authentication Error (Invalid API Key)"
                429 -> "API Quota Exceeded / Rate Limit"
                500, 503 -> "Service Unavailable"
                else -> "HTTP $code Error"
            }
        } else {
            try {
                val json = JSONObject(responseBody)
                val error = json.optJSONObject("error")
                val msg = error?.optString("message")
                if (!msg.isNullOrBlank()) msg else "HTTP $code"
            } catch (e: Exception) {
                "HTTP $code: $responseBody"
            }
        }

        // Bengali user-friendly mapping
        return when {
            code == 401 || code == 403 || rawMsg.contains("API_KEY_INVALID", ignoreCase = true) ->
                "এআই এপিআই কি (API Key) সঠিক নয় বা মেয়াদোত্তীর্ণ। অনুগ্রহ করে API Manager-এ যাচাই করুন।"
            code == 429 || rawMsg.contains("RESOURCE_EXHAUSTED", ignoreCase = true) || rawMsg.contains("quota", ignoreCase = true) ->
                "এআই সার্ভারের দৈনিক লিমিট পূর্ণ হয়েছে। কিছুক্ষণ পর পুনরায় চেষ্টা করুন।"
            code in 500..599 || rawMsg.contains("UNAVAILABLE", ignoreCase = true) ->
                "এআই ইমেজ সার্ভারে সাময়িক সংযোগ সমস্যা। অনুগ্রহ করে আবার চেষ্টা করুন।"
            rawMsg.contains("SAFETY", ignoreCase = true) || rawMsg.contains("blocked", ignoreCase = true) ->
                "প্রম্পটটি এআই সেফটি ফিল্টারে আটকে গেছে। অনুগ্রহ করে শালীন ও ভক্তিমূলক শব্দ ব্যবহার করুন।"
            else -> rawMsg
        }
    }
}
