package com.example.domain.audio

import android.content.Context
import android.content.Intent
import android.media.MediaPlayer
import android.media.PlaybackParams
import android.net.Uri
import androidx.core.content.FileProvider
import com.example.data.model.KirtanAudioEntity
import kotlinx.coroutines.*
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.update
import org.json.JSONObject
import java.io.File

data class AudioPlayerState(
    val currentAudio: KirtanAudioEntity? = null,
    val isPlaying: Boolean = false,
    val currentPositionMs: Int = 0,
    val durationMs: Int = 0,
    val progress: Float = 0.0f,
    val playbackSpeed: Float = 1.0f,
    val volume: Float = 1.0f,
    val activeStem: String = "MASTER", // "MASTER", "MUSIC_ONLY", "VOCAL_ONLY"
    val activeSectionTitle: String = "",
    val activeSectionBengali: String = "",
    val error: String? = null
)

class KirtanAudioPlayerManager(private val context: Context) {

    private var mediaPlayer: MediaPlayer? = null
    private val coroutineScope = CoroutineScope(Dispatchers.Main + SupervisorJob())
    private var progressJob: Job? = null

    private val _playerState = MutableStateFlow(AudioPlayerState())
    val playerState: StateFlow<AudioPlayerState> = _playerState.asStateFlow()

    private var sectionMarkers: List<TimelineSectionMarker> = emptyList()

    data class TimelineSectionMarker(
        val id: String,
        val name: String,
        val nameBengali: String,
        val startMs: Int,
        val endMs: Int
    )

    fun loadAudio(audio: KirtanAudioEntity, autoPlay: Boolean = false) {
        release()

        val filePath = when (_playerState.value.activeStem) {
            "MUSIC_ONLY" -> audio.musicOnlyStorageReference ?: audio.storageReference
            "VOCAL_ONLY" -> audio.vocalOnlyStorageReference ?: audio.storageReference
            else -> audio.storageReference
        }

        val file = File(filePath)
        if (!file.exists() || file.length() == 0L) {
            _playerState.update { it.copy(error = "অডিও ফাইলটি পাওয়া যায়নি বা ক্ষতিগ্রস্ত।", currentAudio = audio) }
            return
        }

        // Parse section markers from metadata
        parseSectionMarkers(audio.generationMetadata)

        try {
            mediaPlayer = MediaPlayer().apply {
                setDataSource(filePath)
                prepare()
                val dur = duration
                _playerState.update {
                    it.copy(
                        currentAudio = audio,
                        durationMs = dur,
                        currentPositionMs = 0,
                        progress = 0.0f,
                        isPlaying = false,
                        error = null
                    )
                }

                setOnCompletionListener {
                    _playerState.update { it.copy(isPlaying = false, currentPositionMs = 0, progress = 0.0f) }
                    stopProgressTracker()
                }

                setOnErrorListener { _, what, extra ->
                    _playerState.update { it.copy(error = "প্লেয়ারে ত্রুটি ঘটেছে (code: $what, extra: $extra)", isPlaying = false) }
                    stopProgressTracker()
                    true
                }
            }

            if (autoPlay) {
                play()
            }
        } catch (e: Exception) {
            _playerState.update { it.copy(error = "অডিও লোড করতে ব্যর্থ: ${e.localizedMessage}") }
        }
    }

    fun play() {
        val player = mediaPlayer ?: return
        try {
            player.start()
            setPlaybackSpeed(_playerState.value.playbackSpeed)
            _playerState.update { it.copy(isPlaying = true, error = null) }
            startProgressTracker()
        } catch (e: Exception) {
            _playerState.update { it.copy(error = "প্লে করতে ত্রুটি: ${e.localizedMessage}") }
        }
    }

    fun pause() {
        try {
            mediaPlayer?.pause()
            _playerState.update { it.copy(isPlaying = false) }
            stopProgressTracker()
        } catch (e: Exception) {
            _playerState.update { it.copy(error = "পজ করতে ত্রুটি: ${e.localizedMessage}") }
        }
    }

    fun togglePlayPause() {
        if (_playerState.value.isPlaying) {
            pause()
        } else {
            play()
        }
    }

    fun seekTo(positionMs: Int) {
        val player = mediaPlayer ?: return
        val safePos = positionMs.coerceIn(0, _playerState.value.durationMs)
        try {
            player.seekTo(safePos)
            updateSectionAtPosition(safePos)
            _playerState.update {
                it.copy(
                    currentPositionMs = safePos,
                    progress = if (it.durationMs > 0) safePos.toFloat() / it.durationMs else 0.0f
                )
            }
        } catch (e: Exception) {
            // Ignore seek error
        }
    }

    fun seekRelative(seconds: Int) {
        val current = _playerState.value.currentPositionMs
        val target = current + (seconds * 1000)
        seekTo(target)
    }

    fun setPlaybackSpeed(speed: Float) {
        val player = mediaPlayer ?: return
        try {
            val params = player.playbackParams
            params.speed = speed
            player.playbackParams = params
            _playerState.update { it.copy(playbackSpeed = speed) }
        } catch (e: Exception) {
            // If device playbackParams fails, gracefully fallback
            _playerState.update { it.copy(playbackSpeed = speed) }
        }
    }

    fun setVolume(volume: Float) {
        val player = mediaPlayer ?: return
        val v = volume.coerceIn(0.0f, 1.0f)
        try {
            player.setVolume(v, v)
            _playerState.update { it.copy(volume = v) }
        } catch (e: Exception) {
            // Ignore volume error
        }
    }

    fun switchStem(stem: String) {
        if (_playerState.value.activeStem == stem) return
        val currentAudio = _playerState.value.currentAudio ?: return
        val currentPos = _playerState.value.currentPositionMs
        val wasPlaying = _playerState.value.isPlaying

        _playerState.update { it.copy(activeStem = stem) }
        loadAudio(currentAudio, autoPlay = false)
        seekTo(currentPos)
        if (wasPlaying) {
            play()
        }
    }

    fun jumpToSection(sectionMarker: TimelineSectionMarker) {
        seekTo(sectionMarker.startMs)
    }

    fun getSectionMarkers(): List<TimelineSectionMarker> = sectionMarkers

    private fun parseSectionMarkers(metadataJson: String) {
        try {
            val json = JSONObject(metadataJson)
            val timelineArr = json.optJSONArray("timeline") ?: return
            val list = mutableListOf<TimelineSectionMarker>()
            for (i in 0 until timelineArr.length()) {
                val item = timelineArr.getJSONObject(i)
                list.add(
                    TimelineSectionMarker(
                        id = item.optString("id", "sec_$i"),
                        name = item.optString("name", "Section $i"),
                        nameBengali = item.optString("name_bengali", "অংশ $i"),
                        startMs = item.optInt("start", 0) * 1000,
                        endMs = item.optInt("end", 0) * 1000
                    )
                )
            }
            sectionMarkers = list
        } catch (e: Exception) {
            sectionMarkers = emptyList()
        }
    }

    private fun updateSectionAtPosition(posMs: Int) {
        val currentSec = sectionMarkers.firstOrNull { posMs in it.startMs..it.endMs }
        if (currentSec != null) {
            _playerState.update {
                it.copy(
                    activeSectionTitle = currentSec.name,
                    activeSectionBengali = currentSec.nameBengali
                )
            }
        }
    }

    private fun startProgressTracker() {
        stopProgressTracker()
        progressJob = coroutineScope.launch {
            while (isActive) {
                mediaPlayer?.let { player ->
                    if (player.isPlaying) {
                        val pos = player.currentPosition
                        val dur = player.duration
                        updateSectionAtPosition(pos)
                        _playerState.update {
                            it.copy(
                                currentPositionMs = pos,
                                durationMs = dur,
                                progress = if (dur > 0) pos.toFloat() / dur else 0.0f
                            )
                        }
                    }
                }
                delay(200)
            }
        }
    }

    private fun stopProgressTracker() {
        progressJob?.cancel()
        progressJob = null
    }

    fun shareAudio(context: Context, audio: KirtanAudioEntity) {
        val file = File(audio.storageReference)
        if (!file.exists()) return

        try {
            val uri: Uri = FileProvider.getUriForFile(
                context,
                "${context.packageName}.provider",
                file
            )
            val intent = Intent(Intent.ACTION_SEND).apply {
                type = "audio/wav"
                putExtra(Intent.EXTRA_STREAM, uri)
                putExtra(Intent.EXTRA_SUBJECT, "VedaNova AI — Kirtan Audio: ${audio.ragaName}")
                putExtra(Intent.EXTRA_TEXT, "VedaNova AI দ্বারা রচিত ও পরিবেশিত বিশুদ্ধ আধ্যাত্মিক কীর্তন অডিও।")
                addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
            }
            context.startActivity(Intent.createChooser(intent, "কীর্তন অডিও শেয়ার করুন"))
        } catch (e: Exception) {
            // Fallback: system chooser
        }
    }

    fun release() {
        stopProgressTracker()
        try {
            mediaPlayer?.stop()
            mediaPlayer?.release()
        } catch (e: Exception) {
            // Ignore
        }
        mediaPlayer = null
        _playerState.update { it.copy(isPlaying = false, currentPositionMs = 0) }
    }
}
