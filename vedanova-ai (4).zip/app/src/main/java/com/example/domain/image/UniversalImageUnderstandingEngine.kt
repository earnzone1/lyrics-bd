package com.example.domain.image

import java.util.Locale

/**
 * Universal AI Picture Prompt Analysis & Classification
 * Supports Bengali, Banglish, Hindi, Sanskrit, and English.
 */
data class UniversalImagePromptAnalysis(
    val rawPrompt: String,
    val subject: String,
    val deity: String? = null,
    val festival: String? = null,
    val detectedType: ImageCategoryType = ImageCategoryType.DEVOTIONAL_ART,
    val detectedStyle: ImageArtStyle = ImageArtStyle.SACRED_MASTERPIECE,
    val suggestedAspectRatio: ImageAspectRatio = ImageAspectRatio.SQUARE,
    val suggestedQuality: ImageQuality = ImageQuality.STANDARD,
    val mood: String = "Serene & Divine",
    val detectedLanguage: String = "Bengali",
    val isAmbiguous: Boolean = false,
    val clarificationOptions: List<String> = emptyList(),
    val dharmaSafetyPassed: Boolean = true,
    val dharmaSafetyReason: String? = null,
    val iconographicDetails: String = ""
)

enum class ImageCategoryType(val displayName: String, val bengaliName: String) {
    DEVOTIONAL_ART("Devotional Art", "ভক্তিমূলক আধ্যাত্মিক চিত্র"),
    REALISTIC_PHOTO("Realistic Photo", "বাস্তবধর্মী ছবি"),
    HISTORICAL_TEMPLE("Historical & Temple", "ঐতিহাসিক ও মন্দির স্থাপত্য"),
    NATURE_LANDSCAPE("Nature & Sacred Landscape", "প্রকৃতি ও পবিত্র হিমালয়"),
    FESTIVAL_CELEBRATION("Festival & Ritual", "উৎসব ও পূজা আচার"),
    SYMBOLIC_MANDALA("Sacred Symbols & Yantra", "পবিত্র প্রতীক ও মণ্ডল"),
    DIGITAL_ART("Digital Art", "আধুনিক ডিজিটাল আর্ট")
}

enum class ImageArtStyle(val displayName: String, val stylePromptTag: String) {
    SACRED_MASTERPIECE("Sacred Masterpiece", "Masterpiece traditional sacred oil painting, divine golden hour celestial illumination, authentic traditional iconography, majestic atmosphere, high resolution"),
    CINEMATIC_PHOTO("Cinematic Photorealistic", "Cinematic photorealistic 8k, volumetric soft lighting, natural detailed textures, ultra-realistic portraiture, dramatic depth of field"),
    WATERCOLOR_DEVOTIONAL("Devotional Watercolor", "Ethereal traditional watercolor art, soft pastel color wash, gentle divine aura, fluid elegant brushwork, spiritual sanctuary feel"),
    TEMPLE_SCULPTURE("Ancient Temple Relief", "Ancient classical Indian stone sculpture relief, intricate temple carving aesthetics, warm sandstone textures, Vedic antiquity"),
    MYTHOLOGICAL_ILLUSTRATION("Vedic Graphic Art", "Detailed classical Vedic book illustration, rich colors, gold filigree borders, expressive traditional divine iconography"),
    MODERN_MINIMALIST("Spiritual Minimalist", "Modern minimalist spiritual illustration, clean composition, warm tranquil negative space, peaceful divine silhouette")
}

object UniversalImageUnderstandingEngine {

    fun analyzePrompt(rawPrompt: String): UniversalImagePromptAnalysis {
        val trimmed = rawPrompt.trim()
        val lower = trimmed.lowercase(Locale.ROOT)

        // 1. Language Detection
        val language = when {
            rawPrompt.any { it in '\u0980'..'\u09FF' } -> "Bengali"
            rawPrompt.any { it in '\u0900'..'\u097F' } -> "Hindi/Sanskrit"
            lower.contains("krishna") || lower.contains("shiva") || lower.contains("radha") -> "English/Banglish"
            else -> "English"
        }

        // 2. Deity Detection
        val deity = when {
            lower.contains("কৃষ্ণ") || lower.contains("krishna") || lower.contains("শ্যাম") || lower.contains("govinda") || lower.contains("কানু") -> "শ্রীকৃষ্ণ (Sri Krishna)"
            lower.contains("রাধা") || lower.contains("radha") -> "শ্রীমতী রাধারাণী (Srimati Radharani)"
            lower.contains("শিব") || lower.contains("shiva") || lower.contains("মহাদেব") || lower.contains("mahadev") || lower.contains("ভোলানাথ") -> "ভগবান শিব (Lord Shiva)"
            lower.contains("দুর্গা") || lower.contains("durga") || lower.contains("দেবী") || lower.contains("মহিষাসুরমর্দিনী") -> "মা দুর্গা (Maa Durga)"
            lower.contains("রাম") || lower.contains("rama") || lower.contains("সীতা") || lower.contains("sita") || lower.contains("রঘুপতি") -> "শ্রী রাম ও সীতা (Sri Rama & Sita)"
            lower.contains("গণেশ") || lower.contains("ganesha") || lower.contains("গণপতি") || lower.contains("বিনায়ক") -> "ভগবান শ্রীগণেশ (Lord Ganesha)"
            lower.contains("হনুমান") || lower.contains("hanuman") || lower.contains("বজরংবলী") || lower.contains("পবনপুত্র") -> "শ্রী হনুমানজী (Sri Hanuman)"
            lower.contains("কালী") || lower.contains("kali") || lower.contains("শ্যামা") -> "মা কালী (Maa Kali)"
            lower.contains("সরস্বতী") || lower.contains("saraswati") -> "দেবী সরস্বতী (Devi Saraswati)"
            lower.contains("লক্ষ্মী") || lower.contains("lakshmi") -> "দেবী লক্ষ্মী (Devi Lakshmi)"
            lower.contains("জগন্নাথ") || lower.contains("jagannath") -> "ভগবান জগন্নাথ (Lord Jagannath)"
            else -> null
        }

        // 3. Festival Detection
        val festival = when {
            lower.contains("জন্মাষ্টমী") || lower.contains("janmashtami") -> "জন্মাষ্টমী (Janmashtami)"
            lower.contains("শিবরাত্রি") || lower.contains("shivratri") -> "মহা শিবরাত্রি (Maha Shivratri)"
            lower.contains("দুর্গাপূজা") || lower.contains("durga puja") || lower.contains("নবমী") || lower.contains("অষ্টমী") -> "শারদীয়া দুর্গাপূজা (Durga Puja)"
            lower.contains("দোল") || lower.contains("হোলি") || lower.contains("holi") -> "দোলযাত্রা ও হোলি (Holi)"
            lower.contains("দীপাবলি") || lower.contains("দিওয়ালি") || lower.contains("diwali") -> "দীপাবলি (Diwali)"
            lower.contains("রথযাত্রা") || lower.contains("ratha yatra") -> "রথযাত্রা (Ratha Yatra)"
            lower.contains("রাম নবমী") || lower.contains("ram navami") -> "রাম নবমী (Ram Navami)"
            else -> null
        }

        // 4. Category Type Detection
        val categoryType = when {
            lower.contains("ফটো") || lower.contains("photo") || lower.contains("বাস্তব") || lower.contains("realistic") || lower.contains("camera") -> ImageCategoryType.REALISTIC_PHOTO
            lower.contains("মন্দির") || lower.contains("temple") || lower.contains("স্থাপত্য") || lower.contains("ভাস্কর্য") || lower.contains("architecture") -> ImageCategoryType.HISTORICAL_TEMPLE
            lower.contains("হিমালয়") || lower.contains("গঙ্গা") || lower.contains("নদী") || lower.contains("বন") || lower.contains("nature") || lower.contains("পাহাড়") -> ImageCategoryType.NATURE_LANDSCAPE
            lower.contains("পূজা") || lower.contains("আরতি") || lower.contains("যজ্ঞ") || lower.contains("উৎসব") || lower.contains("ritual") -> ImageCategoryType.FESTIVAL_CELEBRATION
            lower.contains("মণ্ডল") || lower.contains("যন্ত্র") || lower.contains("ওঁ") || lower.contains("চিহ্ন") || lower.contains("yantra") || lower.contains("mandala") -> ImageCategoryType.SYMBOLIC_MANDALA
            lower.contains("ডিজিটাল") || lower.contains("digital") || lower.contains("ইলাস্ট্রেশন") || lower.contains("modern") -> ImageCategoryType.DIGITAL_ART
            else -> ImageCategoryType.DEVOTIONAL_ART
        }

        // 5. Art Style Detection
        val style = when {
            lower.contains("জলরং") || lower.contains("watercolor") -> ImageArtStyle.WATERCOLOR_DEVOTIONAL
            lower.contains("সিনেমাটিক") || lower.contains("cinematic") || lower.contains("ফটোগ্রাফি") || lower.contains("realistic") -> ImageArtStyle.CINEMATIC_PHOTO
            lower.contains("ভাস্কর্য") || lower.contains("খোদাই") || lower.contains("sculpture") || lower.contains("stone") -> ImageArtStyle.TEMPLE_SCULPTURE
            lower.contains("ইলাস্ট্রেশন") || lower.contains("illustration") || lower.contains("book") -> ImageArtStyle.MYTHOLOGICAL_ILLUSTRATION
            lower.contains("মিনিমালিস্ট") || lower.contains("minimal") || lower.contains("সিম্পল") -> ImageArtStyle.MODERN_MINIMALIST
            else -> ImageArtStyle.SACRED_MASTERPIECE
        }

        // 6. Aspect Ratio suggestion
        val ratio = when {
            lower.contains("স্টোরি") || lower.contains("রিল") || lower.contains("story") || lower.contains("reel") || lower.contains("9:16") || lower.contains("লম্বা") -> ImageAspectRatio.PORTRAIT_STORY
            lower.contains("ওয়ালপেপার") || lower.contains("ল্যান্ডস্কেপ") || lower.contains("landscape") || lower.contains("16:9") || lower.contains("পর্দায়") -> ImageAspectRatio.LANDSCAPE
            lower.contains("পোর্ট্রেট") || lower.contains("portrait") || lower.contains("3:4") -> ImageAspectRatio.PORTRAIT
            lower.contains("4:3") -> ImageAspectRatio.LANDSCAPE_PHOTO
            else -> ImageAspectRatio.SQUARE
        }

        // 7. Iconographic Details for Dharma correctness
        val iconographicDetails = when {
            deity?.contains("কৃষ্ণ") == true -> "Authentic iconography: peacock feather (ময়ূরপুচ্ছ), flute (মোহন বাঁশি), yellow silk pitambara attire, gentle benevolent smile, blooming lotuses."
            deity?.contains("শিব") == true -> "Authentic iconography: crescent moon (অর্ধচন্দ্র), Ganga flowing from matted locks, sacred trishula and damru, quiet meditative posture on Kailash."
            deity?.contains("দুর্গা") == true -> "Authentic iconography: riding lion, ten hands with traditional divine attributes, radiant golden maternal protective aura."
            deity?.contains("রাম") == true -> "Authentic iconography: Kodanda bow, noble righteous countenance, serene Vedic prince aura."
            deity?.contains("গণেশ") == true -> "Authentic iconography: holding sacred modaka and lotus, single tusk, auspicious blessings posture, sweet benevolent gaze."
            deity?.contains("হনুমান") == true -> "Authentic iconography: deep Rama-bhakti posture, folded hands or mace, radiant golden hue of spiritual strength."
            else -> "Authentic classical aesthetics and reverent spiritual composition."
        }

        // 8. Ambiguity check: if user just gave 1-2 words like "রাধাকৃষ্ণ"
        val isAmbiguous = trimmed.split("\\s+".toRegex()).size <= 2 && trimmed.length < 15
        val clarificationOptions = if (isAmbiguous) {
            listOf(
                "বৃন্দাবনে শ্রীরাধাকৃষ্ণের যুগল রূপ (ক্ল্যাসিকাল পেইন্টিং)",
                "যমুনা তীরে মোহন বাঁশি বাজানোর দৃশ্য (সিনেমাটিক)",
                "মন্দিরে পুষ্পশোভিত দিব্য সিংহাসনে অধিষ্ঠিত (বাস্তবধর্মী)"
            )
        } else {
            emptyList()
        }

        // 9. Dharma Safety & Respect check
        val lowerNoSpace = lower.replace("\\s+".toRegex(), "")
        val disrespectfulWords = listOf("hate", "violence", "abuse", "insult", "কুরুচিপূর্ণ", "অসম্মান")
        val safetyPassed = disrespectfulWords.none { lowerNoSpace.contains(it) }
        val safetyReason = if (!safetyPassed) "প্রম্পটটিতে সনাতন ভাবাবেগ ও শৃঙ্খলার পরিপন্থী উপাদান পাওয়া গেছে।" else null

        return UniversalImagePromptAnalysis(
            rawPrompt = trimmed,
            subject = deity ?: if (trimmed.isBlank()) "Spiritual Devotional Scene" else trimmed,
            deity = deity,
            festival = festival,
            detectedType = categoryType,
            detectedStyle = style,
            suggestedAspectRatio = ratio,
            suggestedQuality = ImageQuality.STANDARD,
            mood = if (deity?.contains("শিব") == true) "শান্ত, ধ্যানমগ্ন ও চিরন্তন" else "আনন্দময়, প্রেমময় ও দিব্য",
            detectedLanguage = language,
            isAmbiguous = isAmbiguous,
            clarificationOptions = clarificationOptions,
            dharmaSafetyPassed = safetyPassed,
            dharmaSafetyReason = safetyReason,
            iconographicDetails = iconographicDetails
        )
    }

    /**
     * Builds the comprehensive professional prompt for the generative model.
     */
    fun buildEnginePrompt(
        analysis: UniversalImagePromptAnalysis,
        style: ImageArtStyle,
        userCustomInstruction: String? = null
    ): String {
        val basePrompt = analysis.rawPrompt
        val icon = analysis.iconographicDetails
        val styleTag = style.stylePromptTag
        val custom = if (!userCustomInstruction.isNullOrBlank()) "Additional details: $userCustomInstruction." else ""

        return if (analysis.deity != null) {
            "High quality depiction: ${analysis.subject}. $icon. $styleTag. $custom High-end digital rendering, 8k resolution, reverent spiritual presentation, without distortions."
        } else {
            "$basePrompt. $styleTag. $custom High resolution, pristine artistic rendering, authentic Vedic ambiance."
        }
    }
}
