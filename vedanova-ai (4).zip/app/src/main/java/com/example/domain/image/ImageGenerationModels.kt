package com.example.domain.image

enum class ImageGenerationStatus {
    IDLE,
    GENERATING,
    SUCCESS,
    FAILED,
    NOT_CONFIGURED
}

enum class ImagePipelineStage(val stageName: String, val bengaliName: String, val progress: Float) {
    IDLE("Idle", "প্রস্তুত", 0.0f),
    QUEUED("Queued", "সারিতে অপেক্ষমান...", 0.15f),
    ANALYZING("Understanding Prompt", "প্রম্পট ও শাস্ত্রীয় রূপ বিশ্লেষণ...", 0.35f),
    DHARMA_VERIFICATION("Dharma Safety & Verification", "শাস্ত্রীয় তথ্য ও শুদ্ধতা যাচাই...", 0.55f),
    RENDERING("Generating Real Image", "বাস্তব এআই চিত্র রেন্ডারিং...", 0.80f),
    POST_PROCESSING("Post-Processing & Optimization", "চিত্র সংরক্ষণ ও অপ্টিমাইজেশন...", 0.95f),
    COMPLETED("Completed", "চিত্র সফলভাবে প্রস্তুত!", 1.0f),
    FAILED("Failed", "চিত্র তৈরিতে ব্যর্থ", 0.0f)
}

enum class ImageAspectRatio(
    val ratioStr: String,
    val displayName: String,
    val width: Int,
    val height: Int
) {
    SQUARE("1:1", "Square (1:1)", 1024, 1024),
    PORTRAIT("3:4", "Portrait (3:4)", 768, 1024),
    PORTRAIT_STORY("9:16", "Story / Tall (9:16)", 576, 1024),
    LANDSCAPE("16:9", "Landscape (16:9)", 1024, 576),
    LANDSCAPE_PHOTO("4:3", "Landscape (4:3)", 1024, 768)
}

enum class ImageQuality(val displayName: String) {
    STANDARD("Standard (1K)"),
    HIGH("High Definition (2K)")
}

data class ImageGenerationRequest(
    val prompt: String,
    val aspectRatio: ImageAspectRatio = ImageAspectRatio.SQUARE,
    val quality: ImageQuality = ImageQuality.STANDARD,
    val isDharmaEnhanced: Boolean = true,
    val style: ImageArtStyle = ImageArtStyle.SACRED_MASTERPIECE,
    val category: ImageCategoryType = ImageCategoryType.DEVOTIONAL_ART,
    val referenceImageUri: String? = null,
    val editInstruction: String? = null,
    val requestedBy: String = "User"
)

data class ImageGenerationResult(
    val status: ImageGenerationStatus,
    val imageId: Long = 0,
    val imageCode: String = "",
    val imageUri: String? = null,
    val localFilePath: String? = null,
    val rawPrompt: String = "",
    val enhancedPrompt: String = "",
    val aspectRatio: String = "1:1",
    val providerName: String = "",
    val modelName: String = "",
    val errorMessage: String? = null,
    val generatedAt: Long = System.currentTimeMillis(),
    val stage: ImagePipelineStage = ImagePipelineStage.COMPLETED,
    val verificationReport: String? = null
)

data class ImageUnderstandingResult(
    val isSuccess: Boolean,
    val analysisText: String,
    val detectedElements: List<String> = emptyList(),
    val spiritualSignificance: String = "",
    val errorMessage: String? = null
)

