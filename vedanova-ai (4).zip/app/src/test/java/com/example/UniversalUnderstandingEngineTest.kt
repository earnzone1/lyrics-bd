package com.example

import com.example.domain.ai.*
import kotlinx.coroutines.runBlocking
import org.junit.Assert.*
import org.junit.Test

class UniversalUnderstandingEngineTest {

    // 1. GREETING TEST: "hi" must return natural polite greeting, NO religious injection
    @Test
    fun testGreeting_NoReligiousInjection() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "hi",
            history = emptyList(),
            contextState = ConversationContextState()
        )

        assertEquals(UniversalIntent.GREETING, plan.primaryIntent)
        assertFalse("Domain should not be Dharma for casual greeting", plan.isDharmaDomain)
        assertEquals(SubsystemRoute.GENERAL_KNOWLEDGE, plan.targetRoute)
        assertEquals(AnswerType.CASUAL_REPLY, plan.plannedAnswerType)

        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), ConversationContextState())
        assertTrue("Answer should contain a warm greeting", answer.contains("Hi", ignoreCase = true) || answer.contains("Hello", ignoreCase = true) || answer.contains("নমস্কার", ignoreCase = true))
        assertFalse("Answer must NOT contain Gita", answer.contains("গীতা") || answer.contains("Gita"))
        assertFalse("Answer must NOT contain Gayatri", answer.contains("গায়ত্রী") || answer.contains("Gayatri"))
        assertFalse("Answer must NOT contain Puja", answer.contains("পূজা") || answer.contains("Puja"))
    }

    // 2. SCIENCE TEST: "what is gravity?" must classify as scientific question with zero religious bias
    @Test
    fun testScienceQuestion_Gravity() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "what is gravity?",
            history = emptyList(),
            contextState = ConversationContextState()
        )

        assertEquals(UniversalIntent.SCIENTIFIC_QUESTION, plan.primaryIntent)
        assertFalse("Gravity should not be classified as Dharma domain", plan.isDharmaDomain)
        assertTrue("Target route should be General Knowledge or Science", plan.targetRoute == SubsystemRoute.GENERAL_KNOWLEDGE || plan.targetRoute == SubsystemRoute.SCIENCE)

        val generalKnowledge = GeneralKnowledgeEngine.findGeneralKnowledge("what is gravity?")
        assertNotNull("General Knowledge Engine should find gravity", generalKnowledge)
        val answer = generalKnowledge!!.generateAnswer("English")
        assertTrue("Answer should mention mass or spacetime or attraction",
            answer.contains("mass", ignoreCase = true) ||
            answer.contains("attraction", ignoreCase = true) ||
            answer.contains("gravitation", ignoreCase = true)
        )
        assertFalse("Scientific answer must NOT contain shlokas", answer.contains("श्लोक") || answer.contains("গীতা"))
    }

    // 3. CALCULATION TEST: "2+2 কত?" must calculate 4 accurately without religion
    @Test
    fun testCalculation_TwoPlusTwo() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "2+2 কত?",
            history = emptyList(),
            contextState = ConversationContextState()
        )

        assertEquals(UniversalIntent.CALCULATION, plan.primaryIntent)
        assertFalse("Math calculation should not be Dharma domain", plan.isDharmaDomain)
        assertEquals(SubsystemRoute.CALCULATOR, plan.targetRoute)

        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), ConversationContextState())
        assertTrue("Answer must contain 4 or ৪", answer.contains("4") || answer.contains("৪"))
        assertFalse("Math answer must NOT contain religious text", answer.contains("ভগবান") || answer.contains("গীতা"))
    }

    // 4. DHARMA SCRIPTURE TEST: "What is Karma Yoga?" must activate Dharma knowledge base
    @Test
    fun testReligiousQuestion_KarmaYoga() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "What is Karma Yoga?",
            history = emptyList(),
            contextState = ConversationContextState()
        )

        assertEquals(UniversalIntent.RELIGIOUS_QUESTION, plan.primaryIntent)
        assertTrue("Karma Yoga must be Dharma domain", plan.isDharmaDomain)
        assertEquals(SubsystemRoute.DHARMA_KNOWLEDGE, plan.targetRoute)
        assertEquals(AnswerType.EXPLANATION, plan.plannedAnswerType)
    }

    // 5. TRANSLATION TEST: "Translate this into Bengali."
    @Test
    fun testTranslationRequest() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "Translate this sentence into Bengali: Peace of mind is true wealth.",
            history = emptyList(),
            contextState = ConversationContextState()
        )

        assertEquals(UniversalIntent.TRANSLATION, plan.primaryIntent)
        assertEquals(SubsystemRoute.TRANSLATION, plan.targetRoute)
        assertEquals(AnswerType.TRANSLATION, plan.plannedAnswerType)

        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), ConversationContextState())
        assertTrue("Translation answer should be non-empty", answer.isNotBlank())
    }

    // 6. WRITING REQUEST TEST: "Write a short message for my friend."
    @Test
    fun testWritingRequest_Friendship() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "Write a short message for my friend wishing him success.",
            history = emptyList(),
            contextState = ConversationContextState()
        )

        assertEquals(UniversalIntent.WRITING_REQUEST, plan.primaryIntent)
        assertFalse("Friendship message should not be forced into Dharma domain", plan.isDharmaDomain)
        assertEquals(SubsystemRoute.WRITING_ENGINE, plan.targetRoute)

        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), ConversationContextState())
        assertTrue("Should contain friendly wishes", answer.contains("friend", ignoreCase = true) || answer.contains("success", ignoreCase = true) || answer.contains("বন্ধু", ignoreCase = true))
        assertFalse("Should not force religious rituals into general friendship note", answer.contains("যজ্ঞ") || answer.contains("পূজার অর্ঘ্য"))
    }

    // 7. CLARIFICATION TEST: "পূজা কীভাবে করব?" without deity must ask for clarification
    @Test
    fun testClarification_AmbiguousPuja() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "পূজা কীভাবে করব?",
            history = emptyList(),
            contextState = ConversationContextState()
        )

        assertEquals(UniversalIntent.CLARIFICATION, plan.primaryIntent)
        assertTrue("Plan must indicate clarification is required", plan.requiresClarification)
        assertEquals(SubsystemRoute.CLARIFICATION_ENGINE, plan.targetRoute)
        assertNotNull(plan.clarificationQuestion)
        assertTrue("Clarification question should ask which deity or puja",
            plan.clarificationQuestion!!.contains("শিব") ||
            plan.clarificationQuestion!!.contains("দুর্গা") ||
            plan.clarificationQuestion!!.contains("কোন পূজার কথা বলছেন")
        )
    }

    // 8. FOLLOW-UP TEST: "Why?" after Karma Yoga
    @Test
    fun testFollowUp_WhyKarmaYoga() {
        val contextWithKarmaYoga = ConversationContextState(
            activeSubject = "Karma Yoga",
            activeTopic = "Karma Yoga",
            activeDomain = "DHARMA",
            activeScripture = "Bhagavad Gita"
        )

        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "Why?",
            history = listOf("What is Karma Yoga?" to "Karma Yoga is the path of selfless action without attachment to fruits."),
            contextState = contextWithKarmaYoga
        )

        assertEquals(UniversalIntent.FOLLOW_UP, plan.primaryIntent)
        assertEquals("Karma Yoga", plan.resolvedFollowUpSubject)
        assertEquals(SubsystemRoute.CONTEXT_ENGINE, plan.targetRoute)

        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), contextWithKarmaYoga)
        assertTrue("Answer should explain reason for Karma Yoga practice",
            answer.contains("নিষ্কাম", ignoreCase = true) ||
            answer.contains("বন্ধন", ignoreCase = true) ||
            answer.contains("चित्त", ignoreCase = true) ||
            answer.contains("কর্মফল", ignoreCase = true) ||
            answer.contains("action", ignoreCase = true)
        )
    }

    // 9. CONTEXT SWITCHING TEST: From Karma Yoga to Gravity resets religious domain
    @Test
    fun testContextSwitch_KarmaYogaToGravity() {
        val previousDharmaState = ConversationContextState(
            activeSubject = "Karma Yoga",
            activeTopic = "Karma Yoga",
            activeDomain = "DHARMA",
            activeScripture = "Bhagavad Gita"
        )

        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "what is gravity?",
            history = listOf("What is Karma Yoga?" to "Karma Yoga is selfless action."),
            contextState = previousDharmaState
        )

        assertEquals(UniversalIntent.SCIENTIFIC_QUESTION, plan.primaryIntent)
        assertFalse("New question on gravity must break out of Dharma domain", plan.isDharmaDomain)
        assertTrue("Target route should be General Knowledge or Science", plan.targetRoute == SubsystemRoute.GENERAL_KNOWLEDGE || plan.targetRoute == SubsystemRoute.SCIENCE)
    }

    // 10. VERIFY RELEVANCE GUARD: Non-Dharma query must strip unintended religious words
    @Test
    fun testVerifyAnswerRelevance_StripsUnintendedReligion() {
        val mathPlan = UniversalUnderstandingEngine.understandAndPlan(
            query = "2+2",
            history = emptyList(),
            contextState = ConversationContextState()
        )

        val dirtyAnswer = "2 + 2 = 4. জয় শ্রী কৃষ্ণ! গীতা পাঠ করুন।"
        val (passed, cleanAnswer) = UniversalUnderstandingEngine.verifyAnswerRelevance(mathPlan, dirtyAnswer)

        assertFalse("Dirty answer with unsolicited religion should fail raw check", passed)
        assertTrue("Clean answer should still have the math result", cleanAnswer.contains("4"))
        assertFalse("Clean answer must have stripped Gita reference", cleanAnswer.contains("গীতা পাঠ করুন"))
    }

    // 11. TYPO & GIBBERISH TEST: "asdf" or "123" must ask for clarification politely without guessing
    @Test
    fun testTypoAndGibberish_AsksForClarification() {
        val gibberishPlan = UniversalUnderstandingEngine.understandAndPlan(
            query = "asdf",
            history = emptyList(),
            contextState = ConversationContextState()
        )

        assertEquals(UniversalIntent.CLARIFICATION, gibberishPlan.primaryIntent)
        assertTrue("Gibberish must require clarification", gibberishPlan.requiresClarification)
        assertEquals(ConversationDecision.CLARIFY, gibberishPlan.conversationDecision)
        assertTrue(gibberishPlan.humanInterpretation.isTypoOrGibberish)
        assertFalse("Domain must not be Dharma for gibberish", gibberishPlan.isDharmaDomain)

        val check = UniversalUnderstandingEngine.performFinalDecisionCheck(gibberishPlan)
        assertTrue(check.isTypoOrGibberish)
        assertEquals(ConversationDecision.CLARIFY, check.decision)

        val answer = UniversalUnderstandingEngine.generateAnswer(gibberishPlan, emptyList(), ConversationContextState())
        assertTrue("Answer should ask to clarify politely", answer.contains("একটু পরিষ্কার করে লিখবেন") || answer.contains("clarify"))
        assertFalse("Answer must NOT contain religious text", answer.contains("ভগবান") || answer.contains("গীতা"))
    }

    // 12. NUMBER ONLY TEST: "123" or "১২৩৪" should ask if a specific calculation was intended
    @Test
    fun testStandaloneDigits_Clarification() {
        val digitPlan = UniversalUnderstandingEngine.understandAndPlan(
            query = "123",
            history = emptyList(),
            contextState = ConversationContextState()
        )

        assertEquals(UniversalIntent.CLARIFICATION, digitPlan.primaryIntent)
        assertTrue(digitPlan.requiresClarification)
        assertEquals(ConversationDecision.CLARIFY, digitPlan.conversationDecision)
        assertTrue(digitPlan.clarificationQuestion?.contains("হিসাব") == true || digitPlan.clarificationQuestion?.contains("সংখ্যা") == true)
    }

    // 13. JOKE TEST: "একটি কৌতুক বলো" / "tell me a joke" must return wholesome humor, no religious preaching
    @Test
    fun testJokeRequest_HumorWithoutPreaching() {
        val jokePlan = UniversalUnderstandingEngine.understandAndPlan(
            query = "একটি কৌতুক বলো",
            history = emptyList(),
            contextState = ConversationContextState()
        )

        assertEquals(UniversalIntent.CREATIVE_REQUEST, jokePlan.primaryIntent)
        assertFalse("Joke request should not be Dharma domain", jokePlan.isDharmaDomain)
        assertEquals(ConversationDecision.CREATIVE_RESPONSE, jokePlan.conversationDecision)

        val answer = UniversalUnderstandingEngine.generateAnswer(jokePlan, emptyList(), ConversationContextState())
        assertTrue("Answer should contain a joke or playful tone", answer.contains("ক্যাশিয়ার") || answer.contains("হাসি") || answer.contains("joke", ignoreCase = true))
        assertFalse("Answer must NOT contain scripture or mantras", answer.contains("উপনিষদ") || answer.contains("পূজা") || answer.contains("মন্ত্র"))
    }

    // 14. CASUAL ACKNOWLEDGMENT TEST: "ok", "ঠিক আছে", "ধন্যবাদ"
    @Test
    fun testCasualAcknowledgment_OkAndThanks() {
        val okPlan = UniversalUnderstandingEngine.understandAndPlan(
            query = "ঠিক আছে",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertEquals(UniversalIntent.CASUAL_CONVERSATION, okPlan.primaryIntent)
        assertEquals(ConversationDecision.ACKNOWLEDGE, okPlan.conversationDecision)
        val okAnswer = UniversalUnderstandingEngine.generateAnswer(okPlan, emptyList(), ConversationContextState())
        assertTrue(okAnswer.contains("ঠিক আছে"))

        val thanksPlan = UniversalUnderstandingEngine.understandAndPlan(
            query = "ধন্যবাদ",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertEquals(UniversalIntent.CASUAL_CONVERSATION, thanksPlan.primaryIntent)
        assertEquals(ConversationDecision.ACKNOWLEDGE, thanksPlan.conversationDecision)
        val thanksAnswer = UniversalUnderstandingEngine.generateAnswer(thanksPlan, emptyList(), ConversationContextState())
        assertTrue(thanksAnswer.contains("স্বাগতম") || thanksAnswer.contains("welcome", ignoreCase = true))
    }

    // 15. CASUAL TURN CONTINUATION TEST: "হুম", "আচ্ছা"
    @Test
    fun testCasualContinuation_HmmAndAccha() {
        val hmmPlan = UniversalUnderstandingEngine.understandAndPlan(
            query = "হুম",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertEquals(UniversalIntent.CASUAL_CONVERSATION, hmmPlan.primaryIntent)
        assertEquals(ConversationDecision.CONTINUE_CONVERSATION, hmmPlan.conversationDecision)
        val hmmAnswer = UniversalUnderstandingEngine.generateAnswer(hmmPlan, emptyList(), ConversationContextState())
        assertTrue(hmmAnswer.contains("শুনছি"))
    }

    // 16. VAGUE FOLLOW-UP WITHOUT HISTORY TEST: "Why?" or "কীভাবে?" without context asks for clarification
    @Test
    fun testVagueFollowUpWithoutHistory_AsksClarification() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "কীভাবে?",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertEquals(UniversalIntent.CLARIFICATION, plan.primaryIntent)
        assertTrue(plan.requiresClarification)
        assertEquals(ConversationDecision.CLARIFY, plan.conversationDecision)
        assertTrue(
            plan.clarificationQuestion?.contains("পরিষ্কার") == true ||
            plan.clarificationQuestion?.contains("কোন বিষয়") == true ||
            plan.clarificationQuestion?.contains("নির্দিষ্ট") == true ||
            plan.clarificationQuestion?.contains("specify") == true
        )
    }

    // 17. CONTEXT FOLLOW-UP: "কীভাবে?" with active Karma Yoga gives practice instructions
    @Test
    fun testContextFollowUp_HowToPracticeActiveTopic() {
        val contextWithKarmaYoga = ConversationContextState(
            activeSubject = "Karma Yoga",
            activeTopic = "Karma Yoga",
            activeDomain = "DHARMA",
            activeScripture = "Bhagavad Gita"
        )
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "কীভাবে?",
            history = listOf("What is Karma Yoga?" to "Karma Yoga is selfless action."),
            contextState = contextWithKarmaYoga
        )
        assertEquals(UniversalIntent.FOLLOW_UP, plan.primaryIntent)
        assertEquals(ConversationDecision.EXPLAIN, plan.conversationDecision)
        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), contextWithKarmaYoga)
        assertTrue("Should contain practice steps", answer.contains("অনুশীলন") || answer.contains("পদ্ধতি") || answer.contains("practice", ignoreCase = true))
    }

    // 18. STEP 8: RELATIONSHIP MISUNDERSTANDING
    @Test
    fun testRelationshipQuery_FriendMisunderstanding() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "আমার বন্ধুর সাথে ভুল বোঝাবুঝি হয়েছে।",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertEquals(UniversalIntent.RELATIONSHIP_ADVICE, plan.primaryIntent)
        assertEquals(SubsystemRoute.ADVICE_ENGINE, plan.targetRoute)
        assertEquals(AnswerType.EMPATHETIC_ADVICE, plan.plannedAnswerType)
        assertEquals(ConversationDecision.RECOMMEND, plan.conversationDecision)
        assertEquals(EpistemicClassification.ADVICE, plan.epistemicType)
        assertFalse(plan.isDharmaDomain)

        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), ConversationContextState())
        assertTrue("Should offer calm, direct discussion steps", answer.contains("শান্ত") && answer.contains("যোগাযোগ"))
        assertFalse("Should not inject religious doctrine", answer.contains("গীতা") || answer.contains("উপনিষদ"))
    }

    // 19. STEP 8: RESPECTFUL COMMUNICATION / ADMIRATION
    @Test
    fun testRelationshipQuery_RespectfulExpression() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "কাউকে পছন্দ করলে কীভাবে সম্মানের সঙ্গে কথা বলা যায়?",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertEquals(UniversalIntent.RELATIONSHIP_ADVICE, plan.primaryIntent)
        assertEquals(ConversationDecision.RECOMMEND, plan.conversationDecision)

        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), ConversationContextState())
        assertTrue("Should advise respect, boundaries and gentle communication", answer.contains("সম্মান") && answer.contains("সীমানা"))
    }

    // 20. STEP 8: EMOTIONAL SHARING (HAPPY)
    @Test
    fun testEmotionalSharing_Happy() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "আজ অনেক ভালো লাগছে।",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertEquals(UniversalIntent.EMOTIONAL_CONVERSATION, plan.primaryIntent)
        assertEquals(ConversationalEmotionTone.HAPPY, plan.detectedTone)
        assertEquals(ConversationDecision.CONTINUE_CONVERSATION, plan.conversationDecision)

        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), ConversationContextState())
        assertTrue("Should respond with warm happiness", answer.contains("ভালো লাগল") || answer.contains("আনন্দ"))
    }

    // 21. STEP 8: EMOTIONAL SHARING (CONFUSED)
    @Test
    fun testEmotionalSharing_Confused() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "আমি একটু confused.",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertEquals(UniversalIntent.EMOTIONAL_CONVERSATION, plan.primaryIntent)
        assertEquals(ConversationalEmotionTone.CONFUSED, plan.detectedTone)
        assertEquals(ConversationDecision.EXPLAIN, plan.conversationDecision)

        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), ConversationContextState())
        assertTrue("Should offer gentle explanation", answer.contains("দ্বিধা") || answer.contains("বিভ্রান্তি") || answer.contains("confusion", ignoreCase = true))
    }

    // 22. STEP 8: OPINION REQUEST
    @Test
    fun testOpinionRequest_DistinguishesOpinionFromFact() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "তুমি কী মনে কর?",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertEquals(UniversalIntent.OPINION_REQUEST, plan.primaryIntent)
        assertEquals(EpistemicClassification.OPINION, plan.epistemicType)
        assertEquals(AnswerType.OPINION_STATEMENT, plan.plannedAnswerType)

        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), ConversationContextState())
        assertTrue("Should clarify AI perspective vs dogma", answer.contains("মতামত") || answer.contains("দৃষ্টিকোণ"))
    }

    // 23. STEP 8: CURIOSITY PROMPT
    @Test
    fun testCuriosityPrompt_EngagingFactualInsight() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "Tell me something interesting.",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertEquals(UniversalIntent.CURIOSITY_PROMPT, plan.primaryIntent)
        assertEquals(EpistemicClassification.FACT, plan.epistemicType)
        assertEquals(AnswerType.CURATED_INSIGHT, plan.plannedAnswerType)

        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), ConversationContextState())
        assertTrue("Should provide captivating natural fact", answer.contains("Wood Wide Web") || answer.contains("tree", ignoreCase = true))
    }

    // 24. STEP 8: META-COMMUNICATION
    @Test
    fun testMetaCommunication_UnderstandingCheck() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "আমি কী বলতে চেয়েছি বুঝেছ?",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertEquals(UniversalIntent.META_COMMUNICATION, plan.primaryIntent)
        assertEquals(ConversationDecision.CONTINUE_CONVERSATION, plan.conversationDecision)

        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), ConversationContextState())
        assertTrue("Should confirm active listening", answer.contains("বুঝতে পেরেছি") || answer.contains("শুনছি"))
    }

    // 25. STEP 8: COMPARISON QUERY WITHOUT CONTEXT
    @Test
    fun testComparisonQuery_WithoutContext_AsksClarification() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "What's the difference between these two?",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertEquals(UniversalIntent.CLARIFICATION, plan.primaryIntent)
        assertTrue(plan.requiresClarification)
        assertEquals(ConversationDecision.CLARIFY, plan.conversationDecision)
        assertTrue("Should ask which two subjects to compare", plan.clarificationQuestion?.contains("two subjects", ignoreCase = true) == true || plan.clarificationQuestion?.contains("দুটি বিষয়") == true)
    }

    // =========================================================================
    // STEP 9: UNIVERSAL QUESTION UNDERSTANDING & ACCURACY TEST SUITE (A - Z)
    // =========================================================================

    // A. FACTUAL QUESTION: "What is the capital of France?"
    @Test
    fun testStep9_FactualQuestion_SecularNoDharma() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "What is the capital of France?",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertFalse("Must not be Dharma", plan.isDharmaDomain)
        assertEquals(QuestionType.FACTUAL, plan.questionType)
        assertEquals(AnswerDepth.CONCISE, plan.answerDepth)
        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), ConversationContextState())
        assertTrue("Answer should mention Paris", answer.contains("Paris", ignoreCase = true) || answer.contains("প্যারিস"))
        assertFalse("Answer must not mention Gita or Krishna", answer.contains("Gita") || answer.contains("Krishna"))
    }

    // B. EXPLANATORY QUESTION: "How does an airplane fly?"
    @Test
    fun testStep9_ExplanatoryQuestion_AirplaneAerodynamics() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "How does an airplane fly?",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertFalse("Must not be Dharma", plan.isDharmaDomain)
        assertEquals(SubsystemRoute.SCIENCE, plan.targetRoute)
        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), ConversationContextState())
        assertTrue("Answer should mention lift, Bernoulli, wings, or aerodynamics",
            answer.contains("lift", ignoreCase = true) || answer.contains("wing", ignoreCase = true) || answer.contains("aerodynamic", ignoreCase = true))
    }

    // C. WHY/HOW QUESTION: "Why do leaves change color in autumn?"
    @Test
    fun testStep9_WhyHowQuestion_LeavesColor() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "গাছের পাতা কেন সবুজ হয়?",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertFalse("Must not be Dharma", plan.isDharmaDomain)
        assertEquals(SubsystemRoute.SCIENCE, plan.targetRoute)
        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), ConversationContextState())
        assertTrue("Must explain chlorophyll or photosynthesis", answer.contains("ক্লোরোফিল") || answer.contains("সালোকসংশ্লেষণ"))
    }

    // D. COMPARISON QUESTION: "What is the difference between speed and velocity?"
    @Test
    fun testStep9_ComparisonQuestion_SpeedAndVelocity() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "What is the difference between speed and velocity?",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertEquals(UniversalIntent.COMPARISON, plan.primaryIntent)
        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), ConversationContextState())
        assertTrue("Must mention direction, scalar, or vector",
            answer.contains("direction", ignoreCase = true) || answer.contains("vector", ignoreCase = true) || answer.contains("scalar", ignoreCase = true))
    }

    // E. DEFINITION QUESTION: "Define artificial intelligence"
    @Test
    fun testStep9_DefinitionQuestion_ArtificialIntelligence() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "Define artificial intelligence",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertFalse("Must not be Dharma", plan.isDharmaDomain)
        assertEquals(SubsystemRoute.TECHNOLOGY, plan.targetRoute)
        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), ConversationContextState())
        assertTrue("Must define computer science or intelligent machines",
            answer.contains("computer", ignoreCase = true) || answer.contains("machine", ignoreCase = true) || answer.contains("intelligence", ignoreCase = true))
    }

    // F. CALCULATION QUESTION: "15 * 8 কত?"
    @Test
    fun testStep9_CalculationQuestion() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "15 * 8 কত?",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertEquals(UniversalIntent.CALCULATION, plan.primaryIntent)
        assertEquals(SubsystemRoute.CALCULATOR, plan.targetRoute)
        assertEquals(QuestionType.CALCULATION, plan.questionType)
        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), ConversationContextState())
        assertTrue("Answer must contain 120 or ১২০", answer.contains("120") || answer.contains("১২০"))
    }

    // G. TRANSLATION QUESTION: "Translate 'Good morning' into Bengali"
    @Test
    fun testStep9_TranslationQuestion() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "Translate 'Good morning' into Bengali",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertEquals(UniversalIntent.TRANSLATION, plan.primaryIntent)
        assertEquals(SubsystemRoute.TRANSLATION, plan.targetRoute)
        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), ConversationContextState())
        assertTrue("Must translate to শুভ সকাল", answer.contains("শুভ সকাল") || answer.contains("সুপ্রভাত"))
    }

    // H. SUMMARIZATION QUESTION: "Summarize the water cycle in three points"
    @Test
    fun testStep9_SummarizationQuestion() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "Summarize the water cycle in three points",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertEquals(UniversalIntent.SUMMARIZATION, plan.primaryIntent)
        assertEquals(ConversationDecision.SUMMARIZE, plan.conversationDecision)
    }

    // I. WRITING REQUEST: "Write a sick leave application to my manager"
    @Test
    fun testStep9_WritingRequest() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "Write a letter to a friend",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertEquals(UniversalIntent.WRITING_REQUEST, plan.primaryIntent)
        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), ConversationContextState())
        assertTrue("Must contain letter format", answer.contains("Dear Friend") || answer.contains("প্রিয় বন্ধু"))
    }

    // J. CREATIVE REQUEST: "Tell me a joke"
    @Test
    fun testStep9_CreativeRequest_Joke() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "Tell me a joke",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertEquals(UniversalIntent.CREATIVE_REQUEST, plan.primaryIntent)
        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), ConversationContextState())
        assertTrue("Must contain a joke", answer.contains("light") || answer.contains("bugs") || answer.contains("😄"))
    }

    // K. ADVICE QUESTION: "How can I focus better while studying?"
    @Test
    fun testStep9_AdviceQuestion_Focus() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "পড়াশোনায় কীভাবে আরও মনোযোগ বাড়ানো যায়?",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertEquals(UniversalIntent.HOW_TO_REQUEST, plan.primaryIntent)
        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), ConversationContextState())
        assertTrue("Must contain helpful study advice", answer.contains("মনোযোগ") || answer.contains("সময়") || answer.contains("রুটিন"))
    }

    // L. OPINION QUESTION: "Is remote work better than office work?"
    @Test
    fun testStep9_OpinionQuestion_EpistemicIntegrity() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "তুমি কী মনে কর?",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertEquals(UniversalIntent.OPINION_REQUEST, plan.primaryIntent)
        assertEquals(EpistemicClassification.OPINION, plan.epistemicType)
    }

    // M. CASUAL CONVERSATION: "How is your day going?" / "কেমন আছো?"
    @Test
    fun testStep9_CasualConversation() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "কেমন আছো?",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertEquals(UniversalIntent.CASUAL_CONVERSATION, plan.primaryIntent)
        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), ConversationContextState())
        assertTrue("Must give friendly conversational response", answer.contains("ভালো") || answer.contains("ধন্যবাদ"))
        assertFalse("Must not inject scripture", answer.contains("গীতা") || answer.contains("বেদ"))
    }

    // N. GREETING: "Hello" / "নমস্কার"
    @Test
    fun testStep9_Greeting() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "নমস্কার",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertEquals(UniversalIntent.GREETING, plan.primaryIntent)
        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), ConversationContextState())
        assertTrue("Should greet warmly", answer.contains("নমস্কার") || answer.contains("ভালো"))
    }

    // O. FOLLOW-UP QUESTION: "Why?" with active context
    @Test
    fun testStep9_FollowUpQuestion() {
        val state = ConversationContextState(
            activeTopic = "Karma Yoga",
            activeConcept = "Nishkama Karma",
            activeDomain = "DHARMA"
        )
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "Why?",
            history = listOf("User" to "What is Karma Yoga?", "AI" to "Karma Yoga is selfless action."),
            contextState = state
        )
        assertEquals(UniversalIntent.FOLLOW_UP, plan.primaryIntent)
        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), state)
        assertTrue("Must explain reasons based on active topic", answer.contains("Bhagavad Gita") || answer.contains("চিত্তশুদ্ধি") || answer.contains("Karma"))
    }

    // P. CORRECTION REQUEST: "তুমি আগের উত্তরে ভুল বলেছ"
    @Test
    fun testStep9_CorrectionRequest_SelfReview() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "তুমি আগের উত্তরে ভুল বলেছ",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertEquals(UniversalIntent.CORRECTION, plan.primaryIntent)
        assertTrue(plan.isUserCorrection)
        assertEquals(ConversationDecision.CORRECT, plan.conversationDecision)
        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), ConversationContextState())
        assertTrue("Must apologize or acknowledge feedback graciously", answer.contains("ধন্যবাদ") || answer.contains("সংশোধন") || answer.contains("যাচাই"))
    }

    // Q. RESEARCH QUESTION: "Latest findings about Mars rovers"
    @Test
    fun testStep9_ResearchQuestion() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "Mars rover research details",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertFalse("Must not be Dharma", plan.isDharmaDomain)
        assertTrue("Route should be Science or General", plan.targetRoute == SubsystemRoute.SCIENCE || plan.targetRoute == SubsystemRoute.GENERAL_KNOWLEDGE)
    }

    // R. RELIGIOUS / PHILOSOPHICAL QUESTION: "What is Nishkama Karma in Gita?"
    @Test
    fun testStep9_DharmaScriptureQuestion() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "শ্রীমদ্ভগবদ্গীতার মূল বার্তা কী?",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertTrue("Must be Dharma", plan.isDharmaDomain)
        assertEquals(UniversalIntent.RELIGIOUS_QUESTION, plan.primaryIntent)
        assertEquals(SubsystemRoute.DHARMA_KNOWLEDGE, plan.targetRoute)
    }

    // S. BANGLISH QUERY: "gita ki", "kormo ki"
    @Test
    fun testStep9_BanglishQuery_PhoneticMapping() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "gita ki",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertTrue("Should detect Banglish query and normalize", plan.normalizedQuery.contains("গীতা") || plan.detectedTopic?.contains("গীতা") == true)
        assertTrue("Should recognize as spiritual topic", plan.isDharmaDomain)
        assertEquals(SubsystemRoute.DHARMA_KNOWLEDGE, plan.targetRoute)
    }

    // T. FALSE PREMISE QUESTION: "সূর্য কেন পৃথিবীর চারদিকে ঘোরে?"
    @Test
    fun testStep9_FalsePremise_Rectification() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "সূর্য কেন পৃথিবীর চারদিকে ঘোরে?",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertTrue("Must flag false premise", plan.hasFalsePremise)
        assertFalse("Must not force Dharma on astronomy", plan.isDharmaDomain)
        assertEquals(SubsystemRoute.SCIENCE, plan.targetRoute)
        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), ConversationContextState())
        assertTrue("Must clarify that Earth rotates around Sun, not the reverse",
            answer.contains("ঘোরে না") || answer.contains("সূর্য পৃথিবীর চারদিকে ঘোরে না") || answer.contains("পৃথিবীই সূর্যের চারদিকে"))
    }

    // U. MULTI-PART QUESTION: "কর্ম কী এবং কেন এটি গুরুত্বপূর্ণ? এটি কীভাবে প্রয়োগ করব?"
    @Test
    fun testStep9_MultiPartQuestion_SystematicDecomposition() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "কর্ম কী এবং কেন এটি গুরুত্বপূর্ণ? এটি কীভাবে প্রয়োগ করব?",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertTrue("Must flag multi-part inquiry", plan.isMultiPart)
        assertTrue("Must decompose into multiple parts", plan.decomposedParts.size >= 2)
        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), ConversationContextState())
        assertTrue("Answer must systematically address all parts", answer.contains("১.") && answer.contains("২."))
    }

    // V. REAL-TIME / CURRENT INFORMATION QUESTION: "আজকের সোনার দাম কত?"
    @Test
    fun testStep9_CurrentInfo_AntiHallucinationBoundary() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "আজকের সোনার দাম কত?",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertTrue("Must flag current info requirement", plan.requiresCurrentInfo)
        assertEquals(SubsystemRoute.RESEARCH, plan.targetRoute)
        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), ConversationContextState())
        assertTrue("Must declare lack of live internet connection to prevent hallucination",
            answer.contains("লাইভ") || answer.contains("সংবাদ") || answer.contains("বাস্তব-সময়") || answer.contains("রিয়েল-টাইম"))
    }

    // W. SIMPLE FACTUAL VS DHARMA: "আইনস্টাইন কে ছিলেন?" -> Secular, zero Dharma
    @Test
    fun testStep9_SecularFactual_ZeroDharmaIntrusion() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "আইনস্টাইন কে ছিলেন?",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertFalse("Must NOT be Dharma", plan.isDharmaDomain)
        assertTrue("Target route must be History, Science or General",
            plan.targetRoute == SubsystemRoute.HISTORY || plan.targetRoute == SubsystemRoute.SCIENCE || plan.targetRoute == SubsystemRoute.GENERAL_KNOWLEDGE)
        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), ConversationContextState())
        assertTrue("Must describe physicist / relativity", answer.contains("পদার্থবিজ্ঞানী") || answer.contains("আপেক্ষিকতা") || answer.contains("physicist", ignoreCase = true))
        assertFalse("Must NOT inject religious texts", answer.contains("গীতা") || answer.contains("বেদ"))
    }

    // X. SHORT INCOMPLETE QUERY: "বিজ্ঞান"
    @Test
    fun testStep9_ShortIncompleteQuery() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "বিজ্ঞান",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertTrue(plan.isShortMessage)
        assertFalse("Must not be Dharma", plan.isDharmaDomain)
        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), ConversationContextState())
        assertTrue("Should give helpful introductory overview or ask clarification", answer.isNotBlank())
    }

    // Y. EMOTIONAL INQUIRY: "আমি খুব হতাশ, কী করব?"
    @Test
    fun testStep9_EmotionalInquiry_EmpatheticTone() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "আমি খুব হতাশ, কী করব?",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        assertEquals(UniversalIntent.EMOTIONAL_CONVERSATION, plan.primaryIntent)
        assertEquals(ConversationalEmotionTone.SAD, plan.detectedTone)
        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), ConversationContextState())
        assertTrue("Must provide warm, empathetic support", answer.contains("হতাশ") || answer.contains("বিশ্রাম") || answer.contains("ধৈর্য"))
    }

    // Z. QUALITY & SAFETY EVALUATION TEST: evaluateStep9Quality verification
    @Test
    fun testStep9_QualityAndSafetyEvaluation() {
        val plan = UniversalUnderstandingEngine.understandAndPlan(
            query = "What is gravity?",
            history = emptyList(),
            contextState = ConversationContextState()
        )
        val answer = UniversalUnderstandingEngine.generateAnswer(plan, emptyList(), ConversationContextState())
        val eval = UniversalUnderstandingEngine.evaluateStep9Quality(plan, answer)

        assertTrue("Quality check must pass", eval.passed)
        assertTrue("Overall score must be >= 80", eval.overallQualityScore >= 80)
        assertEquals(AnswerConfidence.HIGH, eval.confidence)
        assertEquals(0, eval.hallucinationRiskScore)
    }
}
