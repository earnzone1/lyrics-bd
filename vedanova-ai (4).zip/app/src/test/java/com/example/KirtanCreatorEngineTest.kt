package com.example

import com.example.domain.ai.KirtanEngine
import org.junit.Assert.*
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(manifest = Config.NONE)
class KirtanCreatorEngineTest {

    @Test
    fun testNaturalLanguagePromptParsing_SriKrishnaJoyfulBengali() {
        val prompt = "শ্রীকৃষ্ণকে নিয়ে একটি আনন্দময় বাংলা কীর্তন তৈরি করো।"
        val intent = KirtanEngine.parseNaturalPrompt(prompt)

        assertEquals("শ্রীকৃষ্ণ", intent.deity)
        assertEquals("Joyful", intent.mood)
        assertEquals("Bengali", intent.language)
        assertEquals("Nama Sankirtan", intent.type)
    }

    @Test
    fun testNaturalLanguagePromptParsing_ShivaMeditative() {
        val prompt = "মহাদেবের ধ্যানমগ্ন ওঙ্কার ধ্বনির একটি গম্ভীর সংস্কৃত কীর্তন রচনা করো"
        val intent = KirtanEngine.parseNaturalPrompt(prompt)

        assertEquals("মহাদেব শিব", intent.deity)
        assertEquals("Meditative", intent.mood)
        assertEquals("Sanskrit", intent.language)
    }

    @Test
    fun testOriginalKirtanComposition_FullStructureAndCopyrightSafety() {
        val prompt = "শ্রীকৃষ্ণকে নিয়ে একটি আনন্দময় বাংলা কীর্তন তৈরি করো।"
        val intent = KirtanEngine.parseNaturalPrompt(prompt)
        val kirtan = KirtanEngine.generateOriginalKirtan(intent, prompt, emptyList())

        // Verify Essential Attributes
        assertNotNull(kirtan.id)
        assertTrue(kirtan.title.isNotBlank())
        assertEquals("শ্রীকৃষ্ণ", kirtan.deity)
        assertEquals("Bengali", kirtan.language)
        assertEquals("Joyful", kirtan.mood)

        // Verify Full 7-part Structure
        assertTrue("Opening must not be blank", kirtan.opening.isNotBlank())
        assertTrue("Chorus / Dhruva must not be blank", kirtan.chorus.isNotBlank())
        assertTrue("Call & Response must not be blank", kirtan.callResponse.isNotBlank())
        assertTrue("Verses / Antara must not be blank", kirtan.verses.isNotBlank())
        assertTrue("Climax must not be blank", kirtan.climax.isNotBlank())
        assertTrue("Ending must not be blank", kirtan.ending.isNotBlank())
        assertTrue("Closing Shanti Prayer must not be blank", kirtan.closingPrayer.isNotBlank())

        // Verify Musical and Performance Guides
        assertTrue("Instrument guide must include traditional instruments", kirtan.instrumentGuide.contains("খোল") || kirtan.instrumentGuide.contains("করতাল"))
        assertTrue("Performance guide must be present", kirtan.performanceGuide.isNotBlank())

        // Verify Zero-Fake & Canonical Citation
        assertTrue("Scriptural quotes must cite authentic scripture", kirtan.scripturalQuotesUsed.isNotBlank())
        assertTrue("Must be marked as original verified", kirtan.isOriginalVerified)
        assertTrue("Must pass copyright safety check", kirtan.copyrightSafetyPassed)
    }

    @Test
    fun testDharmaAndCopyrightVerification() {
        val prompt = "মা দুর্গার আগমনি ও মহিষাসুরমর্দিনী বন্দনার একটি শক্তিশালী ভক্তিমূলক কীর্তন"
        val intent = KirtanEngine.parseNaturalPrompt(prompt)
        val kirtan = KirtanEngine.generateOriginalKirtan(intent, prompt, emptyList())

        val report = KirtanEngine.verifyDharmaAndCopyright(kirtan)
        assertTrue("Verification must pass for generated original kirtan", report.isValid)
        assertTrue("Copyright safety must pass", report.copyrightPassed)
        assertTrue("Dharma alignment must pass", report.dharmaPassed)
        assertTrue("Messages must be present", report.messages.isNotEmpty())
    }

    @Test
    fun testKirtanVariationGeneration() {
        val prompt = "শ্রীকৃষ্ণকে নিয়ে একটি আনন্দময় বাংলা কীর্তন তৈরি করো।"
        val intent = KirtanEngine.parseNaturalPrompt(prompt)
        val base = KirtanEngine.generateOriginalKirtan(intent, prompt, emptyList())

        val variation = KirtanEngine.createVariation(base, "ধীর লয়ের ভাবগম্ভীর বিরহ সংকীর্তন রূপান্তর")

        assertNotEquals(base.id, variation.id)
        assertTrue("Title must indicate variation", variation.title.contains("রূপভেদ"))
        assertTrue("Theme must not be blank", variation.theme.isNotBlank())
        assertTrue(variation.verses.isNotBlank())
    }

    @Test
    fun testJsonSerializationRoundTrip() {
        val prompt = "চৈতন্য মহাপ্রভুর হরিনাম প্রচারের কীর্তন"
        val intent = KirtanEngine.parseNaturalPrompt(prompt)
        val kirtan = KirtanEngine.generateOriginalKirtan(intent, prompt, emptyList())

        val jsonStr = KirtanEngine.kirtanToJson(kirtan)
        assertNotNull(jsonStr)
        assertTrue(jsonStr.contains(kirtan.title))

        val parsed = KirtanEngine.kirtanFromJson(jsonStr)
        assertEquals(kirtan.id, parsed.id)
        assertEquals(kirtan.title, parsed.title)
        assertEquals(kirtan.deity, parsed.deity)
        assertEquals(kirtan.chorus, parsed.chorus)
        assertEquals(kirtan.closingPrayer, parsed.closingPrayer)
    }
}
