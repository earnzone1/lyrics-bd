package com.example

import android.app.Application
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.VedaNovaDatabase
import com.example.data.model.ApiKeyEntity
import com.example.data.model.KirtanAuditLogEntity
import com.example.data.model.KirtanEntity
import com.example.data.model.KirtanVersionEntity
import com.example.data.repository.VedaNovaRepository
import com.example.domain.ai.KirtanEngine
import com.example.domain.api.ApiGatewayRequest
import com.example.domain.api.VedaNovaApiGateway
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class KirtanProductionVerificationTest {

    private lateinit var app: Application
    private lateinit var database: VedaNovaDatabase
    private lateinit var repository: VedaNovaRepository
    private lateinit var apiGateway: VedaNovaApiGateway

    private val testApiKeyWithKirtan = "test-key-kirtan-valid"
    private val testApiKeyWithoutKirtan = "test-key-chat-only"

    @Before
    fun setup() {
        app = ApplicationProvider.getApplicationContext()
        database = Room.inMemoryDatabaseBuilder(app, VedaNovaDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = VedaNovaRepository(database, app)
        apiGateway = VedaNovaApiGateway(
            apiKeyDao = database.apiKeyDao(),
            apiLogDao = database.apiLogDao(),
            knowledgeDao = database.knowledgeDao(),
            aiOrchestrator = com.example.domain.ai.AiOrchestrator(database.knowledgeDao()),
            capabilityProposalDao = database.capabilityProposalDao(),
            imageGenerationEngine = null,
            systemSettingDao = database.systemSettingDao(),
            context = app,
            database = database
        )

        // Seed API Keys
        runBlocking {
            database.apiKeyDao().insertApiKey(
                ApiKeyEntity(
                    id = 1,
                    name = "VedaNova Music Client",
                    appName = "VedaNova Music Client",
                    apiKey = testApiKeyWithKirtan,
                    maskedKey = "test-***-valid",
                    permissions = "kirtan,chat,status,mantra,scripture",
                    status = "Active",
                    rateLimitPerMin = 100,
                    version = "1.0.0"
                )
            )
            database.apiKeyDao().insertApiKey(
                ApiKeyEntity(
                    id = 2,
                    name = "Restricted Client",
                    appName = "Restricted Client",
                    apiKey = testApiKeyWithoutKirtan,
                    maskedKey = "test-***-restricted",
                    permissions = "chat,status",
                    status = "Active",
                    rateLimitPerMin = 100,
                    version = "1.0.0"
                )
            )
        }
    }

    @After
    fun tearDown() {
        database.close()
    }

    // 1. Natural Language Test
    @Test
    fun test01_NaturalLanguageParsing() {
        val prompt = "শ্রীকৃষ্ণকে নিয়ে একটি আনন্দময় বাংলা কীর্তন তৈরি করো"
        val intent = KirtanEngine.parseNaturalPrompt(prompt)

        assertEquals("শ্রীকৃষ্ণ", intent.deity)
        assertEquals("Joyful", intent.mood)
        assertEquals("Bengali", intent.language)
        assertTrue(intent.hasCallAndResponse)
        assertNotNull(intent.theme)
    }

    // 2. Complete Kirtan Test (7-part canonical sequence)
    @Test
    fun test02_CompleteKirtan7TierStructure() {
        val prompt = "শ্রীকৃষ্ণকে নিয়ে একটি আনন্দময় বাংলা কীর্তন তৈরি করো"
        val intent = KirtanEngine.parseNaturalPrompt(prompt)
        val kirtan = KirtanEngine.generateOriginalKirtan(intent, prompt, emptyList())

        assertTrue("Opening Invocation must be present", kirtan.opening.isNotBlank())
        assertTrue("Main Chorus / Dhruva must be present", kirtan.chorus.isNotBlank())
        assertTrue("Call & Response must be present", kirtan.callResponse.isNotBlank())
        assertTrue("Verses / Antara must be present", kirtan.verses.isNotBlank())
        assertTrue("Climax must be present", kirtan.climax.isNotBlank())
        assertTrue("Ending must be present", kirtan.ending.isNotBlank())
        assertTrue("Closing Shanti Prayer must be present", kirtan.closingPrayer.isNotBlank())

        assertTrue("Structure tag must be 7-step sequence", kirtan.structure.contains("বন্দনা") && kirtan.structure.contains("শান্তিপাঠ"))
    }

    // 3. Originality / Copyright Safety
    @Test
    fun test03_OriginalityAndCopyrightSafety() {
        val prompt = "শ্রীগৌরাঙ্গ মহাপ্রভুর হরিনাম মহিমা সংকীর্তন"
        val intent = KirtanEngine.parseNaturalPrompt(prompt)
        val kirtan = KirtanEngine.generateOriginalKirtan(intent, prompt, emptyList())

        assertTrue("Must pass copyright safety check", kirtan.copyrightSafetyPassed)
        assertTrue("Must be original verified", kirtan.isOriginalVerified)

        val report = KirtanEngine.verifyDharmaAndCopyright(kirtan)
        assertTrue("Copyright safety report must pass", report.copyrightSafe)
        assertTrue(report.isValid)
    }

    // 4. Dharma Verification (Scriptural citations and authentic canonical deities)
    @Test
    fun test04_DharmaVerificationAndScriptureAccuracy() {
        val prompt = "মহাদেবের ভস্মভূষিত শান্ত রূপের কীর্তন"
        val intent = KirtanEngine.parseNaturalPrompt(prompt)
        val kirtan = KirtanEngine.generateOriginalKirtan(intent, prompt, emptyList())

        assertTrue("Scriptural quotes must be authentic citation", kirtan.scripturalQuotesUsed.isNotBlank())

        val report = KirtanEngine.verifyDharmaAndCopyright(kirtan)
        assertTrue("Dharma accuracy must pass for recognized canonical deity", report.dharmaAccuracyVerified)
        assertTrue("Report must be valid", report.isValid)

        // Invalid deity test
        val fakeKirtan = kirtan.copy(deity = "Unknown Uncanonical Deity")
        val invalidReport = KirtanEngine.verifyDharmaAndCopyright(fakeKirtan)
        assertFalse("Uncanonical deity must fail dharma verification", invalidReport.isValid)
        assertFalse("Dharma accuracy must be false for uncanonical deity", invalidReport.dharmaAccuracyVerified)
    }

    // 5. Database CRUD, persistence & Room integration
    @Test
    fun test05_DatabaseCrudAndPersistence() = runBlocking {
        val kirtanDao = database.kirtanDao()

        // Create & Insert
        val prompt = "শ্রীরামচন্দ্র ও সীতার জয়ধ্বনি কীর্তন"
        val kirtan = repository.createKirtanFromPrompt(prompt, "AdminTester")
        assertNotNull(kirtanDao.getKirtanById(kirtan.id))

        // Read / Query
        val all = kirtanDao.searchKirtans("")
        assertTrue(all.any { it.id == kirtan.id })

        // Update
        val updated = kirtan.copy(title = "Updated Sri Rama Kirtan")
        repository.saveKirtan(updated, "AdminTester")
        val fetchedUpdated = kirtanDao.getKirtanById(kirtan.id)
        assertEquals("Updated Sri Rama Kirtan", fetchedUpdated?.title)

        // Bookmark
        repository.toggleKirtanBookmark(kirtan.id, true)
        val bookmarked = kirtanDao.getKirtanById(kirtan.id)
        assertTrue(bookmarked?.isBookmarked == true)

        // Delete
        repository.deleteKirtan(kirtan.id, "AdminTester")
        assertNull(kirtanDao.getKirtanById(kirtan.id))
    }

    // 6. Version & Rollback (v1 -> v2 -> rollback)
    @Test
    fun test06_VersionAndRollbackFlow() = runBlocking {
        val kirtanDao = database.kirtanDao()

        // 1. Initial Creation (v1)
        val base = repository.createKirtanFromPrompt("রাধা-কৃষ্ণের মিলন কীর্তন", "AdminTester")
        assertEquals(1, base.version)

        // 2. Variation Creation (v2)
        val variation = repository.createKirtanVariation(base.id, "ধীর লয়ের ভাব বিস্তার", "AdminTester")
        val versions = kirtanDao.getVersionsForKirtan(base.id)
        assertTrue("Base Kirtan has v1 version snapshot", versions.any { it.version == 1 })

        // 3. Edit Base Kirtan
        val edited = base.copy(title = "Edited Title Before Rollback", version = 2)
        kirtanDao.insertKirtan(edited)
        kirtanDao.insertVersion(
            KirtanVersionEntity(
                id = "${base.id}_v2",
                kirtanId = base.id,
                version = 2,
                title = edited.title,
                snapshotJson = KirtanEngine.kirtanToJson(edited),
                changeReason = "Edit Title",
                createdBy = "AdminTester"
            )
        )

        // 4. Rollback to v1
        val rollbackSuccess = repository.rollbackKirtan(base.id, "${base.id}_v1", "AdminTester")
        assertTrue("Rollback must succeed", rollbackSuccess)

        val restored = kirtanDao.getKirtanById(base.id)
        assertNotNull(restored)
        assertEquals(base.title, restored?.title)
        assertEquals(2, restored?.version) // Restored to v1 creating version 2
    }

    // 7. Admin Workflow: DRAFT -> VERIFIED -> PUBLISHED -> REJECTED
    @Test
    fun test07_AdminWorkflowStatuses() = runBlocking {
        val kirtanDao = database.kirtanDao()

        // 1. DRAFT initially
        val kirtan = repository.createKirtanFromPrompt("মা দুর্গার মহাশক্তি সংকীর্তন", "AdminTester")
        assertEquals("DRAFT", kirtan.verificationStatus)

        // 2. VERIFIED
        val report = repository.verifyKirtan(kirtan.id, "AdminTester")
        assertTrue(report.isValid)
        var current = kirtanDao.getKirtanById(kirtan.id)
        assertEquals("VERIFIED", current?.verificationStatus)

        // 3. PUBLISHED
        val pubSuccess = repository.publishKirtan(kirtan.id, "AdminTester")
        assertTrue("Publish must succeed", pubSuccess)
        current = kirtanDao.getKirtanById(kirtan.id)
        assertEquals("PUBLISHED", current?.verificationStatus)
        assertNotNull(current?.publishedAt)

        // 4. REJECTED
        val rejSuccess = repository.rejectKirtan(kirtan.id, "Defective meter", "AdminTester")
        assertTrue("Reject must succeed", rejSuccess)
        current = kirtanDao.getKirtanById(kirtan.id)
        assertEquals("REJECTED", current?.verificationStatus)
    }

    // 8. API Gateway Real Verification
    @Test
    fun test08_ApiGatewayEndpointsAndKirtanScope() = runBlocking {
        // Test 8a: Generate via API
        val genReq = ApiGatewayRequest(
            apiKey = testApiKeyWithKirtan,
            endpoint = "/api/v1/kirtan/generate",
            method = "POST",
            body = """{"prompt": "শ্রীকৃষ্ণের মধুর বংশীধ্বনি কীর্তন", "language": "Bengali"}"""
        )
        val genRes = apiGateway.executeRequest(genReq)
        assertEquals(200, genRes.statusCode)
        assertTrue("Response must contain generated kirtan title", genRes.jsonBody.contains("title"))
        assertTrue("Response must indicate DRAFT status", genRes.jsonBody.contains("DRAFT"))

        // Extract Kirtan ID
        val createdId = genRes.jsonBody.substringAfter("\"id\": \"").substringBefore("\"")
        assertTrue("Created ID must be valid string", createdId.isNotBlank())

        // Test 8b: Search via API
        val searchReq = ApiGatewayRequest(
            apiKey = testApiKeyWithKirtan,
            endpoint = "/api/v1/kirtan/search?query=শ্রীকৃষ্ণ",
            method = "GET"
        )
        val searchRes = apiGateway.executeRequest(searchReq)
        assertEquals(200, searchRes.statusCode)
        assertTrue("Search must find total_found", searchRes.jsonBody.contains("total_found"))

        // Test 8c: Verify via API
        val verifyReq = ApiGatewayRequest(
            apiKey = testApiKeyWithKirtan,
            endpoint = "/api/v1/kirtan/verify",
            method = "POST",
            body = """{"kirtan_id": "$createdId"}"""
        )
        val verifyRes = apiGateway.executeRequest(verifyReq)
        assertEquals(200, verifyRes.statusCode)
        assertTrue("Verify response must contain is_valid: true", verifyRes.jsonBody.contains("\"is_valid\": true"))

        // Test 8d: Publish via API
        val pubReq = ApiGatewayRequest(
            apiKey = testApiKeyWithKirtan,
            endpoint = "/api/v1/kirtan/publish",
            method = "POST",
            body = """{"kirtan_id": "$createdId"}"""
        )
        val pubRes = apiGateway.executeRequest(pubReq)
        assertEquals(200, pubRes.statusCode)
        assertTrue("Publish response must contain PUBLISHED", pubRes.jsonBody.contains("PUBLISHED"))

        // Test 8e: Variation via API
        val varReq = ApiGatewayRequest(
            apiKey = testApiKeyWithKirtan,
            endpoint = "/api/v1/kirtan/variation",
            method = "POST",
            body = """{"base_id": "$createdId", "instruction": "দ্রুত লয় ও আনন্দ ভাব"}"""
        )
        val varRes = apiGateway.executeRequest(varReq)
        assertEquals(200, varRes.statusCode)
        assertTrue("Variation must contain रूपভেদ or রূপভেদ", varRes.jsonBody.contains("রূপভেদ"))

        // Test 8f: Scope Enforcement (Missing KIRTAN scope returns 403)
        val unauthorizedReq = ApiGatewayRequest(
            apiKey = testApiKeyWithoutKirtan,
            endpoint = "/api/v1/kirtan/generate",
            method = "POST",
            body = """{"prompt": "unauthorized attempt"}"""
        )
        val unauthorizedRes = apiGateway.executeRequest(unauthorizedReq)
        assertEquals(403, unauthorizedRes.statusCode)
        assertTrue("Must reject with INSUFFICIENT_SCOPE", unauthorizedRes.jsonBody.contains("INSUFFICIENT_SCOPE"))
    }

    // 9. Multilingual Generation (Bengali, Sanskrit, Hindi, English)
    @Test
    fun test09_MultilingualGeneration() {
        val languages = listOf("Bengali", "Sanskrit", "Hindi", "English")

        for (lang in languages) {
            val prompt = "Compose a $lang Kirtan for Lord Krishna"
            val intent = KirtanEngine.parseNaturalPrompt(prompt).copy(language = lang)
            val kirtan = KirtanEngine.generateOriginalKirtan(intent, prompt, emptyList())

            assertEquals(lang, kirtan.language)
            assertTrue("Chorus must not be blank in $lang", kirtan.chorus.isNotBlank())
            assertTrue("Verses must not be blank in $lang", kirtan.verses.isNotBlank())
            assertTrue("Prayer must not be blank in $lang", kirtan.closingPrayer.isNotBlank())
        }
    }

    // 10. Existing System Regression Check
    @Test
    fun test10_ExistingSystemRegression() = runBlocking {
        // Status Endpoint Check
        val statusReq = ApiGatewayRequest(
            apiKey = testApiKeyWithKirtan,
            endpoint = "/api/v1/status",
            method = "GET"
        )
        val statusRes = apiGateway.executeRequest(statusReq)
        assertEquals(200, statusRes.statusCode)
        assertTrue(statusRes.jsonBody.contains("OPERATIONAL"))

        // Mantra Search Endpoint Check
        val mantraReq = ApiGatewayRequest(
            apiKey = testApiKeyWithKirtan,
            endpoint = "/api/v1/mantra/search?query=গায়ত্রী",
            method = "GET"
        )
        val mantraRes = apiGateway.executeRequest(mantraReq)
        assertEquals(200, mantraRes.statusCode)

        // Scripture Search Endpoint Check
        val scriptureReq = ApiGatewayRequest(
            apiKey = testApiKeyWithKirtan,
            endpoint = "/api/v1/scripture/search?query=গীতা",
            method = "GET"
        )
        val scriptureRes = apiGateway.executeRequest(scriptureReq)
        assertEquals(200, scriptureRes.statusCode)
    }

    // 11. Fake Data Policy Check
    @Test
    fun test11_FakeDataPolicyCheck() = runBlocking {
        val kirtanDao = database.kirtanDao()

        val kirtan = repository.createKirtanFromPrompt("শ্রীহরির নামকীর্তন", "AdminTester")
        // Check that counts reflect database realities
        val initialCount = kirtanDao.getTotalKirtansCount()
        assertTrue("Count must match real DB count", initialCount >= 1)

        // Ensure zero mock statuses
        val allK = kirtanDao.searchKirtans("")
        for (k in allK) {
            assertTrue(
                "Status must be real enum status",
                k.verificationStatus in listOf("DRAFT", "VERIFIED", "PUBLISHED", "REJECTED")
            )
            assertTrue("Source must be canonical AI creation or verified", k.sourceType.isNotBlank())
        }
    }
}
