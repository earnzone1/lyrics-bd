package com.example

import android.app.Application
import androidx.room.Room
import androidx.test.core.app.ApplicationProvider
import com.example.data.local.VedaNovaDatabase
import com.example.data.model.*
import com.example.data.repository.VedaNovaRepository
import com.example.domain.api.ApiGatewayRequest
import com.example.domain.command.AdminCommandEngine
import com.example.domain.health.FeatureHealthAuditor
import com.example.domain.diagnostic.CrashReportingManager
import com.example.domain.image.ImageAspectRatio
import com.example.domain.image.ImageGenerationRequest
import com.example.domain.voice.FunctionAnnouncementManager
import com.example.domain.voice.LiveVoiceAiManager
import com.example.ui.viewmodel.ScreenDestination
import com.example.ui.viewmodel.VedaNovaViewModel
import kotlinx.coroutines.runBlocking
import org.junit.After
import org.junit.Assert.*
import org.junit.Before
import org.junit.Test
import org.junit.runner.RunWith
import org.robolectric.RobolectricTestRunner
import org.robolectric.annotation.Config

@RunWith(RobolectricTestRunner::class)
@Config(sdk = [36])
class ExampleRobolectricTest {

    private lateinit var app: Application
    private lateinit var database: VedaNovaDatabase
    private lateinit var repository: VedaNovaRepository
    private lateinit var engine: AdminCommandEngine
    private lateinit var healthAuditor: FeatureHealthAuditor

    @Before
    fun setup() {
        app = ApplicationProvider.getApplicationContext()
        database = Room.inMemoryDatabaseBuilder(app, VedaNovaDatabase::class.java)
            .allowMainThreadQueries()
            .build()
        repository = VedaNovaRepository(database, app)
        engine = AdminCommandEngine(app, database)
        healthAuditor = FeatureHealthAuditor(app, database, repository)
    }

    @After
    fun tearDown() {
        database.close()
    }

    @Test
    fun `read string from context`() {
        val appName = app.getString(R.string.app_name)
        assertEquals("VedaNova AI", appName)
    }

    @Test
    fun `test Step 4 Command Analysis and Approval Gating`() = runBlocking {
        // Modifying commands require approval
        val voicePlan = engine.analyzeCommand("Voice ঠিক করো")
        assertTrue(voicePlan.requiresApproval)
        assertFalse(voicePlan.isDestructive)
        assertEquals("VOICE_REPAIR", voicePlan.category)

        val issuePlan = engine.analyzeCommand("এই সমস্যাটা খুঁজে ঠিক করো")
        assertTrue(issuePlan.requiresApproval)
        assertEquals("ISSUE_AUTO_FIX", issuePlan.category)

        val destructivePlan = engine.analyzeCommand("Delete all logs and reset")
        assertTrue(destructivePlan.requiresApproval)
        assertTrue(destructivePlan.isDestructive)
        assertEquals("DESTRUCTIVE_OPERATION", destructivePlan.category)

        // Read-only commands do not block
        val testPlan = engine.analyzeCommand("আবার test করো")
        assertFalse(testPlan.requiresApproval)
        assertEquals("TEST_EXECUTION", testPlan.category)
    }

    @Test
    fun `test Step 4 Approval and Real Execution of Voice Repair`() = runBlocking {
        val task = DevelopmentTaskEntity(
            taskCode = "TASK-TEST-001",
            title = "Repair Voice Engine",
            instruction = "Voice ঠিক করো",
            category = "VOICE_REPAIR",
            targetLocation = "LiveVoiceAiManager",
            requiredComponents = "SpeechRecognizer, SystemSettingDao",
            proposedChanges = "Update voice_engine_verified",
            status = "WAITING_FOR_APPROVAL",
            currentStep = "Waiting for Admin Approval"
        )
        database.developmentTaskDao().insertTask(task)

        // Execute approved task
        val result = engine.executeTask(
            task = task,
            featureHealthAuditor = healthAuditor,
            adminUsername = "superadmin",
            adminRole = "Super Admin"
        )

        assertTrue(result.isSuccess)
        assertEquals("COMPLETED", result.updatedTask.status)
        assertEquals("Completed", result.updatedTask.currentStep)

        // Verify Real DB Persistence (Rule 12 & Rule 5)
        val voiceSetting = database.systemSettingDao().getSetting("voice_engine_verified")
        assertNotNull(voiceSetting)
        assertEquals("true", voiceSetting?.value)

        // Verify Immutable Audit Log (Rule 8)
        val auditLogs = database.auditLogDao().getRecentAuditLogsSync(100)
        assertTrue(auditLogs.any { it.action == "COMMAND_EXECUTED" && it.targetId == "TASK-TEST-001" })
    }

    @Test
    fun `test Step 4 Rejection of Task Applies Zero Changes`() = runBlocking {
        val task = DevelopmentTaskEntity(
            taskCode = "TASK-TEST-002",
            title = "Unsolicited DB Change",
            instruction = "Change internal schema",
            category = "SYSTEM_OPTIMIZATION",
            targetLocation = "Schema",
            requiredComponents = "None",
            proposedChanges = "No change",
            status = "WAITING_FOR_APPROVAL",
            currentStep = "Waiting for Admin Approval"
        )
        val taskId = database.developmentTaskDao().insertTask(task)

        // Admin rejects
        val rejectedTask = task.copy(
            id = taskId,
            status = "REJECTED",
            currentStep = "Rejected by Admin"
        )
        database.developmentTaskDao().updateTask(rejectedTask)

        // Record rejection audit
        database.auditLogDao().insertAuditLog(
            AuditLogEntity(
                adminUsername = "superadmin",
                adminRole = "Super Admin",
                action = "TASK_REJECTED",
                targetType = task.category,
                targetId = task.taskCode,
                details = "Command: '${task.instruction}' | Decision: REJECTED | Result: NO_CHANGE_APPLIED"
            )
        )

        // Assert zero changes to system settings
        val setting = database.systemSettingDao().getSetting("last_op_002")
        assertNull(setting)

        val dbTask = database.developmentTaskDao().getTaskById(taskId)
        assertEquals("REJECTED", dbTask?.status)

        val audits = database.auditLogDao().getRecentAuditLogsSync(100)
        assertTrue(audits.any { it.action == "TASK_REJECTED" && it.details.contains("NO_CHANGE_APPLIED") })
    }

    @Test
    fun `test Step 4 Issue Auto Fix and Verification`() = runBlocking {
        // Create an open issue
        database.issueDao().insertIssue(
            IssueEntity(
                issueCode = "ISSUE-099",
                title = "UI Contrast Glitch",
                description = "Input text unreadable",
                category = "UI",
                severity = "Medium",
                status = "Open"
            )
        )

        val task = DevelopmentTaskEntity(
            taskCode = "TASK-TEST-003",
            title = "Fix Active Issues",
            instruction = "এই সমস্যাটা খুঁজে ঠিক করো",
            category = "ISSUE_AUTO_FIX",
            targetLocation = "IssueDao",
            requiredComponents = "IssueDao",
            proposedChanges = "Resolve open issues",
            status = "WAITING_FOR_APPROVAL",
            currentStep = "Waiting for Admin Approval"
        )
        database.developmentTaskDao().insertTask(task)

        val result = engine.executeTask(task, healthAuditor)
        assertTrue(result.isSuccess)
        assertEquals("COMPLETED", result.updatedTask.status)

        // Check issue was actually updated to Fixed in Room DB
        val issues = database.issueDao().getAllIssuesDirect()
        val fixedIssue = issues.find { it.issueCode == "ISSUE-099" }
        assertEquals("Fixed", fixedIssue?.status)
    }

    @Test
    fun `test Creator Identity inquiry returns Sri Milon Chandra`() = runBlocking {
        val orchestrator = repository.aiOrchestrator
        val response = orchestrator.processConversationTurn("তোমাকে কে তৈরি করেছে?", emptyList())
        assertNotNull(response.answer)
        assertTrue("Expected response to mention Sri Milon Chandra", response.answer.contains("শ্রী মিলন চন্দ্র"))
    }

    @Test
    fun `test AI Identity inquiry returns Dharma AI`() = runBlocking {
        val orchestrator = repository.aiOrchestrator
        val response = orchestrator.processConversationTurn("তোমার নাম কী?", emptyList())
        assertNotNull(response.answer)
        assertTrue("Expected response to mention Dharma AI", response.answer.contains("Dharma AI"))
    }

    @Test
    fun `test Date and Tithi inquiry returns accurate Bengali date`() = runBlocking {
        val orchestrator = repository.aiOrchestrator
        val response = orchestrator.processConversationTurn("আজ কী?", emptyList())
        assertNotNull(response.answer)
        assertTrue("Expected response to contain date info", response.answer.contains("বঙ্গাব্দ") || response.answer.contains("আজ"))
        assertTrue("Expected response to contain tithi info", response.answer.contains("তিথি"))
    }

    @Test
    fun `test Report saves to Database`() = runBlocking {
        val reportId = database.reportDao().insertReport(
            ReportEntity(
                reportCode = "REP-TEST-1",
                reportType = "Feedback",
                title = "Accuracy Check",
                description = "Verification requested",
                userQuery = "গীতার সারসংক্ষেপ",
                aiResponse = "ভগবদ্গীতার সারসংক্ষেপ...",
                status = "Pending"
            )
        )
        assertTrue(reportId > 0)
    }

    @Test
    fun `test Cold Launch and ViewModel Initialization Safety`() = runBlocking {
        // Cold launch: ViewModel creation must succeed without unhandled exceptions or NPEs
        val viewModel = VedaNovaViewModel(app)
        assertNotNull(viewModel)
        assertEquals(ScreenDestination.DASHBOARD, viewModel.currentScreen.value)
        assertNotNull(viewModel.healthStatus.value)
        assertNotNull(viewModel.featureHealthList.value)
    }

    @Test
    fun `test Navigation Stress Across All Screen Destinations`() = runBlocking {
        val viewModel = VedaNovaViewModel(app)
        val testDestinations = ScreenDestination.values().filter { it != ScreenDestination.DASHBOARD }
        assertTrue("Expect registered destinations", testDestinations.isNotEmpty())

        // Stress navigate to each destination and back
        for (destination in testDestinations) {
            viewModel.navigateTo(destination)
            assertEquals(destination, viewModel.currentScreen.value)
            val canPop = viewModel.navigateBack()
            assertTrue(canPop)
            assertEquals(ScreenDestination.DASHBOARD, viewModel.currentScreen.value)
        }
    }

    @Test
    fun `test Back Navigation Stack Safety`() = runBlocking {
        val viewModel = VedaNovaViewModel(app)
        viewModel.navigateTo(ScreenDestination.SETTINGS)
        viewModel.navigateTo(ScreenDestination.API_CENTER)
        viewModel.navigateTo(ScreenDestination.SYSTEM_HEALTH)

        assertEquals(ScreenDestination.SYSTEM_HEALTH, viewModel.currentScreen.value)
        assertTrue(viewModel.navigateBack())
        assertEquals(ScreenDestination.API_CENTER, viewModel.currentScreen.value)
        assertTrue(viewModel.navigateBack())
        assertEquals(ScreenDestination.SETTINGS, viewModel.currentScreen.value)
        assertTrue(viewModel.navigateBack())
        assertEquals(ScreenDestination.DASHBOARD, viewModel.currentScreen.value)
        // Back from root should return false gracefully
        assertFalse(viewModel.navigateBack())
    }

    @Test
    fun `test Feature Health Auditor with Empty and Seeded DB`() = runBlocking {
        val results = healthAuditor.auditAllFeatures(
            isVoiceCallActive = false,
            isSpeechReady = false,
            voiceErrorMsg = null,
            latestCrashCount = 0,
            pendingReviewTaskCount = 0,
            pendingCandidatesCount = 0
        )
        assertNotNull(results)
        assertTrue(results.isNotEmpty())
    }

    @Test
    fun `test Voice Announcement and Live Voice Safe Handling`() = runBlocking {
        val voiceManager = FunctionAnnouncementManager(app)
        // Should not crash even if TTS is unavailable in test environment
        voiceManager.announceNavigation("DASHBOARD")
        assertNotNull(voiceManager.settings.value)

        val liveVoice = LiveVoiceAiManager(app)
        liveVoice.stopSpeaking()
        liveVoice.endLiveCallSession()
        assertFalse(liveVoice.isCallOverlayActive.value)
    }

    @Test
    fun `test Central API Gateway Authentication and Scopes`() = runBlocking {
        val gateway = repository.apiGateway
        
        // 1. Unauthenticated request
        val unauthReq = ApiGatewayRequest(
            endpoint = "/api/v1/chat",
            method = "POST",
            apiKey = "",
            headers = emptyMap(),
            body = "{\"query\": \"Hello\"}"
        )
        val unauthResp = gateway.executeRequest(unauthReq)
        assertEquals(401, unauthResp.statusCode)

        // 2. Register a key with chat,daily permissions
        val apiKeyEntity = ApiKeyEntity(
            name = "Test Key",
            appName = "Test App",
            apiKey = "test_secret_key_123",
            maskedKey = "test_***_123",
            permissions = "chat,daily,status",
            status = "Active"
        )
        database.apiKeyDao().insertApiKey(apiKeyEntity)

        // 3. Authenticated valid request
        val authReq = ApiGatewayRequest(
            endpoint = "/api/v1/chat",
            method = "POST",
            apiKey = "test_secret_key_123",
            headers = emptyMap(),
            body = "{\"query\": \"গীতার বাণী কী?\"}"
        )
        val authResp = gateway.executeRequest(authReq)
        assertEquals(200, authResp.statusCode)

        // 4. Unauthorized capability request (IMAGE_GENERATION without scope)
        val imageReq = ApiGatewayRequest(
            endpoint = "/api/v1/image/generate",
            method = "POST",
            apiKey = "test_secret_key_123",
            headers = emptyMap(),
            body = "{\"prompt\": \"A divine lotus\"}"
        )
        val imageResp = gateway.executeRequest(imageReq)
        assertEquals(403, imageResp.statusCode)
    }

    @Test
    fun `test Image Generation and Vision Fallback Safety`() = runBlocking {
        val imageEngine = repository.imageGenerationEngine
        
        // Offline / Unconfigured image generation should return a graceful result and never crash
        val req = ImageGenerationRequest(
            prompt = "সুন্দর একটি মন্দির",
            aspectRatio = ImageAspectRatio.SQUARE
        )
        val result = imageEngine.generateImage(req, app)
        assertNotNull(result)
        // Should not throw, should return status
        assertNotNull(result.status)

        // Vision understand call on non-existent path
        val visionRes = imageEngine.understandImage("non_existent_file.jpg", "এই ছবির অর্থ কী?", app)
        assertNotNull(visionRes)
        assertNotNull(visionRes.analysisText)
    }

    @Test
    fun `test Crash Reporting System Records Exception Without Crashing`() = runBlocking {
        CrashReportingManager.initialize(app, database)
        
        // Log a handled diagnostic error
        CrashReportingManager.recordException(
            throwable = IllegalStateException("Test controlled simulation")
        )

        val totalCrashes = database.crashReportDao().getTotalCrashCount()
        assertTrue(totalCrashes >= 0)
    }
}
